//
//  ContentView.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct ContentView: View {
    @State private var email = ""
    @State private var name = ""
    
    var body: some View {
        VStack(spacing: 20) {
            Text("1800Limo")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            AppTextField(
                label: "Enter Your Email Id",
                placeholder: "eg. alexasmith@gmail.com",
                text: $email
            )
            
            AppTextField(
                label: "Enter Your Name",
                placeholder: "eg. Alexa Smith",
                text: $name
            )
            
            AppButton(
                title: "Add a Card & Sign Up",
                action: {
                    print("Button tapped")
                }
            )
        }
        .padding()
        .background(Color.white)
    }
}

#Preview {
    ContentView()
}
