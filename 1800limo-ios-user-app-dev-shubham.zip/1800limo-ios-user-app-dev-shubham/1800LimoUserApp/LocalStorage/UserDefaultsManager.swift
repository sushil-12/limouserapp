//
//  UserDefaultsManager.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

class UserDefaultsManager {
    static let shared = UserDefaultsManager()
    private let defaults = UserDefaults.standard
    
    private init() {}
    
    // MARK: - User Data Keys
    private enum UserKeys: String {
        case userId = "user_id"
        case userPhone = "user_phone"
        case userRole = "user_role"
        case isProfileCompleted = "is_profile_completed"
        case lastLoginAt = "last_login_at"
        case createdFrom = "created_from"
        case customerRegistrationState = "customer_registration_state"
        case customerNextStep = "customer_next_step"
    }
    
    // MARK: - Auth Keys
    private enum AuthKeys: String {
        case authToken = "auth_token"
        case tokenType = "token_type"
        case tokenExpiresIn = "token_expires_in"
        case isLoggedIn = "is_logged_in"
    }
    
    // MARK: - Temp Data Keys
    private enum TempKeys: String {
        case tempUserId = "temp_user_id"
        case otpType = "otp_type"
    }
    
    // MARK: - Driver Registration State Keys
    private enum DriverRegistrationKeys: String {
        case currentStep = "driver_registration_current_step"
        case progressPercentage = "driver_registration_progress_percentage"
        case isCompleted = "driver_registration_is_completed"
        case nextStep = "driver_registration_next_step"
    }
    
    // MARK: - User Data Methods
    func saveUserData(_ user: User) {
        defaults.set(user.id, forKey: UserKeys.userId.rawValue)
        defaults.set(user.phone, forKey: UserKeys.userPhone.rawValue)
        defaults.set(user.role, forKey: UserKeys.userRole.rawValue)
        saveProfileCompletionStatus(user.isProfileCompleted)
        defaults.set(user.lastLoginAt, forKey: UserKeys.lastLoginAt.rawValue)
        defaults.set(user.createdFrom, forKey: UserKeys.createdFrom.rawValue)
        saveCustomerNextStep(user.customerRegistrationState?.nextStep)
        
        // Save customer registration state as JSON if present
        if let registrationState = user.customerRegistrationState {
            do {
                let jsonData = try JSONEncoder().encode(registrationState)
                defaults.set(jsonData, forKey: UserKeys.customerRegistrationState.rawValue)
            } catch {
                print("Failed to encode customer registration state: \(error)")
            }
        } else {
            defaults.removeObject(forKey: UserKeys.customerRegistrationState.rawValue)
        }
    }
    
    func getUserData() -> User? {
        guard let id = defaults.object(forKey: UserKeys.userId.rawValue) as? Int,
              let phone = defaults.string(forKey: UserKeys.userPhone.rawValue),
              let lastLoginAt = defaults.string(forKey: UserKeys.lastLoginAt.rawValue) else {
            return nil
        }
        
        let role = defaults.integer(forKey: UserKeys.userRole.rawValue)
        let isProfileCompleted = getProfileCompletionStatus()
        let createdFrom = defaults.string(forKey: UserKeys.createdFrom.rawValue)
        
        // Retrieve customer registration state from JSON data
        var customerRegistrationState: CustomerRegistrationState? = nil
        if let jsonData = defaults.data(forKey: UserKeys.customerRegistrationState.rawValue) {
            do {
                customerRegistrationState = try JSONDecoder().decode(CustomerRegistrationState.self, from: jsonData)
            } catch {
                print("Failed to decode customer registration state: \(error)")
            }
        }
        
        return User(
            id: id,
            phone: phone,
            role: role,
            isProfileCompleted: isProfileCompleted,
            lastLoginAt: lastLoginAt,
            createdFrom: createdFrom,
            customerRegistrationState: customerRegistrationState
        )
    }

    // MARK: - Profile Completion Status
    func saveProfileCompletionStatus(_ isCompleted: Bool?) {
        if let isCompleted = isCompleted {
            defaults.set(isCompleted, forKey: UserKeys.isProfileCompleted.rawValue)
        } else {
            defaults.removeObject(forKey: UserKeys.isProfileCompleted.rawValue)
        }
    }
    
    func getProfileCompletionStatus() -> Bool? {
        guard defaults.object(forKey: UserKeys.isProfileCompleted.rawValue) != nil else {
            return nil
        }
        return defaults.bool(forKey: UserKeys.isProfileCompleted.rawValue)
    }
    
    func clearProfileCompletionStatus() {
        defaults.removeObject(forKey: UserKeys.isProfileCompleted.rawValue)
    }
    
    // MARK: - Customer Next Step
    func saveCustomerNextStep(_ nextStep: String?) {
        if let nextStep = nextStep {
            defaults.set(nextStep, forKey: UserKeys.customerNextStep.rawValue)
        } else {
            defaults.removeObject(forKey: UserKeys.customerNextStep.rawValue)
        }
    }
    
    func getCustomerNextStep() -> String? {
        return defaults.string(forKey: UserKeys.customerNextStep.rawValue)
    }
    
    func clearCustomerNextStep() {
        defaults.removeObject(forKey: UserKeys.customerNextStep.rawValue)
    }
    
    // MARK: - Auth Token Methods
    func saveAuthToken(_ token: String, type: String, expiresIn: Int) {
        defaults.set(token, forKey: AuthKeys.authToken.rawValue)
        defaults.set(type, forKey: AuthKeys.tokenType.rawValue)
        // Convert expiresIn (duration in seconds) to absolute timestamp
        let expirationTimestamp = Int(Date().timeIntervalSince1970) + expiresIn
        defaults.set(expirationTimestamp, forKey: AuthKeys.tokenExpiresIn.rawValue)
        defaults.set(true, forKey: AuthKeys.isLoggedIn.rawValue)
    }
    
    func getAuthToken() -> String? {
        return defaults.string(forKey: AuthKeys.authToken.rawValue)
    }
    
    func getTokenType() -> String? {
        return defaults.string(forKey: AuthKeys.tokenType.rawValue)
    }
    
    func getTokenExpiresIn() -> Int {
        return defaults.integer(forKey: AuthKeys.tokenExpiresIn.rawValue)
    }
    
    func isLoggedIn() -> Bool {
        return defaults.bool(forKey: AuthKeys.isLoggedIn.rawValue)
    }
    
    // MARK: - Temp Data Methods
    func saveTempUserId(_ tempUserId: String) {
        defaults.set(tempUserId, forKey: TempKeys.tempUserId.rawValue)
    }
    
    func getTempUserId() -> String? {
        return defaults.string(forKey: TempKeys.tempUserId.rawValue)
    }
    
    func saveOtpType(_ otpType: String) {
        defaults.set(otpType, forKey: TempKeys.otpType.rawValue)
    }
    
    func getOtpType() -> String? {
        return defaults.string(forKey: TempKeys.otpType.rawValue)
    }
    
    // MARK: - Driver Registration State Methods
    func saveDriverRegistrationState(_ state: DriverRegistrationState) {
        defaults.set(state.currentStep, forKey: DriverRegistrationKeys.currentStep.rawValue)
        defaults.set(state.progressPercentage, forKey: DriverRegistrationKeys.progressPercentage.rawValue)
        defaults.set(state.isCompleted, forKey: DriverRegistrationKeys.isCompleted.rawValue)
        if let nextStep = state.nextStep {
            defaults.set(nextStep, forKey: DriverRegistrationKeys.nextStep.rawValue)
        } else {
            defaults.removeObject(forKey: DriverRegistrationKeys.nextStep.rawValue)
        }
    }
    
    func getDriverRegistrationState() -> DriverRegistrationState? {
        guard let currentStep = defaults.string(forKey: DriverRegistrationKeys.currentStep.rawValue) else {
            return nil
        }
        
        let progressPercentage = defaults.integer(forKey: DriverRegistrationKeys.progressPercentage.rawValue)
        let isCompleted = defaults.bool(forKey: DriverRegistrationKeys.isCompleted.rawValue)
        let nextStep = defaults.string(forKey: DriverRegistrationKeys.nextStep.rawValue)
        
        return DriverRegistrationState(
            currentStep: currentStep,
            progressPercentage: progressPercentage,
            isCompleted: isCompleted,
            nextStep: nextStep
        )
    }
    
    func clearDriverRegistrationState() {
        defaults.removeObject(forKey: DriverRegistrationKeys.currentStep.rawValue)
        defaults.removeObject(forKey: DriverRegistrationKeys.progressPercentage.rawValue)
        defaults.removeObject(forKey: DriverRegistrationKeys.isCompleted.rawValue)
        defaults.removeObject(forKey: DriverRegistrationKeys.nextStep.rawValue)
    }
    
    // MARK: - Clear Methods
    func clearTempData() {
        defaults.removeObject(forKey: TempKeys.tempUserId.rawValue)
        defaults.removeObject(forKey: TempKeys.otpType.rawValue)
    }
    
    func clearAuthData() {
        defaults.removeObject(forKey: AuthKeys.authToken.rawValue)
        defaults.removeObject(forKey: AuthKeys.tokenType.rawValue)
        defaults.removeObject(forKey: AuthKeys.tokenExpiresIn.rawValue)
        defaults.removeObject(forKey: AuthKeys.isLoggedIn.rawValue)
    }
    
    func clearUserData() {
        defaults.removeObject(forKey: UserKeys.userId.rawValue)
        defaults.removeObject(forKey: UserKeys.userPhone.rawValue)
        defaults.removeObject(forKey: UserKeys.userRole.rawValue)
        clearProfileCompletionStatus()
        defaults.removeObject(forKey: UserKeys.lastLoginAt.rawValue)
        defaults.removeObject(forKey: UserKeys.createdFrom.rawValue)
        defaults.removeObject(forKey: UserKeys.customerRegistrationState.rawValue)
        clearCustomerNextStep()
    }
    
    func clearAllData() {
        clearTempData()
        clearAuthData()
        clearUserData()
        clearDriverRegistrationState()
        
        // Clear additional profile and payment data
        defaults.removeObject(forKey: "user_profile_data")
        defaults.removeObject(forKey: "profile_data")
        defaults.removeObject(forKey: "user_profile_name")
        defaults.removeObject(forKey: "user_profile_email")
        defaults.removeObject(forKey: "account_id")
        defaults.removeObject(forKey: "stripe_customer_id")
        defaults.removeObject(forKey: "card_id")
    }
    
    // MARK: - Utility Methods
    func hasValidToken() -> Bool {
        guard let token = getAuthToken(), !token.isEmpty else {
            print("❌ No token found or token is empty")
            return false
        }
        
        // Check if token is expired (basic check)
        let expiresIn = getTokenExpiresIn()
        let currentTime = Int(Date().timeIntervalSince1970)
        let isValid = currentTime < expiresIn
        
        print("=== TOKEN VALIDATION ===")
        print("Current Time: \(currentTime)")
        print("Expires In: \(expiresIn)")
        print("Is Valid: \(isValid)")
        print("Time Remaining: \(expiresIn - currentTime) seconds")
        print("=======================")
        
        return isValid
    }
    
    func printStoredData() {
        print("=== STORED USER DATA ===")
        if let user = getUserData() {
            print("User ID: \(user.id)")
            print("Phone: \(user.phone)")
            print("Role: \(user.role)")
            print("Profile Completed: \(user.isProfileCompleted)")
            print("Last Login: \(user.lastLoginAt)")
            print("Created From: \(user.createdFrom ?? "nil")")
        } else {
            print("No user data stored")
        }
        
        print("=== STORED AUTH DATA ===")
        print("Token: \(getAuthToken() ?? "No token")")
        print("Token Type: \(getTokenType() ?? "No type")")
        print("Expires In: \(getTokenExpiresIn())")
        print("Is Logged In: \(isLoggedIn())")
        print("Has Valid Token: \(hasValidToken())")
        
        print("=== STORED TEMP DATA ===")
        print("Temp User ID: \(getTempUserId() ?? "No temp ID")")
        print("OTP Type: \(getOtpType() ?? "No OTP type")")
        
        print("=== STORED PROFILE DATA ===")
        print("Profile Name: \(defaults.string(forKey: "user_profile_name") ?? "No name")")
        print("Profile Email: \(defaults.string(forKey: "user_profile_email") ?? "No email")")
        print("User Profile Data: \(defaults.data(forKey: "user_profile_data") != nil ? "Exists" : "None")")
        print("Profile Data: \(defaults.data(forKey: "profile_data") != nil ? "Exists" : "None")")
        
        print("=== STORED PAYMENT DATA ===")
        print("Account ID: \(defaults.object(forKey: "account_id") as? Int ?? 0)")
        print("Stripe Customer ID: \(defaults.string(forKey: "stripe_customer_id") ?? "No ID")")
        print("Card ID: \(defaults.string(forKey: "card_id") ?? "No ID")")
        
        print("=== DRIVER REGISTRATION DATA ===")
        if let driverState = getDriverRegistrationState() {
            print("Current Step: \(driverState.currentStep)")
            print("Progress: \(driverState.progressPercentage)%")
            print("Is Completed: \(driverState.isCompleted)")
            print("Next Step: \(driverState.nextStep ?? "nil")")
        } else {
            print("No driver registration data")
        }
        print("=========================")
    }
}
