//
//  KeychainManager.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation
import Security

class KeychainManager {
    static let shared = KeychainManager()
    private init() {}
    
    // MARK: - Keychain Keys
    private enum KeychainKeys: String {
        case authToken = "auth_token"
        case refreshToken = "refresh_token"
    }
    
    // MARK: - Save Data
    func save(_ data: Data, forKey key: String) -> Bool {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        
        // Delete existing item first
        SecItemDelete(query as CFDictionary)
        
        // Add new item
        let status = SecItemAdd(query as CFDictionary, nil)
        return status == errSecSuccess
    }
    
    func save(_ string: String, forKey key: String) -> Bool {
        guard let data = string.data(using: .utf8) else { return false }
        return save(data, forKey: key)
    }
    
    // MARK: - Retrieve Data
    func retrieve(forKey key: String) -> Data? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        
        return (result as? Data)
    }
    
    func retrieveString(forKey key: String) -> String? {
        guard let data = retrieve(forKey: key) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    
    // MARK: - Delete Data
    func delete(forKey key: String) -> Bool {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key
        ]
        
        let status = SecItemDelete(query as CFDictionary)
        return status == errSecSuccess || status == errSecItemNotFound
    }
    
    // MARK: - Token Management
    func saveAuthToken(_ token: String) -> Bool {
        return save(token, forKey: KeychainKeys.authToken.rawValue)
    }
    
    func getAuthToken() -> String? {
        return retrieveString(forKey: KeychainKeys.authToken.rawValue)
    }
    
    func deleteAuthToken() -> Bool {
        return delete(forKey: KeychainKeys.authToken.rawValue)
    }
    
    func saveRefreshToken(_ token: String) -> Bool {
        return save(token, forKey: KeychainKeys.refreshToken.rawValue)
    }
    
    func getRefreshToken() -> String? {
        return retrieveString(forKey: KeychainKeys.refreshToken.rawValue)
    }
    
    func deleteRefreshToken() -> Bool {
        return delete(forKey: KeychainKeys.refreshToken.rawValue)
    }
    
    // MARK: - Clear All
    func clearAllTokens() {
        deleteAuthToken()
        deleteRefreshToken()
    }
    
    // MARK: - Utility
    func hasValidToken() -> Bool {
        return getAuthToken() != nil
    }
    
    func printKeychainData() {
        print("=== KEYCHAIN DATA ===")
        print("Auth Token: \(getAuthToken() ?? "No token")")
        print("Refresh Token: \(getRefreshToken() ?? "No refresh token")")
        print("Has Valid Token: \(hasValidToken())")
        print("=====================")
    }
}








