//
//  StorageManager.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

class StorageManager {
    static let shared = StorageManager()
    private let userDefaults = UserDefaultsManager.shared
    private let keychain = KeychainManager.shared
    
    private init() {}
    
    // MARK: - User Data Management
    func saveUserData(_ user: User) {
        userDefaults.saveUserData(user)
    }
    
    func getUserData() -> User? {
        return userDefaults.getUserData()
    }
    
    // MARK: - User Profile Data Management
    func saveUserProfileData(_ profileData: UserProfileData) {
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(profileData)
            UserDefaults.standard.set(data, forKey: "user_profile_data")
        } catch {
        }
    }
    
    func getUserProfileData() -> UserProfileData? {
        guard let data = UserDefaults.standard.data(forKey: "user_profile_data") else {
            return nil
        }
        
        do {
            let decoder = JSONDecoder()
            let profileData = try decoder.decode(UserProfileData.self, from: data)
            return profileData
        } catch {
            return nil
        }
    }
    
    func saveUserProfile(name: String, email: String) {
        UserDefaults.standard.set(name, forKey: "user_profile_name")
        UserDefaults.standard.set(email, forKey: "user_profile_email")
    }
    
    func getUserProfile() -> (name: String, email: String)? {
        guard let name = UserDefaults.standard.string(forKey: "user_profile_name"),
              let email = UserDefaults.standard.string(forKey: "user_profile_email") else {
            return nil
        }
        return (name: name, email: email)
    }
    
    func getUserName() -> String? {
        // Try to get from profile data first
        if let profileData = getUserProfileData() {
            return profileData.fullName
        }
        // Fallback to old method
        return UserDefaults.standard.string(forKey: "user_profile_name")
    }
    
    func getUserEmail() -> String? {
        // Try to get from profile data first
        if let profileData = getUserProfileData() {
            return profileData.email
        }
        // Fallback to old method
        return UserDefaults.standard.string(forKey: "user_profile_email")
    }
    
    func getUserMobile() -> String? {
        if let profileData = getUserProfileData() {
            return profileData.fullMobileNumber
        }
        return nil
    }
    
    func getUserAddress() -> String? {
        if let profileData = getUserProfileData() {
            return profileData.fullAddress
        }
        return nil
    }
    
    // MARK: - Profile Data Management (New API)
    func saveProfileData(_ profileData: ProfileData) {
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(profileData)
            UserDefaults.standard.set(data, forKey: "profile_data")
        } catch {
        }
    }
    
    func getProfileData() -> ProfileData? {
        guard let data = UserDefaults.standard.data(forKey: "profile_data") else {
            return nil
        }
        
        do {
            let decoder = JSONDecoder()
            let profileData = try decoder.decode(ProfileData.self, from: data)
            return profileData
        } catch {
            return nil
        }
    }
    
    // MARK: - Auth Token Management (Secure)
    func saveAuthToken(_ token: String, type: String, expiresIn: Int) {
        // Save token securely in Keychain
        let tokenSaved = keychain.saveAuthToken(token)
        
        // Save other auth data in UserDefaults
        userDefaults.saveAuthToken(token, type: type, expiresIn: expiresIn)
        
    }
    
    func getAuthToken() -> String? {
        // Try Keychain first (more secure)
        if let keychainToken = keychain.getAuthToken() {
            return keychainToken
        }
        
        // Fallback to UserDefaults
        return userDefaults.getAuthToken()
    }
    
    func isLoggedIn() -> Bool {
        return userDefaults.isLoggedIn() && hasValidToken()
    }
    
    func hasValidToken() -> Bool {
        return keychain.hasValidToken() || userDefaults.hasValidToken()
    }
    
    // MARK: - Temp Data Management
    func saveTempUserId(_ tempUserId: String) {
        userDefaults.saveTempUserId(tempUserId)
    }
    
    func getTempUserId() -> String? {
        return userDefaults.getTempUserId()
    }
    
    func saveOtpType(_ otpType: String) {
        userDefaults.saveOtpType(otpType)
    }
    
    func getOtpType() -> String? {
        return userDefaults.getOtpType()
    }
    
    // MARK: - Driver Registration State Management
    func saveDriverRegistrationState(_ state: DriverRegistrationState) {
        userDefaults.saveDriverRegistrationState(state)
    }
    
    func getDriverRegistrationState() -> DriverRegistrationState? {
        return userDefaults.getDriverRegistrationState()
    }
    
    func clearDriverRegistrationState() {
        userDefaults.clearDriverRegistrationState()
    }
    
    // MARK: - Complete Auth Flow Storage
    func saveLoginData(_ response: VerifyOTPResponse) {
        // Save user data
        saveUserData(response.data.user)
        
        // Persist profile completion status and next step
        setProfileCompletionStatus(response.data.user.isProfileCompleted)
        let resolvedNextStep = response.data.user.customerRegistrationState?.nextStep
            ?? (response.data.action.isEmpty ? nil : response.data.action)
        saveCustomerNextStep(resolvedNextStep)
        
        // Save auth token securely
        saveAuthToken(
            response.data.token,
            type: response.data.tokenType,
            expiresIn: response.data.expiresIn
        )
        
        // Save driver registration state if available
        if let driverRegistrationState = response.data.driverRegistrationState {
            saveDriverRegistrationState(driverRegistrationState)
        }
        
        // Fetch and save profile data (name, email, etc.) if profile is completed
        if response.data.user.isProfileCompleted == true {
            Task {
                await fetchAndSaveProfileData()
            }
        }
        
        // Clear temp data
        clearTempData()
        
    }
    
    // MARK: - Fetch and Save Profile Data
    private func fetchAndSaveProfileData() async {
        do {
            print("📥 [StorageManager] Fetching profile data...")
            
            // Try userProfile endpoint first (registration profile)
            let response: UserProfileResponse = try await NetworkService.shared.request(
                endpoint: .userProfile,
                responseType: UserProfileResponse.self
            )
            
            if response.success {
                // Save complete profile data
                saveUserProfileData(response.data)
                
                // Also save name and email separately for quick access
                let fullName = response.data.fullName
                saveUserProfile(name: fullName, email: response.data.email)
                
                print("✅ [StorageManager] Profile data saved successfully")
                print("   Name: \(fullName)")
                print("   Email: \(response.data.email)")
            } else {
                print("⚠️ [StorageManager] Profile fetch failed: \(response.message)")
            }
        } catch {
            print("❌ [StorageManager] Error fetching profile data: \(error.localizedDescription)")
            
            // Fallback: Try the alternative profile endpoint
            do {
                print("📥 [StorageManager] Trying alternative profile endpoint...")
                let response: ProfileDataResponse = try await NetworkService.shared.request(
                    endpoint: .getProfileData,
                    responseType: ProfileDataResponse.self
                )
                
                if response.success {
                    // Save complete profile data
                    saveProfileData(response.data)
                    
                    // Also save name and email separately for quick access
                    let fullName = "\(response.data.first_name) \(response.data.last_name)".trimmingCharacters(in: .whitespaces)
                    saveUserProfile(name: fullName, email: response.data.email)
                    
                    print("✅ [StorageManager] Profile data saved successfully (alternative endpoint)")
                    print("   Name: \(fullName)")
                    print("   Email: \(response.data.email)")
                } else {
                    print("⚠️ [StorageManager] Alternative profile fetch failed: \(response.message)")
                }
            } catch {
                print("❌ [StorageManager] Error fetching alternative profile data: \(error.localizedDescription)")
            }
        }
    }
    
    func saveTempAuthData(_ response: AuthResponse) {
        // Save temp data for OTP verification
        saveTempUserId(response.data.tempUserId)
        saveOtpType(response.data.otpType)
        
    }

    // MARK: - Customer Registration Progress Helpers
    func saveCustomerNextStep(_ nextStep: String?) {
        userDefaults.saveCustomerNextStep(normalizeOnboardingStep(nextStep))
    }
    
    func getCustomerNextStep() -> String? {
        return userDefaults.getCustomerNextStep()
    }
    
    func getNormalizedCustomerNextStep() -> String? {
        return normalizeOnboardingStep(userDefaults.getCustomerNextStep())
    }
    
    func normalizeCustomerNextStep(_ step: String?) -> String? {
        return normalizeOnboardingStep(step)
    }
    
    func clearCustomerNextStep() {
        userDefaults.clearCustomerNextStep()
    }
    
    func setProfileCompletionStatus(_ isCompleted: Bool?) {
        let preservedNextStep = getNormalizedCustomerNextStep()
        userDefaults.saveProfileCompletionStatus(isCompleted)
        
        if var user = getUserData() {
            let updatedUser = User(
                id: user.id,
                phone: user.phone,
                role: user.role,
                isProfileCompleted: isCompleted,
                lastLoginAt: user.lastLoginAt,
                createdFrom: user.createdFrom,
                customerRegistrationState: user.customerRegistrationState
            )
            saveUserData(updatedUser)
        }
        
        if let preservedNextStep = preservedNextStep {
            saveCustomerNextStep(preservedNextStep)
        } else {
            saveCustomerNextStep(nil)
        }
    }
    
    func getProfileCompletionStatus() -> Bool? {
        return userDefaults.getProfileCompletionStatus()
    }

    // MARK: - Onboarding Step Normalization
    private func normalizeOnboardingStep(_ step: String?) -> String? {
        guard var step = step?.trimmingCharacters(in: .whitespacesAndNewlines),
              !step.isEmpty else {
            return nil
        }
        
        // Replace separators with underscores
        step = step.replacingOccurrences(of: "-", with: "_")
            .replacingOccurrences(of: " ", with: "_")
        
        let lowercased = step.lowercased()
        
        // Handle camelCase or concatenated forms
        let collapsed = lowercased.replacingOccurrences(of: "_", with: "")
        
        if collapsed.contains("basic") && collapsed.contains("detail") {
            return "basic_details"
        }
        
        if collapsed.contains("basic") && collapsed.contains("info") {
            return "basic_info"
        }
        
        if collapsed.contains("credit") && collapsed.contains("card") {
            return "credit_card"
        }
        
        if collapsed.contains("dashboard") {
            return "dashboard"
        }
        
        return lowercased
    }
    
    // MARK: - Clear Methods
    func clearTempData() {
        userDefaults.clearTempData()
    }
    
    func clearAuthData() {
        userDefaults.clearAuthData()
        keychain.clearAllTokens()
    }
    
    func clearUserData() {
        userDefaults.clearUserData()
        
        // Clear profile data
        UserDefaults.standard.removeObject(forKey: "user_profile_name")
        UserDefaults.standard.removeObject(forKey: "user_profile_email")
        UserDefaults.standard.removeObject(forKey: "user_profile_data")
        UserDefaults.standard.removeObject(forKey: "profile_data")
        UserDefaults.standard.removeObject(forKey: "account_id")
        UserDefaults.standard.removeObject(forKey: "stripe_customer_id")
        UserDefaults.standard.removeObject(forKey: "card_id")
        
    }
    
    func clearAllData() {
        userDefaults.clearAllData()
        keychain.clearAllTokens()
    }
    
    // MARK: - Logout
    func logout() {
        print("🔐 [StorageManager] Logging out and clearing all local data (UserDefaults + Keychain)")
        print("🧹 [StorageManager] Before clearAllData() debug dump:")
        printAllStoredData()
        
        // Disconnect Socket.IO before clearing data
        SimpleSocketIOService.shared.disconnectForLogout()
        print("🔌 [StorageManager] Socket.IO disconnected")
        
        // Clear all stored data
        clearAllData()
        print("✅ [StorageManager] clearAllData() completed")
        print("🧾 [StorageManager] After clearAllData() debug dump:")
        printAllStoredData()
    }
    
    // MARK: - Debug Methods
    func printAllStoredData() {
        userDefaults.printStoredData()
        keychain.printKeychainData()
    }
    
    // MARK: - Utility Methods
    func getAuthHeaders() -> [String: String] {
        var headers = APIConfig.defaultHeaders
        
        if let token = getAuthToken() {
            headers["Authorization"] = "Bearer \(token)"
        }
        
        return headers
    }
    
    func shouldCompleteProfile() -> Bool {
        guard let user = getUserData() else { return false }
        return !(user.isProfileCompleted ?? false)
    }
    
    // MARK: - Registration Flow Storage
    func saveAccountId(_ accountId: Int) {
        UserDefaults.standard.set(accountId, forKey: "account_id")
    }
    
    func getAccountId() -> Int? {
        return UserDefaults.standard.object(forKey: "account_id") as? Int
    }
    
    func saveCardDetails(_ cardData: CreditCardData) {
        UserDefaults.standard.set(cardData.stripeCustomerId, forKey: "stripe_customer_id")
        UserDefaults.standard.set(cardData.cardId, forKey: "card_id")
        
        print("Stripe Customer ID: \(cardData.stripeCustomerId)")
        print("Card ID: \(cardData.cardId)")
    }
    
    func updateProfileCompletionStatus(_ isCompleted: Bool) {
        setProfileCompletionStatus(isCompleted)
    }
    
    // MARK: - Firebase and Socket.IO Helper Methods
    func getUserIdString() -> String? {
        guard let user = getUserData() else {
            return nil
        }
        let userIdString = String(user.id)
        return userIdString
    }
    
    func getToken() -> String? {
        return getAuthToken()
    }
    
    // MARK: - Public Profile Data Fetch
    /// Manually fetch and save profile data from the server
    /// Call this after login or when you need to refresh profile data
    func refreshProfileData() async {
        await fetchAndSaveProfileData()
    }
}
