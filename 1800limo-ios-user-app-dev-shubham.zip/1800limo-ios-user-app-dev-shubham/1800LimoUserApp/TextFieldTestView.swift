//
//  TextFieldTestView.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct TextFieldTestView: View {
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    
    var body: some View {
        VStack(spacing: 20) {
            Text("TextField Test")
                .font(.title)
            
            AppTextField(
                label: "Enter Your Name",
                placeholder: "eg. Alexa Smith",
                text: $name,
                onEditingChanged: { isEditing in
                    print("Name editing changed: \(isEditing)")
                },
                onCommit: {
                    print("Name commit")
                }
            )
            
            AppTextField(
                label: "Email Address",
                placeholder: "Enter your email",
                text: $email,
                keyboardType: .emailAddress,
                textContentType: .emailAddress,
                onEditingChanged: { isEditing in
                    print("Email editing changed: \(isEditing)")
                },
                onCommit: {
                    print("Email commit")
                }
            )
            
            AppTextField(
                label: "Password",
                placeholder: "Enter your password",
                text: $password,
                isSecure: true,
                textContentType: .password,
                onEditingChanged: { isEditing in
                    print("Password editing changed: \(isEditing)")
                },
                onCommit: {
                    print("Password commit")
                }
            )
            
            Text("Current values:")
                .font(.headline)
            
            Text("Name: \(name)")
            Text("Email: \(email)")
            Text("Password: \(password)")
        }
        .padding()
    }
}

#Preview {
    TextFieldTestView()
}









