//
//  AppDropdown.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct AppDropdown<T: Hashable>: View {
    let label: String
    let placeholder: String
    let options: [T]
    let optionToString: (T) -> String
    @Binding var selectedOption: T?
    @State private var isExpanded = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Label
            Text(label)
                .appLabel()
                .padding(.leading, 4)
            
            // Dropdown Field
            VStack(alignment: .leading, spacing: 0) {
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isExpanded.toggle()
                    }
                }) {
                    HStack {
                        Text(selectedOption != nil ? optionToString(selectedOption!) : placeholder)
                            .font(.system(size: AppTypography.body, weight: .medium))
                            .foregroundColor(selectedOption != nil ? AppColors.primaryText : AppColors.placeholderText)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(AppColors.secondaryText)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(AppColors.backgroundGray)
                    .cornerRadius(8)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(AppColors.borderGray, lineWidth: 1)
                    )
                }
                .buttonStyle(PlainButtonStyle())
                
                // Dropdown Options
                if isExpanded {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(Array(options.enumerated()), id: \.element) { index, option in
                            Button(action: {
                                selectedOption = option
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    isExpanded = false
                                }
                            }) {
                                Text(optionToString(option))
                                    .font(.system(size: AppTypography.body, weight: .medium))
                                    .foregroundColor(AppColors.primaryText)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 12)
                                    .background(selectedOption == option ? AppColors.primaryOrange.opacity(0.1) : AppColors.white)
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            if index < options.count - 1 {
                                Divider()
                                    .background(AppColors.borderLight)
                                    .padding(.horizontal, 16)
                            }
                        }
                    }
                    .background(AppColors.white)
                    .cornerRadius(8)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(AppColors.borderGray, lineWidth: 1)
                    )
                    .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
        }
        .onTapGesture {
            // Close dropdown when tapping outside
            if isExpanded {
                withAnimation(.easeInOut(duration: 0.2)) {
                    isExpanded = false
                }
            }
        }
    }
}

// Preview
struct AppDropdown_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            AppDropdown(
                label: "Select Vehicle Type",
                placeholder: "Choose a vehicle",
                options: ["Sedan", "SUV", "Luxury", "Van", "Bus"],
                optionToString: { $0 },
                selectedOption: .constant(nil)
            )
            
            AppDropdown(
                label: "Select Payment Method",
                placeholder: "Choose payment method",
                options: ["Credit Card", "Debit Card", "Cash", "Digital Wallet"],
                optionToString: { $0 },
                selectedOption: .constant("Credit Card")
            )
        }
        .padding()
        .background(Color.white)
    }
}









