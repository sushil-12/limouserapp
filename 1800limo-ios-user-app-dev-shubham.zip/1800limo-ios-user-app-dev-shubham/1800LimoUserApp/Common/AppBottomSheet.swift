//
//  AppBottomSheet.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI
import UIKit

struct AppBottomSheet<Content: View>: View {
    let title: String?
    let isPresented: Binding<Bool>
    let content: Content
    let showDragIndicator: Bool
    let dismissOnTapOutside: Bool
    
    init(
        title: String? = nil,
        isPresented: Binding<Bool>,
        showDragIndicator: Bool = true,
        dismissOnTapOutside: Bool = true,
        @ViewBuilder content: () -> Content
    ) {
        self.title = title
        self.isPresented = isPresented
        self.content = content()
        self.showDragIndicator = showDragIndicator
        self.dismissOnTapOutside = dismissOnTapOutside
    }
    
    var body: some View {
        ZStack {
            if isPresented.wrappedValue {
                // Background overlay
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                    .onTapGesture {
                        if dismissOnTapOutside {
                            // Use transaction to scope animation and prevent Metal crashes
                            var transaction = Transaction(animation: .easeInOut(duration: 0.3))
                            transaction.disablesAnimations = false
                            withTransaction(transaction) {
                                isPresented.wrappedValue = false
                            }
                        }
                    }
                
                // Bottom sheet content
                VStack(spacing: 0) {
                    Spacer()
                    
                    VStack(spacing: 0) {
                        // Drag indicator
                        if showDragIndicator {
                            RoundedRectangle(cornerRadius: 2.5)
                                .fill(AppColors.borderGray)
                                .frame(width: 36, height: 5)
                                .padding(.top, 8)
                                .padding(.bottom, 16)
                        }
                        
                        // Title
                        if let title = title {
                            HStack {
                                Text(title)
                                    .appTitle()
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                
                                Button(action: {
                                    // Use transaction to scope animation and prevent Metal crashes
                                    var transaction = Transaction(animation: .easeInOut(duration: 0.3))
                                    transaction.disablesAnimations = false
                                    withTransaction(transaction) {
                                        isPresented.wrappedValue = false
                                    }
                                }) {
                                    Image(systemName: "xmark")
                                        .font(.system(size: 16, weight: .medium))
                                        .foregroundColor(AppColors.secondaryText)
                                }
                            }
                            .padding(.horizontal, 24)
                            .padding(.bottom, 16)
                        }
                        
                        // Content
                        content
                            .padding(.horizontal, 24)
                            .padding(.bottom, 24)
                    }
                    .background(AppColors.white)
                    .cornerRadius(20, corners: [.topLeft, .topRight])
                    .shadow(color: Color.black.opacity(0.15), radius: 10, x: 0, y: -5)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        // Use transaction modifier instead of global animation to prevent Metal crashes
        .transaction { transaction in
            if isPresented.wrappedValue {
                transaction.animation = .easeInOut(duration: 0.3)
            } else {
                transaction.animation = .easeInOut(duration: 0.3)
            }
        }
    }
}

// Extension for rounded corners
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

// Simple extension for easy usage without ViewModifier
extension View {
    func appBottomSheet<Content: View>(
        isPresented: Binding<Bool>,
        title: String? = nil,
        showDragIndicator: Bool = true,
        dismissOnTapOutside: Bool = true,
        @ViewBuilder content: () -> Content
    ) -> some View {
        ZStack {
            self
            
            AppBottomSheet(
                title: title,
                isPresented: isPresented,
                showDragIndicator: showDragIndicator,
                dismissOnTapOutside: dismissOnTapOutside,
                content: content
            )
        }
    }
}

// Preview
struct AppBottomSheet_Previews: PreviewProvider {
    static var previews: some View {
        VStack {
            Text("Main Content")
                .appBottomSheet(
                    isPresented: .constant(true),
                    title: "Select Options"
                ) {
                    VStack(spacing: 20) {
                        AppDropdown(
                            label: "Vehicle Type",
                            placeholder: "Select vehicle",
                            options: ["Sedan", "SUV", "Luxury"],
                            optionToString: { $0 },
                            selectedOption: .constant(nil)
                        )
                        
                        AppButton(
                            title: "Confirm Selection",
                            action: {}
                        )
                    }
                }
        }
        .padding()
    }
}
