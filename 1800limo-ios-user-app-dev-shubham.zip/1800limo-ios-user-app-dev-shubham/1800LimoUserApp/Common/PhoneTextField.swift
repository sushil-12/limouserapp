import SwiftUI

public struct Country: Identifiable, Equatable {
    public let id = UUID()
    public let name: String
    public let code: String
    public let flag: String
    public let phoneLength: Int
    public let shortCode: String
    
    public init(name: String, code: String, flag: String, phoneLength: Int, shortCode: String) {
        self.name = name
        self.code = code
        self.flag = flag
        self.phoneLength = phoneLength
        self.shortCode = shortCode
    }
}

public let countries: [Country] = [
    Country(name: "United States", code: "+1", flag: "🇺🇸", phoneLength: 10, shortCode: "US"),

    Country(name: "Afghanistan", code: "+93", flag: "🇦🇫", phoneLength: 9, shortCode: "AF"),
    Country(name: "Åland Islands", code: "+358", flag: "🇦🇽", phoneLength: 10, shortCode: "AX"),
    Country(name: "Albania", code: "+355", flag: "🇦🇱", phoneLength: 9, shortCode: "AL"),
    Country(name: "Algeria", code: "+213", flag: "🇩🇿", phoneLength: 9, shortCode: "DZ"),
    Country(name: "American Samoa", code: "+1", flag: "🇦🇸", phoneLength: 7, shortCode: "AS"),
    Country(name: "Andorra", code: "+376", flag: "🇦🇩", phoneLength: 6, shortCode: "AD"),
    Country(name: "Angola", code: "+244", flag: "🇦🇴", phoneLength: 9, shortCode: "AO"),
    Country(name: "Anguilla", code: "+1", flag: "🇦🇮", phoneLength: 10, shortCode: "AI"),
    Country(name: "Antarctica", code: "+672", flag: "🇦🇶", phoneLength: 6, shortCode: "AQ"),
    Country(name: "Antigua and Barbuda", code: "+1", flag: "🇦🇬", phoneLength: 10, shortCode: "AG"),
    Country(name: "Argentina", code: "+54", flag: "🇦🇷", phoneLength: 10, shortCode: "AR"),
    Country(name: "Armenia", code: "+374", flag: "🇦🇲", phoneLength: 8, shortCode: "AM"),
    Country(name: "Aruba", code: "+297", flag: "🇦🇼", phoneLength: 7, shortCode: "AW"),
    Country(name: "Australia", code: "+61", flag: "🇦🇺", phoneLength: 9, shortCode: "AU"),
    Country(name: "Austria", code: "+43", flag: "🇦🇹", phoneLength: 10, shortCode: "AT"),
    Country(name: "Azerbaijan", code: "+994", flag: "🇦🇿", phoneLength: 9, shortCode: "AZ"),
    Country(name: "Bahamas", code: "+1", flag: "🇧🇸", phoneLength: 10, shortCode: "BS"),
    Country(name: "Bahrain", code: "+973", flag: "🇧🇭", phoneLength: 8, shortCode: "BH"),
    Country(name: "Bangladesh", code: "+880", flag: "🇧🇩", phoneLength: 10, shortCode: "BD"),
    Country(name: "Barbados", code: "+1", flag: "🇧🇧", phoneLength: 10, shortCode: "BB"),
    Country(name: "Belarus", code: "+375", flag: "🇧🇾", phoneLength: 9, shortCode: "BY"),
    Country(name: "Belgium", code: "+32", flag: "🇧🇪", phoneLength: 9, shortCode: "BE"),
    Country(name: "Belize", code: "+501", flag: "🇧🇿", phoneLength: 7, shortCode: "BZ"),
    Country(name: "Benin", code: "+229", flag: "🇧🇯", phoneLength: 8, shortCode: "BJ"),
    Country(name: "Bermuda", code: "+1", flag: "🇧🇲", phoneLength: 10, shortCode: "BM"),
    Country(name: "Bhutan", code: "+975", flag: "🇧🇹", phoneLength: 8, shortCode: "BT"),
    Country(name: "Bolivia", code: "+591", flag: "🇧🇴", phoneLength: 8, shortCode: "BO"),
    Country(name: "Bonaire, Sint Eustatius and Saba", code: "+599", flag: "🇧🇶", phoneLength: 7, shortCode: "BQ"),
    Country(name: "Bosnia and Herzegovina", code: "+387", flag: "🇧🇦", phoneLength: 8, shortCode: "BA"),
    Country(name: "Botswana", code: "+267", flag: "🇧🇼", phoneLength: 8, shortCode: "BW"),
    Country(name: "Bouvet Island", code: "+47", flag: "🇧🇻", phoneLength: 8, shortCode: "BV"),
    Country(name: "Brazil", code: "+55", flag: "🇧🇷", phoneLength: 11, shortCode: "BR"),
    Country(name: "British Indian Ocean Territory", code: "+246", flag: "🇮🇴", phoneLength: 7, shortCode: "IO"),
    Country(name: "British Virgin Islands", code: "+1", flag: "🇻🇬", phoneLength: 10, shortCode: "VG"),
    Country(name: "Brunei Darussalam", code: "+673", flag: "🇧🇳", phoneLength: 7, shortCode: "BN"),
    Country(name: "Bulgaria", code: "+359", flag: "🇧🇬", phoneLength: 9, shortCode: "BG"),
    Country(name: "Burkina Faso", code: "+226", flag: "🇧🇫", phoneLength: 8, shortCode: "BF"),
    Country(name: "Burundi", code: "+257", flag: "🇧🇮", phoneLength: 8, shortCode: "BI"),
    Country(name: "Cambodia", code: "+855", flag: "🇰🇭", phoneLength: 9, shortCode: "KH"),
    Country(name: "Cameroon", code: "+237", flag: "🇨🇲", phoneLength: 9, shortCode: "CM"),
    Country(name: "Canada", code: "+1", flag: "🇨🇦", phoneLength: 10, shortCode: "CA"),
    Country(name: "Cape Verde", code: "+238", flag: "🇨🇻", phoneLength: 7, shortCode: "CV"),
    Country(name: "Cayman Islands", code: "+1", flag: "🇰🇾", phoneLength: 10, shortCode: "KY"),
    Country(name: "Central African Republic", code: "+236", flag: "🇨🇫", phoneLength: 8, shortCode: "CF"),
    Country(name: "Chad", code: "+235", flag: "🇹🇩", phoneLength: 8, shortCode: "TD"),
    Country(name: "Chile", code: "+56", flag: "🇨🇱", phoneLength: 9, shortCode: "CL"),
    Country(name: "China", code: "+86", flag: "🇨🇳", phoneLength: 11, shortCode: "CN"),
    Country(name: "Christmas Island", code: "+61", flag: "🇨🇽", phoneLength: 9, shortCode: "CX"),
    Country(name: "Cocos (Keeling) Islands", code: "+61", flag: "🇨🇨", phoneLength: 9, shortCode: "CC"),
    Country(name: "Colombia", code: "+57", flag: "🇨🇴", phoneLength: 10, shortCode: "CO"),
    Country(name: "Comoros", code: "+269", flag: "🇰🇲", phoneLength: 7, shortCode: "KM"),
    Country(name: "Congo", code: "+242", flag: "🇨🇬", phoneLength: 9, shortCode: "CG"),
    Country(name: "Congo, Democratic Republic of the", code: "+243", flag: "🇨🇩", phoneLength: 9, shortCode: "CD"),
    Country(name: "Cook Islands", code: "+682", flag: "🇨🇰", phoneLength: 5, shortCode: "CK"),
    Country(name: "Costa Rica", code: "+506", flag: "🇨🇷", phoneLength: 8, shortCode: "CR"),
    Country(name: "Côte d'Ivoire", code: "+225", flag: "🇨🇮", phoneLength: 8, shortCode: "CI"),
    Country(name: "Croatia", code: "+385", flag: "🇭🇷", phoneLength: 9, shortCode: "HR"),
    Country(name: "Cuba", code: "+53", flag: "🇨🇺", phoneLength: 8, shortCode: "CU"),
    Country(name: "Curaçao", code: "+599", flag: "🇨🇼", phoneLength: 7, shortCode: "CW"),
    Country(name: "Cyprus", code: "+357", flag: "🇨🇾", phoneLength: 8, shortCode: "CY"),
    Country(name: "Czech Republic", code: "+420", flag: "🇨🇿", phoneLength: 9, shortCode: "CZ"),
    Country(name: "Denmark", code: "+45", flag: "🇩🇰", phoneLength: 8, shortCode: "DK"),
    Country(name: "Djibouti", code: "+253", flag: "🇩🇯", phoneLength: 8, shortCode: "DJ"),
    Country(name: "Dominica", code: "+1", flag: "🇩🇲", phoneLength: 10, shortCode: "DM"),
    Country(name: "Dominican Republic", code: "+1", flag: "🇩🇴", phoneLength: 10, shortCode: "DO"),
    Country(name: "Ecuador", code: "+593", flag: "🇪🇨", phoneLength: 9, shortCode: "EC"),
    Country(name: "Egypt", code: "+20", flag: "🇪🇬", phoneLength: 10, shortCode: "EG"),
    Country(name: "El Salvador", code: "+503", flag: "🇸🇻", phoneLength: 8, shortCode: "SV"),
    Country(name: "Equatorial Guinea", code: "+240", flag: "🇬🇶", phoneLength: 9, shortCode: "GQ"),
    Country(name: "Eritrea", code: "+291", flag: "🇪🇷", phoneLength: 7, shortCode: "ER"),
    Country(name: "Estonia", code: "+372", flag: "🇪🇪", phoneLength: 8, shortCode: "EE"),
    Country(name: "Eswatini", code: "+268", flag: "🇸🇿", phoneLength: 8, shortCode: "SZ"),
    Country(name: "Ethiopia", code: "+251", flag: "🇪🇹", phoneLength: 9, shortCode: "ET"),
    Country(name: "Falkland Islands", code: "+500", flag: "🇫🇰", phoneLength: 5, shortCode: "FK"),
    Country(name: "Faroe Islands", code: "+298", flag: "🇫🇴", phoneLength: 6, shortCode: "FO"),
    Country(name: "Fiji", code: "+679", flag: "🇫🇯", phoneLength: 7, shortCode: "FJ"),
    Country(name: "Finland", code: "+358", flag: "🇫🇮", phoneLength: 9, shortCode: "FI"),
    Country(name: "France", code: "+33", flag: "🇫🇷", phoneLength: 9, shortCode: "FR"),
    Country(name: "French Guiana", code: "+594", flag: "🇬🇫", phoneLength: 9, shortCode: "GF"),
    Country(name: "French Polynesia", code: "+689", flag: "🇵🇫", phoneLength: 8, shortCode: "PF"),
    Country(name: "French Southern Territories", code: "+262", flag: "🇹🇫", phoneLength: 9, shortCode: "TF"),
    Country(name: "Gabon", code: "+241", flag: "🇬🇦", phoneLength: 8, shortCode: "GA"),
    Country(name: "Gambia", code: "+220", flag: "🇬🇲", phoneLength: 7, shortCode: "GM"),
    Country(name: "Georgia", code: "+995", flag: "🇬🇪", phoneLength: 9, shortCode: "GE"),
    Country(name: "Germany", code: "+49", flag: "🇩🇪", phoneLength: 10, shortCode: "DE"),
    Country(name: "Ghana", code: "+233", flag: "🇬🇭", phoneLength: 9, shortCode: "GH"),
    Country(name: "Gibraltar", code: "+350", flag: "🇬🇮", phoneLength: 8, shortCode: "GI"),
    Country(name: "Greece", code: "+30", flag: "🇬🇷", phoneLength: 10, shortCode: "GR"),
    Country(name: "Greenland", code: "+299", flag: "🇬🇱", phoneLength: 6, shortCode: "GL"),
    Country(name: "Grenada", code: "+1", flag: "🇬🇩", phoneLength: 10, shortCode: "GD"),
    Country(name: "Guadeloupe", code: "+590", flag: "🇬🇵", phoneLength: 9, shortCode: "GP"),
    Country(name: "Guam", code: "+1", flag: "🇬🇺", phoneLength: 10, shortCode: "GU"),
    Country(name: "Guatemala", code: "+502", flag: "🇬🇹", phoneLength: 8, shortCode: "GT"),
    Country(name: "Guernsey", code: "+44", flag: "🇬🇬", phoneLength: 10, shortCode: "GG"),
    Country(name: "Guinea", code: "+224", flag: "🇬🇳", phoneLength: 9, shortCode: "GN"),
    Country(name: "Guinea-Bissau", code: "+245", flag: "🇬🇼", phoneLength: 9, shortCode: "GW"),
    Country(name: "Guyana", code: "+592", flag: "🇬🇾", phoneLength: 7, shortCode: "GY"),
    Country(name: "Haiti", code: "+509", flag: "🇭🇹", phoneLength: 8, shortCode: "HT"),
    Country(name: "Heard Island and McDonald Islands", code: "+672", flag: "🇭🇲", phoneLength: 6, shortCode: "HM"),
    Country(name: "Holy See", code: "+39", flag: "🇻🇦", phoneLength: 10, shortCode: "VA"),
    Country(name: "Honduras", code: "+504", flag: "🇭🇳", phoneLength: 8, shortCode: "HN"),
    Country(name: "Hong Kong", code: "+852", flag: "🇭🇰", phoneLength: 8, shortCode: "HK"),
    Country(name: "Hungary", code: "+36", flag: "🇭🇺", phoneLength: 9, shortCode: "HU"),
    Country(name: "Iceland", code: "+354", flag: "🇮🇸", phoneLength: 7, shortCode: "IS"),
    Country(name: "India", code: "+91", flag: "🇮🇳", phoneLength: 10, shortCode: "IN"),
    Country(name: "Indonesia", code: "+62", flag: "🇮🇩", phoneLength: 10, shortCode: "ID"),
    Country(name: "Iran", code: "+98", flag: "🇮🇷", phoneLength: 10, shortCode: "IR"),
    Country(name: "Iraq", code: "+964", flag: "🇮🇶", phoneLength: 10, shortCode: "IQ"),
    Country(name: "Ireland", code: "+353", flag: "🇮🇪", phoneLength: 9, shortCode: "IE"),
    Country(name: "Isle of Man", code: "+44", flag: "🇮🇲", phoneLength: 10, shortCode: "IM"),
    Country(name: "Israel", code: "+972", flag: "🇮🇱", phoneLength: 9, shortCode: "IL"),
    Country(name: "Italy", code: "+39", flag: "🇮🇹", phoneLength: 10, shortCode: "IT"),
    Country(name: "Jamaica", code: "+1", flag: "🇯🇲", phoneLength: 10, shortCode: "JM"),
    Country(name: "Japan", code: "+81", flag: "🇯🇵", phoneLength: 10, shortCode: "JP"),
    Country(name: "Jersey", code: "+44", flag: "🇯🇪", phoneLength: 10, shortCode: "JE"),
    Country(name: "Jordan", code: "+962", flag: "🇯🇴", phoneLength: 9, shortCode: "JO"),
    Country(name: "Kazakhstan", code: "+7", flag: "🇰🇿", phoneLength: 10, shortCode: "KZ"),
    Country(name: "Kenya", code: "+254", flag: "🇰🇪", phoneLength: 10, shortCode: "KE"),
    Country(name: "Kiribati", code: "+686", flag: "🇰🇮", phoneLength: 8, shortCode: "KI"),
    Country(name: "Korea, Democratic People's Republic of", code: "+850", flag: "🇰🇵", phoneLength: 10, shortCode: "KP"),
    Country(name: "Korea, Republic of", code: "+82", flag: "🇰🇷", phoneLength: 10, shortCode: "KR"),
    Country(name: "Kuwait", code: "+965", flag: "🇰🇼", phoneLength: 8, shortCode: "KW"),
    Country(name: "Kyrgyzstan", code: "+996", flag: "🇰🇬", phoneLength: 9, shortCode: "KG"),
    Country(name: "Laos", code: "+856", flag: "🇱🇦", phoneLength: 9, shortCode: "LA"),
    Country(name: "Latvia", code: "+371", flag: "🇱🇻", phoneLength: 8, shortCode: "LV"),
    Country(name: "Lebanon", code: "+961", flag: "🇱🇧", phoneLength: 8, shortCode: "LB"),
    Country(name: "Lesotho", code: "+266", flag: "🇱🇸", phoneLength: 8, shortCode: "LS"),
    Country(name: "Liberia", code: "+231", flag: "🇱🇷", phoneLength: 9, shortCode: "LR"),
    Country(name: "Libya", code: "+218", flag: "🇱🇾", phoneLength: 9, shortCode: "LY"),
    Country(name: "Liechtenstein", code: "+423", flag: "🇱🇮", phoneLength: 7, shortCode: "LI"),
    Country(name: "Lithuania", code: "+370", flag: "🇱🇹", phoneLength: 8, shortCode: "LT"),
    Country(name: "Luxembourg", code: "+352", flag: "🇱🇺", phoneLength: 9, shortCode: "LU"),
    Country(name: "Macao", code: "+853", flag: "🇲🇴", phoneLength: 8, shortCode: "MO"),
    Country(name: "Madagascar", code: "+261", flag: "🇲🇬", phoneLength: 9, shortCode: "MG"),
    Country(name: "Malawi", code: "+265", flag: "🇲🇼", phoneLength: 9, shortCode: "MW"),
    Country(name: "Malaysia", code: "+60", flag: "🇲🇾", phoneLength: 9, shortCode: "MY"),
    Country(name: "Maldives", code: "+960", flag: "🇲🇻", phoneLength: 7, shortCode: "MV"),
    Country(name: "Mali", code: "+223", flag: "🇲🇱", phoneLength: 8, shortCode: "ML"),
    Country(name: "Malta", code: "+356", flag: "🇲🇹", phoneLength: 8, shortCode: "MT"),
    Country(name: "Marshall Islands", code: "+692", flag: "🇲🇭", phoneLength: 7, shortCode: "MH"),
    Country(name: "Martinique", code: "+596", flag: "🇲🇶", phoneLength: 9, shortCode: "MQ"),
    Country(name: "Mauritania", code: "+222", flag: "🇲🇷", phoneLength: 8, shortCode: "MR"),
    Country(name: "Mauritius", code: "+230", flag: "🇲🇺", phoneLength: 8, shortCode: "MU"),
    Country(name: "Mayotte", code: "+262", flag: "🇾🇹", phoneLength: 9, shortCode: "YT"),
    Country(name: "Mexico", code: "+52", flag: "🇲🇽", phoneLength: 10, shortCode: "MX"),
    Country(name: "Micronesia", code: "+691", flag: "🇫🇲", phoneLength: 7, shortCode: "FM"),
    Country(name: "Moldova", code: "+373", flag: "🇲🇩", phoneLength: 8, shortCode: "MD"),
    Country(name: "Monaco", code: "+377", flag: "🇲🇨", phoneLength: 9, shortCode: "MC"),
    Country(name: "Mongolia", code: "+976", flag: "🇲🇳", phoneLength: 8, shortCode: "MN"),
    Country(name: "Montenegro", code: "+382", flag: "🇲🇪", phoneLength: 8, shortCode: "ME"),
    Country(name: "Montserrat", code: "+1", flag: "🇲🇸", phoneLength: 10, shortCode: "MS"),
    Country(name: "Morocco", code: "+212", flag: "🇲🇦", phoneLength: 9, shortCode: "MA"),
    Country(name: "Mozambique", code: "+258", flag: "🇲🇿", phoneLength: 9, shortCode: "MZ"),
    Country(name: "Myanmar", code: "+95", flag: "🇲🇲", phoneLength: 9, shortCode: "MM"),
    Country(name: "Namibia", code: "+264", flag: "🇳🇦", phoneLength: 9, shortCode: "NA"),
    Country(name: "Nauru", code: "+674", flag: "🇳🇷", phoneLength: 7, shortCode: "NR"),
    Country(name: "Nepal", code: "+977", flag: "🇳🇵", phoneLength: 10, shortCode: "NP"),
    Country(name: "Netherlands", code: "+31", flag: "🇳🇱", phoneLength: 9, shortCode: "NL"),
    Country(name: "New Caledonia", code: "+687", flag: "🇳🇨", phoneLength: 6, shortCode: "NC"),
    Country(name: "New Zealand", code: "+64", flag: "🇳🇿", phoneLength: 9, shortCode: "NZ"),
    Country(name: "Nicaragua", code: "+505", flag: "🇳🇮", phoneLength: 8, shortCode: "NI"),
    Country(name: "Niger", code: "+227", flag: "🇳🇪", phoneLength: 8, shortCode: "NE"),
    Country(name: "Nigeria", code: "+234", flag: "🇳🇬", phoneLength: 10, shortCode: "NG"),
    Country(name: "Niue", code: "+683", flag: "🇳🇺", phoneLength: 4, shortCode: "NU"),
    Country(name: "Norfolk Island", code: "+672", flag: "🇳🇫", phoneLength: 6, shortCode: "NF"),
    Country(name: "North Macedonia", code: "+389", flag: "🇲🇰", phoneLength: 8, shortCode: "MK"),
    Country(name: "Northern Mariana Islands", code: "+1", flag: "🇲🇵", phoneLength: 10, shortCode: "MP"),
    Country(name: "Norway", code: "+47", flag: "🇳🇴", phoneLength: 8, shortCode: "NO"),
    Country(name: "Oman", code: "+968", flag: "🇴🇲", phoneLength: 8, shortCode: "OM"),
    Country(name: "Pakistan", code: "+92", flag: "🇵🇰", phoneLength: 10, shortCode: "PK"),
    Country(name: "Palau", code: "+680", flag: "🇵🇼", phoneLength: 7, shortCode: "PW"),
    Country(name: "Palestine", code: "+970", flag: "🇵🇸", phoneLength: 9, shortCode: "PS"),
    Country(name: "Panama", code: "+507", flag: "🇵🇦", phoneLength: 8, shortCode: "PA"),
    Country(name: "Papua New Guinea", code: "+675", flag: "🇵🇬", phoneLength: 7, shortCode: "PG"),
    Country(name: "Paraguay", code: "+595", flag: "🇵🇾", phoneLength: 9, shortCode: "PY"),
    Country(name: "Peru", code: "+51", flag: "🇵🇪", phoneLength: 9, shortCode: "PE"),
    Country(name: "Philippines", code: "+63", flag: "🇵🇭", phoneLength: 10, shortCode: "PH"),
    Country(name: "Pitcairn", code: "+64", flag: "🇵🇳", phoneLength: 9, shortCode: "PN"),
    Country(name: "Poland", code: "+48", flag: "🇵🇱", phoneLength: 9, shortCode: "PL"),
    Country(name: "Portugal", code: "+351", flag: "🇵🇹", phoneLength: 9, shortCode: "PT"),
    Country(name: "Puerto Rico", code: "+1", flag: "🇵🇷", phoneLength: 10, shortCode: "PR"),
    Country(name: "Qatar", code: "+974", flag: "🇶🇦", phoneLength: 8, shortCode: "QA"),
    Country(name: "Réunion", code: "+262", flag: "🇷🇪", phoneLength: 9, shortCode: "RE"),
    Country(name: "Romania", code: "+40", flag: "🇷🇴", phoneLength: 9, shortCode: "RO"),
    Country(name: "Russia", code: "+7", flag: "🇷🇺", phoneLength: 10, shortCode: "RU"),
    Country(name: "Rwanda", code: "+250", flag: "🇷🇼", phoneLength: 9, shortCode: "RW"),
    Country(name: "Saint Barthélemy", code: "+590", flag: "🇧🇱", phoneLength: 9, shortCode: "BL"),
    Country(name: "Saint Helena, Ascension and Tristan da Cunha", code: "+290", flag: "🇸🇭", phoneLength: 4, shortCode: "SH"),
    Country(name: "Saint Kitts and Nevis", code: "+1", flag: "🇰🇳", phoneLength: 10, shortCode: "KN"),
    Country(name: "Saint Lucia", code: "+1", flag: "🇱🇨", phoneLength: 10, shortCode: "LC"),
    Country(name: "Saint Martin", code: "+590", flag: "🇲🇫", phoneLength: 9, shortCode: "MF"),
    Country(name: "Saint Pierre and Miquelon", code: "+508", flag: "🇵🇲", phoneLength: 6, shortCode: "PM"),
    Country(name: "Saint Vincent and the Grenadines", code: "+1", flag: "🇻🇨", phoneLength: 10, shortCode: "VC"),
    Country(name: "Samoa", code: "+685", flag: "🇼🇸", phoneLength: 7, shortCode: "WS"),
    Country(name: "San Marino", code: "+378", flag: "🇸🇲", phoneLength: 10, shortCode: "SM"),
    Country(name: "São Tomé and Príncipe", code: "+239", flag: "🇸🇹", phoneLength: 7, shortCode: "ST"),
    Country(name: "Saudi Arabia", code: "+966", flag: "🇸🇦", phoneLength: 9, shortCode: "SA"),
    Country(name: "Senegal", code: "+221", flag: "🇸🇳", phoneLength: 9, shortCode: "SN"),
    Country(name: "Serbia", code: "+381", flag: "🇷🇸", phoneLength: 9, shortCode: "RS"),
    Country(name: "Seychelles", code: "+248", flag: "🇸🇨", phoneLength: 7, shortCode: "SC"),
    Country(name: "Sierra Leone", code: "+232", flag: "🇸🇱", phoneLength: 8, shortCode: "SL"),
    Country(name: "Singapore", code: "+65", flag: "🇸🇬", phoneLength: 8, shortCode: "SG"),
    Country(name: "Sint Maarten", code: "+1", flag: "🇸🇽", phoneLength: 10, shortCode: "SX"),
    Country(name: "Slovakia", code: "+421", flag: "🇸🇰", phoneLength: 9, shortCode: "SK"),
    Country(name: "Slovenia", code: "+386", flag: "🇸🇮", phoneLength: 8, shortCode: "SI"),
    Country(name: "Solomon Islands", code: "+677", flag: "🇸🇧", phoneLength: 7, shortCode: "SB"),
    Country(name: "Somalia", code: "+252", flag: "🇸🇴", phoneLength: 9, shortCode: "SO"),
    Country(name: "South Africa", code: "+27", flag: "🇿🇦", phoneLength: 9, shortCode: "ZA"),
    Country(name: "South Georgia and the South Sandwich Islands", code: "+500", flag: "🇬🇸", phoneLength: 5, shortCode: "GS"),
    Country(name: "South Sudan", code: "+211", flag: "🇸🇸", phoneLength: 9, shortCode: "SS"),
    Country(name: "Spain", code: "+34", flag: "🇪🇸", phoneLength: 9, shortCode: "ES"),
    Country(name: "Sri Lanka", code: "+94", flag: "🇱🇰", phoneLength: 9, shortCode: "LK"),
    Country(name: "Sudan", code: "+249", flag: "🇸🇩", phoneLength: 9, shortCode: "SD"),
    Country(name: "Suriname", code: "+597", flag: "🇸🇷", phoneLength: 7, shortCode: "SR"),
    Country(name: "Svalbard and Jan Mayen", code: "+47", flag: "🇸🇯", phoneLength: 8, shortCode: "SJ"),
    Country(name: "Sweden", code: "+46", flag: "🇸🇪", phoneLength: 9, shortCode: "SE"),
    Country(name: "Switzerland", code: "+41", flag: "🇨🇭", phoneLength: 9, shortCode: "CH"),
    Country(name: "Syria", code: "+963", flag: "🇸🇾", phoneLength: 9, shortCode: "SY"),
    Country(name: "Taiwan", code: "+886", flag: "🇹🇼", phoneLength: 9, shortCode: "TW"),
    Country(name: "Tajikistan", code: "+992", flag: "🇹🇯", phoneLength: 9, shortCode: "TJ"),
    Country(name: "Tanzania", code: "+255", flag: "🇹🇿", phoneLength: 9, shortCode: "TZ"),
    Country(name: "Thailand", code: "+66", flag: "🇹🇭", phoneLength: 9, shortCode: "TH"),
    Country(name: "Timor-Leste", code: "+670", flag: "🇹🇱", phoneLength: 8, shortCode: "TL"),
    Country(name: "Togo", code: "+228", flag: "🇹🇬", phoneLength: 8, shortCode: "TG"),
    Country(name: "Tokelau", code: "+690", flag: "🇹🇰", phoneLength: 4, shortCode: "TK"),
    Country(name: "Tonga", code: "+676", flag: "🇹🇴", phoneLength: 7, shortCode: "TO"),
    Country(name: "Trinidad and Tobago", code: "+1", flag: "🇹🇹", phoneLength: 10, shortCode: "TT"),
    Country(name: "Tunisia", code: "+216", flag: "🇹🇳", phoneLength: 8, shortCode: "TN"),
    Country(name: "Turkey", code: "+90", flag: "🇹🇷", phoneLength: 10, shortCode: "TR"),
    Country(name: "Turkmenistan", code: "+993", flag: "🇹🇲", phoneLength: 8, shortCode: "TM"),
    Country(name: "Turks and Caicos Islands", code: "+1", flag: "🇹🇨", phoneLength: 10, shortCode: "TC"),
    Country(name: "Tuvalu", code: "+688", flag: "🇹🇻", phoneLength: 5, shortCode: "TV"),
    Country(name: "Uganda", code: "+256", flag: "🇺🇬", phoneLength: 9, shortCode: "UG"),
    Country(name: "Ukraine", code: "+380", flag: "🇺🇦", phoneLength: 9, shortCode: "UA"),
    Country(name: "United Arab Emirates", code: "+971", flag: "🇦🇪", phoneLength: 9, shortCode: "AE"),
    Country(name: "United Kingdom", code: "+44", flag: "🇬🇧", phoneLength: 10, shortCode: "GB"),
    Country(name: "United States Minor Outlying Islands", code: "+1", flag: "🇺🇲", phoneLength: 10, shortCode: "UM"),
    Country(name: "Uruguay", code: "+598", flag: "🇺🇾", phoneLength: 8, shortCode: "UY"),
    Country(name: "Uzbekistan", code: "+998", flag: "🇺🇿", phoneLength: 9, shortCode: "UZ"),
    Country(name: "Vanuatu", code: "+678", flag: "🇻🇺", phoneLength: 7, shortCode: "VU"),
    Country(name: "Venezuela", code: "+58", flag: "🇻🇪", phoneLength: 10, shortCode: "VE"),
    Country(name: "Vietnam", code: "+84", flag: "🇻🇳", phoneLength: 9, shortCode: "VN"),
    Country(name: "Virgin Islands, U.S.", code: "+1", flag: "🇻🇮", phoneLength: 10, shortCode: "VI"),
    Country(name: "Wallis and Futuna", code: "+681", flag: "🇼🇫", phoneLength: 6, shortCode: "WF"),
    Country(name: "Western Sahara", code: "+212", flag: "🇪🇭", phoneLength: 9, shortCode: "EH"),
    Country(name: "Yemen", code: "+967", flag: "🇾🇪", phoneLength: 9, shortCode: "YE"),
    Country(name: "Zambia", code: "+260", flag: "🇿🇲", phoneLength: 9, shortCode: "ZM"),
    Country(name: "Zimbabwe", code: "+263", flag: "🇿🇼", phoneLength: 9, shortCode: "ZW")
]

struct CommonPhoneTextField: View {
    var label: String
    @Binding var phone: String
    @Binding var selectedCountry: Country
    var isRequired: Bool = false
    @State private var showSheet = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            if !label.isEmpty {
                HStack(spacing: 2) {
                    Text(label)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(AppColors.backgroundGray)
                        .textCase(.uppercase)
                        .lineSpacing(0)
                    if isRequired {
                        Text("*")
                            .foregroundColor(.red)
                            .font(.system(size: 12, weight: .medium))
                            .textCase(.uppercase)
                            .lineSpacing(0)
                    }
                }
            }
            HStack(spacing: 8) {
                Button(action: { showSheet.toggle() }) {
                    HStack(spacing: 6) {
                        Text(selectedCountry.flag)
                         Image("arrowIcon")

                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .background(AppColors.backgroundGray)
                    .cornerRadius(8)
                }
                .buttonStyle(PlainButtonStyle())
                .sheet(isPresented: $showSheet) {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            Spacer()
                            Text("Select Country")
                                .font(.headline)
                                .padding()
                            Spacer()
                        }
                        Divider()
                        ScrollView {
                            VStack(alignment: .leading, spacing: 0) {
                                ForEach(countries) { country in
                                    Button(action: {
                                        selectedCountry = country
                                        showSheet = false
                                    }) {
                                        HStack {
                                            Text(country.flag)
                                            Text(country.name)
                                            Spacer()
                                            Text(country.code)
                                        }
                                        .padding(12)
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                }
                            }
                        }
                    }
                    .presentationDetents([.medium, .large])
                }
                HStack {
                    Text(selectedCountry.code)
                        .foregroundColor(.black)
                        .font(.system(size: 16))
                    TextField("Enter Your Phone Number", text: $phone)
                        .keyboardType(.numberPad)
                        .font(.system(size: 16))
                        .onChange(of: phone) { newValue in
                            // Filter out non-numeric characters
                            let filtered = newValue.filter { $0.isNumber }
                            if filtered != newValue {
                                phone = filtered
                            }
                        }
                    Image("personpasskey")
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(AppColors.backgroundGray)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.3), lineWidth: 0.5)
                )
            }
        }
    }
} 
