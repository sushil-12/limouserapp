import SwiftUI

struct RideCompletionDialog: View {
    @Binding var isPresented: Bool
    @State private var selectedRating: RatingType = .none
    @State private var feedbackText: String = ""
    @State private var showFeedbackField: Bool = false
    @State private var isSubmitting: Bool = false
    
    let onRatingSubmitted: (RatingType, String?) -> Void
    
    enum RatingType {
        case none
        case like
        case unlike
    }
    
    var body: some View {
        ZStack {
            // Background overlay
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture {
                    // Don't allow dismissing by tapping background
                }
            
            // Dialog content
            ScrollView {
                VStack(spacing: 0) {
                // Header
                VStack(spacing: 16) {
                    // Success icon
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.green)
                    
                    // Title
                    Text("Ride Completed!")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    // Subtitle
                    Text("Hope you enjoyed your ride!")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 32)
                .padding(.horizontal, 24)
                
                // Rating section
                VStack(spacing: 20) {
                    Text("How was your ride?")
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                    
                    // Like/Unlike buttons
                    HStack(spacing: 40) {
                        // Unlike button
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                selectedRating = .unlike
                                showFeedbackField = true
                            }
                        }) {
                            VStack(spacing: 8) {
                                Image(systemName: "hand.thumbsdown.fill")
                                    .font(.system(size: 32))
                                    .foregroundColor(selectedRating == .unlike ? .red : .gray)
                                
                                Text("Unhappy")
                                    .font(.caption)
                                    .fontWeight(.medium)
                                    .foregroundColor(selectedRating == .unlike ? .red : .gray)
                            }
                            .frame(width: 80, height: 80)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(selectedRating == .unlike ? Color.red.opacity(0.1) : Color.gray.opacity(0.1))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16)
                                            .stroke(selectedRating == .unlike ? Color.red : Color.gray.opacity(0.3), lineWidth: 2)
                                    )
                            )
                        }
                        .scaleEffect(selectedRating == .unlike ? 1.05 : 1.0)
                        
                        // Like button
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                selectedRating = .like
                                showFeedbackField = false
                                feedbackText = ""
                            }
                            // Immediately submit like rating
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                onRatingSubmitted(.like, nil)
                            }
                        }) {
                            VStack(spacing: 8) {
                                Image(systemName: "hand.thumbsup.fill")
                                    .font(.system(size: 32))
                                    .foregroundColor(selectedRating == .like ? .green : .gray)
                                
                                Text("Happy")
                                    .font(.caption)
                                    .fontWeight(.medium)
                                    .foregroundColor(selectedRating == .like ? .green : .gray)
                            }
                            .frame(width: 80, height: 80)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(selectedRating == .like ? Color.green.opacity(0.1) : Color.gray.opacity(0.1))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16)
                                            .stroke(selectedRating == .like ? Color.green : Color.gray.opacity(0.3), lineWidth: 2)
                                    )
                            )
                        }
                        .scaleEffect(selectedRating == .like ? 1.05 : 1.0)
                    }
                    
                    // Feedback text field (only shown for unlike)
                    if showFeedbackField {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Tell us what went wrong")
                                .font(.subheadline)
                                .fontWeight(.medium)
                                .foregroundColor(.primary)
                            
                            TextField("Please describe your experience...", text: $feedbackText, axis: .vertical)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .lineLimit(3...6)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(Color(.systemGray6))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12)
                                                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                        )
                                )
                                .onTapGesture {
                                    // Dismiss keyboard when tapping outside text field
                                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                                }
                        }
                        .transition(.asymmetric(
                            insertion: .opacity.combined(with: .move(edge: .top)),
                            removal: .opacity.combined(with: .move(edge: .top))
                        ))
                    }
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 20)
                
                // Action buttons
                VStack(spacing: 12) {
                    // Submit button
                    Button(action: {
                        submitRating()
                    }) {
                        HStack {
                            if isSubmitting {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    .scaleEffect(0.8)
                            } else {
                                Image(systemName: selectedRating == .like ? "checkmark" : "paperplane")
                                    .font(.system(size: 16, weight: .semibold))
                            }
                            
                            Text(isSubmitting ? "Submitting..." : (selectedRating == .like ? "Great!" : "Submit Feedback"))
                                .font(.system(size: 16, weight: .semibold))
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(
                            RoundedRectangle(cornerRadius: 25)
                                .fill(selectedRating == .like ? Color.green : Color.red)
                        )
                    }
                    .disabled(selectedRating == .none || (selectedRating == .unlike && feedbackText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty))
                    .opacity(selectedRating == .none ? 0.5 : 1.0)
                    
                    // Cancel button (only for unlike with feedback)
                    if selectedRating == .unlike && !feedbackText.isEmpty {
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                feedbackText = ""
                                showFeedbackField = false
                                selectedRating = .none
                            }
                        }) {
                            Text("Cancel")
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.gray)
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
                }
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color(.systemBackground))
                        .shadow(color: .black.opacity(0.1), radius: 20, x: 0, y: 10)
                )
                .padding(.horizontal, 24)
            }
        }
    }
    
    private func submitRating() {
        guard selectedRating != .none else { return }
        
        isSubmitting = true
        
        // Simulate API call delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            isSubmitting = false
            
            // Call the completion handler
            let feedback = selectedRating == .unlike ? feedbackText : nil
            onRatingSubmitted(selectedRating, feedback)
            
            // Close dialog
            withAnimation(.easeInOut(duration: 0.3)) {
                isPresented = false
            }
        }
    }
}

// MARK: - Preview
struct RideCompletionDialog_Previews: PreviewProvider {
    static var previews: some View {
        RideCompletionDialog(isPresented: .constant(true)) { rating, feedback in
            print("Rating: \(rating), Feedback: \(feedback ?? "none")")
        }
    }
}
