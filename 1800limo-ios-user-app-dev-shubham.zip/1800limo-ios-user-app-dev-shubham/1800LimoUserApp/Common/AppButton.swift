//
//  AppButton.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct AppButton: View {
    let title: String
    let action: () -> Void
    var isEnabled: Bool = true
    var isLoading: Bool = false
    var buttonStyle: AppButtonStyle = .primary
    
    var body: some View {
        Button(action: {
            if isEnabled && !isLoading {
                action()
            }
        }) {
            HStack {
                if isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: buttonStyle.textColor))
                        .scaleEffect(0.8)
                        .padding(.trailing, 8)
                }
                
                Text(title.uppercased())
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(buttonStyle.textColor)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .frame(width: 361, height: 48)
            .padding(.top, 4)
            .padding(.trailing, 10)
            .padding(.bottom, 4)
            .padding(.leading, 10)
            .background(buttonStyle.backgroundColor)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(buttonStyle.borderColor, lineWidth: buttonStyle.borderWidth)
            )
        }
        .disabled(!isEnabled || isLoading)
        .opacity(isEnabled ? 1.0 : 0.6)
    }
}

// Button Styles
enum AppButtonStyle {
    case primary
    case secondary
    case outline
    case danger
    
    var backgroundColor: Color {
        switch self {
        case .primary:
            return AppColors.primaryOrange
        case .secondary:
            return AppColors.backgroundGray
        case .outline:
            return AppColors.clear
        case .danger:
            return AppColors.error
        }
    }
    
    var textColor: Color {
        switch self {
        case .primary:
            return AppColors.white
        case .secondary:
            return AppColors.primaryText
        case .outline:
            return AppColors.primaryOrange
        case .danger:
            return AppColors.white
        }
    }
    
    var borderColor: Color {
        switch self {
        case .primary, .secondary, .danger:
            return AppColors.clear
        case .outline:
            return AppColors.primaryOrange
        }
    }
    
    var borderWidth: CGFloat {
        switch self {
        case .outline:
            return 1.5
        default:
            return 0
        }
    }
}

// Button Sizes
enum AppButtonSize {
    case small
    case medium
    case large
    
    var height: CGFloat {
        switch self {
        case .small:
            return 40
        case .medium:
            return 50
        case .large:
            return 60
        }
    }
    
    var fontSize: CGFloat {
        switch self {
        case .small:
            return AppTypography.small
        case .medium:
            return AppTypography.body
        case .large:
            return AppTypography.title
        }
    }
}

// Preview
struct AppButton_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            AppButton(
                title: "Add a Card & Sign Up",
                action: {}
            )
            
            AppButton(
                title: "Secondary Button",
                action: {},
                buttonStyle: .secondary
            )
            
            AppButton(
                title: "Outline Button",
                action: {},
                buttonStyle: .outline
            )
            
            AppButton(
                title: "Loading Button",
                action: {},
                isLoading: true
            )
            
            AppButton(
                title: "Disabled Button",
                action: {},
                isEnabled: false
            )
        }
        .padding()
        .background(Color.white)
    }
}
