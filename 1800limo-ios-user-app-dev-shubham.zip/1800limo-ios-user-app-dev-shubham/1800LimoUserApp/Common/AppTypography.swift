//
//  AppTypography.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct AppTypography {
    // Font Family
    static let fontFamily = "SF Pro"
    
    // Font Sizes
    static let small: CGFloat = 12
    static let body: CGFloat = 14
    static let title: CGFloat = 16
    static let heading: CGFloat = 18
    static let largeHeading: CGFloat = 24
    static let extraLargeHeading: CGFloat = 32
    
    // Line Heights
    static let lineHeight150: CGFloat = 1.5
    static let lineHeight120: CGFloat = 1.2
    static let lineHeight100: CGFloat = 1.0
    
    // Letter Spacing
    static let letterSpacing: CGFloat = 0
}

// Typography Styles
extension Text {
    // Heading Styles
    func appHeading() -> some View {
        self.font(.system(size: AppTypography.heading, weight: .semibold, design: .default))
            .foregroundColor(AppColors.primaryText)
            .lineSpacing(AppTypography.lineHeight150)
    }
    
    func appLargeHeading() -> some View {
        self.font(.system(size: AppTypography.largeHeading, weight: .bold, design: .default))
            .foregroundColor(AppColors.primaryText)
            .lineSpacing(AppTypography.lineHeight120)
    }
    
    // Body Text Styles
    func appBodyText() -> some View {
        self.font(.system(size: AppTypography.body, weight: .medium, design: .default))
            .foregroundColor(AppColors.primaryText)
            .lineSpacing(AppTypography.lineHeight150)
    }
    
    func appBodyTextRegular() -> some View {
        self.font(.system(size: AppTypography.body, weight: .regular, design: .default))
            .foregroundColor(AppColors.primaryText)
            .lineSpacing(AppTypography.lineHeight150)
    }
    
    // Label Styles
    func appLabel() -> some View {
        self.font(.system(size: AppTypography.body, weight: .medium, design: .default))
            .foregroundColor(AppColors.secondaryText)
            .lineSpacing(AppTypography.lineHeight150)
    }
    
    // Small Text Styles
    func appSmallText() -> some View {
        self.font(.system(size: AppTypography.small, weight: .regular, design: .default))
            .foregroundColor(AppColors.secondaryText)
            .lineSpacing(AppTypography.lineHeight150)
    }
    
    // Title Styles
    func appTitle() -> some View {
        self.font(.system(size: AppTypography.title, weight: .semibold, design: .default))
            .foregroundColor(AppColors.primaryText)
            .lineSpacing(AppTypography.lineHeight120)
    }
}
