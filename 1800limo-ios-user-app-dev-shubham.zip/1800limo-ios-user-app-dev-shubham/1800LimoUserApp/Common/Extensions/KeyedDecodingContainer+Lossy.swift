//
//  KeyedDecodingContainer+Lossy.swift
//  1800LimoUserApp
//
//  Created by ChatGPT on 11/24/25.
//
//  Provides a safe way to decode string fields that the backend occasionally
//  returns as numeric primitives. This keeps the decoding logic localized
//  instead of sprinkling try/catch blocks throughout every model.
//

import Foundation

extension KeyedDecodingContainer {
    /// Attempts to decode a `String` but gracefully falls back to numeric types.
    /// - Parameter key: Coding key to decode.
    /// - Returns: String value if it can be derived, otherwise `nil`.
    func decodeLossyString(forKey key: Key) -> String? {
        if let stringValue = try? decodeIfPresent(String.self, forKey: key) {
            return stringValue
        }
        if let intValue = try? decodeIfPresent(Int.self, forKey: key) {
            return String(intValue)
        }
        if let doubleValue = try? decodeIfPresent(Double.self, forKey: key) {
            return doubleValue.truncatingRemainder(dividingBy: 1) == 0
                ? String(Int(doubleValue))
                : String(doubleValue)
        }
        if let boolValue = try? decodeIfPresent(Bool.self, forKey: key) {
            return String(boolValue)
        }
        return nil
    }
}




