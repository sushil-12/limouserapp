import SwiftUI

struct ConnectionStatusIndicator: View {
    let connectionStatus: ConnectionStatus
    let lastConnected: Date?
    let attempts: Int
    let isReconnecting: Bool
    
    @State private var showDetails = false
    
    var body: some View {
        VStack(alignment: .trailing, spacing: 4) {
            // Main status dot
            HStack(spacing: 6) {
                // Status dot with animation
                Circle()
                    .fill(statusColor)
                    .frame(width: 12, height: 12)
                    .overlay(
                        Circle()
                            .stroke(Color.white, lineWidth: 2)
                    )
                    .scaleEffect(isReconnecting ? 1.2 : 1.0)
                    .animation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true), value: isReconnecting)
                
                // Status text
                Text(statusText)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white)
                    .opacity(showDetails ? 1.0 : 0.0)
                    .animation(.easeInOut(duration: 0.3), value: showDetails)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.black.opacity(0.7))
            )
            .onTapGesture {
                withAnimation(.easeInOut(duration: 0.3)) {
                    showDetails.toggle()
                }
            }
            
            // Detailed info (shown when tapped)
            if showDetails {
                VStack(alignment: .trailing, spacing: 2) {
                    if let lastConnected = lastConnected {
                        Text("Last: \(formatTime(lastConnected))")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.8))
                    }
                    
                    if attempts > 0 {
                        Text("Attempts: \(attempts)")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.8))
                    }
                    
                    Text("Tap to hide")
                        .font(.system(size: 9))
                        .foregroundColor(.white.opacity(0.6))
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.black.opacity(0.8))
                )
                .transition(.opacity.combined(with: .scale(scale: 0.9)))
            }
        }
    }
    
    // MARK: - Computed Properties
    
    private var statusColor: Color {
        switch connectionStatus {
        case .connected:
            return .green
        case .disconnected:
            return .red
        case .connecting:
            return .orange
        case .reconnecting:
            return .yellow
        case .error:
            return .red
        }
    }
    
    private var statusText: String {
        switch connectionStatus {
        case .connected:
            return "Connected"
        case .disconnected:
            return "Disconnected"
        case .connecting:
            return "Connecting..."
        case .reconnecting:
            return "Reconnecting..."
        case .error:
            return "Error"
        }
    }
    
    // MARK: - Helper Methods
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

// MARK: - Preview
#Preview {
    VStack(spacing: 20) {
        ConnectionStatusIndicator(
            connectionStatus: .connected,
            lastConnected: Date(),
            attempts: 0,
            isReconnecting: false
        )
        
        ConnectionStatusIndicator(
            connectionStatus: .disconnected,
            lastConnected: Date().addingTimeInterval(-300),
            attempts: 3,
            isReconnecting: false
        )
        
        ConnectionStatusIndicator(
            connectionStatus: .reconnecting,
            lastConnected: Date().addingTimeInterval(-60),
            attempts: 2,
            isReconnecting: true
        )
    }
    .padding()
    .background(Color.gray.opacity(0.2))
}




