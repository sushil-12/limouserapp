//
//  AppDialog.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct AppDialog: View {
    let title: String
    let message: String
    let primaryButtonTitle: String
    let secondaryButtonTitle: String?
    let primaryAction: () -> Void
    let secondaryAction: (() -> Void)?
    let dialogType: AppDialogType
    
    init(
        title: String,
        message: String,
        primaryButtonTitle: String,
        secondaryButtonTitle: String? = nil,
        dialogType: AppDialogType = .info,
        primaryAction: @escaping () -> Void,
        secondaryAction: (() -> Void)? = nil
    ) {
        self.title = title
        self.message = message
        self.primaryButtonTitle = primaryButtonTitle
        self.secondaryButtonTitle = secondaryButtonTitle
        self.dialogType = dialogType
        self.primaryAction = primaryAction
        self.secondaryAction = secondaryAction
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Icon
            Image(systemName: dialogType.iconName)
                .font(.system(size: 48, weight: .light))
                .foregroundColor(dialogType.iconColor)
                .padding(.bottom, 16)
            
            // Title
            Text(title)
                .appTitle()
                .multilineTextAlignment(.center)
                .padding(.bottom, 8)
            
            // Message
            Text(message)
                .appBodyTextRegular()
                .multilineTextAlignment(.center)
                .foregroundColor(AppColors.secondaryText)
                .padding(.bottom, 24)
            
            // Buttons
            VStack(spacing: 12) {
                AppButton(
                    title: primaryButtonTitle,
                    action: primaryAction,
                    buttonStyle: dialogType.primaryButtonStyle
                )
                
                if let secondaryButtonTitle = secondaryButtonTitle {
                    AppButton(
                        title: secondaryButtonTitle,
                        action: {
                            secondaryAction?()
                        },
                        buttonStyle: .outline
                    )
                }
            }
        }
        .padding(24)
        .background(AppColors.white)
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.15), radius: 10, x: 0, y: 5)
        .padding(.horizontal, 24)
    }
}

// Dialog Types
enum AppDialogType {
    case info
    case success
    case warning
    case error
    case confirmation
    
    var iconName: String {
        switch self {
        case .info:
            return "info.circle"
        case .success:
            return "checkmark.circle"
        case .warning:
            return "exclamationmark.triangle"
        case .error:
            return "xmark.circle"
        case .confirmation:
            return "questionmark.circle"
        }
    }
    
    var iconColor: Color {
        switch self {
        case .info:
            return AppColors.info
        case .success:
            return AppColors.success
        case .warning:
            return AppColors.warning
        case .error:
            return AppColors.error
        case .confirmation:
            return AppColors.primaryOrange
        }
    }
    
    var primaryButtonStyle: AppButtonStyle {
        switch self {
        case .info, .success, .confirmation:
            return .primary
        case .warning:
            return .primary
        case .error:
            return .danger
        }
    }
}

// Simple extension for easy usage without ViewModifier
extension View {
    func appDialog(
        isPresented: Binding<Bool>,
        dialog: AppDialog
    ) -> some View {
        ZStack {
            self
            
            if isPresented.wrappedValue {
                Color.black.opacity(0.4)
                    .ignoresSafeArea()
                    .onTapGesture {
                        // Use transaction to scope animation and prevent Metal crashes
                        var transaction = Transaction(animation: .easeInOut(duration: 0.3))
                        transaction.disablesAnimations = false
                        withTransaction(transaction) {
                            isPresented.wrappedValue = false
                        }
                    }
                
                AppDialog(
                    title: dialog.title,
                    message: dialog.message,
                    primaryButtonTitle: dialog.primaryButtonTitle,
                    secondaryButtonTitle: dialog.secondaryButtonTitle,
                    dialogType: dialog.dialogType,
                    primaryAction: {
                        dialog.primaryAction()
                        // Use transaction to scope animation and prevent Metal crashes
                        var transaction = Transaction(animation: .easeInOut(duration: 0.3))
                        transaction.disablesAnimations = false
                        withTransaction(transaction) {
                            isPresented.wrappedValue = false
                        }
                    },
                    secondaryAction: {
                        dialog.secondaryAction?()
                        // Use transaction to scope animation and prevent Metal crashes
                        var transaction = Transaction(animation: .easeInOut(duration: 0.3))
                        transaction.disablesAnimations = false
                        withTransaction(transaction) {
                            isPresented.wrappedValue = false
                        }
                    }
                )
                .padding(.horizontal, 24)
                .transition(.scale.combined(with: .opacity))
            }
        }
        // Use transaction modifier instead of global animation to prevent Metal crashes
        .transaction { transaction in
            if isPresented.wrappedValue {
                transaction.animation = .easeInOut(duration: 0.3)
            } else {
                transaction.animation = .easeInOut(duration: 0.3)
            }
        }
    }
}

// Preview
struct AppDialog_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            AppDialog(
                title: "Success!",
                message: "Your booking has been confirmed successfully.",
                primaryButtonTitle: "OK",
                dialogType: .success,
                primaryAction: {}
            )
            
            AppDialog(
                title: "Confirm Booking",
                message: "Are you sure you want to confirm this booking?",
                primaryButtonTitle: "Confirm",
                secondaryButtonTitle: "Cancel",
                dialogType: .confirmation,
                primaryAction: {},
                secondaryAction: {}
            )
            
            AppDialog(
                title: "Error",
                message: "Something went wrong. Please try again.",
                primaryButtonTitle: "Retry",
                dialogType: .error,
                primaryAction: {}
            )
        }
        .padding()
        .background(Color.gray.opacity(0.1))
    }
}
