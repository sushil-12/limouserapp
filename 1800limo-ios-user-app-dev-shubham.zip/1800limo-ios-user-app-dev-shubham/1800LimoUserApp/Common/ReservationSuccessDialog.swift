import SwiftUI

struct ReservationSuccessDialog: View {
    let reservationId: Int
    let orderId: Int
    let message: String
    let currency: ReservationCurrencyInfo?
    let onClose: () -> Void
    
    var body: some View {
        ZStack {
            // Background overlay
            Color.black.opacity(0.5)
                .ignoresSafeArea()
                .onTapGesture {
                    onClose()
                }
            
            // Dialog content
            VStack(spacing: 24) {
                // Success icon
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 60))
                    .foregroundColor(AppColors.greenColor)
                
                // Title
                Text("Reservation Created!")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.primary)
                
                // Message
                Text(message)
                    .font(.system(size: 16))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                
                // Reservation details
                VStack(spacing: 12) {
                    HStack {
                        Text("Reservation ID:")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.secondary)
                        Spacer()
                        Text("#\(reservationId)")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.primary)
                    }
                    
                    HStack {
                        Text("Order ID:")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.secondary)
                        Spacer()
                        Text("#\(orderId)")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.primary)
                    }
                    
                    if let currency = currency {
                        HStack {
                            Text("Currency:")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.secondary)
                            Spacer()
                            Text("\(currency.symbol) \(currency.currency)")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(.primary)
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
                .background(Color(.systemGray6))
                .cornerRadius(12)
                
                // Close button
                Button(action: onClose) {
                    Text("Close")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(AppColors.primaryOrange)
                        .cornerRadius(8)
                }
            }
            .padding(24)
            .background(Color(.systemBackground))
            .cornerRadius(16)
            .shadow(radius: 20)
            .padding(.horizontal, 40)
        }
    }
}

#Preview {
    ReservationSuccessDialog(
        reservationId: 1615,
        orderId: 1609,
        message: "Reservation has been created successfully.",
        currency: ReservationCurrencyInfo(
            countryName: "United States",
            currency: "USD",
            currencyCountry: "US",
            symbol: "$",
            dateFormat: "M/d/yyyy"
        ),
        onClose: {}
    )
}
