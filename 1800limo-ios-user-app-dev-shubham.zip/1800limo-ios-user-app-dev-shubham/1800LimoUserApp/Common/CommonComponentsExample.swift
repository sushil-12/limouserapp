//
//  CommonComponentsExample.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct CommonComponentsExample: View {
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var selectedVehicle: String?
    @State private var selectedPayment: String?
    @State private var showDialog = false
    @State private var showBottomSheet = false
    
    let vehicleOptions = ["Sedan", "SUV", "Luxury", "Van", "Bus"]
    let paymentOptions = ["Credit Card", "Debit Card", "Cash", "Digital Wallet"]
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                // Header
                VStack(spacing: 8) {
                    AppText.largeHeading("1800Limo", alignment: .center)
                    AppText.body("Premium Limousine Service", alignment: .center)
                }
                .padding(.top, 20)
                
                // Text Fields Section
                VStack(alignment: .leading, spacing: 16) {
                    AppText.heading("User Information")
                    
                    AppTextField(
                        label: "Enter Your Name",
                        placeholder: "eg. Alexa Smith",
                        text: $name
                    )
                    
                    AppTextField(
                        label: "Email Address",
                        placeholder: "Enter your email",
                        text: $email,
                        keyboardType: .emailAddress,
                        textContentType: .emailAddress
                    )
                    
                    AppTextField(
                        label: "Password",
                        placeholder: "Enter your password",
                        text: $password,
                        isSecure: true,
                        textContentType: .password
                    )
                }
                
                // Dropdowns Section
                VStack(alignment: .leading, spacing: 16) {
                    AppText.heading("Booking Options")
                    
                    AppDropdown(
                        label: "Select Vehicle Type",
                        placeholder: "Choose a vehicle",
                        options: vehicleOptions,
                        optionToString: { $0 },
                        selectedOption: $selectedVehicle
                    )
                    
                    AppDropdown(
                        label: "Payment Method",
                        placeholder: "Choose payment method",
                        options: paymentOptions,
                        optionToString: { $0 },
                        selectedOption: $selectedPayment
                    )
                }
                
                // Buttons Section
                VStack(spacing: 16) {
                    AppText.heading("Actions")
                    
                    AppButton(
                        title: "Add a Card & Sign Up",
                        action: {
                            showDialog = true
                        }
                    )
                    
                    AppButton(
                        title: "Secondary Action",
                        action: {
                            showBottomSheet = true
                        },
                        buttonStyle: .secondary
                    )
                    
                    AppButton(
                        title: "Outline Button",
                        action: {},
                        buttonStyle: .outline
                    )
                    
                    AppButton(
                        title: "Loading Button",
                        action: {},
                        isLoading: true
                    )
                }
                
                // Text Examples Section
                VStack(alignment: .leading, spacing: 16) {
                    AppText.heading("Typography Examples")
                    
                    AppText.title("This is a title")
                    AppText.body("This is body text with medium weight")
                    AppText.bodyRegular("This is regular body text")
                    AppText.label("This is a label")
                    AppText.small("This is small text")
                    AppText.caption("This is caption text")
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
        }
        .background(AppColors.backgroundGray)
        .appDialog(
            isPresented: $showDialog,
            dialog: AppDialog(
                title: "Success!",
                message: "Your account has been created successfully. Welcome to 1800Limo!",
                primaryButtonTitle: "Continue",
                dialogType: .success,
                primaryAction: {
                    print("Dialog action performed")
                }
            )
        )
        .appBottomSheet(
            isPresented: $showBottomSheet,
            title: "Additional Options"
        ) {
            VStack(spacing: 20) {
                AppText.body("Select additional services for your booking")
                
                AppDropdown(
                    label: "Extra Services",
                    placeholder: "Select services",
                    options: ["WiFi", "Refreshments", "Chauffeur", "Premium Audio"],
                    optionToString: { $0 },
                    selectedOption: .constant(nil)
                )
                
                AppButton(
                    title: "Confirm Selection",
                    action: {
                        showBottomSheet = false
                    }
                )
            }
        }
    }
}

// Preview
struct CommonComponentsExample_Previews: PreviewProvider {
    static var previews: some View {
        CommonComponentsExample()
    }
}









