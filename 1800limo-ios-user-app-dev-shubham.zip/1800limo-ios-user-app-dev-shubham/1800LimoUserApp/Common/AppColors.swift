
//
//  AppColors.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct AppColors {
    // Main App Colors
    static let primaryOrange = Color(hex: "#F3933D")
    static let lightOrange = Color(hex: "#F3933D1A")
    static let backgroundGray = Color(hex: "#F5F5F5")
    static let greenColor = Color(hex: "#008F43") // RGB(0, 143, 67)
    
    // Text Colors
    static let primaryText = Color.black
    static let secondaryText = Color.gray
    static let placeholderText = Color.gray.opacity(0.6)
    
    // UI Colors
    static let white = Color.white
    static let black = Color.black
    static let clear = Color.clear
    
    // Border Colors
    static let borderGray = Color.gray.opacity(0.3)
    static let borderLight = Color.gray.opacity(0.1)
    
    // Status Colors
    static let success = Color.green
    static let error = Color.red
    static let warning = Color.orange
    static let info = Color.blue
}

// Extension to create Color from hex string
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }

        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

