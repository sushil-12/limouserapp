import Foundation
import SwiftUI

/// Tracks the current screen/view that the user is on
class ScreenTracker: ObservableObject {
    static let shared = ScreenTracker()
    
    @Published var currentScreen: ScreenType = .none
    
    enum ScreenType {
        case none
        case chat(bookingId: Int)
        case dashboard
        case bookingDetails
        case rideInProgress
        
        var isChatScreen: Bool {
            if case .chat = self {
                return true
            }
            return false
        }
        
        var bookingId: Int? {
            if case .chat(let bookingId) = self {
                return bookingId
            }
            return nil
        }
    }
    
    private init() {}
    
    func setCurrentScreen(_ screen: ScreenType) {
        DispatchQueue.main.async {
            self.currentScreen = screen
            print("📱 ScreenTracker: Current screen set to \(screen)")
        }
    }
    
    func clearScreen() {
        DispatchQueue.main.async {
            self.currentScreen = .none
            print("📱 ScreenTracker: Screen cleared")
        }
    }
    
    func isOnChatScreen(for bookingId: Int? = nil) -> Bool {
        if case .chat(let currentBookingId) = currentScreen {
            // If specific bookingId provided, check if it matches
            if let bookingId = bookingId {
                return currentBookingId == bookingId
            }
            // If no specific bookingId, return true if on any chat screen
            return true
        }
        return false
    }
}









