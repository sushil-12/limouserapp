//
//  AirportAirlineModels.swift
//  1800LimoUserApp
//
//  Created by AI Assistant
//

import Foundation

// MARK: - Airport Model
struct AirportItem: SearchableItem {
    let id: Int
    let name: String
    let code: String
    let city: String
    let country: String
    
    var searchText: String {
        return "\(code) \(name) \(city) \(country)".lowercased()
    }
    
    var displayText: String {
        return "\(code) - \(name)"
    }
    
    var subtitle: String? {
        return "\(city), \(country)"
    }
    
    static func == (lhs: AirportItem, rhs: AirportItem) -> Bool {
        lhs.id == rhs.id
    }
}

// MARK: - Airline Model
struct AirlineItem: SearchableItem {
    let id: Int
    let name: String
    let code: String
    let country: String?
    
    var searchText: String {
        return "\(code) \(name) \(country ?? "")".lowercased()
    }
    
    var displayText: String {
        return "\(code) - \(name)"
    }
    
    var subtitle: String? {
        return country
    }
    
    static func == (lhs: AirlineItem, rhs: AirlineItem) -> Bool {
        lhs.id == rhs.id
    }
}

// MARK: - Extensions for existing models
extension Airport: SearchableItem {
    var searchText: String {
        return "\(code) \(name) \(city) \(country)".lowercased()
    }
    
    var displayText: String {
        return "\(code) - \(name)"
    }
    
    var subtitle: String? {
        return "\(city), \(country)"
    }
}

extension Airline: SearchableItem {
    var searchText: String {
        return "\(code) \(name) \(country ?? "")".lowercased()
    }
    
    var displayText: String {
        return "\(code) - \(name)"
    }
    
    var subtitle: String? {
        return country
    }
}
