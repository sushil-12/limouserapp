//
//  AppText.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct AppText: View {
    let text: String
    let style: AppTextStyle
    let alignment: TextAlignment
    let maxLines: Int?
    
    init(
        _ text: String,
        style: AppTextStyle = .body,
        alignment: TextAlignment = .leading,
        maxLines: Int? = nil
    ) {
        self.text = text
        self.style = style
        self.alignment = alignment
        self.maxLines = maxLines
    }
    
    var body: some View {
        Text(style.processedText(text))
            .font(style.font)
            .foregroundColor(style.color)
            .lineSpacing(style.lineSpacing)
            .multilineTextAlignment(alignment)
            .lineLimit(maxLines)
    }
}

// Text Styles
enum AppTextStyle {
    case heading
    case largeHeading
    case title
    case body
    case bodyRegular
    case label
    case small
    case caption
    case button
    
    var font: Font {
        switch self {
        case .heading:
            return .system(size: AppTypography.heading, weight: .semibold, design: .default)
        case .largeHeading:
            return .system(size: AppTypography.largeHeading, weight: .bold, design: .default)
        case .title:
            return .system(size: AppTypography.title, weight: .semibold, design: .default)
        case .body:
            return .system(size: AppTypography.body, weight: .medium, design: .default)
        case .bodyRegular:
            return .system(size: AppTypography.body, weight: .regular, design: .default)
        case .label:
            return .system(size: AppTypography.body, weight: .medium, design: .default)
        case .small:
            return .system(size: AppTypography.small, weight: .regular, design: .default)
        case .caption:
            return .system(size: 10, weight: .regular, design: .default)
        case .button:
            return .system(size: AppTypography.body, weight: .semibold, design: .default)
        }
    }
    
    var color: Color {
        switch self {
        case .heading, .largeHeading, .title, .body, .bodyRegular:
            return AppColors.primaryText
        case .label, .small, .caption:
            return AppColors.secondaryText
        case .button:
            return AppColors.white
        }
    }
    
    var lineSpacing: CGFloat {
        switch self {
        case .heading, .largeHeading:
            return AppTypography.lineHeight120
        case .title:
            return AppTypography.lineHeight120
        case .body, .bodyRegular, .label, .small, .caption:
            return AppTypography.lineHeight150
        case .button:
            return AppTypography.lineHeight100
        }
    }
    
    func processedText(_ text: String) -> String {
        switch self {
        case .heading, .label, .button:
            return text.uppercased()
        default:
            return text
        }
    }
}

// Convenience initializers for common use cases
extension AppText {
    // Heading styles
    static func heading(_ text: String, alignment: TextAlignment = .leading) -> AppText {
        AppText(text, style: .heading, alignment: alignment)
    }
    
    static func largeHeading(_ text: String, alignment: TextAlignment = .leading) -> AppText {
        AppText(text, style: .largeHeading, alignment: alignment)
    }
    
    // Title styles
    static func title(_ text: String, alignment: TextAlignment = .leading) -> AppText {
        AppText(text, style: .title, alignment: alignment)
    }
    
    // Body styles
    static func body(_ text: String, alignment: TextAlignment = .leading, maxLines: Int? = nil) -> AppText {
        AppText(text, style: .body, alignment: alignment, maxLines: maxLines)
    }
    
    static func bodyRegular(_ text: String, alignment: TextAlignment = .leading, maxLines: Int? = nil) -> AppText {
        AppText(text, style: .bodyRegular, alignment: alignment, maxLines: maxLines)
    }
    
    // Label styles
    static func label(_ text: String, alignment: TextAlignment = .leading) -> AppText {
        AppText(text, style: .label, alignment: alignment)
    }
    
    // Small text styles
    static func small(_ text: String, alignment: TextAlignment = .leading) -> AppText {
        AppText(text, style: .small, alignment: alignment)
    }
    
    static func caption(_ text: String, alignment: TextAlignment = .leading) -> AppText {
        AppText(text, style: .caption, alignment: alignment)
    }
    
    // Button text styles
    static func button(_ text: String, alignment: TextAlignment = .center) -> AppText {
        AppText(text, style: .button, alignment: alignment)
    }
}

// Preview
struct AppText_Previews: PreviewProvider {
    static var previews: some View {
        VStack(alignment: .leading, spacing: 16) {
            AppText.largeHeading("Welcome to 1800Limo")
            
            AppText.heading("Book Your Ride")
            
            AppText.title("Vehicle Selection")
            
            AppText.body("Choose from our premium fleet of vehicles for your comfortable journey.")
            
            AppText.bodyRegular("We offer the best limousine service in the city with professional drivers.")
            
            AppText.label("Enter Your Name")
            
            AppText.small("Additional information and terms")
            
            AppText.caption("Terms & Conditions apply")
            
            AppText.button("Book Now")
        }
        .padding()
        .background(Color.white)
    }
}
