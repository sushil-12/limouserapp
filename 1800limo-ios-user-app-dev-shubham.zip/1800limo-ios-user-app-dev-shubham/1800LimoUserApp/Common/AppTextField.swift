//
//  AppTextField.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

// Custom UITextField wrapper that auto-selects all text on tap
struct AutoSelectTextField: UIViewRepresentable {
    var placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var textContentType: UITextContentType?
    var isSecure: Bool = false
    var textAlignment: NSTextAlignment = .left
    var fontSize: CGFloat = 16
    var fontWeight: UIFont.Weight = .regular
    var textColor: Color? = nil
    var isEnabled: Bool = true
    var onEditingChanged: ((Bool) -> Void)? = nil
    var onCommit: (() -> Void)? = nil
    
    func makeUIView(context: Context) -> UITextField {
        let textField = UITextField()
        textField.placeholder = placeholder
        textField.keyboardType = keyboardType
        textField.isSecureTextEntry = isSecure
        textField.textContentType = textContentType
        textField.textAlignment = textAlignment
        textField.isEnabled = isEnabled
        textField.delegate = context.coordinator
        textField.font = .systemFont(ofSize: fontSize, weight: fontWeight)
        textField.textColor = textColor != nil ? UIColor(textColor!) : UIColor(AppColors.primaryText)
        textField.addTarget(context.coordinator, action: #selector(Coordinator.textFieldDidChange(_:)), for: .editingChanged)
        
        // Disable autocapitalization for email fields
        if keyboardType == .emailAddress {
            textField.autocapitalizationType = .none
            textField.autocorrectionType = .no
        }
        
        // Set content hugging and compression resistance priorities to prevent size changes
        // High priority for vertical to maintain fixed height
        textField.setContentHuggingPriority(.required, for: .vertical)
        textField.setContentCompressionResistancePriority(.required, for: .vertical)
        textField.setContentHuggingPriority(.defaultLow, for: .horizontal)
        textField.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        
        // Prevent UITextField from expanding vertically - this maintains consistent height
        textField.borderStyle = .none // Remove default border to prevent size jumps
        
        return textField
    }
    
    func updateUIView(_ uiView: UITextField, context: Context) {
        // Only update text if it's different and the field is not being edited
        if uiView.text != text && !uiView.isFirstResponder {
            uiView.text = text
        }
        // Update text alignment if changed
        if uiView.textAlignment != textAlignment {
            uiView.textAlignment = textAlignment
        }
        // Update font if changed
        if uiView.font != .systemFont(ofSize: fontSize, weight: fontWeight) {
            uiView.font = .systemFont(ofSize: fontSize, weight: fontWeight)
        }
        // Update text color if changed
        let targetColor = textColor != nil ? UIColor(textColor!) : UIColor(AppColors.primaryText)
        if uiView.textColor != targetColor {
            uiView.textColor = targetColor
        }
        // Update enabled state
        if uiView.isEnabled != isEnabled {
            uiView.isEnabled = isEnabled
        }
        // Ensure autocapitalization is disabled for email fields
        if keyboardType == .emailAddress {
            uiView.autocapitalizationType = .none
            uiView.autocorrectionType = .no
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UITextFieldDelegate {
        var parent: AutoSelectTextField
        
        init(_ parent: AutoSelectTextField) {
            self.parent = parent
        }
        
        func textFieldDidBeginEditing(_ textField: UITextField) {
            // Select all text when field becomes first responder
            if let text = textField.text, !text.isEmpty {
                DispatchQueue.main.async {
                    textField.selectAll(nil)
                }
            }
            // Notify about editing started
            parent.onEditingChanged?(true)
        }
        
        func textFieldDidEndEditing(_ textField: UITextField) {
            // Notify about editing ended
            parent.onEditingChanged?(false)
        }
        
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            // Handle commit/return
            parent.onCommit?()
            textField.resignFirstResponder()
            return true
        }
        
        func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
            // For email fields, convert input to lowercase immediately
            if parent.keyboardType == .emailAddress && !string.isEmpty {
                let lowercaseString = string.lowercased()
                if lowercaseString != string {
                    // Replace the text with lowercase version
                    if let text = textField.text, let textRange = Range(range, in: text) {
                        let newText = text.replacingCharacters(in: textRange, with: lowercaseString)
                        textField.text = newText
                        parent.text = newText
                        return false // We've already handled the change
                    }
                }
            }
            // Allow the text change to happen normally
            return true
        }
        
        @objc func textFieldDidChange(_ textField: UITextField) {
            // Update the binding when text changes
            parent.text = textField.text ?? ""
        }
    }
}

struct AppTextField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    var isSecure: Bool = false
    var keyboardType: UIKeyboardType = .default
    var textContentType: UITextContentType?
    var hasError: Bool = false
    var onEditingChanged: ((Bool) -> Void)?
    var onCommit: (() -> Void)?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Label
            if !label.isEmpty {
                Text(label)
                    .font(.system(size: 14, weight: .medium, design: .default))
                    .foregroundColor(AppColors.primaryText)
                    .lineSpacing(2)
                    .padding(.leading, 4)
            }
            
            // Text Field
            AutoSelectTextField(
                placeholder: placeholder,
                text: $text,
                keyboardType: keyboardType,
                textContentType: textContentType,
                isSecure: isSecure,
                onEditingChanged: onEditingChanged,
                onCommit: onCommit
            )
            .padding(.top, 4)
            .padding(.trailing, 10)
            .padding(.bottom, 4)
            .padding(.leading, 16)
            .frame(maxWidth: .infinity)
            .frame(height: 40)
            .background(AppColors.backgroundGray)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(hasError ? Color.red : AppColors.borderGray, lineWidth: hasError ? 1.5 : 1)
            )
        }
    }
}

// Preview
struct AppTextField_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            AppTextField(
                label: "Enter Your Email Id",
                placeholder: "eg. alexasmith@gmail.com",
                text: .constant("")
            )
            
            AppTextField(
                label: "Enter Your Name",
                placeholder: "eg. Alexa Smith",
                text: .constant("")
            )
            
            AppTextField(
                label: "Password",
                placeholder: "Enter your password",
                text: .constant(""),
                isSecure: true,
                textContentType: .password
            )
        }
        .padding()
        .background(Color.white)
    }
}
