import SwiftUI

struct AddressAutocompleteField: View {
    @ObservedObject var viewModel: AddressAutocompleteViewModel
    var label: String
    var placeholder: String
    var isRequired: Bool = false
    @Binding var value: String
    var hasError: Bool = false
    var onSelect: ((String) -> Void)? = nil
    var onLocationSelected: ((String, LocationCoordinate?, String?) -> Void)? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 0) {
                Text(label)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(AppColors.primaryText)
                    .textCase(.uppercase)
                    .lineSpacing(0)
                if isRequired {
                    Text(" *")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.red)
                }
            }
            TextField(placeholder, text: Binding(
                get: { viewModel.input },
                set: { newValue in
                    viewModel.input = newValue
                    value = newValue
                })
            , onEditingChanged: { editing in
                viewModel.isEditing = editing
            })
            .padding(12)
            .background(AppColors.backgroundGray)
            .background(RoundedRectangle(cornerRadius: 8).stroke(hasError ? Color.red : Color.gray.opacity(0.3), lineWidth: hasError ? 1.5 : 1))
            if viewModel.isLoading {
                ProgressView()
                    .padding(.leading, 8)
            }
            if !viewModel.suggestions.isEmpty {
                ScrollViewReader { proxy in
                    ScrollView(.vertical, showsIndicators: true) {
                        VStack(alignment: .leading, spacing: 0) {
                            ForEach(viewModel.suggestions, id: \ .self) { suggestion in
                                Button(action: {
                                    viewModel.selectSuggestion(suggestion)
                                    value = suggestion
                                    onSelect?(suggestion)
                                    
                                    // Notify parent when location is selected
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                        onLocationSelected?(suggestion, viewModel.selectedCoordinate, viewModel.selectedPostalCode)
                                    }
                                }) {
                                    HStack {
                                        Text(suggestion)
                                            .foregroundColor(.primary)
                                        Spacer()
                                    }
                                    .padding(12)
                                }
                                .background(Color.white)
                                .buttonStyle(PlainButtonStyle())
                                .id(suggestion)
                            }
                        }
                    }
                    .frame(maxHeight: min(CGFloat(viewModel.suggestions.count) * 48, 200))
                    .background(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.3)))
                    .shadow(radius: 2)
                    .onChange(of: viewModel.suggestions) { suggestions in
                        if let first = suggestions.first {
                            withAnimation {
                                proxy.scrollTo(first, anchor: .top)
                            }
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    @State var value = ""
    return AddressAutocompleteField(viewModel: AddressAutocompleteViewModel(), label: "Enter your location", placeholder: "Enter your location", isRequired: true, value: $value)
} 
