//
//  CancelBookingDialogs.swift
//  1800LimoUserApp
//
//  Created by ChatGPT on 10/11/25.
//

import SwiftUI

struct CancelBookingConfirmationDialog: View {
    let title: String
    let message: String
    let onEdit: () -> Void
    let onConfirm: () -> Void
    let onCancel: () -> Void
    let isProcessing: Bool
    
    init(
        title: String = "Are you sure you want to cancel the booking?",
        message: String = "Click Edit / Change to make changes to the booking instead of cancelling.",
        isProcessing: Bool,
        onEdit: @escaping () -> Void,
        onConfirm: @escaping () -> Void,
        onCancel: @escaping () -> Void
    ) {
        self.title = title
        self.message = message
        self.isProcessing = isProcessing
        self.onEdit = onEdit
        self.onConfirm = onConfirm
        self.onCancel = onCancel
    }
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.45)
                .ignoresSafeArea()
                .onTapGesture {
                    guard !isProcessing else { return }
                    onCancel()
                }
            
            VStack(spacing: 24) {
                VStack(spacing: 12) {
                    Text(title)
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(AppColors.error)
                        .multilineTextAlignment(.center)
                    
                    Text(message)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(AppColors.primaryText)
                        .multilineTextAlignment(.center)
                        .lineSpacing(4)
                }
                .padding(.horizontal, 12)
                
                HStack(spacing: 12) {
                    Button(action: {
                        guard !isProcessing else { return }
                        onEdit()
                    }) {
                        Text("Edit / Change")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(AppColors.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 48)
                            .background(AppColors.greenColor)
                            .cornerRadius(12)
                    }
                    
                    Button(action: {
                        guard !isProcessing else { return }
                        onConfirm()
                    }) {
                        if isProcessing {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: AppColors.white))
                                .frame(maxWidth: .infinity)
                                .frame(height: 48)
                        } else {
                            Text("Yes")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundColor(AppColors.white)
                                .frame(maxWidth: .infinity)
                                .frame(height: 48)
                        }
                    }
                    .background(AppColors.greenColor)
                    .cornerRadius(12)
                    
                    Button(action: {
                        guard !isProcessing else { return }
                        onCancel()
                    }) {
                        Text("No")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(AppColors.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 48)
                            .background(AppColors.black)
                            .cornerRadius(12)
                    }
                }
            }
            .padding(24)
            .background(AppColors.white)
            .cornerRadius(20)
            .shadow(color: Color.black.opacity(0.2), radius: 20, x: 0, y: 10)
            .padding(.horizontal, 24)
        }
        .accessibilityElement(children: .contain)
        .accessibilityAddTraits(.isModal)
    }
}

struct CancelBookingResultDialog: View {
    let message: String
    let onDismiss: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.45)
                .ignoresSafeArea()
                .onTapGesture {
                    onDismiss()
                }
            
            VStack(spacing: 24) {
                Text(message)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(AppColors.primaryText)
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
                
                Button(action: onDismiss) {
                    Text("OK")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(AppColors.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(AppColors.primaryOrange)
                        .cornerRadius(12)
                }
            }
            .padding(24)
            .background(AppColors.white)
            .cornerRadius(20)
            .shadow(color: Color.black.opacity(0.2), radius: 20, x: 0, y: 10)
            .padding(.horizontal, 32)
        }
        .accessibilityElement(children: .contain)
        .accessibilityAddTraits(.isModal)
    }
}


