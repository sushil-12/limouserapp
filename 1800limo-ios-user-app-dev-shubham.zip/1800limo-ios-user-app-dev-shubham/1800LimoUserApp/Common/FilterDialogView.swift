import SwiftUI

struct FilterDialogView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var filterService = FilterService()
    @StateObject private var filterSelection = FilterSelectionState()
    @State private var expandedCategories: Set<FilterCategory> = []
    @State private var paginationState: [FilterCategory: Int] = [:]
    
    private let itemsPerPage = 12
    
    // Callback to notify parent when filters are applied
    let onApplyFilters: ((FilterSelectionState) -> Void)?
    
    // Initial filter state to restore previous selections
    let initialFilterState: FilterSelectionState?
    
    init(onApplyFilters: ((FilterSelectionState) -> Void)? = nil, initialFilterState: FilterSelectionState? = nil) {
        self.onApplyFilters = onApplyFilters
        self.initialFilterState = initialFilterState
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Drag Handle
            RoundedRectangle(cornerRadius: 2.5)
                .fill(Color.gray.opacity(0.3))
                .frame(width: 36, height: 5)
                .padding(.top, 8)
                .padding(.bottom, 16)
            
            // Header
            HStack {
                Spacer()
                
                Text("Filters")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.black)
                
                Spacer()
                
                Button(action: {
                    dismiss()
                }) {
                    Image(systemName: "xmark")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.black)
                }
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 24)
            
            // Filter Options List
            if filterService.isLoading {
                VStack {
                    ProgressView()
                        .scaleEffect(1.2)
                    Text("Loading filters...")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                        .padding(.top, 8)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let errorMessage = filterService.errorMessage {
                VStack {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.system(size: 40))
                        .foregroundColor(.red)
                    Text("Error loading filters")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.black)
                        .padding(.top, 8)
                    Text(errorMessage)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.top, 4)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    VStack(spacing: 0) {
                        ForEach(Array(FilterCategory.mainCategories.enumerated()), id: \.offset) { index, category in
                            if category == .driverPreferences {
                                DriverPreferencesSection(
                                    filterData: filterService.filterData,
                                    filterSelection: filterSelection,
                                    isExpanded: expandedCategories.contains(category),
                                    onToggleExpanded: {
                                        toggleCategory(category)
                                    }
                                )
                            } else if category == .makeModel {
                                MakeModelSection(
                                    filterData: filterService.filterData,
                                    filterSelection: filterSelection,
                                    isExpanded: expandedCategories.contains(category),
                                    onToggleExpanded: {
                                        toggleCategory(category)
                                    }
                                )
                            } else {
                                FilterCategorySection(
                                    category: category,
                                    filterData: filterService.filterData,
                                    filterSelection: filterSelection,
                                    isExpanded: expandedCategories.contains(category),
                                    currentPage: paginationState[category] ?? 0,
                                    itemsPerPage: itemsPerPage,
                                    onToggleExpanded: {
                                        toggleCategory(category)
                                    },
                                    onLoadMore: {
                                        loadMoreItems(for: category)
                                    },
                                    onSelectionChange: { item, isSelected in
                                        updateSelection(for: category, item: item, isSelected: isSelected)
                                    }
                                )
                            }
                            
                            if index < FilterCategory.mainCategories.count - 1 {
                                Rectangle()
                                    .fill(Color.gray.opacity(0.2))
                                    .frame(height: 1)
                                    .padding(.horizontal, 24)
                            }
                        }
                    }
                }
            }
            
            Spacer()
            
            // Action Buttons
            HStack(spacing: 16) {
                Button(action: {
                    filterSelection.clearAll()
                    onApplyFilters?(filterSelection)
                    dismiss()
                }) {
                    Text("Clear")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(Color.black)
                        .cornerRadius(8)
                }
                
                Button(action: {
                    onApplyFilters?(filterSelection)
                    dismiss()
                }) {
                    Text("Apply Filter")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(AppColors.greenColor)
                        .cornerRadius(8)
                }
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
        .background(Color.white)
        .presentationDetents([.large])
        .presentationDragIndicator(.hidden)
        .onAppear {
            // Restore initial filter state if provided
            if let initialState = initialFilterState {
                filterSelection.selectedVehicleTypes = initialState.selectedVehicleTypes
                filterSelection.selectedAmenities = initialState.selectedAmenities
                filterSelection.selectedSpecialAmenities = initialState.selectedSpecialAmenities
                filterSelection.selectedInteriors = initialState.selectedInteriors
                filterSelection.selectedMakes = initialState.selectedMakes
                filterSelection.selectedModels = initialState.selectedModels
                filterSelection.selectedYears = initialState.selectedYears
                filterSelection.selectedColors = initialState.selectedColors
                filterSelection.selectedDriverLanguages = initialState.selectedDriverLanguages
                filterSelection.selectedDriverDresses = initialState.selectedDriverDresses
                filterSelection.selectedDriverGenders = initialState.selectedDriverGenders
                filterSelection.selectedDriverBackgrounds = initialState.selectedDriverBackgrounds
                filterSelection.selectedVehicleServiceAreas = initialState.selectedVehicleServiceAreas
                filterSelection.selectedAffiliatePreferences = initialState.selectedAffiliatePreferences
                
                print("🔍 FILTER DIALOG - RESTORED PREVIOUS FILTER STATE:")
                print("Selected Vehicle Types: \(filterSelection.selectedVehicleTypes)")
                print("Selected Amenities: \(filterSelection.selectedAmenities)")
                print("Selected Special Amenities: \(filterSelection.selectedSpecialAmenities)")
                print("Selected Interiors: \(filterSelection.selectedInteriors)")
                print("Selected Makes: \(filterSelection.selectedMakes)")
                print("Selected Models: \(filterSelection.selectedModels)")
                print("Selected Years: \(filterSelection.selectedYears)")
                print("Selected Colors: \(filterSelection.selectedColors)")
                print("Selected Driver Languages: \(filterSelection.selectedDriverLanguages)")
                print("Selected Driver Dresses: \(filterSelection.selectedDriverDresses)")
                print("Selected Driver Genders: \(filterSelection.selectedDriverGenders)")
                print("Selected Driver Backgrounds: \(filterSelection.selectedDriverBackgrounds)")
                print("Selected Vehicle Service Areas: \(filterSelection.selectedVehicleServiceAreas)")
                print("Selected Affiliate Preferences: \(filterSelection.selectedAffiliatePreferences)")
            }
            
            Task {
                await filterService.fetchFilters()
            }
        }
    }
    
    // MARK: - Helper Methods
    private func toggleCategory(_ category: FilterCategory) {
        if expandedCategories.contains(category) {
            // If already expanded, collapse it
            expandedCategories.remove(category)
        } else {
            // Close all other categories and open this one (accordion behavior)
            expandedCategories.removeAll()
            expandedCategories.insert(category)
        }
    }
    
    private func loadMoreItems(for category: FilterCategory) {
        let currentPage = paginationState[category] ?? 0
        paginationState[category] = currentPage + 1
    }
    
    private func updateSelection(for category: FilterCategory, item: any FilterItem, isSelected: Bool) {
        switch category {
        case .vehicleType:
            if let vehicleType = item as? VehicleTypeFilter {
                if isSelected {
                    filterSelection.selectedVehicleTypes.insert(vehicleType.id)
                } else {
                    filterSelection.selectedVehicleTypes.remove(vehicleType.id)
                }
            }
        case .amenities:
            if let amenity = item as? AmenityFilter {
                if isSelected {
                    filterSelection.selectedAmenities.insert(amenity.id)
                } else {
                    filterSelection.selectedAmenities.remove(amenity.id)
                }
            }
        case .extraAmenities:
            if let specialAmenity = item as? SpecialAmenityFilter {
                if isSelected {
                    filterSelection.selectedSpecialAmenities.insert(specialAmenity.id)
                } else {
                    filterSelection.selectedSpecialAmenities.remove(specialAmenity.id)
                }
            }
        case .interiors:
            if let interior = item as? InteriorFilter {
                if isSelected {
                    filterSelection.selectedInteriors.insert(interior.id)
                } else {
                    filterSelection.selectedInteriors.remove(interior.id)
                }
            }
        case .make:
            if let make = item as? MakeFilter {
                if isSelected {
                    filterSelection.selectedMakes.insert(make.id)
                } else {
                    filterSelection.selectedMakes.remove(make.id)
                }
            }
        case .model:
            if let model = item as? ModelFilter {
                if isSelected {
                    filterSelection.selectedModels.insert(model.id)
                } else {
                    filterSelection.selectedModels.remove(model.id)
                }
            }
        case .years:
            if let year = item as? YearFilter {
                if isSelected {
                    filterSelection.selectedYears.insert(year.id)
                } else {
                    filterSelection.selectedYears.remove(year.id)
                }
            }
        case .colors:
            if let color = item as? ColorFilter {
                if isSelected {
                    filterSelection.selectedColors.insert(color.id)
                } else {
                    filterSelection.selectedColors.remove(color.id)
                }
            }
        case .driverDresses:
            if let driverDress = item as? DriverDressFilter {
                if isSelected {
                    filterSelection.selectedDriverDresses.insert(driverDress.id)
                } else {
                    filterSelection.selectedDriverDresses.remove(driverDress.id)
                }
            }
        case .driverLanguages:
            if let driverLanguage = item as? DriverLanguageFilter {
                if isSelected {
                    filterSelection.selectedDriverLanguages.insert(driverLanguage.id)
                } else {
                    filterSelection.selectedDriverLanguages.remove(driverLanguage.id)
                }
            }
        case .driverGender:
            if let driverGender = item as? DriverGenderFilter {
                if isSelected {
                    filterSelection.selectedDriverGenders.insert(driverGender.slug)
                } else {
                    filterSelection.selectedDriverGenders.remove(driverGender.slug)
                }
            }
        case .driverBackground:
            if let driverBackground = item as? DriverDressFilter { // Using same type for now
                if isSelected {
                    filterSelection.selectedDriverBackgrounds.insert(driverBackground.id)
                } else {
                    filterSelection.selectedDriverBackgrounds.remove(driverBackground.id)
                }
            }
        case .vehicleServiceArea:
            if let serviceArea = item as? VehicleServiceAreaFilter {
                if isSelected {
                    filterSelection.selectedVehicleServiceAreas.insert(serviceArea.slug)
                } else {
                    filterSelection.selectedVehicleServiceAreas.remove(serviceArea.slug)
                }
            }
        case .operatorPreferences:
            if let affiliate = item as? AffiliatePreference {
                if isSelected {
                    filterSelection.selectedAffiliatePreferences.insert(affiliate.slug)
                } else {
                    filterSelection.selectedAffiliatePreferences.remove(affiliate.slug)
                }
            }
        case .driverPreferences, .makeModel:
            // These are main categories handled by their respective section components
            break
        }
    }
}

// MARK: - Filter Category Section
struct FilterCategorySection: View {
    let category: FilterCategory
    let filterData: FilterData?
    @ObservedObject var filterSelection: FilterSelectionState
    let isExpanded: Bool
    let currentPage: Int
    let itemsPerPage: Int
    let onToggleExpanded: () -> Void
    let onLoadMore: () -> Void
    let onSelectionChange: (any FilterItem, Bool) -> Void
    
    @State private var searchText = ""
    
    var body: some View {
        VStack(spacing: 0) {
            // Category Header
            Button(action: onToggleExpanded) {
                HStack {
                    Text(category.displayName)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.black)
                    
                    Spacer()
                    
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .contentShape(Rectangle())
            }
            .buttonStyle(PlainButtonStyle())
            
            // Expanded Content
            if isExpanded {
                VStack(spacing: 0) {
                    // Search Bar
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                            .padding(.leading, 8)
                        
                        TextField("Search \(category.displayName.lowercased())...", text: $searchText)
                            .textFieldStyle(PlainTextFieldStyle())
                            .padding(.vertical, 8)
                    }
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                    
                    // Filtered Items
                    ForEach(Array(filteredItems.enumerated()), id: \.offset) { index, item in
                        FilterItemRow(
                            item: item,
                            category: category,
                            isSelected: isItemSelected(item),
                            onSelectionChange: onSelectionChange
                        )
                    }
                    
                    // Show More Button
                    if hasMoreItems && searchText.isEmpty {
                        Button(action: onLoadMore) {
                            HStack {
                                Text("Show More (+12)")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(AppColors.primaryOrange)
                                
                                 Image("arrowIcon")

                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(AppColors.primaryOrange)
                            }
                            .padding(.horizontal, 24)
                            .padding(.vertical, 12)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            }
        }
    }
    
    // MARK: - Computed Properties
    private var visibleItems: [any FilterItem] {
        guard let data = filterData else { return [] }
        
        let allItems = getItemsForCategory(data)
        let endIndex = min((currentPage + 1) * itemsPerPage, allItems.count)
        return Array(allItems[0..<endIndex])
    }
    
    private var filteredItems: [any FilterItem] {
        if searchText.isEmpty {
            return visibleItems
        } else {
            guard let data = filterData else { return [] }
            let allItems = getItemsForCategory(data)
            return allItems.filter { item in
                item.displayName.lowercased().contains(searchText.lowercased())
            }
        }
    }
    
    private var hasMoreItems: Bool {
        guard let data = filterData else { return false }
        let allItems = getItemsForCategory(data)
        return (currentPage + 1) * itemsPerPage < allItems.count
    }
    
    private var remainingItemsCount: Int {
        guard let data = filterData else { return 0 }
        let allItems = getItemsForCategory(data)
        let shownItems = (currentPage + 1) * itemsPerPage
        return max(0, allItems.count - shownItems)
    }
    
    private func getItemsForCategory(_ data: FilterData) -> [any FilterItem] {
        switch category {
        case .vehicleType:
            return data.vehicleType.sorted { ($0.sortOrder ?? 0) < ($1.sortOrder ?? 0) }
        case .amenities:
            return data.amenities
        case .extraAmenities:
            return data.specialAmenities
        case .interiors:
            return data.interiors
        case .make:
            return data.make
        case .model:
            return data.model
        case .years:
            return data.years.sorted { $0.name > $1.name }
        case .colors:
            return data.colors
        case .driverDresses:
            return data.driverDresses
        case .driverLanguages:
            return data.driverLanguages
        case .driverGender:
            return data.driverGender
        case .driverBackground:
            return [] // Add driver background data when available
        case .vehicleServiceArea:
            return data.vehicleServiceArea
        case .operatorPreferences:
            return data.affiliatePreferences
        default:
            return []
        }
    }
    
    private func isItemSelected(_ item: any FilterItem) -> Bool {
        switch category {
        case .vehicleType:
            if let vehicleType = item as? VehicleTypeFilter {
                return filterSelection.selectedVehicleTypes.contains(vehicleType.id)
            }
        case .amenities:
            if let amenity = item as? AmenityFilter {
                return filterSelection.selectedAmenities.contains(amenity.id)
            }
        case .extraAmenities:
            if let specialAmenity = item as? SpecialAmenityFilter {
                return filterSelection.selectedSpecialAmenities.contains(specialAmenity.id)
            }
        case .interiors:
            if let interior = item as? InteriorFilter {
                return filterSelection.selectedInteriors.contains(interior.id)
            }
        case .make:
            if let make = item as? MakeFilter {
                return filterSelection.selectedMakes.contains(make.id)
            }
        case .model:
            if let model = item as? ModelFilter {
                return filterSelection.selectedModels.contains(model.id)
            }
        case .years:
            if let year = item as? YearFilter {
                return filterSelection.selectedYears.contains(year.id)
            }
        case .colors:
            if let color = item as? ColorFilter {
                return filterSelection.selectedColors.contains(color.id)
            }
        case .driverDresses:
            if let driverDress = item as? DriverDressFilter {
                return filterSelection.selectedDriverDresses.contains(driverDress.id)
            }
        case .driverLanguages:
            if let driverLanguage = item as? DriverLanguageFilter {
                return filterSelection.selectedDriverLanguages.contains(driverLanguage.id)
            }
        case .driverGender:
            if let driverGender = item as? DriverGenderFilter {
                return filterSelection.selectedDriverGenders.contains(driverGender.slug)
            }
        case .driverBackground:
            if let driverBackground = item as? DriverDressFilter { // Using same type for now
                return filterSelection.selectedDriverBackgrounds.contains(driverBackground.id)
            }
        case .vehicleServiceArea:
            if let serviceArea = item as? VehicleServiceAreaFilter {
                return filterSelection.selectedVehicleServiceAreas.contains(serviceArea.slug)
            }
        case .operatorPreferences:
            if let affiliate = item as? AffiliatePreference {
                return filterSelection.selectedAffiliatePreferences.contains(affiliate.slug)
            }
        case .driverPreferences, .makeModel:
            // These are main categories handled by their respective section components
            return false
        }
        return false
    }
}

// MARK: - Filter Item Row
struct FilterItemRow: View {
    let item: any FilterItem
    let category: FilterCategory
    let isSelected: Bool
    let onSelectionChange: (any FilterItem, Bool) -> Void
    
    var body: some View {
        Button(action: {
            onSelectionChange(item, !isSelected)
        }) {
            HStack {
                // Checkbox
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(isSelected ? AppColors.primaryOrange : .gray)
                
                // Item Name
                Text(itemName)
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(.black)
                
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 12)
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    private var itemName: String {
        return item.displayName
    }
}

// MARK: - Driver Preferences Section
struct DriverPreferencesSection: View {
    let filterData: FilterData?
    @ObservedObject var filterSelection: FilterSelectionState
    let isExpanded: Bool
    let onToggleExpanded: () -> Void
    @State private var paginationState: [FilterCategory: Int] = [:]
    @State private var expandedSubCategories: Set<FilterCategory> = []
    @State private var searchText = ""
    
    private let itemsPerPage = 12
    
    var body: some View {
        VStack(spacing: 0) {
            // Main Driver Preferences Header
            Button(action: onToggleExpanded) {
                HStack {
                    Text("Driver Preferences")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.black)
                    
                    Spacer()
                    
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .contentShape(Rectangle())
            }
            .buttonStyle(PlainButtonStyle())
            
            // Expanded Content with Sub-sections
            if isExpanded {
                VStack(spacing: 0) {
                    ForEach(Array(FilterCategory.driverPreferencesSubCategories.enumerated()), id: \.offset) { index, subCategory in
                        VStack(spacing: 0) {
                            // Sub-category Header with left padding to show hierarchy
                            Button(action: {
                                toggleSubCategory(subCategory)
                            }) {
                                HStack {
                                    Text(subCategory.displayName)
                                        .font(.system(size: 16, weight: .regular))
                                        .foregroundColor(.black)
                                    
                                    Spacer()
                                    
                                    Image(systemName: expandedSubCategories.contains(subCategory) ? "chevron.up" : "chevron.down")
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(.gray)
                                }
                                .padding(.leading, 40)
                                .padding(.trailing, 24)
                                .padding(.vertical, 16)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            // Sub-category Content
                            if expandedSubCategories.contains(subCategory) {
                                FilterSubCategoryContent(
                                    category: subCategory,
                                    filterData: filterData,
                                    filterSelection: filterSelection,
                                    currentPage: paginationState[subCategory] ?? 0,
                                    itemsPerPage: itemsPerPage,
                                    showSearch: true,
                                    onLoadMore: {
                                        loadMoreItems(for: subCategory)
                                    },
                                    onSelectionChange: { item, isSelected in
                                        updateSelection(for: subCategory, item: item, isSelected: isSelected)
                                    }
                                )
                            }
                        }
                        
                        if index < FilterCategory.driverPreferencesSubCategories.count - 1 {
                            Rectangle()
                                .fill(Color.gray.opacity(0.2))
                                .frame(height: 1)
                                .padding(.horizontal, 24)
                        }
                    }
                }
            }
        }
    }
    
    private func toggleSubCategory(_ category: FilterCategory) {
        if expandedSubCategories.contains(category) {
            // If already expanded, collapse it
            expandedSubCategories.remove(category)
        } else {
            // Close all other sub-categories and open this one (accordion behavior)
            expandedSubCategories.removeAll()
            expandedSubCategories.insert(category)
        }
    }
    
    private func loadMoreItems(for category: FilterCategory) {
        let currentPage = paginationState[category] ?? 0
        paginationState[category] = currentPage + 1
    }
    
    private func updateSelection(for category: FilterCategory, item: any FilterItem, isSelected: Bool) {
        switch category {
        case .driverDresses:
            if let driverDress = item as? DriverDressFilter {
                if isSelected {
                    filterSelection.selectedDriverDresses.insert(driverDress.id)
                } else {
                    filterSelection.selectedDriverDresses.remove(driverDress.id)
                }
            }
        case .driverLanguages:
            if let driverLanguage = item as? DriverLanguageFilter {
                if isSelected {
                    filterSelection.selectedDriverLanguages.insert(driverLanguage.id)
                } else {
                    filterSelection.selectedDriverLanguages.remove(driverLanguage.id)
                }
            }
        case .driverGender:
            if let driverGender = item as? DriverGenderFilter {
                if isSelected {
                    filterSelection.selectedDriverGenders.insert(driverGender.slug)
                } else {
                    filterSelection.selectedDriverGenders.remove(driverGender.slug)
                }
            }
        case .driverBackground:
            // Handle driver background if needed
            break
        default:
            break
        }
    }
}

// MARK: - Make Model Section
struct MakeModelSection: View {
    let filterData: FilterData?
    @ObservedObject var filterSelection: FilterSelectionState
    let isExpanded: Bool
    let onToggleExpanded: () -> Void
    @State private var paginationState: [FilterCategory: Int] = [:]
    @State private var expandedSubCategories: Set<FilterCategory> = []
    @State private var searchText = ""
    
    private let itemsPerPage = 12
    
    var body: some View {
        VStack(spacing: 0) {
            // Main Make Model Header
            Button(action: onToggleExpanded) {
                HStack {
                    Text("Make Model")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.black)
                    
                    Spacer()
                    
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .contentShape(Rectangle())
            }
            .buttonStyle(PlainButtonStyle())
            
            // Expanded Content with Sub-sections
            if isExpanded {
                VStack(spacing: 0) {
                    ForEach(Array(FilterCategory.makeModelSubCategories.enumerated()), id: \.offset) { index, subCategory in
                        VStack(spacing: 0) {
                            // Sub-category Header with left padding to show hierarchy
                            Button(action: {
                                toggleSubCategory(subCategory)
                            }) {
                                HStack {
                                    Text(subCategory.displayName)
                                        .font(.system(size: 16, weight: .regular))
                                        .foregroundColor(.black)
                                    
                                    Spacer()
                                    
                                    Image(systemName: expandedSubCategories.contains(subCategory) ? "chevron.up" : "chevron.down")
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(.gray)
                                }
                                .padding(.leading, 40)
                                .padding(.trailing, 24)
                                .padding(.vertical, 16)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            // Sub-category Content
                            if expandedSubCategories.contains(subCategory) {
                                FilterSubCategoryContent(
                                    category: subCategory,
                                    filterData: filterData,
                                    filterSelection: filterSelection,
                                    currentPage: paginationState[subCategory] ?? 0,
                                    itemsPerPage: itemsPerPage,
                                    showSearch: true,
                                    onLoadMore: {
                                        loadMoreItems(for: subCategory)
                                    },
                                    onSelectionChange: { item, isSelected in
                                        updateSelection(for: subCategory, item: item, isSelected: isSelected)
                                    }
                                )
                            }
                        }
                        
                        if index < FilterCategory.makeModelSubCategories.count - 1 {
                            Rectangle()
                                .fill(Color.gray.opacity(0.2))
                                .frame(height: 1)
                                .padding(.horizontal, 24)
                        }
                    }
                }
            }
        }
    }
    
    private func toggleSubCategory(_ category: FilterCategory) {
        if expandedSubCategories.contains(category) {
            // If already expanded, collapse it
            expandedSubCategories.remove(category)
        } else {
            // Close all other sub-categories and open this one (accordion behavior)
            expandedSubCategories.removeAll()
            expandedSubCategories.insert(category)
        }
    }
    
    private func loadMoreItems(for category: FilterCategory) {
        let currentPage = paginationState[category] ?? 0
        paginationState[category] = currentPage + 1
    }
    
    private func updateSelection(for category: FilterCategory, item: any FilterItem, isSelected: Bool) {
        switch category {
        case .make:
            if let make = item as? MakeFilter {
                if isSelected {
                    filterSelection.selectedMakes.insert(make.id)
                } else {
                    filterSelection.selectedMakes.remove(make.id)
                }
            }
        case .model:
            if let model = item as? ModelFilter {
                if isSelected {
                    filterSelection.selectedModels.insert(model.id)
                } else {
                    filterSelection.selectedModels.remove(model.id)
                }
            }
        default:
            break
        }
    }
}

// MARK: - Filter Sub Category Content
struct FilterSubCategoryContent: View {
    let category: FilterCategory
    let filterData: FilterData?
    @ObservedObject var filterSelection: FilterSelectionState
    let currentPage: Int
    let itemsPerPage: Int
    var showSearch: Bool = true
    let onLoadMore: () -> Void
    let onSelectionChange: (any FilterItem, Bool) -> Void
    
    @State private var searchText = ""
    
    var body: some View {
        VStack(spacing: 0) {
            // Search Bar (conditionally shown)
            if showSearch {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                        .padding(.leading, 8)
                    
                    TextField("Search \(category.displayName.lowercased())...", text: $searchText)
                        .textFieldStyle(PlainTextFieldStyle())
                        .padding(.vertical, 8)
                }
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
            }
            
            // Filtered Items
            ForEach(Array(filteredItems.enumerated()), id: \.offset) { index, item in
                FilterItemRow(
                    item: item,
                    category: category,
                    isSelected: isItemSelected(item),
                    onSelectionChange: onSelectionChange
                )
            }
            
            // Show More Button
            if hasMoreItems && searchText.isEmpty {
                Button(action: onLoadMore) {
                    HStack {
                        Text("Show More (+12)")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(AppColors.primaryOrange)
                        
                         Image("arrowIcon")

                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(AppColors.primaryOrange)
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
    }
    
    // MARK: - Computed Properties
    private var visibleItems: [any FilterItem] {
        guard let data = filterData else { return [] }
        
        let allItems = getItemsForCategory(data)
        let endIndex = min((currentPage + 1) * itemsPerPage, allItems.count)
        return Array(allItems[0..<endIndex])
    }
    
    private var filteredItems: [any FilterItem] {
        if searchText.isEmpty {
            return visibleItems
        } else {
            guard let data = filterData else { return [] }
            let allItems = getItemsForCategory(data)
            return allItems.filter { item in
                item.displayName.lowercased().contains(searchText.lowercased())
            }
        }
    }
    
    private var hasMoreItems: Bool {
        guard let data = filterData else { return false }
        let allItems = getItemsForCategory(data)
        return (currentPage + 1) * itemsPerPage < allItems.count
    }
    
    private var remainingItemsCount: Int {
        guard let data = filterData else { return 0 }
        let allItems = getItemsForCategory(data)
        let shownItems = (currentPage + 1) * itemsPerPage
        return max(0, allItems.count - shownItems)
    }
    
    private func getItemsForCategory(_ data: FilterData) -> [any FilterItem] {
        switch category {
        case .vehicleType:
            return data.vehicleType.sorted { ($0.sortOrder ?? 0) < ($1.sortOrder ?? 0) }
        case .amenities:
            return data.amenities
        case .extraAmenities:
            return data.specialAmenities
        case .interiors:
            return data.interiors
        case .make:
            return data.make
        case .model:
            return data.model
        case .years:
            return data.years.sorted { $0.name > $1.name }
        case .colors:
            return data.colors
        case .driverDresses:
            return data.driverDresses
        case .driverLanguages:
            return data.driverLanguages
        case .driverGender:
            return data.driverGender
        case .driverBackground:
            return [] // Add driver background data when available
        case .vehicleServiceArea:
            return data.vehicleServiceArea
        case .operatorPreferences:
            return data.affiliatePreferences
        default:
            return []
        }
    }
    
    private func isItemSelected(_ item: any FilterItem) -> Bool {
        switch category {
        case .vehicleType:
            if let vehicleType = item as? VehicleTypeFilter {
                return filterSelection.selectedVehicleTypes.contains(vehicleType.id)
            }
        case .amenities:
            if let amenity = item as? AmenityFilter {
                return filterSelection.selectedAmenities.contains(amenity.id)
            }
        case .extraAmenities:
            if let specialAmenity = item as? SpecialAmenityFilter {
                return filterSelection.selectedSpecialAmenities.contains(specialAmenity.id)
            }
        case .interiors:
            if let interior = item as? InteriorFilter {
                return filterSelection.selectedInteriors.contains(interior.id)
            }
        case .make:
            if let make = item as? MakeFilter {
                return filterSelection.selectedMakes.contains(make.id)
            }
        case .model:
            if let model = item as? ModelFilter {
                return filterSelection.selectedModels.contains(model.id)
            }
        case .years:
            if let year = item as? YearFilter {
                return filterSelection.selectedYears.contains(year.id)
            }
        case .colors:
            if let color = item as? ColorFilter {
                return filterSelection.selectedColors.contains(color.id)
            }
        case .driverDresses:
            if let driverDress = item as? DriverDressFilter {
                return filterSelection.selectedDriverDresses.contains(driverDress.id)
            }
        case .driverLanguages:
            if let driverLanguage = item as? DriverLanguageFilter {
                return filterSelection.selectedDriverLanguages.contains(driverLanguage.id)
            }
        case .driverGender:
            if let driverGender = item as? DriverGenderFilter {
                return filterSelection.selectedDriverGenders.contains(driverGender.slug)
            }
        case .driverBackground:
            if let driverBackground = item as? DriverDressFilter { // Using same type for now
                return filterSelection.selectedDriverBackgrounds.contains(driverBackground.id)
            }
        case .vehicleServiceArea:
            if let serviceArea = item as? VehicleServiceAreaFilter {
                return filterSelection.selectedVehicleServiceAreas.contains(serviceArea.slug)
            }
        case .operatorPreferences:
            if let affiliate = item as? AffiliatePreference {
                return filterSelection.selectedAffiliatePreferences.contains(affiliate.slug)
            }
        case .driverPreferences, .makeModel:
            // These are main categories handled by their respective section components
            return false
        }
        return false
    }
}

#Preview {
    FilterDialogView()
}
