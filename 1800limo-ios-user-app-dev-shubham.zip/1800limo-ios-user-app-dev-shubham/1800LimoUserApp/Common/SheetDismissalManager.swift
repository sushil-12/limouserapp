import Foundation
import SwiftUI

class SheetDismissalManager: ObservableObject {
    static let shared = SheetDismissalManager()
    
    @Published var shouldDismissAllSheets = false
    
    private init() {}
    
    func dismissAllSheets() {
        DispatchQueue.main.async {
            // Post notification to all sheets
            NotificationCenter.default.post(name: .dismissAllSheets, object: nil)
            self.shouldDismissAllSheets = true

            // Increase delay to allow animations (0.3s) to complete before force dismiss
            // This prevents Metal crashes from views being deallocated during animations
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                // Force dismiss all sheets after animations complete
                NotificationCenter.default.post(name: .forceDismissAllSheets, object: nil)
            }
        }
    }
    
    func reset() {
        DispatchQueue.main.async {
            self.shouldDismissAllSheets = false
        }
    }
}

extension Notification.Name {
    static let dismissAllSheets = Notification.Name("dismissAllSheets")
    static let forceDismissAllSheets = Notification.Name("forceDismissAllSheets")
}
