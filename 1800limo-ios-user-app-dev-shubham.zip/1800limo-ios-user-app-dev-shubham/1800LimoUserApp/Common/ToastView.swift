import SwiftUI

struct ToastView: View {
    let title: String?
    let message: String
    let detail: String?
    let type: ToastType
    let countdown: Int?
    let avatarText: String?
    let isInteractive: Bool
    @Binding var isShowing: Bool
    let onTap: (() -> Void)?
    
    var body: some View {
        if isShowing {
            toastContent
        }
    }
    
    private var toastContent: some View {
        VStack(alignment: .leading, spacing: 6) {
            if let title = title, !title.isEmpty {
                Text(title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                    .transition(.opacity)
            }
            
            Text(messageBody)
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(.white.opacity(0.95))
                .multilineTextAlignment(.leading)
                .lineLimit(3)
            
            if let detail = detail, !detail.isEmpty {
                Text(detail)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white.opacity(0.65))
                    .lineLimit(2)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(backgroundGradient)
                .shadow(color: .black.opacity(0.12), radius: 10, x: 0, y: 8)
        )
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 20)
        .transition(.asymmetric(
            insertion: .move(edge: .top).combined(with: .opacity),
            removal: .move(edge: .top).combined(with: .opacity)
        ))
        .animation(.easeInOut(duration: 0.3), value: isShowing)
        .onTapGesture {
            if let onTap = onTap {
                onTap()
            } else {
                withAnimation(.easeInOut(duration: 0.3)) {
                    isShowing = false
                }
            }
        }
    }
    
    private var messageBody: String {
        let trimmed = message.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? " " : trimmed
    }
    
    private var backgroundGradient: LinearGradient {
        let colors = gradientColors
        return LinearGradient(
            gradient: Gradient(colors: colors),
            startPoint: .leading,
            endPoint: .trailing
        )
    }
    
    private var gradientColors: [Color] {
        switch type {
        case .success:
            return [Color(red: 0.09, green: 0.47, blue: 0.29), Color(red: 0.05, green: 0.37, blue: 0.22)]
        case .error:
            return [Color(red: 0.70, green: 0.14, blue: 0.19), Color(red: 0.54, green: 0.10, blue: 0.14)]
        case .warning:
            return [Color(red: 0.83, green: 0.46, blue: 0.11), Color(red: 0.70, green: 0.33, blue: 0.07)]
        case .info:
            return [Color(red: 0.16, green: 0.40, blue: 0.76), Color(red: 0.11, green: 0.28, blue: 0.58)]
        case .chat:
            return [
                AppColors.primaryOrange.opacity(0.95),
                AppColors.primaryOrange.opacity(0.85)
            ]
        }
    }
}

// MARK: - Toast Overlay Wrapper View
private struct ToastOverlayWrapper: View {
    @ObservedObject private var socketService = SimpleSocketIOService.shared
    
    var body: some View {
        VStack {
            ToastView(
                title: socketService.toastTitle,
                message: socketService.toastMessage,
                detail: socketService.toastDetail,
                type: socketService.toastType,
                countdown: socketService.toastCountdown,
                avatarText: socketService.toastAvatarText,
                isInteractive: socketService.toastIsInteractive,
                isShowing: $socketService.showToast,
                onTap: {
                    if socketService.toastIsInteractive {
                        socketService.handleToastTap()
                    } else {
                        socketService.hideToast()
                    }
                }
            )
            .zIndex(1000)
            
            Spacer()
        }
    }
}

// MARK: - Toast Overlay Modifier
struct ToastOverlay: ViewModifier {
    func body(content: Content) -> some View {
        ZStack {
            content
            ToastOverlayWrapper()
        }
    }
}

// MARK: - View Extension
extension View {
    func toastOverlay() -> some View {
        self.modifier(ToastOverlay())
    }
}

// MARK: - Preview
struct ToastView_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            ToastView(
                title: "Suyash",
                message: "Please wait, I'll be there soon",
                detail: nil,
                type: .chat,
                countdown: nil,
                avatarText: nil,
                isInteractive: true,
                isShowing: .constant(true),
                onTap: {}
            )
            ToastView(
                title: "Success",
                message: "Your booking was created successfully",
                detail: nil,
                type: .success,
                countdown: nil,
                avatarText: nil,
                isInteractive: false,
                isShowing: .constant(true),
                onTap: {}
            )
        }
        .padding()
        .background(Color.gray.opacity(0.1))
    }
}


