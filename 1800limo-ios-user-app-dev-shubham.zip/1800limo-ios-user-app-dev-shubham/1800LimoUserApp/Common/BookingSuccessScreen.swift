import SwiftUI

struct BookingSuccessScreen: View {
    let onOK: () -> Void
    let hasDriverAssigned: Bool // New parameter to check if driver is already assigned
    
    var body: some View {
        ZStack {
            // Background
            Color.white
                .ignoresSafeArea()
            
            VStack(spacing: 32) {
                Spacer()
                
                // Success Icon
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 80))
                    .foregroundColor(AppColors.greenColor)
                
                // Title
                Text("Booking Confirmed")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.black)
                
                // Description
                VStack(spacing: 8) {
                    Text("Your ride has been booked successfully.")
                        .font(.system(size: 16))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                    
                    // Only show this message if driver is NOT assigned yet
                    if !hasDriverAssigned {
                        Text("We'll notify you as soon as a driver is assigned.")
                            .font(.system(size: 16))
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                    }
                }
                
                Spacer()
                
                // OK Button
                Button(action: onOK) {
                    Text("OK")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(AppColors.primaryOrange)
                        .cornerRadius(12)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 40)
            }
        }
    }
}

#Preview {
    BookingSuccessScreen(onOK: {}, hasDriverAssigned: false)
}
