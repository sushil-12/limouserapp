import SwiftUI

struct RideCompletionBottomSheet: View {
    @Binding var isPresented: Bool
    @State private var selectedRating: Int = 0
    @State private var feedbackText: String = ""
    @State private var isSubmitting: Bool = false
    @Binding var showTextField: Bool
    
    let onRatingSubmitted: (Int, String?) -> Void
    var onClose: (() -> Void)? = nil
    
    init(
        isPresented: Binding<Bool>,
        showTextField: Binding<Bool> = .constant(false),
        onRatingSubmitted: @escaping (Int, String?) -> Void,
        onClose: (() -> Void)? = nil
    ) {
        self._isPresented = isPresented
        self._showTextField = showTextField
        self.onRatingSubmitted = onRatingSubmitted
        self.onClose = onClose
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                // Green checkmark circle
                Circle()
                    .fill(Color.green)
                    .frame(width: 80, height: 80)
                    .overlay(
                        Image(systemName: "checkmark")
                            .font(.system(size: 40, weight: .bold))
                            .foregroundColor(.white)
                    )
                    .padding(.top, 20)
                
                // Title - Orange color
                Text("Ride Completed")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(Color.orange)
                
                // Subtitle
                Text("Hope you enjoyed your ride!")
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                
                // Rating section
                VStack(spacing: 16) {
                    Text("Rate your experience with 1800Limo")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.black)
                    
                    // Star rating
                    HStack(spacing: 12) {
                        ForEach(1...5, id: \.self) { index in
                            Button(action: {
                                withAnimation(.easeInOut(duration: 0.2)) {
                                    selectedRating = index
                                    showTextField = (index > 0 && index <= 3)
                                    
                                    // Auto-close if rating > 3
                                    if index > 3 {
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                            submitRating()
                                        }
                                    }
                                }
                            }) {
                                Image(systemName: index <= selectedRating ? "star.fill" : "star")
                                    .font(.system(size: 32))
                                    .foregroundColor(index <= selectedRating ? .black : .gray.opacity(0.3))
                                    .frame(width: 40, height: 40)
                            }
                        }
                    }
                }
                .padding(.top, 8)
                
                // Feedback text field (only shown if rating <= 3 and rating > 0)
                if showTextField {
                    VStack(alignment: .leading, spacing: 8) {
                        TextField("Type feedback here...", text: $feedbackText, axis: .vertical)
                            .textFieldStyle(PlainTextFieldStyle())
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.white)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                    )
                            )
                            .lineLimit(3...6)
                    }
                    .padding(.top, 8)
                    .transition(.asymmetric(
                        insertion: .opacity.combined(with: .move(edge: .top)),
                        removal: .opacity.combined(with: .move(edge: .top))
                    ))
                }
                
                // Action buttons
                HStack(spacing: 12) {
                    // Close button (left, white)
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            isPresented = false
                        }
                        
                        // Navigate back to dashboard after closing
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                            onClose?()
                        }
                    }) {
                        Text("Close")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(Color.white)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                    )
                            )
                    }
                    
                    // Submit button (right, orange)
                    Button(action: {
                        submitRating()
                    }) {
                        HStack {
                            if isSubmitting {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    .scaleEffect(0.8)
                            } else {
                                Text("Submit")
                                    .font(.system(size: 16, weight: .semibold))
                            }
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.orange)
                        )
                    }
                    .disabled(selectedRating == 0 || isSubmitting || (selectedRating <= 3 && feedbackText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty))
                    .opacity((selectedRating == 0 || (selectedRating <= 3 && feedbackText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)) ? 0.5 : 1.0)
                }
                .padding(.top, 24)
                .padding(.bottom, 32)
            }
            .padding(.horizontal, 24)
            .frame(maxWidth: .infinity)
        }
        .scrollBounceBehavior(.basedOnSize)
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .background(Color.white)
        // Tap anywhere on sheet to dismiss keyboard
        .onTapGesture {
            dismissKeyboard()
        }
    }
    
    private func submitRating() {
        guard selectedRating > 0 else { return }
        
        // If rating > 3, feedback is not required
        if selectedRating > 3 {
            isSubmitting = true
            
            // Simulate API call delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                isSubmitting = false
                let feedback = selectedRating <= 3 ? feedbackText : nil
                onRatingSubmitted(selectedRating, feedback)
                
                // Close sheet
                withAnimation(.easeInOut(duration: 0.3)) {
                    isPresented = false
                }
            }
        } else {
            // For rating <= 3, require feedback
            guard !feedbackText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
            
            isSubmitting = true
            
            // Simulate API call delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                isSubmitting = false
                onRatingSubmitted(selectedRating, feedbackText)
                
                // Close sheet
                withAnimation(.easeInOut(duration: 0.3)) {
                    isPresented = false
                }
            }
        }
    }

    private func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

// MARK: - Preview
struct RideCompletionBottomSheet_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Color.gray.opacity(0.3)
                .ignoresSafeArea()
            
            VStack {
                Spacer()
                RideCompletionBottomSheet(
                    isPresented: .constant(true),
                    showTextField: .constant(false),
                    onRatingSubmitted: { rating, feedback in
                        print("Rating: \(rating), Feedback: \(feedback ?? "none")")
                    },
                    onClose: {
                        print("Close tapped")
                    }
                )
            }
        }
    }
}

