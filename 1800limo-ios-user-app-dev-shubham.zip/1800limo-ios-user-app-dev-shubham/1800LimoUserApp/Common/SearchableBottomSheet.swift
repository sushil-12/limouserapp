//
//  SearchableBottomSheet.swift
//  1800LimoUserApp
//
//  Created by AI Assistant
//

import SwiftUI

// MARK: - Searchable Item Protocol
protocol SearchableItem: Identifiable, Equatable {
    var searchText: String { get }
    var displayText: String { get }
    var subtitle: String? { get }
}

// MARK: - Searchable Bottom Sheet Component
struct SearchableBottomSheet<T: SearchableItem>: View {
    let title: String
    let items: [T]
    @Binding var selectedItem: T?
    @Binding var isPresented: Bool
    let onItemSelected: (T) -> Void
    let initialItemLimit: Int?
    let onSearchChanged: ((String) -> Void)?
    
    @State private var searchText = ""
    @State private var filteredItems: [T] = []
    
    init(title: String, items: [T], selectedItem: Binding<T?>, isPresented: Binding<Bool>, onItemSelected: @escaping (T) -> Void, initialItemLimit: Int? = nil, onSearchChanged: ((String) -> Void)? = nil) {
        self.title = title
        self.items = items
        self._selectedItem = selectedItem
        self._isPresented = isPresented
        self.onItemSelected = onItemSelected
        self.initialItemLimit = initialItemLimit
        self.onSearchChanged = onSearchChanged
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header with title and close button
            Spacer().frame(height:8)
            HStack {
                Spacer()
                Text(title)
                    .font(.headline)
                    .padding()
                Spacer()
            }
            
            // Search Bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                    .font(.system(size: 16))
                
                TextField("Search...", text: $searchText)
                    .font(.system(size: 16))
                    .textFieldStyle(PlainTextFieldStyle())
                
                if !searchText.isEmpty {
                    Button(action: {
                        searchText = ""
                        // Clear search will trigger onChange which will call API
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.gray)
                            .font(.system(size: 16))
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            
            // Items List
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(filteredItems) { item in
                        Button(action: {
                            selectedItem = item
                            onItemSelected(item)
                            isPresented = false
                        }) {
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.displayText)
                                        .font(.system(size: 16))
                                        .foregroundColor(.black)
                                        .multilineTextAlignment(.leading)
                                    
                                    if let subtitle = item.subtitle, !subtitle.isEmpty {
                                        Text(subtitle)
                                            .font(.system(size: 14))
                                            .foregroundColor(.gray)
                                            .multilineTextAlignment(.leading)
                                    }
                                }
                                
                                Spacer()
                                
                                if selectedItem?.id == item.id {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundColor(.orange)
                                }
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        if item.id != filteredItems.last?.id {
                            Divider()
                                .padding(.leading, 12)
                        }
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(Color.white)
        .onAppear {
            print("🔍 SearchableBottomSheet appeared with \(items.count) items")
            filterItems()
        }
        .onChange(of: items) { newItems in
            print("🔍 SearchableBottomSheet items changed to \(newItems.count) items")
            filterItems()
        }
        .onChange(of: searchText) { newValue in
            print("🔍 Search text changed to: '\(newValue)'")
            filterItems()
            // Call API for both empty and non-empty search
            onSearchChanged?(newValue)
        }
    }
    
    private func filterItems() {
        print("🔍 filterItems called - searchText: '\(searchText)', items count: \(items.count)")
        
        if searchText.isEmpty {
            // When no search, show all items with selected item at top
            var itemsToShow = items
            
            // If there's a selected item, put it at the top
            if let selected = selectedItem {
                itemsToShow = itemsToShow.filter { $0.id != selected.id }
                itemsToShow.insert(selected, at: 0)
            }
            
            filteredItems = itemsToShow
            print("🔍 Showing all items: \(filteredItems.count) items")
        } else {
            // When searching, show all current items
            // The API search will update the items array, so we show all current items
            filteredItems = items
            print("🔍 Showing items for API search: \(filteredItems.count) items for search '\(searchText)'")
        }
    }
}

// MARK: - Preview
#Preview {
    struct PreviewItem: SearchableItem {
        let id = UUID()
        let searchText: String
        let displayText: String
        let subtitle: String?
        
        static func == (lhs: PreviewItem, rhs: PreviewItem) -> Bool {
            lhs.id == rhs.id
        }
    }
    
    let sampleItems = [
        PreviewItem(searchText: "LAX", displayText: "LAX - Los Angeles International Airport", subtitle: "Los Angeles, USA"),
        PreviewItem(searchText: "JFK", displayText: "JFK - John F. Kennedy International Airport", subtitle: "New York, USA"),
        PreviewItem(searchText: "LHR", displayText: "LHR - London Heathrow Airport", subtitle: "London, UK"),
        PreviewItem(searchText: "CDG", displayText: "CDG - Charles de Gaulle Airport", subtitle: "Paris, France"),
        PreviewItem(searchText: "NRT", displayText: "NRT - Narita International Airport", subtitle: "Tokyo, Japan")
    ]
    
    return SearchableBottomSheet<PreviewItem>(
        title: "Select Airport",
        items: sampleItems,
        selectedItem: .constant(nil),
        isPresented: .constant(true),
        onItemSelected: { _ in },
        initialItemLimit: 5
    )
}
