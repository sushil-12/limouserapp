//
//  _800LimoUserAppApp.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI
import Firebase
import FirebaseAnalytics

@main
struct _800LimoUserAppApp: App {
    // Initialize notification manager when app starts
    @StateObject private var notificationManager = LocalNotificationManager.shared
    @StateObject private var firebaseService = FirebasePushNotificationService.shared
    
    // Add AppDelegate for APNs token handling
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    init() {
        // Configure Firebase
        FirebaseApp.configure()
        
        // Configure Firebase Analytics
        Analytics.setAnalyticsCollectionEnabled(true)
    }
    
    var body: some Scene {
        WindowGroup {
            SplashScreen()
                .preferredColorScheme(.light) // Force light mode
                .onAppear {
                    // Ensure AppDelegate is properly registered
                    print("App launched with AppDelegate: \(delegate)")
                    // Clear badge when app launches
                    LocalNotificationManager.shared.clearBadge()
                }
        }
    }
}
