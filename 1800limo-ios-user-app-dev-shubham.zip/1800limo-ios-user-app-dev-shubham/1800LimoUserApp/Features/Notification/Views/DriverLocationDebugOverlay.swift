import SwiftUI
import CoreLocation

struct DriverLocationDebugOverlay: View {
    @ObservedObject var socketService: SimpleSocketIOService
    @State private var isExpanded = false
    
    var body: some View {
        VStack {
            if socketService.showDebugOverlay {
                VStack(alignment: .leading, spacing: 8) {
                    // Header
                    HStack {
                        Image(systemName: "location.circle.fill")
                            .foregroundColor(.green)
                        Text("Driver Location Debug")
                            .font(.headline)
                            .fontWeight(.bold)
                        
                        Spacer()
                        
                        Button(action: {
                            isExpanded.toggle()
                        }) {
                            Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                                .foregroundColor(.blue)
                        }
                        
                        Button(action: {
                            socketService.clearDebugEvents()
                        }) {
                            Image(systemName: "trash")
                                .foregroundColor(.red)
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.black.opacity(0.8))
                    .foregroundColor(.white)
                    .cornerRadius(8)
                    
                    if isExpanded {
                        // Connection Status
                        HStack {
                            Circle()
                                .fill(socketService.isConnected ? Color.green : Color.red)
                                .frame(width: 8, height: 8)
                            Text(socketService.isConnected ? "Connected" : "Disconnected")
                                .font(.caption)
                                .foregroundColor(.white)
                            
                            Spacer()
                            
                            Text("Events: \(socketService.debugDriverLocationEvents.count)")
                                .font(.caption)
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 4)
                        .background(Color.black.opacity(0.6))
                        .cornerRadius(6)
                        
                        // Current User Location
                        if let userLocation = socketService.currentUserLocation {
                            HStack {
                                Image(systemName: "person.circle.fill")
                                    .foregroundColor(.blue)
                                Text("User: \(String(format: "%.6f", userLocation.latitude)), \(String(format: "%.6f", userLocation.longitude))")
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 4)
                            .background(Color.black.opacity(0.6))
                            .cornerRadius(6)
                        }
                        
                        // Events List
                        ScrollView {
                            LazyVStack(spacing: 4) {
                                ForEach(socketService.debugDriverLocationEvents.reversed()) { event in
                                    DriverLocationDebugEventView(event: event)
                                }
                            }
                        }
                        .frame(maxHeight: 200)
                        .background(Color.black.opacity(0.6))
                        .cornerRadius(6)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(Color.black.opacity(0.9))
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 2)
            }
            
            Spacer()
        }
    }
}

struct DriverLocationDebugEventView: View {
    let event: DriverLocationDebugEvent
    
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(event.formattedTime)
                    .font(.caption2)
                    .foregroundColor(.green)
                
                Spacer()
                
                Text(event.eventType)
                    .font(.caption2)
                    .foregroundColor(.orange)
                    .padding(.horizontal, 4)
                    .padding(.vertical, 1)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(3)
            }
            
            HStack {
                Text("📍 \(event.locationString)")
                    .font(.caption2)
                    .foregroundColor(.white)
                
                Spacer()
                
                if let bookingId = event.bookingId {
                    Text("ID: \(bookingId)")
                        .font(.caption2)
                        .foregroundColor(.cyan)
                }
            }
            
            HStack {
                if let accuracy = event.accuracy {
                    Text("Acc: \(String(format: "%.1f", accuracy))m")
                        .font(.caption2)
                        .foregroundColor(.yellow)
                }
                
                if let heading = event.heading {
                    Text("H: \(String(format: "%.0f", heading))°")
                        .font(.caption2)
                        .foregroundColor(.yellow)
                }
                
                if let speed = event.speed {
                    Text("S: \(String(format: "%.1f", speed))km/h")
                        .font(.caption2)
                        .foregroundColor(.yellow)
                }
                
                Spacer()
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(Color.black.opacity(0.4))
        .cornerRadius(4)
    }
}

#Preview {
    DriverLocationDebugOverlay(socketService: SimpleSocketIOService.shared)
}
