import Foundation
import SocketIO
import UserNotifications
import CoreLocation
import SwiftUI
import UIKit




// MARK: - Connection Status Enum
enum ConnectionStatus {
    case connected
    case disconnected
    case connecting
    case reconnecting
    case error
    
    var color: String {
        switch self {
        case .connected:
            return "green"
        case .disconnected:
            return "red"
        case .connecting:
            return "orange"
        case .reconnecting:
            return "yellow"
        case .error:
            return "red"
        }
    }
    
    var description: String {
        switch self {
        case .connected:
            return "Connected"
        case .disconnected:
            return "Disconnected"
        case .connecting:
            return "Connecting..."
        case .reconnecting:
            return "Reconnecting..."
        case .error:
            return "Connection Error"
        }
    }
}

// MARK: - Toast Type Enum
enum ToastType {
    case success
    case error
    case warning
    case info
    case chat
    
    var color: String {
        switch self {
        case .success:
            return "green"
        case .error:
            return "red"
        case .warning:
            return "orange"
        case .info:
            return "blue"
        case .chat:
            return "indigo"
        }
    }
    
    var icon: String {
        switch self {
        case .success:
            return "checkmark.circle.fill"
        case .error:
            return "xmark.circle.fill"
        case .warning:
            return "exclamationmark.triangle.fill"
        case .info:
            return "info.circle.fill"
        case .chat:
            return "bubble.left.and.bubble.right.fill"
        }
    }
}

// MARK: - Live Ride Data Model
struct LiveRideData {
    let bookingId: String
    let driverId: String
    let customerId: String
    let status: String
    let driverLatitude: Double
    let driverLongitude: Double
    let pickupLatitude: Double
    let pickupLongitude: Double
    let dropoffLatitude: Double
    let dropoffLongitude: Double
    let pickupAddress: String
    let dropoffAddress: String
    let timestamp: String
    let title: String
    let message: String
    let driverName: String?
    let driverPhone: String?
    
    init(
        bookingId: String,
        driverId: String,
        customerId: String,
        status: String,
        driverLatitude: Double,
        driverLongitude: Double,
        pickupLatitude: Double,
        pickupLongitude: Double,
        dropoffLatitude: Double,
        dropoffLongitude: Double,
        pickupAddress: String,
        dropoffAddress: String,
        timestamp: String,
        title: String,
        message: String,
        driverName: String? = nil,
        driverPhone: String? = nil
    ) {
        self.bookingId = bookingId
        self.driverId = driverId
        self.customerId = customerId
        self.status = status
        self.driverLatitude = driverLatitude
        self.driverLongitude = driverLongitude
        self.pickupLatitude = pickupLatitude
        self.pickupLongitude = pickupLongitude
        self.dropoffLatitude = dropoffLatitude
        self.dropoffLongitude = dropoffLongitude
        self.pickupAddress = pickupAddress
        self.dropoffAddress = dropoffAddress
        self.timestamp = timestamp
        self.title = title
        self.message = message
        self.driverName = driverName
        self.driverPhone = driverPhone
    }
}

// MARK: - Driver Location Update Model
struct DriverLocationUpdate {
    let latitude: Double
    let longitude: Double
    let bookingId: String?
    let customerId: String?
    let accuracy: Double?
    let heading: Double?
    let speed: Double?
    let timestamp: Double
}

// MARK: - Debug Event Model
struct DriverLocationDebugEvent: Identifiable {
    let id = UUID()
    let timestamp: Date
    let latitude: Double
    let longitude: Double
    let bookingId: String?
    let customerId: String?
    let accuracy: Double?
    let heading: Double?
    let speed: Double?
    let eventType: String
    
    var formattedTime: String {
        let formatter = DateFormatter()
        formatter.timeStyle = .medium
        return formatter.string(from: timestamp)
    }
    
    var locationString: String {
        return String(format: "%.6f, %.6f", latitude, longitude)
    }
}

// MARK: - Value Normalization Helpers
private func normalizedString(from value: Any?) -> String? {
    switch value {
    case let string as String:
        let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    case let int as Int:
        return String(int)
    case let double as Double:
        return String(double)
    case let number as NSNumber:
        return number.stringValue
    default:
        return nil
    }
}

private func normalizedDouble(from value: Any?) -> Double? {
    if let doubleValue = value as? Double {
        return doubleValue
    }
    if let intValue = value as? Int {
        return Double(intValue)
    }
    if let numberValue = value as? NSNumber {
        return numberValue.doubleValue
    }
    if let stringValue = value as? String {
        let trimmed = stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        return Double(trimmed)
    }
    return nil
}

// MARK: - Active Ride Data Model
struct ActiveRideData {
    let bookingId: Int
    let status: String
    let statusDisplay: String
    let customer: CustomerInfo
    let driver: DriverInfo
    let vehicle: VehicleInfo?
    let locations: RideLocationInfo
    let tripDetails: TripDetails
    let specialRequirements: SpecialRequirements
    let amenities: [String]
    let instructions: String
    let timestamps: Timestamps
    let metadata: Metadata
}

struct CustomerInfo {
    let id: Int
    let name: String
    let email: String?
    let phone: String
}

struct DriverInfo {
    let id: Int
    let name: String
    let phone: String
    let rating: Int
}

struct VehicleInfo {
    let id: Int?
    let make: String?
    let model: String?
    let year: String?
    let color: String?
    let licensePlate: String?
}

struct RideLocationInfo {
    let pickup: PickupLocation
    let dropoff: DropoffLocation
}

struct PickupLocation {
    let address: String
    let latitude: String
    let longitude: String
    let datetime: String
}

struct DropoffLocation {
    let address: String
    let latitude: String
    let longitude: String
}

struct TripDetails {
    let passengers: Int
    let luggage: Int
    let distance: String
    let duration: String
    let estimatedFare: Double?
    let actualFare: Double?
    let paymentStatus: String
    let paymentMethod: String?
}

struct SpecialRequirements {
    let childCertified: Bool
    let babySeat: Bool
    let boosterSeat: Bool
    let petFriendly: Bool
    let handicap: Bool
}

struct Timestamps {
    let createdAt: String
    let updatedAt: String
    let acceptedOn: String?
}

struct Metadata {
    let affiliateId: Int
    let waitingTime: Int
    let driverLanguages: [String]
    let driverDresses: [String]
}

class SimpleSocketIOService: ObservableObject {
    static let shared = SimpleSocketIOService()
    
    private var manager: SocketManager?
    private var socket: SocketIOClient?
    private var reconnectTimer: Timer?
    private var connectionMonitorTimer: Timer?
    private var heartbeatTimer: Timer?
    
    // Connection state management
    private enum InternalConnectionState {
        case disconnected
        case connecting
        case connected
        case reconnecting
    }
    
    private var internalConnectionState: InternalConnectionState = .disconnected
    private let connectionQueue = DispatchQueue(label: "com.limo.socket.connection", qos: .userInitiated)
    private var isConnectionInProgress = false
    private var eventHandlersSetup = false
    
    @Published var isConnected = false
    @Published var socketId: String = "Not Connected"
    @Published var liveRideData: LiveRideData?
    @Published var shouldShowRideInProgress = false
    @Published var driverLocationUpdate: DriverLocationUpdate?
    @Published var activeRideData: ActiveRideData?
    @Published var shouldNavigateToActiveRide = false
    
    // MARK: - Connection Monitoring Properties
    @Published var connectionStatus: ConnectionStatus = .disconnected
    @Published var lastConnectionTime: Date?
    @Published var connectionAttempts: Int = 0
    @Published var isReconnecting: Bool = false
    
    // MARK: - Debug Properties
    @Published var debugDriverLocationEvents: [DriverLocationDebugEvent] = []
    @Published var showDebugOverlay = false
    @Published var currentUserLocation: CLLocationCoordinate2D?
    
    // MARK: - Toast Properties
    @Published var showToast = false
    @Published var toastMessage = ""
    @Published var toastTitle: String?
    @Published var toastDetail: String?
    @Published var toastAvatarText: String?
    @Published var toastCountdown: Int?
    @Published var toastType: ToastType = .info
    @Published var toastIsInteractive: Bool = false
    
    private var toastCountdownTimer: Timer?
    private var currentToastID = UUID()
    
    private enum ToastAction {
        case openChat(ChatToastActionData)
    }
    
    private struct ChatToastActionData {
        let bookingId: Int
        let driverId: String
        let driverName: String
    }
    
    private var toastAction: ToastAction?
    private var lifecycleObservers: [NSObjectProtocol] = []
    
    // Track processed chat messages to prevent duplicates
    private var processedChatMessageIds = Set<String>()
    private let processedMessagesQueue = DispatchQueue(label: "com.limo.processedMessages", attributes: .concurrent)
    
    // private let serverURL = "https://service-1800limo.onrender.com"
     private let serverURL = "https://limortservice.infodevbox.com"
//    private let serverURL = "http://10.10.60.196:3000"
//    private let serverURL = "https://5324aaae0bdd.ngrok-free.app"

    private let notificationManager = LocalNotificationManager.shared
    
    private init() {
        // Defer socket setup to avoid initialization crashes
        // Setup will happen lazily when needed
        setupAppLifecycleObservers()
    }
    
    private func setupSocket() {
        // Ensure this runs on main thread
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in
                self?.setupSocket()
            }
            return
        }
        
        // Get dynamic user ID from StorageManager with detailed logging
        let userId = StorageManager.shared.getUserIdString() ?? "unknown"
        print("🔌 SimpleSocketIOService: Setting up socket with userId: \(userId)")
        
        if userId == "unknown" {
            print("⚠️ SimpleSocketIOService: Cannot setup socket - User ID is unknown")
            return
        }
        
        // Only create new manager if we don't have one or user ID changed
        let needsNewManager = manager == nil || socket == nil
        
        if needsNewManager {
            guard let url = URL(string: serverURL) else {
                print("❌ SimpleSocketIOService: Invalid server URL: \(serverURL)")
                return
            }
            
            manager = SocketManager(socketURL: url, config: [
                .log(false),
                .compress,
                .connectParams([
                    "client": "ios_app",
                    "secret": "limoapi_notifications_secret_2024_xyz789",
                    "userId": userId,
                    "userType": "customer"
                ]),
                .forceNew(true),
                .reconnects(true)
            ])
            
            socket = manager?.defaultSocket
            
            // Setup event handlers only once when socket is created
            if !eventHandlersSetup {
                setupEventHandlers()
                eventHandlersSetup = true
            }
        } else {
            // Update connection params if user ID changed
            // Note: SocketManager doesn't support dynamic param updates, so we keep existing connection
            print("🔌 SimpleSocketIOService: Socket manager already exists, reusing connection")
        }
    }

    private func setupAppLifecycleObservers() {
        guard lifecycleObservers.isEmpty else { return }
        let center = NotificationCenter.default
        
        let willEnter = center.addObserver(forName: UIApplication.willEnterForegroundNotification, object: nil, queue: .main) { [weak self] _ in
            self?.handleAppWillEnterForeground()
        }
        
        let didBecomeActive = center.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self] _ in
            self?.handleAppDidBecomeActive()
        }
        
        let didEnterBackground = center.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in
            self?.handleAppDidEnterBackground()
        }
        
        lifecycleObservers = [willEnter, didBecomeActive, didEnterBackground]
    }

    private func handleAppWillEnterForeground() {
        print("🔔 SimpleSocketIOService: App will enter foreground - ensuring socket connection")
        // Clear badge when app enters foreground
        notificationManager.clearBadge()
        ensureConnection()
    }
    
    private func handleAppDidBecomeActive() {
        print("🔔 SimpleSocketIOService: App became active - verifying subscriptions and room membership")
        // Clear badge when app becomes active
        notificationManager.clearBadge()
        ensureConnection()
    }
    
    private func handleAppDidEnterBackground() {
        print("🔕 SimpleSocketIOService: App entered background - pausing connection monitoring")
        stopConnectionMonitoring()
    }
    
    private func setupEventHandlers() {
        guard let socket = socket else { 
            print("⚠️ SimpleSocketIOService: Cannot setup event handlers - socket is nil")
            return 
        }
        
        print("🔌 SimpleSocketIOService: Setting up event handlers")
        
        // Only remove handlers if they were already set up
        // This prevents losing subscriptions on reconnection
        if eventHandlersSetup {
            socket.removeAllHandlers()
        }
        
        // Connection events
        socket.on(clientEvent: .connect) { [weak self] data, ack in
            DispatchQueue.main.async {
                guard let self = self else { return }
                
                self.isConnected = true
                self.internalConnectionState = .connected
                self.connectionStatus = .connected
                self.lastConnectionTime = Date()
                self.connectionAttempts = 0
                self.isReconnecting = false
                self.isConnectionInProgress = false
                
                // Get socket ID for debugging
                if let socketId = self.socket?.sid {
                    self.socketId = socketId
                    print("✅ SimpleSocketIOService: Socket Connected - ID: \(socketId)")
                }
                
                // Join room with current user ID
                self.joinUserRoom()
                
                // Start connection monitoring if not already active
                if !self.isConnectionMonitoringActive {
                    self.startConnectionMonitoring()
                }
            }
        }
        
        // Listen for status changes
        socket.on(clientEvent: .statusChange) { [weak self] data, ack in
            DispatchQueue.main.async {
                if let statusData = data.first as? [String: Any],
                   let status = statusData["status"] as? String {
                    if status == "connected" {
                        self?.isConnected = true
                        self?.connectionStatus = .connected
                        self?.lastConnectionTime = Date()
                    

                        
                    } else if status == "disconnected" {
                        self?.isConnected = false
                        self?.connectionStatus = .disconnected
                    }
                }
            }
        }
        
        socket.on(clientEvent: .disconnect) { [weak self] data, ack in
            DispatchQueue.main.async {
                guard let self = self else { return }
                
                print("🔌 SimpleSocketIOService: Socket Disconnected")
                self.isConnected = false
                self.internalConnectionState = .disconnected
                self.connectionStatus = .disconnected
                self.socketId = "Disconnected"
                self.isConnectionInProgress = false
                
                // Only start reconnection if we're not explicitly disconnecting for logout
                // The reconnect logic will handle automatic reconnection
                if self.internalConnectionState != .disconnected {
                    self.startImmediateReconnection()
                }
            }
        }
        
        socket.on(clientEvent: .reconnect) { [weak self] data, ack in
            DispatchQueue.main.async {
                guard let self = self else { return }
                
                print("✅ SimpleSocketIOService: Socket Reconnected")
                self.isConnected = true
                self.internalConnectionState = .connected
                self.connectionStatus = .connected
                self.lastConnectionTime = Date()
                self.isReconnecting = false
                self.isConnectionInProgress = false
                self.connectionAttempts = 0
                
                // Get socket ID for debugging
                if let socketId = self.socket?.sid {
                    self.socketId = socketId
                    print("✅ SimpleSocketIOService: Socket Reconnected - ID: \(socketId)")
                }
                
                // Rejoin room with current user ID after reconnection
                self.joinUserRoom()
            }
        }
        
        socket.on("user.notifications") { [weak self] data, ack in
            DispatchQueue.main.async {
                 
                print("RideDrive---user.notifications")
                 
                
                if let notificationData = data.first as? [String: Any] {
                    print("RideDrive---user.notifications payload: \(notificationData)")
                    let typeZenga = notificationData["type"] as? String
                    print("RideDrive---typeZenga---> \(String(describing: typeZenga))")
                    
                    // Check if this is a chat message and forward to ChatService
                    // Also check if the notification type itself is "user_notification" with chat_message in data
                    let isChatMessage = {
                        // Check if data contains chat_message
                        if let messageData = notificationData["data"] as? [String: Any],
                           let messageType = messageData["type"] as? String,
                           messageType == "chat_message" {
                            return true
                        }
                        // Check if the notification type is chat_message
                        if let notificationType = notificationData["type"] as? String,
                           notificationType == "chat_message" {
                            return true
                        }
                        return false
                    }()
                    
                    if isChatMessage {
                        print("💬 SimpleSocketIOService: Forwarding chat message to ChatService")
                        
                        // Extract message data from either data field or notificationData itself
                        var messageData: [String: Any]?
                        if let dataDict = notificationData["data"] as? [String: Any],
                           let messageType = dataDict["type"] as? String,
                           messageType == "chat_message" {
                            messageData = dataDict
                        } else if notificationData["type"] as? String == "chat_message" {
                            messageData = notificationData
                        }
                        
                        guard let messageData = messageData else {
                            print("❌ SimpleSocketIOService: Could not extract message data")
                            return
                        }
                        
                        // Extract message ID for deduplication
                        let messageId = (messageData["_id"] as? String) ?? 
                                      (messageData["id"] as? String) ?? 
                                      UUID().uuidString
                        
                        // Check if this message has already been processed
                        var alreadyProcessed = false
                        self?.processedMessagesQueue.sync {
                            alreadyProcessed = self?.processedChatMessageIds.contains(messageId) ?? false
                            if !alreadyProcessed {
                                self?.processedChatMessageIds.insert(messageId)
                                // Clean up old message IDs (keep only last 100)
                                if let count = self?.processedChatMessageIds.count, count > 100 {
                                    // Convert Set to Array, take the first (count - 100) elements, and remove them
                                    let allIds = Array(self?.processedChatMessageIds ?? [])
                                    let idsToRemove = Array(allIds.prefix(count - 100))
                                    idsToRemove.forEach { self?.processedChatMessageIds.remove($0) }
                                }
                            }
                        }
                        
                        if alreadyProcessed {
                            print("💬 SimpleSocketIOService: Chat message already processed (ID: \(messageId)), skipping duplicate")
                            return
                        }
                        
                        print("💬 SimpleSocketIOService: Message data: \(messageData)")
                        
                        // Extract bookingId to check if user is on that chat screen
                        var chatBookingId: Int?
                        if let bookingId = messageData["bookingId"] as? Int {
                            chatBookingId = bookingId
                        } else if let bookingIdStr = messageData["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                            chatBookingId = bookingId
                        }
                        
                        // Check if user is on chat screen - if not, show notification
                        let isOnChatScreen = ScreenTracker.shared.isOnChatScreen(for: chatBookingId)
                        if !isOnChatScreen {
                            // User is not on chat screen, show notification
                            let title = notificationData["title"] as? String ?? "New Message"
                            let message = notificationData["message"] as? String ?? "You have a new message"
                            print("💬 SimpleSocketIOService: User is NOT on chat screen - showing notification")
                            self?.notificationManager.showNotificationEvent(title: title, body: message)
                        } else {
                            print("💬 SimpleSocketIOService: User is on chat screen - suppressing notification")
                        }
                        
                        // Forward message data directly to ChatService (always process for UI update)
                        // Skip NotificationCenter post since we're handling notifications here
                        ChatService.shared.processChatMessage(data: messageData, skipNotificationCenterPost: true)
                        return // CRITICAL: Return early to prevent duplicate processing
                    }
                    
                    // Handle non-chat notifications
                    if let type = notificationData["type"] as? String,
                       (type == "live_ride" || type == "live_ride_do") {
                        print("RideDrive---1")
                        self?.handleLiveRideNotification(notificationData)
                    } else if let type = notificationData["type"] as? String, type == "user_notification" {
                        // Skip handleNotificationEvent for user_notification type - it's already handled above or will be handled by user_notification event
                        print("💬 SimpleSocketIOService: Skipping handleNotificationEvent for user_notification type (already processed or will be handled separately)")
                    } else {
                        print("RideDrive---2")
                        self?.handleNotificationEvent(data: data)
                    }
                } else {
                    print("RideDrive---user.notifications payload raw data: \(data)")
                }
            }
        }
        
        // Listen for direct user_notification events (chat messages)
        // NOTE: This handler is for direct user_notification events that don't come through user.notifications
        // If a message comes through user.notifications, it will be handled there and this won't be called
        socket.on("user_notification") { [weak self] data, ack in
            DispatchQueue.main.async {
                print("💬 SimpleSocketIOService: Received direct user_notification event")
                
                // Check if this is a chat message
                if let messageData = data.first as? [String: Any] {
                    // Check if it's a chat message in the data field
                    var isChatMessage = false
                    var actualMessageData: [String: Any]?
                    
                    if let messageType = messageData["type"] as? String,
                       messageType == "chat_message" {
                        isChatMessage = true
                        actualMessageData = messageData
                    } else if let nestedData = messageData["data"] as? [String: Any],
                              let messageType = nestedData["type"] as? String,
                              messageType == "chat_message" {
                        isChatMessage = true
                        actualMessageData = nestedData
                    }
                    
                    if isChatMessage, let messageData = actualMessageData {
                        // Extract message ID for deduplication
                        let messageId = (messageData["_id"] as? String) ?? 
                                      (messageData["id"] as? String) ?? 
                                      UUID().uuidString
                        
                        // Check if this message has already been processed
                        var alreadyProcessed = false
                        self?.processedMessagesQueue.sync {
                            alreadyProcessed = self?.processedChatMessageIds.contains(messageId) ?? false
                            if !alreadyProcessed {
                                self?.processedChatMessageIds.insert(messageId)
                                // Clean up old message IDs (keep only last 100)
                                if let count = self?.processedChatMessageIds.count, count > 100 {
                                    // Convert Set to Array, take the first (count - 100) elements, and remove them
                                    let allIds = Array(self?.processedChatMessageIds ?? [])
                                    let idsToRemove = Array(allIds.prefix(count - 100))
                                    idsToRemove.forEach { self?.processedChatMessageIds.remove($0) }
                                }
                            }
                        }
                        
                        if alreadyProcessed {
                            print("💬 SimpleSocketIOService: Chat message already processed (ID: \(messageId)), skipping duplicate from user_notification")
                            return
                        }
                        
                        print("💬 SimpleSocketIOService: Processing direct chat message from user_notification event")
                        
                        // Extract bookingId to check if user is on that chat screen
                        var chatBookingId: Int?
                        if let bookingId = messageData["bookingId"] as? Int {
                            chatBookingId = bookingId
                        } else if let bookingIdStr = messageData["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                            chatBookingId = bookingId
                        }
                        
                        // Check if user is on chat screen - if not, show notification
                        let isOnChatScreen = ScreenTracker.shared.isOnChatScreen(for: chatBookingId)
                        if !isOnChatScreen {
                            // User is not on chat screen, show notification
                            let title = (data.first as? [String: Any])?["title"] as? String ?? "New Message"
                            let message = (data.first as? [String: Any])?["message"] as? String ?? messageData["message"] as? String ?? "You have a new message"
                            print("💬 SimpleSocketIOService: User is NOT on chat screen - showing notification via user_notification")
                            self?.notificationManager.showNotificationEvent(title: title, body: message)
                        } else {
                            print("💬 SimpleSocketIOService: User is on chat screen - suppressing notification via user_notification")
                        }
                        
                        // Forward message data directly to ChatService (always process for UI update)
                        // Skip NotificationCenter post since we're handling notifications here
                        ChatService.shared.processChatMessage(data: messageData, skipNotificationCenterPost: true)
                    } else {
                        print("💬 SimpleSocketIOService: user_notification event is not a chat message, skipping")
                    }
                }
            }
        }
        
        // Listen for driver.location.update events - CONTINUOUS DRIVER LOCATION UPDATES
        socket.on("driver.location.update") { [weak self] data, ack in
            DispatchQueue.main.async {
                 
                 
                
                if let locationData = data.first as? [String: Any] {
                    self?.handleDriverLocationUpdate(locationData)
                } else {
                     
                }
            }
        }
        
        socket.on("active_ride") { [weak self] data, ack in
            DispatchQueue.main.async {
                print("RideDrive---active_ride")
                if let rideData = data.first as? [String: Any] {
                    print("RideDrive---3")
                    self?.handleActiveRideEvent(rideData)
                    print("RideDrive---300")
                } else {
                     
                }
            }
        }
        
        // Chat-specific events (for ChatService)
        socket.on("chat.message.sent") { [weak self] data, ack in
            DispatchQueue.main.async {
                print("✅ SimpleSocketIOService: Chat message sent confirmation received")
                NotificationCenter.default.post(
                    name: NSNotification.Name("ChatMessageSent"),
                    object: nil,
                    userInfo: ["data": data]
                )
            }
        }
        
        socket.on("chat.error") { [weak self] data, ack in
            DispatchQueue.main.async {
                if let errorData = data.first as? [String: Any],
                   let message = errorData["message"] as? String {
                    print("❌ SimpleSocketIOService: Chat error: \(message)")
                    NotificationCenter.default.post(
                        name: NSNotification.Name("ChatError"),
                        object: nil,
                        userInfo: ["message": message]
                    )
                }
            }
        }
        
        // Listen for notification events - using onAny to catch all notification types
        socket.onAny { event in
            DispatchQueue.main.async {
                 
                print("RideDrive---6")
                // Post all socket events for debugging
                NotificationCenter.default.post(
                    name: NSNotification.Name("SocketEventReceived"),
                    object: nil,
                    userInfo: [
                        "eventName": event.event,
                        "data": event.items ?? []
                    ]
                )
                
                // Only handle notification-related events (excluding user.notifications and user_notification as they're handled above)
                let eventZenga = event.event
                print("RideDrive---eventZenga---> \(String(describing: eventZenga))")
                
                // Skip events that are already handled by specific handlers
                let isAlreadyHandled = event.event == "user.notifications" || event.event == "user_notification"
                
                // Check if this is a chat message notification that should be skipped
                var isChatMessageNotification = false
                if let items = event.items,
                   let firstItem = items.first as? [String: Any] {
                    // Check if it's a chat message in the data
                    if let dataDict = firstItem["data"] as? [String: Any],
                       let messageType = dataDict["type"] as? String,
                       messageType == "chat_message" {
                        isChatMessageNotification = true
                    } else if let notificationType = firstItem["type"] as? String,
                              notificationType == "chat_message" {
                        isChatMessageNotification = true
                    }
                }
                
                if !isAlreadyHandled && !isChatMessageNotification &&
                   (event.event.contains("notification") || event.event.contains("notify") || event.event.contains("alert")) {
                     
                    if let items = event.items, !self.shouldSuppressNotificationEvent(items) {
                        self.handleNotificationEvent(data: items)
                    } else {
                         
                    }
                } else if isChatMessageNotification {
                    print("💬 SimpleSocketIOService: onAny - Skipping chat message notification (already handled by specific handlers)")
                }
            }
        }
    }
    
    /// Connect to socket server (thread-safe, prevents duplicate connections)
    func connect() {
        connectionQueue.async { [weak self] in
            guard let self = self else { return }
            
            // Prevent multiple simultaneous connection attempts
            if self.isConnectionInProgress {
                print("⚠️ SimpleSocketIOService: Connection already in progress, skipping duplicate call")
                return
            }
            
            guard let socket = self.socket else {
                print("⚠️ SimpleSocketIOService: Cannot connect - socket is nil, setting up socket first")
                DispatchQueue.main.async {
                    self.setupSocket()
                    self.connect()
                }
                return
            }
            
            // Check if already connected
            if self.isConnected && self.internalConnectionState == .connected {
                print("✅ SimpleSocketIOService: Already connected, skipping")
                return
            }
            
            // Check user ID before connecting
            let currentUserId = StorageManager.shared.getUserIdString() ?? "unknown"
            if currentUserId == "unknown" {
                print("❌ SimpleSocketIOService: Cannot connect - User ID is unknown")
                DispatchQueue.main.async {
                    self.connectionStatus = .error
                }
                return
            }
            
            // Mark connection as in progress
            self.isConnectionInProgress = true
            
            DispatchQueue.main.async {
                self.internalConnectionState = .connecting
                self.connectionStatus = .connecting
                
                print("🔌 SimpleSocketIOService: Connecting to socket server...")
                socket.connect()
                
                // Reset connection in progress flag after a delay
                DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                    self.isConnectionInProgress = false
                }
            }
        }
    }
    
    func disconnect() {
        guard let socket = socket else { 
             
            return 
        }
        
        // Socket disconnection
        print("RideDrive---disconnect445")

        socket.disconnect()
         
    }
    
    /// Explicit disconnection method for logout/app termination
    func disconnectForLogout() {
        print("🔌 SimpleSocketIOService: Disconnecting for logout")
        
        connectionQueue.async { [weak self] in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.internalConnectionState = .disconnected
                self.stopConnectionMonitoring()
                
                guard let socket = self.socket else {
                    self.isConnected = false
                    self.connectionStatus = .disconnected
                    return
                }
                
                socket.disconnect()
                self.isConnected = false
                self.connectionStatus = .disconnected
                self.isConnectionInProgress = false
                self.isReconnecting = false
            }
        }
    }
    
    // MARK: - User ID Management
    /// Reconnect with new user ID (e.g., after login)
    func reconnectWithNewUserId() {
        print("🔄 SimpleSocketIOService: Reconnecting with new user ID...")
        
        connectionQueue.async { [weak self] in
            guard let self = self else { return }
            
            // Get the new user ID before reconnecting
            let newUserId = StorageManager.shared.getUserIdString() ?? "unknown"
            print("🔄 SimpleSocketIOService: Reconnect User ID: \(newUserId)")
            
            if newUserId == "unknown" {
                print("❌ SimpleSocketIOService: Cannot reconnect - User ID is unknown")
                DispatchQueue.main.async {
                    self.connectionStatus = .error
                    self.isReconnecting = false
                }
                return
            }
            
            DispatchQueue.main.async {
                // Stop all timers and monitoring temporarily
                self.stopConnectionMonitoring()
                
                // Disconnect current socket
                if let socket = self.socket {
                    socket.disconnect()
                }
                
                self.isConnected = false
                self.internalConnectionState = .disconnected
                self.connectionStatus = .disconnected
                
                // Small delay to ensure disconnection completes
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    // Reset event handlers flag to allow new setup
                    self.eventHandlersSetup = false
                    
                    // Reinitialize socket with new user ID
                    self.setupSocket()
                    
                    // Small delay then connect
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        self.connect()
                        
                        // Verify connection after a delay
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                            if self.isConnected {
                                print("✅ SimpleSocketIOService: Reconnected successfully with new user ID")
                                self.joinUserRoom()
                                self.startConnectionMonitoring()
                            } else {
                                print("⚠️ SimpleSocketIOService: Reconnection failed, will retry via monitoring")
                                self.startConnectionMonitoring()
                            }
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - FCM Notification Handler
    /// Public method to handle live ride notifications from FCM (Firebase Cloud Messaging)
    func handleLiveRideNotificationFromFCM(_ notificationData: [String: Any]) {
        // Call the private method that handles the notification
        handleLiveRideNotification(notificationData)
    }
 
    
    /// Join room with current user ID
    private func joinUserRoom() {
        guard let socket = socket, isConnected else { 
             
            return 
        }
        
        // Get current user ID
        let userId = StorageManager.shared.getUserIdString() ?? "unknown"
        print("RideDrive---userId-2---> \(String(describing: userId))")
        if userId == "unknown" {
             
            return
        }
        
        // Emit join-room event with user ID
        let roomData: [String: Any] = [
            "room": userId
        ]
        
        socket.emit("join-room", roomData as SocketData) { [weak self] in
             
        }
        
         
    }
    
    /// Emit a custom event to the server
    func emitEvent(eventName: String, data: [String: Any]) {
        guard let socket = socket, isConnected else { 
             
            return 
        }
        socket.emit(eventName, data as SocketData)
         
    }
    
    /// Manually join room with current user ID (public method for debugging)
    func joinRoomManually() {
        joinUserRoom()
    }
    
    /// Toggle debug overlay visibility
    func toggleDebugOverlay() {
        showDebugOverlay.toggle()
         
    }
    
    /// Clear debug events
    func clearDebugEvents() {
        debugDriverLocationEvents.removeAll()
         
    }
    
    /// Get current user location from DashboardViewModel
    func updateCurrentUserLocation(_ location: CLLocationCoordinate2D?) {
        currentUserLocation = location
         
    }
    
    
    // MARK: - Debug Methods
    func debugUserIDStatus() {
         
         
        
        let userId = StorageManager.shared.getUserIdString()
       
        
        if let userId = userId, userId != "unknown" {
             
        } else {
             
             
        }
        
        // Check if we have a valid token as well
        let token = StorageManager.shared.getAuthToken()
        if let token = token, !token.isEmpty {
             
        } else {
             
        }
    }
    
    private func handleNotificationEvent(data: [Any]) {
        print("📬 SimpleSocketIOService: Handling notification event")
        
        if let notificationData = data.first as? [String: Any] {
            let title = notificationData["title"] as? String ?? "New Notification"
            let message = notificationData["message"] as? String ?? "You have a new notification"
            let type = notificationData["type"] as? String
            
            // Check if this is a chat notification
            var isChatNotification = false
            var chatBookingId: Int?
            
            // Check if type is chat_message
            if type == "chat_message" {
                isChatNotification = true
                // Extract bookingId if available
                if let bookingId = notificationData["bookingId"] as? Int {
                    chatBookingId = bookingId
                } else if let bookingIdStr = notificationData["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                    chatBookingId = bookingId
                } else if let data = notificationData["data"] as? [String: Any] {
                    if let bookingId = data["bookingId"] as? Int {
                        chatBookingId = bookingId
                    } else if let bookingIdStr = data["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                        chatBookingId = bookingId
                    }
                }
            } else if let dataDict = notificationData["data"] as? [String: Any],
                      let messageType = dataDict["type"] as? String,
                      messageType == "chat_message" {
                isChatNotification = true
                // Extract bookingId from data
                if let bookingId = dataDict["bookingId"] as? Int {
                    chatBookingId = bookingId
                } else if let bookingIdStr = dataDict["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                    chatBookingId = bookingId
                }
            }
            
            // If it's a chat notification, skip showing notification here
            // Chat notifications are already handled in user.notifications and user_notification event handlers
            // This prevents duplicate notifications
            if isChatNotification {
                let isOnChatScreen = ScreenTracker.shared.isOnChatScreen(for: chatBookingId)
                if isOnChatScreen {
                    print("📬 SimpleSocketIOService: Chat notification received but user is on chat screen - suppressing notification")
                } else {
                    print("📬 SimpleSocketIOService: Chat notification detected in handleNotificationEvent - skipping to prevent duplicate (already handled by user.notifications)")
                }
                // Don't show notification here - it's already been shown by the chat-specific handlers
                return
            }
            
            // Show proper notification for all non-suppressed, non-chat events
            notificationManager.showNotificationEvent(title: title, body: message)
            
            if (type == "on_location" || type == "live_ride" || type == "live_ride_do" || type == "ended"), let data = notificationData["data"] as? [String: Any] {
                if let status = data["status"] as? String {
                    print("📬 SimpleSocketIOService: Ride status update - \(status)")
                    
                    // Post notification for RideInProgressView to update status
                    NotificationCenter.default.post(
                        name: NSNotification.Name("RideStatusUpdate"),
                        object: nil,
                        userInfo: ["status": status]
                    )
                    
                    // Also update liveRideData if we have an active ride
                    if let currentLiveRideData = self.liveRideData {
                        let updatedLiveRideData = LiveRideData(
                            bookingId: currentLiveRideData.bookingId,
                            driverId: currentLiveRideData.driverId,
                            customerId: currentLiveRideData.customerId,
                            status: status,
                            driverLatitude: currentLiveRideData.driverLatitude,
                            driverLongitude: currentLiveRideData.driverLongitude,
                            pickupLatitude: currentLiveRideData.pickupLatitude,
                            pickupLongitude: currentLiveRideData.pickupLongitude,
                            dropoffLatitude: currentLiveRideData.dropoffLatitude,
                            dropoffLongitude: currentLiveRideData.dropoffLongitude,
                            pickupAddress: currentLiveRideData.pickupAddress,
                            dropoffAddress: currentLiveRideData.dropoffAddress,
                            timestamp: currentLiveRideData.timestamp,
                            title: currentLiveRideData.title,
                            message: currentLiveRideData.message,
                            driverName: currentLiveRideData.driverName,
                            driverPhone: currentLiveRideData.driverPhone
                        )
                        self.liveRideData = updatedLiveRideData
                    }
                }
            }
        } else {
            print("📬 SimpleSocketIOService: Invalid notification data format - showing generic notification")
            notificationManager.showNotificationEvent(title: "New Notification", body: "You have received a new notification")
        }
    }
    
    private func shouldSuppressNotificationEvent(_ data: [Any]) -> Bool {
        guard let payload = data.first as? [String: Any] else {
            return false
        }
        
        var isChatNotification = false
        var chatBookingId: Int?
        
        // Check if this is a chat message notification
        if let directType = payload["type"] as? String, directType == "chat_message" {
            isChatNotification = true
            // Extract bookingId if available
            if let bookingId = payload["bookingId"] as? Int {
                chatBookingId = bookingId
            } else if let bookingIdStr = payload["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                chatBookingId = bookingId
            }
        } else if let nested = payload["data"] as? [String: Any],
           let nestedType = nested["type"] as? String,
           nestedType == "chat_message" {
            isChatNotification = true
            // Extract bookingId from nested data if available
            if let bookingId = nested["bookingId"] as? Int {
                chatBookingId = bookingId
            } else if let bookingIdStr = nested["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                chatBookingId = bookingId
            }
        }
        
        // Only suppress if it's a chat notification AND user is on chat screen
        if isChatNotification {
            let isOnChatScreen = ScreenTracker.shared.isOnChatScreen(for: chatBookingId)
            if isOnChatScreen {
                print("📬 SimpleSocketIOService: shouldSuppressNotificationEvent - Chat notification and user is on chat screen - suppressing")
                return true
            }
            print("📬 SimpleSocketIOService: shouldSuppressNotificationEvent - Chat notification but user is NOT on chat screen - allowing")
        }
        
        return false
    }
    
    // MARK: - Live Ride Methods
    
    
    private func handleLiveRideNotification(_ notificationData: [String: Any]) {
         
         
       
        
        // Print complete notification structure
        if let jsonData = try? JSONSerialization.data(withJSONObject: notificationData, options: .prettyPrinted),
           let jsonString = String(data: jsonData, encoding: .utf8) {
             
    
        }
        
        // Extract main fields
        let title = notificationData["title"] as? String ?? ""
        let message = notificationData["message"] as? String ?? ""
        let type = notificationData["type"] as? String ?? ""
        // Extract data object
        guard let data = notificationData["data"] as? [String: Any] else {
             
            return
        }
        
         
        if let dataJson = try? JSONSerialization.data(withJSONObject: data, options: .prettyPrinted),
           let dataJsonString = String(data: dataJson, encoding: .utf8) {
    
        }
        
        // Extract all required fields
        guard let bookingId = normalizedString(from: data["bookingId"]),
              let driverId = normalizedString(from: data["driverId"]),
              let customerId = normalizedString(from: data["customerId"]),
              let status = normalizedString(from: data["status"]),
              let timestamp = normalizedString(from: data["timestamp"]) else {
             
            return
        }
        
        // Extract driver location
        guard let location = data["location"] as? [String: Any],
              let driverLat = normalizedDouble(from: location["latitude"]),
              let driverLng = normalizedDouble(from: location["longitude"]) else {
             
            return
        }
        
        // Extract pickup location - handle both String and Double types
        guard let pickupInfo = data["pickup_info"] as? [String: Any] else {
             
            return
        }
        
        guard let pickupLat = normalizedDouble(from: pickupInfo["latitude"]),
              let pickupLng = normalizedDouble(from: pickupInfo["longitude"]) else {
            
            return
        }
        
        // Extract dropoff location - handle both String and Double types
        guard let dropoffInfo = data["dropoff_info"] as? [String: Any] else {
             
            return
        }
        
        guard let dropoffLat = normalizedDouble(from: dropoffInfo["latitude"]),
              let dropoffLng = normalizedDouble(from: dropoffInfo["longitude"]) else {
            
            return
        }
        
        // Extract addresses
        let pickupAddress = pickupInfo["address"] as? String ?? "Unknown Pickup Address"
        let dropoffAddress = dropoffInfo["address"] as? String ?? "Unknown Dropoff Address"
        
        // Extract driver contact info (name + phone)
        var driverName: String?
        var driverPhone: String?
        
        func trimmedString(from value: Any?) -> String? {
            switch value {
            case let string as String:
                let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
                return trimmed.isEmpty ? nil : trimmed
            case let number as NSNumber:
                let stringValue = number.stringValue
                return stringValue.isEmpty ? nil : stringValue
            default:
                return nil
            }
        }
        
        func extractName(from dict: [String: Any]) -> String? {
            let first = trimmedString(from: dict["first_name"])
            let last = trimmedString(from: dict["last_name"])
            let combined = [first, last].compactMap { $0 }.filter { !$0.isEmpty }
            if !combined.isEmpty {
                return combined.joined(separator: " ")
            }
            if let fullName = trimmedString(from: dict["full_name"]) {
                return fullName
            }
            if let name = trimmedString(from: dict["name"]) {
                return name
            }
            return nil
        }
        
        func extractPhone(from dict: [String: Any]) -> String? {
            let baseNumber = trimmedString(from: dict["mobile"]) ??
                             trimmedString(from: dict["phone"]) ??
                             trimmedString(from: dict["contact_number"])
            guard var number = baseNumber else {
                return nil
            }
            let prefix = trimmedString(from: dict["mobileIsd"]) ??
                         trimmedString(from: dict["isd"]) ??
                         trimmedString(from: dict["country_code"])
            number = number.replacingOccurrences(of: " ", with: "")
            number = number.replacingOccurrences(of: "-", with: "")
            number = number.replacingOccurrences(of: "(", with: "")
            number = number.replacingOccurrences(of: ")", with: "")
            if let prefix = prefix {
                let normalizedPrefix = prefix.hasPrefix("+") ? prefix : "+" + prefix
                if !number.hasPrefix("+") {
                    return normalizedPrefix + number
                }
            }
            return number
        }
        
        func updateDriverInfo(from dict: [String: Any]) {
            if driverName == nil {
                driverName = extractName(from: dict)
            }
            if driverPhone == nil {
                driverPhone = extractPhone(from: dict)
            }
        }
        
        if let metadata = data["metadata"] as? [String: Any] {
            if let driverDict = metadata["driver_object"] as? [String: Any] {
                updateDriverInfo(from: driverDict)
            }
            if let driverDict = metadata["driver"] as? [String: Any] {
                updateDriverInfo(from: driverDict)
            }
        }
        
        if let driverDict = data["driver_object"] as? [String: Any] {
            updateDriverInfo(from: driverDict)
        }
        if let driverDict = data["driver"] as? [String: Any] {
            updateDriverInfo(from: driverDict)
        }
        
        // Create LiveRideData object
        let liveRide = LiveRideData(
            bookingId: bookingId,
            driverId: driverId,
            customerId: customerId,
            status: status,
            driverLatitude: driverLat,
            driverLongitude: driverLng,
            pickupLatitude: pickupLat,
            pickupLongitude: pickupLng,
            dropoffLatitude: dropoffLat,
            dropoffLongitude: dropoffLng,
            pickupAddress: pickupAddress,
            dropoffAddress: dropoffAddress,
            timestamp: timestamp,
            title: title,
            message: message,
            driverName: driverName,
            driverPhone: driverPhone
        )
        
        // Update published properties
        self.liveRideData = liveRide
        self.shouldShowRideInProgress = true
    
         
    }
    
    // MARK: - Driver Location Update Handler
    
    /// Handle driver location update event from driver app
    private func handleDriverLocationUpdate(_ locationData: [String: Any]) {
         
        
        // Print complete location data
        if let jsonData = try? JSONSerialization.data(withJSONObject: locationData, options: .prettyPrinted),
           let jsonString = String(data: jsonData, encoding: .utf8) {
             

        }
        
        // Extract latitude and longitude (required)
        guard let latitude = locationData["latitude"] as? Double,
              let longitude = locationData["longitude"] as? Double else {
             
            return
        }
        
        // Extract optional fields
        let bookingId = normalizedString(from: locationData["bookingId"])
        let customerId = normalizedString(from: locationData["customerId"])
        let accuracy = normalizedDouble(from: locationData["accuracy"])
        let heading = normalizedDouble(from: locationData["heading"])
        let speed = normalizedDouble(from: locationData["speed"])
        let timestamp = Date().timeIntervalSince1970
      
         
         
         
         
         
        
        // Create DriverLocationUpdate object
        let locationUpdate = DriverLocationUpdate(
            latitude: latitude,
            longitude: longitude,
            bookingId: bookingId,
            customerId: customerId,
            accuracy: accuracy,
            heading: heading,
            speed: speed,
            timestamp: timestamp
        )
        
        // Update published property
        self.driverLocationUpdate = locationUpdate
        
        // Add debug event
        let debugEvent = DriverLocationDebugEvent(
            timestamp: Date(),
            latitude: latitude,
            longitude: longitude,
            bookingId: bookingId,
            customerId: customerId,
            accuracy: accuracy,
            heading: heading,
            speed: speed,
            eventType: "driver.location.update"
        )
        
        // Add to debug events (keep last 20 events)
        DispatchQueue.main.async {
            self.debugDriverLocationEvents.append(debugEvent)
            if self.debugDriverLocationEvents.count > 20 {
                self.debugDriverLocationEvents.removeFirst()
            }
        }
        
        // Only post DriverLocationUpdate notification if user is in a ride
        // Check if we have active ride data or live ride data
        let hasActiveRide = activeRideData != nil
        let hasLiveRide = liveRideData != nil
        
        if hasActiveRide || hasLiveRide {
             
            NotificationCenter.default.post(
                name: NSNotification.Name("DriverLocationUpdate"),
                object: nil,
                userInfo: ["locationUpdate": locationUpdate]
            )
        } else {
             
             
        }
        
        // Also update liveRideData if we have an active ride and the booking ID matches
        if let currentLiveRideData = self.liveRideData,
           let locationBookingId = bookingId,
           locationBookingId == currentLiveRideData.bookingId {
             
            let updatedLiveRideData = LiveRideData(
                bookingId: currentLiveRideData.bookingId,
                driverId: currentLiveRideData.driverId,
                customerId: currentLiveRideData.customerId,
                status: currentLiveRideData.status,
                driverLatitude: latitude,
                driverLongitude: longitude,
                pickupLatitude: currentLiveRideData.pickupLatitude,
                pickupLongitude: currentLiveRideData.pickupLongitude,
                dropoffLatitude: currentLiveRideData.dropoffLatitude,
                dropoffLongitude: currentLiveRideData.dropoffLongitude,
                pickupAddress: currentLiveRideData.pickupAddress,
                dropoffAddress: currentLiveRideData.dropoffAddress,
                timestamp: currentLiveRideData.timestamp,
                title: currentLiveRideData.title,
                message: currentLiveRideData.message,
                driverName: currentLiveRideData.driverName,
                driverPhone: currentLiveRideData.driverPhone
            )
            self.liveRideData = updatedLiveRideData
             
        }
        
         
         
         
         
    }
    
    // MARK: - Active Ride Event Handler
    
    private func handleActiveRideEvent(_ rideData: [String: Any]) {
        // Print complete ride data
        if let jsonData = try? JSONSerialization.data(withJSONObject: rideData, options: .prettyPrinted),
           let jsonString = String(data: jsonData, encoding: .utf8) {
             
    
        }
        
        // Ensure connection is established before processing
//        if !isConnected {
//            print("RideDriveActive---active_ride_method not connected")
//            ensureConnectionForViewTransition()
//            
//            // Wait a moment for connection to establish, then retry
//            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
//                if self.isConnected {
//                    print("RideDriveActive---active_ride_method again connected")
//                    self.handleActiveRideEvent(rideData)
//                } else {
//                    print("RideDriveActive---else again not connected")
//                }
//            }
//            return
//        }
        
        // Extract data object
        guard let data = rideData["data"] as? [String: Any] else {
             
            return
        }
        
         
        if let dataJson = try? JSONSerialization.data(withJSONObject: data, options: .prettyPrinted),
           let dataJsonString = String(data: dataJson, encoding: .utf8) {
  
        }
        
        // Extract main fields
        guard let bookingId = data["booking_id"] as? Int,
              let status = data["status"] as? String,
              let statusDisplay = data["status_display"] as? String else {
             
            return
        }
        
        // Extract customer info
        guard let customerData = data["customer"] as? [String: Any],
              let customerId = customerData["id"] as? Int,
              let customerName = customerData["name"] as? String,
              let customerPhone = customerData["phone"] as? String else {
             
            return
        }
        let customerEmail = customerData["email"] as? String
        
        // Extract driver info
        guard let driverData = data["driver"] as? [String: Any],
              let driverId = driverData["id"] as? Int,
              let driverName = driverData["name"] as? String,
              let driverPhone = driverData["phone"] as? String,
              let driverRating = driverData["rating"] as? Int else {
             
            return
        }
        
        // Extract locations
        guard let locationsData = data["locations"] as? [String: Any],
              let pickupData = locationsData["pickup"] as? [String: Any],
              let dropoffData = locationsData["dropoff"] as? [String: Any] else {
             
            return
        }
        
        guard let pickupAddress = pickupData["address"] as? String,
              let pickupDatetime = pickupData["datetime"] as? String,
              let dropoffAddress = dropoffData["address"] as? String else {
             
            return
        }
        
        // Handle coordinates that might be String or Double
        let pickupLatitude: String
        let pickupLongitude: String
        let dropoffLatitude: String
        let dropoffLongitude: String
        
         
         
         
        
        // Parse pickup latitude
        if let pickupLatString = pickupData["latitude"] as? String {
            pickupLatitude = pickupLatString
        } else if let pickupLatDouble = pickupData["latitude"] as? Double {
            pickupLatitude = String(pickupLatDouble)
        } else {
             
            return
        }
        
        // Parse pickup longitude
        if let pickupLngString = pickupData["longitude"] as? String {
            pickupLongitude = pickupLngString
        } else if let pickupLngDouble = pickupData["longitude"] as? Double {
            pickupLongitude = String(pickupLngDouble)
        } else {
            pickupLongitude = "0.0" // Default fallback
        }
        
        // Parse dropoff latitude
        if let dropoffLatString = dropoffData["latitude"] as? String {
            dropoffLatitude = dropoffLatString
        } else if let dropoffLatDouble = dropoffData["latitude"] as? Double {
            dropoffLatitude = String(dropoffLatDouble)
        } else {
             
            return
        }
        
        // Parse dropoff longitude
        if let dropoffLngString = dropoffData["longitude"] as? String {
            dropoffLongitude = dropoffLngString
        } else if let dropoffLngDouble = dropoffData["longitude"] as? Double {
            dropoffLongitude = String(dropoffLngDouble)
        } else {
             
            return
        }
        
         
         
         
        
        // Extract trip details
        guard let tripDetailsData = data["trip_details"] as? [String: Any],
              let passengers = tripDetailsData["passengers"] as? Int,
              let luggage = tripDetailsData["luggage"] as? Int,
              let paymentStatus = tripDetailsData["payment_status"] as? String else {
             
            return
        }
        
        // Handle optional fields that might be null
        let distance = tripDetailsData["distance"] as? String ?? ""
        let duration = tripDetailsData["duration"] as? String ?? ""
        let estimatedFare = tripDetailsData["estimated_fare"] as? Double
        let actualFare = tripDetailsData["actual_fare"] as? Double
        let paymentMethod = tripDetailsData["payment_method"] as? String
        
        // Extract special requirements
        guard let specialReqData = data["special_requirements"] as? [String: Any] else {
             
            return
        }
        
        let childCertified = specialReqData["child_certified"] as? Bool ?? false
        let babySeat = specialReqData["baby_seat"] as? Bool ?? false
        let boosterSeat = specialReqData["booster_seat"] as? Bool ?? false
        let petFriendly = specialReqData["pet_friendly"] as? Bool ?? false
        let handicap = specialReqData["handicap"] as? Bool ?? false
        
        // Extract amenities
        let amenities = data["amenities"] as? [String] ?? []
        
        // Extract instructions
        let instructions = data["instructions"] as? String ?? ""
        
        // Extract timestamps
        guard let timestampsData = data["timestamps"] as? [String: Any],
              let createdAt = timestampsData["created_at"] as? String,
              let updatedAt = timestampsData["updated_at"] as? String else {
             
            return
        }
        let acceptedOn = timestampsData["accepted_on"] as? String
        
        // Extract metadata (optional - may not be present in active ride data)
        let metadataData = data["metadata"] as? [String: Any]
        let affiliateId = metadataData?["affiliate_id"] as? Int ?? 0
        let waitingTime = metadataData?["waiting_time"] as? Int ?? 0
        let driverLanguages = metadataData?["driver_languages"] as? [String] ?? []
        let driverDresses = metadataData?["driver_dresses"] as? [String] ?? []
        
         
         
         
         
        
        // Extract vehicle info (optional)
        let vehicleData = data["vehicle"] as? [String: Any]
        let vehicle: VehicleInfo? = nil // Will be nil if no vehicle data
        
        
        // Create ActiveRideData object
        let customer = CustomerInfo(
            id: customerId,
            name: customerName,
            email: customerEmail,
            phone: customerPhone
        )
        
        let driver = DriverInfo(
            id: driverId,
            name: driverName,
            phone: driverPhone,
            rating: driverRating
        )
        
        let pickup = PickupLocation(
            address: pickupAddress,
            latitude: pickupLatitude,
            longitude: pickupLongitude,
            datetime: pickupDatetime
        )
        
        let dropoff = DropoffLocation(
            address: dropoffAddress,
            latitude: dropoffLatitude,
            longitude: dropoffLongitude
        )
        
        let locations = RideLocationInfo(
            pickup: pickup,
            dropoff: dropoff
        )
        
        let tripDetails = TripDetails(
            passengers: passengers,
            luggage: luggage,
            distance: distance,
            duration: duration,
            estimatedFare: estimatedFare,
            actualFare: actualFare,
            paymentStatus: paymentStatus,
            paymentMethod: paymentMethod
        )
        
        let specialRequirements = SpecialRequirements(
            childCertified: childCertified,
            babySeat: babySeat,
            boosterSeat: boosterSeat,
            petFriendly: petFriendly,
            handicap: handicap
        )
        
        let timestamps = Timestamps(
            createdAt: createdAt,
            updatedAt: updatedAt,
            acceptedOn: acceptedOn
        )
        
        let metadata = Metadata(
            affiliateId: affiliateId,
            waitingTime: waitingTime,
            driverLanguages: driverLanguages,
            driverDresses: driverDresses
        )
        
        let activeRide = ActiveRideData(
            bookingId: bookingId,
            status: status,
            statusDisplay: statusDisplay,
            customer: customer,
            driver: driver,
            vehicle: vehicle,
            locations: locations,
            tripDetails: tripDetails,
            specialRequirements: specialRequirements,
            amenities: amenities,
            instructions: instructions,
            timestamps: timestamps,
            metadata: metadata
        )
        
        // Update published properties
        self.activeRideData = activeRide
        self.shouldNavigateToActiveRide = true
        
        // Also update liveRideData for LiveRideInProgressView to receive real-time updates
        let liveRideData = convertActiveRideToLiveRideData(activeRide)
        self.liveRideData = liveRideData
    }
    
    // MARK: - Connection Monitoring Methods
    
    /// Start continuous connection monitoring
    func startConnectionMonitoring() {
         
        
        // Stop any existing monitoring
        stopConnectionMonitoring()
        
        // Start monitoring every 5 seconds
        connectionMonitorTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { [weak self] _ in
            self?.checkConnectionStatus()
        }
        
         
    }
    
    /// Stop connection monitoring
    func stopConnectionMonitoring() {
         
        connectionMonitorTimer?.invalidate()
        connectionMonitorTimer = nil
        
         
    }
    
    /// Check if connection monitoring is active
    var isConnectionMonitoringActive: Bool {
        return connectionMonitorTimer != nil
    }
    
    /// Check current connection status and attempt reconnection if needed
    private func checkConnectionStatus() {
        guard !isReconnecting && internalConnectionState != .connected else {
            return
        }
        
        if !isConnected {
            print("⚠️ SimpleSocketIOService: Connection check failed - not connected, starting reconnection")
            startImmediateReconnection()
        }
    }
    
    /// Start immediate reconnection attempt with exponential backoff
    private func startImmediateReconnection() {
        // Prevent multiple simultaneous reconnection attempts
        guard !isReconnecting && internalConnectionState != .connected else {
            print("⚠️ SimpleSocketIOService: Reconnection already in progress or connected, skipping")
            return
        }
        
        connectionQueue.async { [weak self] in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                print("🔄 SimpleSocketIOService: Starting reconnection attempt #\(self.connectionAttempts + 1)...")
                
                self.internalConnectionState = .reconnecting
                self.connectionStatus = .reconnecting
                self.isReconnecting = true
                self.connectionAttempts += 1
                
                // Get current user ID
                let userId = StorageManager.shared.getUserIdString() ?? "unknown"
                print("🔄 SimpleSocketIOService: Reconnection User ID: \(userId)")
                if userId == "unknown" {
                    print("❌ SimpleSocketIOService: Cannot reconnect - User ID is unknown")
                    self.connectionStatus = .error
                    self.isReconnecting = false
                    return
                }
                
                // Limit reconnection attempts to prevent infinite loops
                if self.connectionAttempts > 10 {
                    print("❌ SimpleSocketIOService: Max reconnection attempts reached")
                    self.connectionStatus = .error
                    self.isReconnecting = false
                    self.showErrorToast("Connection failed after multiple attempts")
                    return
                }
                
                // Calculate exponential backoff delay
                let baseDelay = 2.0
                let maxDelay = 30.0
                let delay = min(baseDelay * pow(2.0, Double(self.connectionAttempts - 1)), maxDelay)
                
                print("🔄 SimpleSocketIOService: Waiting \(delay)s before reconnection attempt...")
                
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    // Check if we're still supposed to reconnect
                    guard self.isReconnecting else {
                        print("✅ SimpleSocketIOService: Reconnection cancelled")
                        return
                    }
                    
                    // Simply call connect() - socket manager will handle reconnection
                    // Don't recreate socket unnecessarily
                    self.connect()
                    
                    // Set a timeout to check if reconnection succeeded
                    DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) {
                        if !self.isConnected && self.isReconnecting {
                            print("⚠️ SimpleSocketIOService: Reconnection timeout, will retry...")
                            self.isReconnecting = false
                            // Will be retried by connection monitoring
                        } else if self.isConnected {
                            print("✅ SimpleSocketIOService: Reconnection successful")
                            self.isReconnecting = false
                            self.connectionAttempts = 0
                        }
                    }
                }
            }
        }
    }

 
    
    /// Get connection status for UI display
    func getConnectionStatusInfo() -> (status: ConnectionStatus, lastConnected: Date?, attempts: Int) {
        return (connectionStatus, lastConnectionTime, connectionAttempts)
    }
    
    /// Clear ride data when user leaves a ride (returns to dashboard)
    func clearRideData() {
         
         
        activeRideData = nil
        liveRideData = nil
        shouldNavigateToActiveRide = false
        shouldShowRideInProgress = false
         
         
    }
    
    /// Ensure socket connection is maintained (thread-safe)
    /// This should be called when Dashboard appears or when app becomes active
    /// Note: Views should NOT call this - it's managed at app lifecycle level
    func ensureConnection() {
        connectionQueue.async { [weak self] in
            guard let self = self else { return }
            
            // Check user ID before attempting connection
            let currentUserId = StorageManager.shared.getUserIdString() ?? "unknown"
            if currentUserId == "unknown" {
                print("⚠️ SimpleSocketIOService: Cannot connect - User ID is unknown")
                DispatchQueue.main.async {
                    self.connectionStatus = .error
                }
                return
            }
            
            // Ensure socket is set up
            if self.socket == nil {
                DispatchQueue.main.async {
                    self.setupSocket()
                }
            }
            
            // If already connected, just refresh room membership
            if self.isConnected && self.internalConnectionState == .connected {
                print("✅ SimpleSocketIOService: Already connected, refreshing room membership")
                DispatchQueue.main.async {
                    self.joinUserRoom()
                    if !self.isConnectionMonitoringActive {
                        self.startConnectionMonitoring()
                    }
                }
                return
            }
            
            // If not connected, attempt to connect
            print("🔄 SimpleSocketIOService: Not connected, attempting to connect...")
            self.connect()
            
            DispatchQueue.main.async {
                if !self.isConnectionMonitoringActive {
                    self.startConnectionMonitoring()
                }
            }
        }
    }
    
    /// Legacy method for backward compatibility - redirects to ensureConnection
    /// DEPRECATED: Views should not call this. Use app-level connection management instead.
    func ensureConnectionForViewTransition() {
        ensureConnection()
    }
    
    // MARK: - Data Conversion Methods
    
    /// Convert ActiveRideData to LiveRideData for LiveRideInProgressView
    private func convertActiveRideToLiveRideData(_ activeRideData: ActiveRideData) -> LiveRideData {
        // Convert string coordinates to doubles
        let pickupLat = Double(activeRideData.locations.pickup.latitude) ?? 0.0
        let pickupLong = Double(activeRideData.locations.pickup.longitude) ?? 0.0
        let dropoffLat = Double(activeRideData.locations.dropoff.latitude) ?? 0.0
        let dropoffLong = Double(activeRideData.locations.dropoff.longitude) ?? 0.0
        
        // Set driver location away from pickup to show route
        // Offset driver location by ~1km to show a proper route
        let driverLat = pickupLat + 0.01 // ~1km north of pickup
        let driverLong = pickupLong + 0.01 // ~1km east of pickup
        
         
         
         
         
        
        return LiveRideData(
            bookingId: String(activeRideData.bookingId),
            driverId: String(activeRideData.driver.id),
            customerId: String(activeRideData.customer.id),
            status: activeRideData.status,
            driverLatitude: driverLat, // Set driver away from pickup to show route
            driverLongitude: driverLong,
            pickupLatitude: pickupLat,
            pickupLongitude: pickupLong,
            dropoffLatitude: dropoffLat,
            dropoffLongitude: dropoffLong,
            pickupAddress: activeRideData.locations.pickup.address,
            dropoffAddress: activeRideData.locations.dropoff.address,
            timestamp: activeRideData.timestamps.updatedAt,
            title: "Active Ride",
            message: "Driver is \(activeRideData.statusDisplay.lowercased())",
            driverName: activeRideData.driver.name,
            driverPhone: activeRideData.driver.phone
        )
    }
    
    // MARK: - Toast Methods
    
    /// Show a toast message with specified configuration
    private func showToast(
        message: String,
        type: ToastType = .info,
        duration: Double = 3.0,
        title: String? = nil,
        detail: String? = nil,
        avatarText: String? = nil,
        action: ToastAction? = nil,
        countdown: Int? = nil
    ) {
        DispatchQueue.main.async {
            self.currentToastID = UUID()
            let toastID = self.currentToastID
            
            self.toastCountdownTimer?.invalidate()
            self.toastCountdownTimer = nil
            
            self.toastMessage = message
            self.toastTitle = title
            self.toastDetail = detail
            self.toastAvatarText = avatarText
            self.toastType = type
            self.toastAction = action
            self.toastIsInteractive = action != nil
            
            if let countdown = countdown, countdown > 0 {
                self.toastCountdown = countdown
                self.startToastCountdownTimer()
            } else {
                self.toastCountdown = nil
            }
            
            self.showToast = true
            
            let hideDelay: Double
            if let countdown = countdown, countdown > 0 {
                hideDelay = Double(countdown)
            } else {
                hideDelay = duration
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + hideDelay) {
                if self.currentToastID == toastID {
                    self.hideToast()
                }
            }
        }
    }
    
    /// Show success toast
    func showSuccessToast(_ message: String, duration: Double = 3.0) {
        showToast(message: message, type: .success, duration: duration)
    }
    
    /// Show error toast
    func showErrorToast(_ message: String, duration: Double = 4.0) {
        showToast(message: message, type: .error, duration: duration)
    }
    
    /// Show warning toast
    func showWarningToast(_ message: String, duration: Double = 3.0) {
        showToast(message: message, type: .warning, duration: duration)
    }
    
    /// Show chat message toast
    func showChatMessageToast(
        driverName: String,
        message: String,
        bookingId: Int,
        driverId: String,
        duration: Double = 4.0
    ) {
        let trimmedMessage = message.trimmingCharacters(in: .whitespacesAndNewlines)
        let safeDriverName = driverName.trimmingCharacters(in: .whitespacesAndNewlines)
        
        let displayName = safeDriverName.isEmpty ? "Driver" : safeDriverName
        let title = "Message from \(displayName)"
        let detail: String? = nil
        let body = trimmedMessage.isEmpty ? "Open chat to view the message." : trimmedMessage
        let countdown: Int? = nil
        
        let actionData = ChatToastActionData(
            bookingId: bookingId,
            driverId: driverId,
            driverName: safeDriverName.isEmpty ? "Driver" : safeDriverName
        )
        
        showToast(
            message: body,
            type: .chat,
            duration: duration,
            title: title,
            detail: detail,
            avatarText: nil,
            action: .openChat(actionData),
            countdown: countdown
        )
    }
    
    /// Show info toast
    func showInfoToast(_ message: String, duration: Double = 3.0) {
        showToast(message: message, type: .info, duration: duration)
    }
    
    /// Hide the current toast
    func hideToast() {
        DispatchQueue.main.async {
            self.toastCountdownTimer?.invalidate()
            self.toastCountdownTimer = nil
            self.toastCountdown = nil
            self.toastTitle = nil
            self.toastDetail = nil
            self.toastAvatarText = nil
            self.toastAction = nil
            self.toastIsInteractive = false
            self.toastMessage = ""
            self.showToast = false
        }
    }
    
    /// Show toast for connection status changes
    func showConnectionToast() {
        switch connectionStatus {
        case .connected:
            showSuccessToast("Connected to server")
        case .disconnected:
            showErrorToast("Disconnected from server")
        case .connecting:
            showInfoToast("Connecting to server...")
        case .reconnecting:
            showWarningToast("Reconnecting to server...")
        case .error:
            showErrorToast("Connection error occurred")
        }
    }
    
    func handleToastTap() {
        DispatchQueue.main.async {
            guard let action = self.toastAction else {
                self.hideToast()
                return
            }
            
            switch action {
            case .openChat(let data):
                NotificationCenter.default.post(
                    name: .chatToastTapped,
                    object: nil,
                    userInfo: [
                        "bookingId": data.bookingId,
                        "driverId": data.driverId,
                        "driverName": data.driverName
                    ]
                )
            }
            
            self.hideToast()
        }
    }
    
    private func startToastCountdownTimer() {
        toastCountdownTimer?.invalidate()
        guard let countdown = toastCountdown, countdown > 0 else { return }
        
        toastCountdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] timer in
            guard let self = self else {
                timer.invalidate()
                return
            }
            
            DispatchQueue.main.async {
                guard let remaining = self.toastCountdown else {
                    timer.invalidate()
                    return
                }
                
                if remaining > 1 {
                    self.toastCountdown = remaining - 1
                } else {
                    self.toastCountdown = 0
                    timer.invalidate()
                    self.hideToast()
                }
            }
        }
    }
    
}



