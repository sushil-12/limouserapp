//
//  AuthViewModel.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation
import SwiftUI

@MainActor
class AuthViewModel: ObservableObject {
    @Published var authModel = AuthModel()
    @Published var showAlert = false
    @Published var alertMessage = ""
    @Published var isOTPVerified = false
    @Published var userData: User?
    @Published var authToken: String = ""
    @Published var resendCooldown = 0
    @Published var shouldNavigateToBasicInfo = false
    @Published var shouldNavigateToDashboard = false
    @Published var shouldNavigateToCreditCard = false
    @Published var isLoading = false
    
    let countryCodes = countries
    
    func validatePhoneNumber() -> Bool {
        let cleanNumber = authModel.phoneNumber.replacingOccurrences(of: " ", with: "")
        
        // Check if phone number length matches country requirement
        if cleanNumber.count != authModel.countryCode.phoneLength {
            alertMessage = "Phone number must be \(authModel.countryCode.phoneLength) digits for \(authModel.countryCode.name)"
            showAlert = true
            return false
        }
        
        // Check if phone number contains only digits
        if !cleanNumber.allSatisfy({ $0.isNumber }) {
            alertMessage = "Phone number must contain only digits"
            showAlert = true
            return false
        }
        
        authModel.isPhoneNumberValid = true
        return true
    }
    
    func sendVerificationCode() async {
        guard validatePhoneNumber() else { return }
        
        authModel.isLoading = true
        authModel.errorMessage = ""
        
        do {
            // Prepare request body
            let requestBody: [String: Any] = [
                "phone_isd": authModel.countryCode.code,
                "phone_country": authModel.countryCode.shortCode.lowercased(),
                "phone": authModel.phoneNumber.replacingOccurrences(of: " ", with: ""),
                "user_type": "customer"
            ]
            
            // Make API call
            let response: AuthResponse = try await NetworkService.shared.request(
                endpoint: .loginOrRegister,
                body: requestBody,
                responseType: AuthResponse.self
            )
            
            // Handle success
            if response.success {
                // Store temp data using StorageManager
                StorageManager.shared.saveTempAuthData(response)
                
                // Navigate to OTP screen (this will be handled by the view)
                authModel.isLoading = false
            } else {
                authModel.errorMessage = response.message
                alertMessage = response.message
                showAlert = true
                authModel.isLoading = false
            }
            
        } catch {
            // Print error details
            print("=== OTP VERIFICATION ERROR ===")
            print("Error: \(error)")
            print("Error Description: \(error.localizedDescription)")
            print("=============================")
            
            authModel.isLoading = false
            authModel.errorMessage = error.localizedDescription
            alertMessage = error.localizedDescription
            showAlert = true
        }
    }
    
    func verifyOTP(otp: String) async {
        guard !otp.isEmpty else {
            alertMessage = "Please enter the OTP"
            showAlert = true
            return
        }
        
        guard otp.count == 6 else {
            alertMessage = "OTP must be 6 digits"
            showAlert = true
            return
        }
        
        authModel.isLoading = true
        authModel.errorMessage = ""
        
        do {
            // Get stored temp_user_id
            guard let tempUserId = StorageManager.shared.getTempUserId() else {
                alertMessage = "Session expired. Please try again."
                showAlert = true
                authModel.isLoading = false
                return
            }
            
            // Prepare request body
            let requestBody: [String: Any] = [
                "temp_user_id": tempUserId,
                "otp": otp
            ]
            
            // Print request details
            print("=== OTP VERIFICATION REQUEST ===")
            print("Endpoint: /api/mobile/v1/auth/verify-otp")
            print("Temp User ID: \(tempUserId)")
            print("OTP: \(otp)")
            print("Request Body: \(requestBody)")
            print("================================")
            
            // Make API call
            let response: VerifyOTPResponse = try await NetworkService.shared.request(
                endpoint: .verifyOTP,
                body: requestBody,
                responseType: VerifyOTPResponse.self
            )
            
            // Print the complete response
            print("=== OTP VERIFICATION RESPONSE ===")
            print("Success: \(response.success)")
            print("Message: \(response.message)")
            print("Code: \(response.code)")
            print("Timestamp: \(response.timestamp)")
            print("--- User Data ---")
            print("User ID: \(response.data.user.id)")
            print("Phone: \(response.data.user.phone)")
            print("Role: \(response.data.user.role)")
            print("Profile Completed: \(response.data.user.isProfileCompleted ?? false)")
            print("Last Login: \(response.data.user.lastLoginAt)")
            print("Created From: \(response.data.user.createdFrom ?? "nil")")
            print("--- Token Data ---")
            print("Token Type: \(response.data.tokenType)")
            print("Expires In: \(response.data.expiresIn)")
            print("Action: \(response.data.action)")
            print("Token (first 50 chars): \(String(response.data.token.prefix(50)))...")
            print("================================")
            
            // Handle success
            if response.success {
                // Store complete login data using StorageManager
                StorageManager.shared.saveLoginData(response)
                
                // Update ViewModel state
                self.userData = response.data.user
                self.authToken = response.data.token
                
                authModel.isLoading = false
                isOTPVerified = true
                
                // Persist next step and profile completion flags explicitly
                let customerNextStep = response.data.user.customerRegistrationState?.nextStep
                    ?? (response.data.action.isEmpty ? nil : response.data.action)
                StorageManager.shared.saveCustomerNextStep(customerNextStep)
                StorageManager.shared.setProfileCompletionStatus(response.data.user.isProfileCompleted)
                
                let normalizedNextStep = StorageManager.shared.normalizeCustomerNextStep(customerNextStep)
                let isProfileCompleted = response.data.user.isProfileCompleted ?? false
                
                // Reset navigation flags
                shouldNavigateToBasicInfo = false
                shouldNavigateToCreditCard = false
                shouldNavigateToDashboard = false
                
                // Check driver registration state first
                if let driverRegistrationState = response.data.driverRegistrationState {
                    print("=== DRIVER REGISTRATION STATE ===")
                    print("Current Step: \(driverRegistrationState.currentStep)")
                    print("Progress: \(driverRegistrationState.progressPercentage)%")
                    print("Is Completed: \(driverRegistrationState.isCompleted)")
                    print("Next Step: \(driverRegistrationState.nextStep ?? "nil")")
                    print("================================")
                    
                    // If driver registration is completed, navigate directly to dashboard
                    if driverRegistrationState.isCompleted {
                        print("✅ Driver registration completed - navigating to dashboard")
                        shouldNavigateToDashboard = true
                    } else {
                        // Driver registration not completed, evaluate customer onboarding flow
                        handleCustomerOnboardingFlow(nextStep: normalizedNextStep, isProfileCompleted: isProfileCompleted)
                    }
                } else {
                    // No driver registration state, evaluate customer onboarding flow
                    handleCustomerOnboardingFlow(nextStep: normalizedNextStep, isProfileCompleted: isProfileCompleted)
                }
                
                // Print stored data for debugging
                StorageManager.shared.printAllStoredData()
                
            } else {
                authModel.errorMessage = response.message
                alertMessage = response.message
                showAlert = true
                authModel.isLoading = false
            }
            
        } catch {
            authModel.isLoading = false
            authModel.errorMessage = error.localizedDescription
            alertMessage = error.localizedDescription
            showAlert = true
        }
    }
    
    func resendOTP() async {
        guard let tempUserId = StorageManager.shared.getTempUserId() else {
            alertMessage = "Session expired. Please try again."
            showAlert = true
            return
        }
        
        authModel.isLoading = true
        authModel.errorMessage = ""
        
        do {
            // Prepare request body
            let requestBody: [String: Any] = [
                "temp_user_id": tempUserId
            ]
            
            // Print request details
            print("=== RESEND OTP REQUEST ===")
            print("Endpoint: /api/mobile/v1/auth/resend-otp")
            print("Temp User ID: \(tempUserId)")
            print("Request Body: \(requestBody)")
            print("==========================")
            
            // Make API call
            let response: ResendOTPResponse = try await NetworkService.shared.request(
                endpoint: .resendOTP,
                body: requestBody,
                responseType: ResendOTPResponse.self
            )
            
            // Print the complete response
            print("=== RESEND OTP RESPONSE ===")
            print("Success: \(response.success)")
            print("Message: \(response.message)")
            print("Code: \(response.code)")
            print("Timestamp: \(response.timestamp)")
            print("--- Resend Data ---")
            print("Message: \(response.data.message)")
            print("OTP Type: \(response.data.otpType)")
            print("New Temp User ID: \(response.data.tempUserId)")
            print("Expires In: \(response.data.expiresIn)")
            print("Cooldown Remaining: \(response.data.cooldownRemaining)")
            print("===========================")
            
            // Handle success
            if response.success {
                // Update stored temp_user_id with new one
                StorageManager.shared.saveTempUserId(response.data.tempUserId)
                StorageManager.shared.saveOtpType(response.data.otpType)
                
                // Set cooldown timer
                resendCooldown = response.data.cooldownRemaining
                startResendCooldownTimer()
                
                authModel.isLoading = false
                alertMessage = "OTP resent successfully"
                showAlert = true
                
            } else {
                authModel.errorMessage = response.message
                alertMessage = response.message
                showAlert = true
                authModel.isLoading = false
            }
            
        } catch {
            // Print error details
            print("=== RESEND OTP ERROR ===")
            print("Error: \(error)")
            print("Error Description: \(error.localizedDescription)")
            print("========================")
            
            authModel.isLoading = false
            authModel.errorMessage = error.localizedDescription
            alertMessage = error.localizedDescription
            showAlert = true
        }
    }
    
    private func startResendCooldownTimer() {
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            if self.resendCooldown > 0 {
                self.resendCooldown -= 1
            } else {
                timer.invalidate()
            }
        }
    }
    
    // Public initializer to start cooldown when entering OTP screen
    func startInitialResendCooldown(seconds: Int = 60) {
        guard resendCooldown == 0 else { return }
        resendCooldown = seconds
        startResendCooldownTimer()
    }
    
    func formatPhoneNumber(_ number: String) -> String {
        let cleanNumber = number.replacingOccurrences(of: " ", with: "")
        var formatted = ""
        
        for (index, char) in cleanNumber.enumerated() {
            if index == 3 || index == 6 {
                formatted += " "
            }
            formatted += String(char)
        }
        
        return formatted
    }
    
    private func handleCustomerOnboardingFlow(nextStep: String?, isProfileCompleted: Bool) {
        guard let nextStep = nextStep else {
            shouldNavigateToDashboard = isProfileCompleted
            shouldNavigateToBasicInfo = !isProfileCompleted
            return
        }
        
        switch nextStep {
        case "basic_info", "basic_details":
            shouldNavigateToBasicInfo = true
        case "credit_card":
            if isProfileCompleted {
                shouldNavigateToDashboard = true
            } else {
                shouldNavigateToCreditCard = true
            }
        case "dashboard":
            shouldNavigateToDashboard = true
        default:
            if isProfileCompleted {
                shouldNavigateToDashboard = true
            } else {
                shouldNavigateToBasicInfo = true
            }
        }
    }
}
