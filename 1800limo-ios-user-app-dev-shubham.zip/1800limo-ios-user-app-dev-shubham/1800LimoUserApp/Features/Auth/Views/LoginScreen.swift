//
//  LoginScreen.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct LoginScreen: View {
    @StateObject private var viewModel = AuthViewModel()
    @State private var showOTPScreen = false
    
    var body: some View {
        ZStack {
            // Background
            Color.white.ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 0) {
                // Header
                VStack(alignment: .leading, spacing: 8) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Hey Travel Partner ,")
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundColor(AppColors.primaryText)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        
                        Text("tell us your mobile number")
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundColor(AppColors.primaryText)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                    }
                    Spacer().frame(height: 12)
                    Text("We'll send a verification code on this number.")
                        .font(.system(size: 15, weight: .regular))
                        .foregroundColor(AppColors.secondaryText)
                        .lineSpacing(2)
                }
                .padding(.horizontal, 24)
                .padding(.top, 60)
                Spacer().frame(height: 18)
                
                CommonPhoneTextField(
                    label: "",
                    phone: $viewModel.authModel.phoneNumber,
                    selectedCountry: $viewModel.authModel.countryCode,
                    isRequired: true
                )
                .padding(.horizontal, 24)
                
                Spacer()
            }
            
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: {
                        Task {
                            await viewModel.sendVerificationCode()
                            if viewModel.authModel.isPhoneNumberValid && viewModel.authModel.errorMessage.isEmpty {
                                showOTPScreen = true
                            }
                        }
                    }) {
                        HStack(spacing: 8) {
                            Text("Next")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                            
                            Image(systemName: "arrow.right")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                        }
                        .frame(width: 94, height: 48)
                        .background(AppColors.primaryOrange)
                        .cornerRadius(24)
                    }
                   
                    .padding(.trailing, 24)
                    .padding(.bottom, 40)
                }
            }
        }
        .navigationBarHidden(true)
        .fullScreenCover(isPresented: $showOTPScreen) {
            OTPScreen(
                phoneNumber: viewModel.authModel.phoneNumber,
                countryCode: viewModel.authModel.countryCode.code
            )
        }
        .alert("Error", isPresented: $viewModel.showAlert) {
            Button("OK") { }
        } message: {
            Text(viewModel.alertMessage)
        }
    }
}

#Preview {
    LoginScreen()
}
