//
//  CreditCardScreen.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct CreditCardScreen: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AuthViewModel()
    @StateObject private var addressViewModel = AddressAutocompleteViewModel()
    @State private var cardNumber = ""
    @State private var expiryDate = ""
    @State private var cvv = ""
    @State private var nameOnCard = ""
    @State private var location = ""
    @State private var postalCode = ""
    @State private var showNextScreen = false
    @State private var showTermsWebView = false
    @State private var activeFieldId: String? = nil
    @State private var fieldErrors: [String: String] = [:]
    
    // Formatting functions
    private func formatCardNumber(_ number: String) -> String {
        var result = ""
        
        for (index, char) in number.enumerated() {
            if index > 0 && index % 4 == 0 {
                result += " "
            }
            result += String(char)
        }
        
        return result
    }
    
    private func formatExpiryDate(_ date: String) -> String {
        // Remove all non-numeric characters
        let cleaned = date.replacingOccurrences(of: "/", with: "").filter { $0.isNumber }
        
        // Limit to maximum 4 digits (2 for month, 2 for year)
        let limited = String(cleaned.prefix(4))
        
        // Handle different lengths
        switch limited.count {
        case 0:
            return ""
        case 1:
            return limited
        case 2:
            return limited
        case 3:
            // 3 digits: MM/Y (partial year)
            let month = String(limited.prefix(2))
            let year = String(limited.suffix(1))
            return "\(month)/\(year)"
        default: // 4 or more
            // 4 digits: MM/YY (complete)
            let month = String(limited.prefix(2))
            let year = String(limited.suffix(2))
            return "\(month)/\(year)"
        }
    }
    
    // Helper function to dismiss keyboard
    private func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    // MARK: - Error Handling Helpers
    @ViewBuilder
    private func validationMessage(for key: String) -> some View {
        if let message = fieldErrors[key] {
            Text(message)
                .font(.system(size: 12, weight: .regular))
                .foregroundColor(.red)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 4)
                .padding(.leading, 4)
        }
    }
    
    // Helper function to check if a field has an error
    private func hasError(for key: String) -> Bool {
        return fieldErrors[key] != nil
    }
    
    // Helper function to clear error for a specific field
    private func clearError(for key: String) {
        if fieldErrors[key] != nil {
            fieldErrors.removeValue(forKey: key)
        }
    }
    
    // Helper function to focus on field with error
    private func focusField(for key: String, scrollAction: @escaping (String) -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            withAnimation(.easeInOut(duration: 0.3)) {
                scrollAction(key)
            }
        }
        activeFieldId = key
    }
    
    
    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Fixed Header
                VStack(alignment: .leading, spacing: 0) {
                    // Back Button
                    HStack {
                        Button(action: {
                            dismiss()
                        }) {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 18, weight: .medium))
                                .foregroundColor(.black)
                                .frame(width: 40, height: 40)
                                .background(Color.gray.opacity(0.1))
                                .clipShape(Circle())
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 16)
                    
                    // Title
                    Text("Add Credit Card")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(AppColors.primaryText)
                        .padding(.horizontal, 24)
                        .padding(.top, 32)
                }
                
                Spacer().frame(height: 18)
                
                // Scrollable Content (Form Fields Only)
                ScrollViewReader { scrollProxy in
                    VStack(spacing: 0) {
                    ScrollView {
                        VStack(spacing: 18) {
                            // Card Number
                            VStack(alignment: .leading, spacing: 8) {
                                Text("CARD NUMBER")
                                    .font(.system(size: 14, weight: .medium, design: .default))
                                    .foregroundColor(AppColors.primaryText)
                                    .lineSpacing(2)
                                    .padding(.leading, 4)
                                
                                TextField("0123 4567 8910 1112", text: $cardNumber)
                                    .keyboardType(.numberPad)
                                    .font(.system(size: 16, weight: .regular, design: .default))
                                    .foregroundColor(AppColors.primaryText)
                                    .padding(.top, 4)
                                    .padding(.trailing, 10)
                                    .padding(.bottom, 4)
                                    .padding(.leading, 16)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 40)
                                    .background(AppColors.backgroundGray)
                                    .cornerRadius(8)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(hasError(for: "cardNumber") ? Color.red : AppColors.borderGray, lineWidth: hasError(for: "cardNumber") ? 1.5 : 1)
                                    )
                                    .onChange(of: cardNumber) { newValue in
                                        // Clear error when user types
                                        clearError(for: "cardNumber")
                                        
                                        // Remove all non-numeric characters
                                        let digitsOnly = newValue.filter { $0.isNumber }
                                        
                                        // Limit to 16 digits (12-16 range)
                                        let limitedDigits = String(digitsOnly.prefix(16))
                                        
                                        // Format with spaces
                                        cardNumber = formatCardNumber(limitedDigits)
                                    }
                                    .simultaneousGesture(
                                        TapGesture().onEnded {
                                            // Set active field and scroll when tapped
                                            activeFieldId = "cardNumber"
                                        }
                                    )
                                
                                validationMessage(for: "cardNumber")
                            }
                            .padding(.horizontal, 24)
                            .id("cardNumber")
                        
                        // Expiry Date and CVV
                        HStack(spacing: 16) {
                            // Expiry Date
                            VStack(alignment: .leading, spacing: 8) {
                                Text("EXPIRY DATE")
                                    .font(.system(size: 14, weight: .medium, design: .default))
                                    .foregroundColor(AppColors.primaryText)
                                    .lineSpacing(2)
                                    .padding(.leading, 4)
                                
                                TextField("MM/YY", text: $expiryDate)
                                    .keyboardType(.numberPad)
                                    .font(.system(size: 16, weight: .regular, design: .default))
                                    .foregroundColor(AppColors.primaryText)
                                    .padding(.top, 4)
                                    .padding(.trailing, 10)
                                    .padding(.bottom, 4)
                                    .padding(.leading, 16)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 40)
                                    .background(AppColors.backgroundGray)
                                    .cornerRadius(8)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(hasError(for: "expiryDate") ? Color.red : AppColors.borderGray, lineWidth: hasError(for: "expiryDate") ? 1.5 : 1)
                                    )
                                    .onChange(of: expiryDate) { newValue in
                                        // Clear error when user types
                                        clearError(for: "expiryDate")
                                        
                                        // Get current digit count
                                        let currentDigits = expiryDate.replacingOccurrences(of: "/", with: "").filter { $0.isNumber }
                                        
                                        // Only allow numbers and /
                                        let filtered = newValue.filter { $0.isNumber || $0 == "/" }
                                        let newDigits = filtered.replacingOccurrences(of: "/", with: "").filter { $0.isNumber }
                                        
                                        // If user is deleting (fewer digits), allow partial formatting
                                        // If user is adding (more digits), format normally
                                        if newDigits.count < currentDigits.count {
                                            // User is deleting - format but allow partial input
                                            let formatted = formatExpiryDate(filtered)
                                            // Only update if it's actually different to avoid loops
                                            if formatted != expiryDate {
                                                expiryDate = formatted
                                            }
                                        } else {
                                            // User is adding - format and limit
                                            let formatted = formatExpiryDate(filtered)
                                            if formatted != expiryDate {
                                                expiryDate = formatted
                                            }
                                        }
                                    }
                                    .simultaneousGesture(
                                        TapGesture().onEnded {
                                            // Set active field and scroll when tapped
                                            activeFieldId = "expiryDate"
                                        }
                                    )
                                
                                validationMessage(for: "expiryDate")
                            }
                            .frame(maxWidth: .infinity)
                            .id("expiryDate")
                            
                            // CVV
                            VStack(alignment: .leading, spacing: 8) {
                                Text("CVV/CVC")
                                    .font(.system(size: 14, weight: .medium, design: .default))
                                    .foregroundColor(AppColors.primaryText)
                                    .lineSpacing(2)
                                    .padding(.leading, 4)
                                
                                SecureField("123", text: $cvv)
                                    .keyboardType(.numberPad)
                                    .font(.system(size: 16, weight: .regular, design: .default))
                                    .foregroundColor(AppColors.primaryText)
                                    .padding(.top, 4)
                                    .padding(.trailing, 10)
                                    .padding(.bottom, 4)
                                    .padding(.leading, 16)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 40)
                                    .background(AppColors.backgroundGray)
                                    .cornerRadius(8)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(hasError(for: "cvv") ? Color.red : AppColors.borderGray, lineWidth: hasError(for: "cvv") ? 1.5 : 1)
                                    )
                                    .onChange(of: cvv) { newValue in
                                        // Clear error when user types
                                        clearError(for: "cvv")
                                        
                                        // Only allow numbers and limit to 4 digits
                                        let filtered = newValue.filter { $0.isNumber }
                                        cvv = String(filtered.prefix(4))
                                    }
                                    .simultaneousGesture(
                                        TapGesture().onEnded {
                                            // Set active field and scroll when tapped
                                            activeFieldId = "cvv"
                                        }
                                    )
                                
                                validationMessage(for: "cvv")
                            }
                            .frame(maxWidth: .infinity)
                            .id("cvv")
                        }
                        .padding(.horizontal, 24)
                        
                        // Name on Card
                        VStack(alignment: .leading, spacing: 0) {
                            AppTextField(
                                label: "NAME ON CARD",
                                placeholder: "Alexa Smith",
                                text: $nameOnCard,
                                keyboardType: .default,
                                hasError: hasError(for: "nameOnCard"),
                                onEditingChanged: { isEditing in
                                    if isEditing {
                                        // Clear error when user starts editing
                                        clearError(for: "nameOnCard")
                                        // Set active field to trigger scroll
                                        activeFieldId = "nameOnCard"
                                    }
                                }
                            )
                            validationMessage(for: "nameOnCard")
                        }
                        .padding(.horizontal, 24)
                        .id("nameOnCard")
                        
                        // Location
                        VStack(alignment: .leading, spacing: 0) {
                            AddressAutocompleteField(
                                viewModel: addressViewModel,
                                label: "LOCATION",
                                placeholder: "North Hills, LA",
                                isRequired: false,
                                value: $location,
                                hasError: hasError(for: "location"),
                                onLocationSelected: { selectedLocation, coordinate, postalCode in
                                    // Clear error when location is selected
                                    clearError(for: "location")
                                    location = selectedLocation
                                    if let postalCode = postalCode {
                                        self.postalCode = postalCode
                                    }
                                }
                            )
                            validationMessage(for: "location")
                        }
                        .padding(.horizontal, 24)
                        .id("location")
                        .onChange(of: addressViewModel.input) { _ in
                            // Clear error when user types
                            clearError(for: "location")
                        }
                        .onChange(of: addressViewModel.isEditing) { isEditing in
                            // Set active field when location editing starts
                            if isEditing {
                                // Clear error when user starts editing
                                clearError(for: "location")
                                activeFieldId = "location"
                            }
                        }
                        .onChange(of: addressViewModel.suggestions) { suggestions in
                            // Auto-scroll when location suggestions appear
                            if !suggestions.isEmpty {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                    withAnimation(.easeInOut(duration: 0.3)) {
                                        scrollProxy.scrollTo("location", anchor: .top)
                                    }
                                }
                            }
                        }
                        
                        // Postal Code
                        VStack(alignment: .leading, spacing: 0) {
                            AppTextField(
                                label: "POSTAL CODE",
                                placeholder: "91343",
                                text: $postalCode,
                                keyboardType: .numberPad,
                                hasError: hasError(for: "postalCode"),
                                onEditingChanged: { isEditing in
                                    if isEditing {
                                        // Clear error when user starts editing
                                        clearError(for: "postalCode")
                                        // Set active field to trigger scroll
                                        activeFieldId = "postalCode"
                                    }
                                }
                            )
                            validationMessage(for: "postalCode")
                        }
                        .padding(.horizontal, 24)
                        .id("postalCode")
                        
                        
                        // Terms and Conditions
                        HStack {
                            (Text("By adding a new card, you agree to our ")
                                .font(.system(size: AppTypography.small, weight: .regular, design: .default))
                                .foregroundColor(AppColors.primaryText) +
                             Text("Credit cards terms & conditions.")
                                .font(.system(size: AppTypography.small, weight: .regular, design: .default))
                                .foregroundColor(AppColors.primaryOrange)
                                .underline())
                            .lineSpacing(2)
                            
                            Spacer()
                        }
                        .padding(.horizontal, 24)
                        .onTapGesture {
                            showTermsWebView = true
                        }
                    }
                    .padding(.top, 20)
                    .padding(.bottom, 20)
                    }
                    .onChange(of: activeFieldId) { fieldId in
                        // Scroll to active field when keyboard appears
                        if let fieldId = fieldId {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                withAnimation(.easeInOut(duration: 0.3)) {
                                    scrollProxy.scrollTo(fieldId, anchor: .center)
                                }
                            }
                        }
                    }
                    
                    // Fixed Bottom Button (outside ScrollView)
                    VStack {
                        Button(action: {
                            Task {
                                await submitCreditCard(scrollAction: { key in
                                    scrollProxy.scrollTo(key, anchor: .center)
                                })
                            }
                        }) {
                            HStack {
                                if viewModel.isLoading {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                        .scaleEffect(0.8)
                                }
                                
                                Text(viewModel.isLoading ? "PROCESSING..." : "ADD A CARD & SIGN UP")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 48)
                            .background(AppColors.primaryOrange)
                            .cornerRadius(8)
                        }
                        .disabled(viewModel.isLoading)
                        .padding(.horizontal, 24)
                        .padding(.bottom, 40)
                    }
                    }
                }
            }
        }
        .simultaneousGesture(
            TapGesture().onEnded {
                dismissKeyboard()
            }
        )
        .navigationBarHidden(true)
        .alert("Error", isPresented: $viewModel.showAlert) {
            Button("OK") { }
        } message: {
            Text(viewModel.alertMessage)
        }
        .fullScreenCover(isPresented: $showNextScreen) {
            DashboardView()
        }
        .fullScreenCover(isPresented: $showTermsWebView) {
            WebViewScreen(
                url: URL(string: "https://1800limoco.infodevbox.com/client-terms-condition")!,
                title: "Terms & Conditions"
            )
        }
    }
    
    private func isFormValid() -> Bool {
        return !cardNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               !expiryDate.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               !cvv.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               !nameOnCard.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               !location.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               !postalCode.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    private func validateInputs(scrollAction: @escaping (String) -> Void) -> Bool {
        fieldErrors.removeAll()
        var errors: [String: String] = [:]
        var errorOrder: [String] = []
        
        let trimmedCardNumber = cardNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedExpiryDate = expiryDate.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedCvv = cvv.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedNameOnCard = nameOnCard.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedLocation = location.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPostalCode = postalCode.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Validate Card Number
        if trimmedCardNumber.isEmpty {
            errors["cardNumber"] = "Card number is required"
            errorOrder.append("cardNumber")
        } else {
            let cleanCardNumber = trimmedCardNumber.replacingOccurrences(of: " ", with: "")
            if cleanCardNumber.count < 12 || cleanCardNumber.count > 16 {
                errors["cardNumber"] = "Please enter a valid card number (12-16 digits)"
                errorOrder.append("cardNumber")
            }
        }
        
        // Validate Expiry Date
        if trimmedExpiryDate.isEmpty {
            errors["expiryDate"] = "Expiry date is required"
            errorOrder.append("expiryDate")
        } else {
            let expiryValidation = validateExpiryDate(trimmedExpiryDate)
            if !expiryValidation.isValid {
                errors["expiryDate"] = expiryValidation.errorMessage
                errorOrder.append("expiryDate")
            }
        }
        
        // Validate CVV
        if trimmedCvv.isEmpty {
            errors["cvv"] = "CVV/CVC is required"
            errorOrder.append("cvv")
        } else if trimmedCvv.count < 3 || trimmedCvv.count > 4 {
            errors["cvv"] = "Please enter a valid CVV/CVC (3-4 digits)"
            errorOrder.append("cvv")
        }
        
        // Validate Name on Card
        if trimmedNameOnCard.isEmpty {
            errors["nameOnCard"] = "Name on card is required"
            errorOrder.append("nameOnCard")
        } else if trimmedNameOnCard.count < 2 {
            errors["nameOnCard"] = "Name on card must be at least 2 characters"
            errorOrder.append("nameOnCard")
        }
        
        // Validate Location
        if trimmedLocation.isEmpty {
            errors["location"] = "Location is required"
            errorOrder.append("location")
        }
        
        // Validate Postal Code
        if trimmedPostalCode.isEmpty {
            errors["postalCode"] = "Postal code is required"
            errorOrder.append("postalCode")
        }
        
        fieldErrors = errors
        
        // Focus on first error field
        if let firstError = errorOrder.first {
            focusField(for: firstError, scrollAction: scrollAction)
            return false
        }
        
        return true
    }
    
    private func validateExpiryDate(_ date: String) -> (isValid: Bool, errorMessage: String) {
        let components = date.components(separatedBy: "/")
        
        // Check format
        guard components.count == 2 else {
            return (false, "Please enter a valid expiry date (MM/YY)")
        }
        
        // Check if month and year are numeric
        guard let month = Int(components[0]),
              let year = Int(components[1]) else {
            return (false, "Please enter a valid expiry date (MM/YY)")
        }
        
        // Check month range (01-12)
        if month < 1 || month > 12 {
            return (false, "Month must be between 01 and 12")
        }
        
        // Check year format (should be 2 digits)
        if components[1].count != 2 {
            return (false, "Year must be 2 digits (YY)")
        }
        
        // Check if date is not in the past
        let currentDate = Date()
        let calendar = Calendar.current
        let currentYear = calendar.component(.year, from: currentDate) % 100
        let currentMonth = calendar.component(.month, from: currentDate)
        
        // Check if year is in the past
        if year < currentYear {
            return (false, "Expiry date cannot be in the past")
        }
        
        // If same year, check if month is in the past
        if year == currentYear && month < currentMonth {
            return (false, "Expiry date cannot be in the past")
        }
        
        return (true, "")
    }
    
    private func submitCreditCard(scrollAction: @escaping (String) -> Void) async {
        guard validateInputs(scrollAction: scrollAction) else { return }
        
        viewModel.isLoading = true
        
        do {
            // Parse expiry date
            let expiryComponents = expiryDate.components(separatedBy: "/")
            guard expiryComponents.count == 2 else {
                viewModel.alertMessage = "Invalid expiry date format"
                viewModel.showAlert = true
                viewModel.isLoading = false
                return
            }
            
            let expMonth = expiryComponents[0]
            let expYear = expiryComponents[1]
            
            // Parse location
            let locationComponents = location.components(separatedBy: ", ")
            let city = locationComponents.first ?? ""
            let state = locationComponents.count > 1 ? locationComponents[1] : ""
            
            let request = CreditCardRequest(
                number: cardNumber.replacingOccurrences(of: " ", with: ""),
                expMonth: expMonth,
                expYear: expYear,
                cvc: cvv.trimmingCharacters(in: .whitespacesAndNewlines),
                name: nameOnCard.trimmingCharacters(in: .whitespacesAndNewlines),
                location: location.trimmingCharacters(in: .whitespacesAndNewlines),
                city: city,
                state: state,
                zipCode: postalCode.trimmingCharacters(in: .whitespacesAndNewlines),
                cardType: "visa", // Default to visa
                smsOptIn: true
            )
            
            print("Credit Card Request Body:")
            print(String(data: try JSONEncoder().encode(request), encoding: .utf8) ?? "")
            
            let response = try await NetworkService.submitCreditCard(request)
            
            print("Credit Card Response:")
            print(String(data: try JSONEncoder().encode(response), encoding: .utf8) ?? "")
            
            if response.success {
                // Save card details
                StorageManager.shared.saveCardDetails(response.data)
                
                // Update profile completion status to true
                StorageManager.shared.updateProfileCompletionStatus(true)
                StorageManager.shared.saveCustomerNextStep(nil)
                
                showNextScreen = true
            } else {
                viewModel.alertMessage = response.message
                viewModel.showAlert = true
            }
            
        } catch {
            print("Credit Card API Error: \(error)")
            viewModel.alertMessage = "Failed to submit credit card details. Please try again."
            viewModel.showAlert = true
        }
        
        viewModel.isLoading = false
    }
}

#Preview {
    CreditCardScreen()
}
