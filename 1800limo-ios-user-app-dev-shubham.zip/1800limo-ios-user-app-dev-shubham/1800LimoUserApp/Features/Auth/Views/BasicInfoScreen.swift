//
//  BasicInfoScreen.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct BasicInfoScreen: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AuthViewModel()
    @State private var name = ""
    @State private var email = ""
    @State private var showNextScreen = false
    @State private var showTermsWebView = false
    @State private var showPrivacyWebView = false
    @State private var didAutoLaunchCreditCard = false
    @State private var hideContentForAutoLaunch = false
    
    var autoLaunchCreditCard: Bool = false
    
    var body: some View {
        ZStack {
            Color.white.ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 0) {
                // Header
                VStack(alignment: .leading, spacing: 0) {
                    Text("Add Basic Details")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(AppColors.primaryText)
                        .padding(.horizontal, 24)
                        .padding(.top, 60)
                }
                
                Spacer().frame(height: 18)
                
                VStack(spacing: 24) {
                    // Name Input
                    AppTextField(
                        label: "Enter Your Name",
                        placeholder: "eg. Alexa Smith",
                        text: $name,
                        keyboardType: .default
                    )
                    .padding(.horizontal, 24)
                    
                    // Email Input
                    AppTextField(
                        label: "Enter Your Email Id",
                        placeholder: "abc@gmail.com",
                        text: Binding(
                            get: { email },
                            set: { newValue in
                                email = newValue.lowercased()
                            }
                        ),
                        keyboardType: .emailAddress,
                        textContentType: .emailAddress
                    )
                    .padding(.horizontal, 24)
                }
                
                Spacer()
                Spacer()
                
                // Bottom Section
                HStack(alignment: .bottom, spacing: 0) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("By continuing, I agree to the")
                            .font(.system(size: AppTypography.small, weight: .regular, design: .default))
                            .foregroundColor(AppColors.primaryText)
                            .lineSpacing(2)
                        
                        HStack(spacing: 0) {
                            Button("Terms of use") {
                                showTermsWebView = true
                            }
                            .font(.system(size: AppTypography.small, weight: .regular, design: .default))
                            .foregroundColor(AppColors.primaryOrange)
                            .lineSpacing(2)
                            
                            Text(" & ")
                                .font(.system(size: AppTypography.small, weight: .regular, design: .default))
                                .foregroundColor(AppColors.primaryText)
                                .lineSpacing(2)
                            
                            Button("Privacy policy") {
                                showPrivacyWebView = true
                            }
                            .font(.system(size: AppTypography.small, weight: .regular, design: .default))
                            .foregroundColor(AppColors.primaryOrange)
                            .lineSpacing(2)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 40)
                    
                    Spacer()
                    
                    Button(action: {
                        Task {
                            await submitBasicDetails()
                        }
                    }) {
                        HStack(spacing: 8) {
                            Text("Next")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                            
                            Image(systemName: "arrow.right")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                        }
                        .frame(width: 94, height: 48)
                        .background(isFormValid() ? AppColors.primaryOrange : AppColors.primaryOrange.opacity(0.5))
                        .cornerRadius(24)
                    }
                    .disabled(!isFormValid() || viewModel.isLoading)
                    .padding(.trailing, 24)
                    .padding(.bottom, 40)
                }
            }
            .opacity(hideContentForAutoLaunch ? 0 : 1)
        }
        .navigationBarHidden(true)
        .alert("Error", isPresented: $viewModel.showAlert) {
            Button("OK") { }
        } message: {
            Text(viewModel.alertMessage)
        }
        .fullScreenCover(isPresented: $showNextScreen) {
            CreditCardScreen()
                .onDisappear {
                    hideContentForAutoLaunch = false
                }
        }
        .onAppear {
            prefillFieldsFromStorage()
            triggerAutoCreditCardIfNeeded()
        }
        .fullScreenCover(isPresented: $showTermsWebView) {
            WebViewScreen(
                url: URL(string: "https://1800limo.com/delivery-membership-terms-condition")!,
                title: "Terms of Use"
            )
        }
        .fullScreenCover(isPresented: $showPrivacyWebView) {
            WebViewScreen(
                url: URL(string: "https://1800limo.com/privacy-policy")!,
                title: "Privacy Policy"
            )
        }
        .onChange(of: showNextScreen) { isPresented in
            if !isPresented {
                hideContentForAutoLaunch = false
            }
        }
    }
    
    private func prefillFieldsFromStorage() {
        if let storedProfile = StorageManager.shared.getUserProfile() {
            if name.isEmpty {
                name = storedProfile.name
            }
            if email.isEmpty {
                email = storedProfile.email
            }
        } else if let storedProfileData = StorageManager.shared.getUserProfileData() {
            if name.isEmpty {
                name = storedProfileData.fullName
            }
            if email.isEmpty {
                email = storedProfileData.email
            }
        }
    }
    
    private func triggerAutoCreditCardIfNeeded() {
        guard autoLaunchCreditCard, !didAutoLaunchCreditCard else { return }
        didAutoLaunchCreditCard = true
        hideContentForAutoLaunch = true
        DispatchQueue.main.async {
            showNextScreen = true
        }
    }
    
    private func isFormValid() -> Bool {
        return !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               !email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
               isValidEmail(email)
    }
    
    private func validateInputs() -> Bool {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if trimmedName.isEmpty {
            viewModel.alertMessage = "Please enter your name"
            viewModel.showAlert = true
            return false
        }
        
        if trimmedName.count < 2 {
            viewModel.alertMessage = "Name must be at least 2 characters long"
            viewModel.showAlert = true
            return false
        }
        
        if trimmedEmail.isEmpty {
            viewModel.alertMessage = "Please enter your email"
            viewModel.showAlert = true
            return false
        }
        
        if !isValidEmail(trimmedEmail) {
            viewModel.alertMessage = "Please enter a valid email address"
            viewModel.showAlert = true
            return false
        }
        
        return true
    }
    
    private func submitBasicDetails() async {
        guard validateInputs() else { return }
        
        // Check if user has valid token
        guard let token = StorageManager.shared.getAuthToken(), !token.isEmpty else {
            viewModel.alertMessage = "Authentication required. Please login again."
            viewModel.showAlert = true
            return
        }
        
        viewModel.isLoading = true
        
        do {
            let request = BasicDetailsRequest(
                name: name.trimmingCharacters(in: .whitespacesAndNewlines),
                email: email.trimmingCharacters(in: .whitespacesAndNewlines)
            )
            
            print("Basic Details Request Body:")
            print(String(data: try JSONEncoder().encode(request), encoding: .utf8) ?? "")
            print("Request URL: \(APIConfig.baseURL + APIEndpoints.basicDetails.path)")
            
            let response = try await NetworkService.submitBasicDetails(request)
            
            print("Basic Details Response:")
            print(String(data: try JSONEncoder().encode(response), encoding: .utf8) ?? "")
            
            if response.success {
                // Save account ID for credit card API
                StorageManager.shared.saveAccountId(response.data.accountId)
                StorageManager.shared.saveCustomerNextStep(response.data.nextStep)
                StorageManager.shared.setProfileCompletionStatus(false)
                
                // Save user profile data (name and email)
                StorageManager.shared.saveUserProfile(
                    name: name.trimmingCharacters(in: .whitespacesAndNewlines),
                    email: email.trimmingCharacters(in: .whitespacesAndNewlines)
                )
                
                showNextScreen = true
            } else {
                viewModel.alertMessage = response.message
                viewModel.showAlert = true
            }
            
        } catch {
            print("Basic Details API Error: \(error)")
            print("Error Details: \(error.localizedDescription)")
            
            // Show only the error message from the response, no additional error text
            if let networkError = error as? NetworkError {
                switch networkError {
                case .serverError(let message):
                    viewModel.alertMessage = message
                case .networkError(let underlyingError):
                    viewModel.alertMessage = underlyingError.localizedDescription
                default:
                    viewModel.alertMessage = "Failed to submit basic details. Please try again."
                }
            } else {
                viewModel.alertMessage = error.localizedDescription
            }
            viewModel.showAlert = true
        }
        
        viewModel.isLoading = false
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
}

#Preview {
    BasicInfoScreen()
}
