//
//  OTPScreen.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct OTPScreen: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = AuthViewModel()
    @State private var otpCode = ""
    @State private var showBasicInfoScreen = false
    @State private var showDashboard = false
    @State private var showCreditCardScreen = false
    @FocusState private var isTextFieldFocused: Bool
    
    let phoneNumber: String
    let countryCode: String
    
    var body: some View {
        ZStack {
            // Background
            Color.white.ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 0) {
                    // Back Button
                    HStack {
                        Button(action: {
                            dismiss()
                        }) {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 18, weight: .medium))
                                .foregroundColor(.black)
                                .frame(width: 40, height: 40)
                                .background(Color.gray.opacity(0.1))
                                .clipShape(Circle())
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 16)
                    
                    // Title
                    VStack(alignment: .leading, spacing: 8) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Enter the verification code")
                                .font(.system(size: 24, weight: .semibold))
                                .foregroundColor(AppColors.primaryText)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                            
                            Text("sent to you")
                                .font(.system(size: 24, weight: .semibold))
                                .foregroundColor(AppColors.primaryText)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                        }
                        
                        Text("We have sent you a 6-digit code on your \(countryCode) \(phoneNumber).")
                            .font(.system(size: 12, weight: .regular))
                            .foregroundColor(AppColors.secondaryText)
                            .lineSpacing(4)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 32)
                }
                
                Spacer().frame(height: 18)
                
                // OTP Input Fields
                HStack(spacing: 16) {
                    ForEach(0..<6, id: \.self) { index in
                        OTPTextField(
                            text: $otpCode,
                            index: index,
                            isActive: otpCode.count == index
                        )
                    }
                }
                .padding(.horizontal, 24)
                .onTapGesture {
                    isTextFieldFocused = true
                }
                
                Spacer()
                
                // Resend Code and Next Button in same line
                HStack {
                    Button(action: {
                        if viewModel.resendCooldown == 0 {
                            Task {
                                await viewModel.resendOTP()
                            }
                        }
                    }) {
                        Text("Resend code via SMS (\(viewModel.resendCooldown))")
                            .font(.system(size: 14, weight: .regular))
                            .foregroundColor(viewModel.resendCooldown == 0 ? AppColors.primaryOrange : AppColors.secondaryText)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(16)
                    }
                    .disabled(viewModel.resendCooldown > 0)
                    
                    Spacer()
                    
                                            Button(action: {
                            if otpCode.count == 6 {
                                Task {
                                    await viewModel.verifyOTP(otp: otpCode)
                                }
                            }
                        }) {
                        HStack(spacing: 8) {
                            Text("Next")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                            
                            Image(systemName: "arrow.right")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white)
                        }
                        .frame(width: 94, height: 48)
                        .background(otpCode.count == 6 ? AppColors.primaryOrange : AppColors.primaryOrange.opacity(0.5))
                        .cornerRadius(24)
                    }
                    .disabled(otpCode.count != 6)
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 40)
                
                // Hidden TextField for native keyboard
                TextField("", text: $otpCode)
                    .keyboardType(.numberPad)
                    .focused($isTextFieldFocused)
                    .opacity(0)
                    .frame(height: 1)
                    .onChange(of: otpCode) { newValue in
                        // Limit to 6 digits
                        if newValue.count > 6 {
                            otpCode = String(newValue.prefix(6))
                        }
                        // Only allow numbers
                        let filtered = newValue.filter { $0.isNumber }
                        if filtered != newValue {
                            otpCode = filtered
                        }
                    }
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            // Auto-focus the TextField to show keyboard
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                isTextFieldFocused = true
            }
            // Start resend cooldown on entering screen (if not already running)
            viewModel.startInitialResendCooldown()
        }
        .alert("Error", isPresented: $viewModel.showAlert) {
            Button("OK") { }
        } message: {
            Text(viewModel.alertMessage)
        }
        .fullScreenCover(isPresented: $showBasicInfoScreen) {
            BasicInfoScreen()
        }
        .fullScreenCover(isPresented: $showDashboard) {
            DashboardView()
        }
        .fullScreenCover(isPresented: $showCreditCardScreen) {
            CreditCardScreen()
        }
        .onChange(of: viewModel.shouldNavigateToBasicInfo) { shouldNavigate in
            if shouldNavigate {
                showBasicInfoScreen = true
                viewModel.shouldNavigateToBasicInfo = false
            }
        }
        .onChange(of: viewModel.shouldNavigateToDashboard) { shouldNavigate in
            if shouldNavigate {
                showDashboard = true
                viewModel.shouldNavigateToDashboard = false
            }
        }
        .onChange(of: viewModel.shouldNavigateToCreditCard) { shouldNavigate in
            if shouldNavigate {
                showCreditCardScreen = true
                viewModel.shouldNavigateToCreditCard = false
            }
        }
    }
    

}

struct OTPTextField: View {
    @Binding var text: String
    let index: Int
    let isActive: Bool
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.white)
                .frame(width: 40, height: 40)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(isActive ? AppColors.borderGray : Color.gray.opacity(0.3), lineWidth: isActive ? 2 : 1)
                )
            
            if index < text.count {
                Text(String(text[text.index(text.startIndex, offsetBy: index)]))
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundColor(AppColors.primaryText)
            }
        }
    }
}



#Preview {
    OTPScreen(phoneNumber: "9876543210", countryCode: "+1")
}
