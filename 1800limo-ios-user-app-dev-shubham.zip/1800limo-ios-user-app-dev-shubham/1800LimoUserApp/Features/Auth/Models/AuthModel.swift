//
//  AuthModel.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

struct AuthModel {
    var phoneNumber: String = ""
    var countryCode: Country = countries.first(where: { $0.code == "+1" }) ?? countries[0]
    var isPhoneNumberValid: Bool = false
    var isLoading: Bool = false
    var errorMessage: String = ""
}
