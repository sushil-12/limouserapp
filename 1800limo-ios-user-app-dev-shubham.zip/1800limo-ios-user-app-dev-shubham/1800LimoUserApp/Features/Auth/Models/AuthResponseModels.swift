//
//  AuthResponseModels.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

// MARK: - Login/Register Response
struct AuthResponse: Codable {
    let success: Bool
    let message: String
    let data: AuthData
    let timestamp: String
    let code: Int
}

struct AuthData: Codable {
    let message: String
    let otpType: String
    let tempUserId: String
    let expiresIn: Int
    let cooldownRemaining: Int
    
    enum CodingKeys: String, CodingKey {
        case message
        case otpType = "otp_type"
        case tempUserId = "temp_user_id"
        case expiresIn = "expires_in"
        case cooldownRemaining = "cooldown_remaining"
    }
}

// MARK: - Login/Register Request
struct LoginRegisterRequest: Codable {
    let phoneIsd: String
    let phoneCountry: String
    let phone: String
    let userType: String
    
    enum CodingKeys: String, CodingKey {
        case phoneIsd = "phone_isd"
        case phoneCountry = "phone_country"
        case phone
        case userType = "user_type"
    }
}

// MARK: - OTP Verification Request
struct VerifyOTPRequest: Codable {
    let tempUserId: String
    let otp: String
    
    enum CodingKeys: String, CodingKey {
        case tempUserId = "temp_user_id"
        case otp
    }
}

// MARK: - OTP Verification Response
struct VerifyOTPResponse: Codable {
    let success: Bool
    let message: String
    let data: VerifyOTPData
    let timestamp: String
    let code: Int
}

struct VerifyOTPData: Codable {
    let user: User
    let token: String
    let tokenType: String
    let expiresIn: Int
    let action: String
    let driverRegistrationState: DriverRegistrationState?
    
    enum CodingKeys: String, CodingKey {
        case user
        case token
        case tokenType = "token_type"
        case expiresIn = "expires_in"
        case action
        case driverRegistrationState = "driver_registration_state"
    }
}

// MARK: - Driver Registration State
struct DriverRegistrationState: Codable {
    let currentStep: String
    let progressPercentage: Int
    let isCompleted: Bool
    let nextStep: String?
    
    enum CodingKeys: String, CodingKey {
        case currentStep = "current_step"
        case progressPercentage = "progress_percentage"
        case isCompleted = "is_completed"
        case nextStep = "next_step"
    }
}

struct User: Codable {
    let id: Int
    let phone: String
    let role: Int
    let isProfileCompleted: Bool?
    let lastLoginAt: String
    let createdFrom: String?
    let customerRegistrationState: CustomerRegistrationState?
    
    enum CodingKeys: String, CodingKey {
        case id
        case phone
        case role
        case isProfileCompleted = "is_profile_completed"
        case lastLoginAt = "last_login_at"
        case createdFrom = "created_from"
        case customerRegistrationState = "customer_registration_state"
    }
    
    // Custom initializer for UserDefaultsManager
    init(id: Int, phone: String, role: Int, isProfileCompleted: Bool?, lastLoginAt: String, createdFrom: String?, customerRegistrationState: CustomerRegistrationState? = nil) {
        self.id = id
        self.phone = phone
        self.role = role
        self.isProfileCompleted = isProfileCompleted
        self.lastLoginAt = lastLoginAt
        self.createdFrom = createdFrom
        self.customerRegistrationState = customerRegistrationState
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decode(Int.self, forKey: .id)
        phone = try container.decode(String.self, forKey: .phone)
        role = try container.decode(Int.self, forKey: .role)
        lastLoginAt = try container.decode(String.self, forKey: .lastLoginAt)
        createdFrom = try container.decodeIfPresent(String.self, forKey: .createdFrom)
        customerRegistrationState = try container.decodeIfPresent(CustomerRegistrationState.self, forKey: .customerRegistrationState)
        
        // Handle is_profile_completed as either Bool or Int (1/0)
        if let boolValue = try? container.decode(Bool.self, forKey: .isProfileCompleted) {
            isProfileCompleted = boolValue
        } else if let intValue = try? container.decode(Int.self, forKey: .isProfileCompleted) {
            isProfileCompleted = intValue == 1
        } else {
            isProfileCompleted = nil
        }
    }
}

// MARK: - Customer Registration State
struct CustomerRegistrationState: Codable {
    let currentStep: String
    let progressPercentage: Int
    let isCompleted: Bool
    let nextStep: String
    let steps: RegistrationSteps
    let completedSteps: [String]
    let totalSteps: Int
    let completedCount: Int
    
    enum CodingKeys: String, CodingKey {
        case currentStep = "current_step"
        case progressPercentage = "progress_percentage"
        case isCompleted = "is_completed"
        case nextStep = "next_step"
        case steps
        case completedSteps = "completed_steps"
        case totalSteps = "total_steps"
        case completedCount = "completed_count"
    }
}

struct RegistrationSteps: Codable {
    let phoneVerified: Bool
    let basicDetails: Bool
    let creditCard: Bool
    let profileComplete: Bool
    
    enum CodingKeys: String, CodingKey {
        case phoneVerified = "phone_verified"
        case basicDetails = "basic_details"
        case creditCard = "credit_card"
        case profileComplete = "profile_complete"
    }
}

// MARK: - Resend OTP Request
struct ResendOTPRequest: Codable {
    let tempUserId: String
    
    enum CodingKeys: String, CodingKey {
        case tempUserId = "temp_user_id"
    }
}

// MARK: - Resend OTP Response
struct ResendOTPResponse: Codable {
    let success: Bool
    let message: String
    let data: ResendOTPData
    let timestamp: String
    let code: Int
}

struct ResendOTPData: Codable {
    let message: String
    let otpType: String
    let tempUserId: String
    let expiresIn: Int
    let cooldownRemaining: Int
    
    enum CodingKeys: String, CodingKey {
        case message
        case otpType = "otp_type"
        case tempUserId = "temp_user_id"
        case expiresIn = "expires_in"
        case cooldownRemaining = "cooldown_remaining"
    }
}

// MARK: - Basic Details API Models
struct BasicDetailsRequest: Codable {
    let name: String
    let email: String
}

struct BasicDetailsResponse: Codable {
    let success: Bool
    let message: String
    let data: BasicDetailsData
    let timestamp: String
    let code: Int
}

struct BasicDetailsData: Codable {
    let accountId: Int
    let nextStep: String
    
    enum CodingKeys: String, CodingKey {
        case accountId = "account_id"
        case nextStep = "next_step"
    }
}

// MARK: - Credit Card API Models
struct CreditCardRequest: Codable {
    let number: String
    let expMonth: String
    let expYear: String
    let cvc: String
    let name: String
    let location: String?
    let city: String?
    let state: String?
    let zipCode: String?
    let cardType: String?
    let smsOptIn: Bool?
    
    enum CodingKeys: String, CodingKey {
        case number
        case expMonth = "exp_month"
        case expYear = "exp_year"
        case cvc
        case name
        case location
        case city
        case state
        case zipCode = "zipCode"
        case cardType = "card_type"
        case smsOptIn = "smsOptIn"
    }
}

struct CreditCardResponse: Codable {
    let success: Bool
    let message: String
    let data: CreditCardData
    let timestamp: String
    let code: Int
}

struct CreditCardData: Codable {
    let stripeCustomerId: String
    let cardId: String
    
    enum CodingKeys: String, CodingKey {
        case stripeCustomerId = "stripe_customer_id"
        case cardId = "card_id"
    }
}

// MARK: - API Error Response
struct APIErrorResponse: Codable {
    let success: Bool
    let message: String
    let code: Int
    let timestamp: String
}

// MARK: - Network Error
enum NetworkError: Error, LocalizedError {
    case invalidURL
    case noData
    case decodingError
    case serverError(String)
    case networkError(Error)
    case invalidResponse
    
    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid URL"
        case .noData:
            return "No data received"
        case .decodingError:
            return "Failed to decode response"
        case .serverError(let message):
            return message
        case .networkError(let error):
            return error.localizedDescription
        case .invalidResponse:
            return "Invalid response from server"
        }
    }
}
