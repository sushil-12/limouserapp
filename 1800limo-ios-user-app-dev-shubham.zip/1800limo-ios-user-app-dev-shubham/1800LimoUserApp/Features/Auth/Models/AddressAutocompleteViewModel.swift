import Foundation
import Combine

enum AddressAutocompleteMode {
    case address
    case city
}

class AddressAutocompleteViewModel: ObservableObject, Equatable {
    @Published var input: String = "" {
        didSet {
            if !isEditing {
                // If input is set programmatically, do not fetch suggestions
                return
            }
            
            // Clear coordinates and postal code when input is changed manually
            if selectedCoordinate != nil {
                selectedCoordinate = nil
            }
            if selectedPostalCode != nil {
                selectedPostalCode = nil
            }
            if selectedCountry != nil {
                selectedCountry = nil
            }
        }
    }
    @Published var suggestions: [String] = []
    @Published var isLoading: Bool = false
    @Published var selectedSuggestion: String? = nil
    @Published var isEditing: Bool = false {
        didSet {
            // When editing starts again, clear suggestions if input is empty
            if isEditing && input.isEmpty {
                suggestions = []
            }
        }
    }
    @Published var selectedCoordinate: LocationCoordinate? = nil
    @Published var selectedPostalCode: String? = nil
    @Published var selectedCountry: String? = nil
    var mode: AddressAutocompleteMode = .address
    
    private var cancellables = Set<AnyCancellable>()
    private let service = GooglePlacesService()
    
    init() {
        $input
            .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
            .removeDuplicates()
            .sink { [weak self] text in
                guard let self = self else { return }
                if self.isEditing && !text.isEmpty {
                    self.fetchSuggestions(for: text)
                } else {
                    // Only clear suggestions if we're not editing anymore
                    if !self.isEditing {
                        self.suggestions = []
                    }
                }
            }
            .store(in: &cancellables)
    }
    
    func fetchSuggestions(for text: String) {
        print("[AddressAutocompleteViewModel] fetchSuggestions called with: \(text)")
        guard !text.isEmpty else {
            suggestions = []
            return
        }
        isLoading = true
        if mode == .city {
            service.fetchCitySuggestions(for: text) { [weak self] results in
                DispatchQueue.main.async {
                    print("[AddressAutocompleteViewModel] City Suggestions received: \(results)")
                    self?.suggestions = results
                    self?.isLoading = false
                }
            }
        } else {
            service.fetchSuggestions(for: text) { [weak self] results in
                DispatchQueue.main.async {
                    print("[AddressAutocompleteViewModel] Suggestions received: \(results)")
                    self?.suggestions = results
                    self?.isLoading = false
                }
            }
        }
    }
    
    func selectSuggestion(_ suggestion: String) {
        selectedSuggestion = suggestion
        isEditing = false  // Set isEditing to false first to prevent triggering suggestions
        input = suggestion
        suggestions = []
        
        // Fetch location details (coordinates and postal code) for the selected address
        service.fetchLocationDetails(for: suggestion) { [weak self] locationDetails in
            DispatchQueue.main.async {
                self?.selectedCoordinate = locationDetails?.coordinate
                self?.selectedPostalCode = locationDetails?.postalCode
                self?.selectedCountry = locationDetails?.country
                print("[AddressAutocompleteViewModel] Selected location details for \(suggestion): coordinate = \(locationDetails?.coordinate?.latitude ?? 0), \(locationDetails?.coordinate?.longitude ?? 0), postal code = \(locationDetails?.postalCode ?? "nil"), country = \(locationDetails?.country ?? "nil")")
            }
        }
    }
    
    // MARK: - Equatable
    static func == (lhs: AddressAutocompleteViewModel, rhs: AddressAutocompleteViewModel) -> Bool {
        return lhs.input == rhs.input &&
               lhs.selectedSuggestion == rhs.selectedSuggestion &&
               lhs.selectedCoordinate == rhs.selectedCoordinate &&
               lhs.isEditing == rhs.isEditing
    }
} 