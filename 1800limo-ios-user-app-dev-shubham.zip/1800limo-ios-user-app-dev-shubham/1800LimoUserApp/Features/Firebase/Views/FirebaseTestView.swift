import SwiftUI
import Firebase
import FirebaseMessaging

struct FirebaseTestView: View {
    @StateObject private var firebaseService = FirebasePushNotificationService.shared
    @State private var showingStatus = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header
                Text("Firebase Push Notifications")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.bottom)
                
                // Status Section
                VStack(alignment: .leading, spacing: 15) {
                    Text("Status")
                        .font(.headline)
                    
                    StatusRow(
                        label: "Firebase App",
                        value: FirebaseApp.app() != nil,
                        details: "Firebase configuration"
                    )
                    
                    StatusRow(
                        label: "APNs Token",
                        value: Messaging.messaging().apnsToken != nil,
                        details: "Required for push notifications"
                    )
                    
                    StatusRow(
                        label: "FCM Token",
                        value: firebaseService.fcmToken != nil,
                        details: "Firebase Cloud Messaging token"
                    )
                    
                    StatusRow(
                        label: "Topic Subscription",
                        value: firebaseService.isSubscribed,
                        details: "Subscribed to user topic"
                    )
                    
                    StatusRow(
                        label: "User ID",
                        value: StorageManager.shared.getUserIdString() != nil,
                        details: StorageManager.shared.getUserIdString() ?? "Not available"
                    )
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
                
                // FCM Token Section
                if let fcmToken = firebaseService.fcmToken {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("FCM Token")
                            .font(.headline)
                        
                        Text(fcmToken)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                        
                        Button("Copy Token") {
                            UIPasteboard.general.string = fcmToken
                        }
                        .font(.caption)
                        .foregroundColor(.blue)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }
                
                // Actions Section
                VStack(alignment: .leading, spacing: 15) {
                    Text("Actions")
                        .font(.headline)
                    
                    Button(action: {
                        firebaseService.requestNotificationPermission()
                    }) {
                        HStack {
                            Image(systemName: "bell.badge")
                            Text("Request Permissions")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    Button(action: {
                        firebaseService.getFCMToken()
                    }) {
                        HStack {
                            Image(systemName: "key")
                            Text("Get FCM Token")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(AppColors.greenColor)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    Button(action: {
                        firebaseService.subscribeToUserTopic()
                    }) {
                        HStack {
                            Image(systemName: "bell")
                            Text("Subscribe to Topic")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    Button(action: {
                        firebaseService.printDebugInfo()
                        showingStatus = true
                    }) {
                        HStack {
                            Image(systemName: "info.circle")
                            Text("Print Debug Info")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    Button(action: {
                        firebaseService.resetAndReinitialize()
                    }) {
                        HStack {
                            Image(systemName: "arrow.clockwise")
                            Text("Reset & Reinitialize")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
                
                // Error Section
                if let error = firebaseService.subscriptionError {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Error")
                            .font(.headline)
                            .foregroundColor(.red)
                        
                        Text(error)
                            .font(.caption)
                            .foregroundColor(.red)
                            .padding()
                            .background(Color.red.opacity(0.1))
                            .cornerRadius(8)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }
                
                // Last Notification Section
                if let notification = firebaseService.lastNotification {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Last Notification")
                            .font(.headline)
                        
                        Text(notification)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(8)
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                }
            }
            .padding()
        }
        .alert("Debug Information", isPresented: $showingStatus) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(firebaseService.getCurrentStatus())
        }
    }
}

struct StatusRow: View {
    let label: String
    let value: Bool
    let details: String
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text(label)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text(details)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Image(systemName: value ? "checkmark.circle.fill" : "xmark.circle.fill")
                .foregroundColor(value ? AppColors.greenColor : .red)
                .font(.title2)
        }
    }
}

#Preview {
    FirebaseTestView()
}






