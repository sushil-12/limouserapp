import UIKit
import Firebase
import FirebaseMessaging
import UserNotifications
import SwiftUI

// MARK: - Date Extension
extension Date {
    var iso8601String: String {
        let formatter = ISO8601DateFormatter()
        return formatter.string(from: self)
    }
}

@objc class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        // Firebase is already configured in _800LimoUserAppApp
        
        // Check entitlements first
        EntitlementsChecker.checkEntitlements()
        EntitlementsChecker.checkCodeSigning()
        
        // Set notification center delegate
        UNUserNotificationCenter.current().delegate = self
        
        // Request notification permissions immediately
        requestNotificationPermissions()
        
        // Set messaging delegate
        Messaging.messaging().delegate = self
        
        return true
    }
    
    // Request notification permissions
    private func requestNotificationPermissions() {
        let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
        UNUserNotificationCenter.current().requestAuthorization(
            options: authOptions,
            completionHandler: { granted, error in
                DispatchQueue.main.async {
                    if granted {
                        print("Firebase: Notification permission granted")
                        // Register for remote notifications after permission is granted
                        UIApplication.shared.registerForRemoteNotifications()
                    } else {
                        print("Firebase: Notification permission denied: \(error?.localizedDescription ?? "Unknown error")")
                    }
                }
            }
        )
    }
    
    // Required for UIApplicationDelegate conformance
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session
    }
    
    // Handle APNs token registration
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        // Set APNs token for Firebase
        Messaging.messaging().apnsToken = deviceToken
        print("Firebase: APNs token set from AppDelegate")
        
        // Notify Firebase service
        FirebasePushNotificationService.shared.setAPNsToken(deviceToken)
        
        // Get FCM token after APNs token is set
        Messaging.messaging().token { token, error in
            if let error = error {
                print("Firebase: Error getting FCM token: \(error)")
                return
            }
            
            if let token = token {
                print("Firebase: FCM Token received: \(token)")
                FirebasePushNotificationService.shared.fcmToken = token
                
                // Subscribe to user topic after FCM token is received
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    print("Firebase: FCM token received, now subscribing to topics")
                    FirebasePushNotificationService.shared.subscribeToUserTopic()
                }
            }
        }
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Firebase: Failed to register for remote notifications: \(error)")
    }
    
    // Handle silent notifications when app is in background or terminated
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        print("Firebase: Received remote notification in background: \(userInfo)")
        
        // Handle the notification data here
        if let aps = userInfo["aps"] as? [String: Any] {
            print("Firebase: APS payload: \(aps)")
            
            // Check if this is a silent notification
            if aps["content-available"] as? Int == 1 {
                print("Firebase: Processing silent notification")
                // Handle silent notification logic here - store data for when app opens
                handleSilentNotification(userInfo: userInfo)
            } else {
                // This is a regular notification that will show to user
                print("Firebase: Processing regular notification")
                // Store notification data for potential deep link navigation
                handleNotificationNavigation(userInfo: userInfo)
            }
        }
        
        // Update Firebase service with notification data
        FirebasePushNotificationService.shared.lastNotification = userInfo["body"] as? String ?? "Background notification received"
        
        completionHandler(.newData)
    }
    
    /// Handle silent notifications (app killed/background)
    private func handleSilentNotification(userInfo: [AnyHashable: Any]) {
        print("🔇 Firebase: Handling silent notification")
        
        // Check if this is a ride completion notification
        if let notificationType = userInfo["type"] as? String,
           let status = userInfo["status"] as? String,
           notificationType == "ended" && status == "ended" {
            print("🎉 Firebase: Ride completion notification detected in background!")
            print("🎉 Booking ID: \(userInfo["bookingId"] ?? "unknown")")
            
            // Post notification to show ride completion dialog when app becomes active
            DispatchQueue.main.async {
                NotificationCenter.default.post(
                    name: NSNotification.Name("RideStatusUpdate"),
                    object: nil,
                    userInfo: [
                        "status": status,
                        "type": notificationType,
                        "bookingId": userInfo["bookingId"] ?? "",
                        "driverId": userInfo["driverId"] ?? "",
                        "customerId": userInfo["customerId"] ?? ""
                    ]
                )
                print("🎉 Posted RideStatusUpdate notification for ride completion from background")
            }
            return
        }
        
        // Extract custom data from notification
        if let customData = userInfo["custom_data"] as? [String: Any] {
            let notificationType = customData["type"] as? String ?? ""
            
            print("🔇 Firebase: Silent notification type: \(notificationType)")
            
            // Handle ride-related silent notifications
            if ["live_ride", "active_ride", "driver_assigned", "on_location", "driver_location_update"].contains(notificationType) {
                print("🚗 Firebase: Storing ride data from silent notification")
                
                // Create LiveRideData from notification
                let liveRideData = createLiveRideDataFromNotification(customData: customData)
                
                // Store the data for when app opens
                NotificationDataManager.shared.storePendingRideData(liveRideData)
                NotificationDataManager.shared.setShouldOpenToRideInProgress()
                
                print("✅ Firebase: Ride data stored for app launch")
            }
        }
    }
    
    // Handle notifications when app is in foreground
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let userInfo = notification.request.content.userInfo
        print("Firebase: Received notification while app is in foreground: \(userInfo)")
        
        // Update Firebase service
        FirebasePushNotificationService.shared.lastNotification = userInfo["body"] as? String ?? "Foreground notification received"
        
        // Check if this is a chat notification and user is on chat screen
        var isChatNotification = false
        var chatBookingId: Int?
        
        // Check notification type
        if let notificationType = userInfo["type"] as? String, notificationType == "chat_message" {
            isChatNotification = true
            if let bookingId = userInfo["bookingId"] as? Int {
                chatBookingId = bookingId
            } else if let bookingIdStr = userInfo["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                chatBookingId = bookingId
            }
        } else if let customData = userInfo["custom_data"] as? [String: Any],
                  let type = customData["type"] as? String, type == "chat_message" {
            isChatNotification = true
            if let bookingId = customData["bookingId"] as? Int {
                chatBookingId = bookingId
            } else if let bookingIdStr = customData["bookingId"] as? String, let bookingId = Int(bookingIdStr) {
                chatBookingId = bookingId
            }
        }
        
        // If it's a chat notification and user is on chat screen, suppress notification
        if isChatNotification {
            let isOnChatScreen = ScreenTracker.shared.isOnChatScreen(for: chatBookingId)
            if isOnChatScreen {
                print("Firebase: Chat notification received but user is on chat screen - suppressing notification")
                completionHandler([])
                return
            }
            print("Firebase: Chat notification received - showing notification")
        }
        
        // Check if this is a ride completion notification
        if let notificationType = userInfo["type"] as? String,
           let status = userInfo["status"] as? String,
           notificationType == "ended" && status == "ended" {
            print("🎉 Firebase: Ride completion notification detected in foreground!")
            print("🎉 Booking ID: \(userInfo["bookingId"] ?? "unknown")")
            
            // Post notification to show ride completion dialog
            DispatchQueue.main.async {
                NotificationCenter.default.post(
                    name: NSNotification.Name("RideStatusUpdate"),
                    object: nil,
                    userInfo: [
                        "status": status,
                        "type": notificationType,
                        "bookingId": userInfo["bookingId"] ?? "",
                        "driverId": userInfo["driverId"] ?? "",
                        "customerId": userInfo["customerId"] ?? ""
                    ]
                )
                print("🎉 Posted RideStatusUpdate notification for ride completion")
            }
            
            // Don't show the system notification, we'll show our custom dialog instead
            completionHandler([])
            return
        }
        
        // Check if this is a live_ride notification and trigger navigation
        if let customData = userInfo["custom_data"] as? [String: Any],
           let notificationType = customData["type"] as? String,
           (notificationType == "live_ride" || notificationType == "live_ride_do") {
            print("🚗 Firebase: live_ride notification detected in foreground - triggering navigation")
            
            // Convert FCM notification format to socket notification format and handle it
            DispatchQueue.main.async {
                // Create notification data in the format expected by socket service
                var notificationData: [String: Any] = [
                    "type": notificationType,
                    "title": userInfo["title"] as? String ?? customData["title"] as? String ?? "Ride Update",
                    "message": userInfo["body"] as? String ?? userInfo["message"] as? String ?? customData["message"] as? String ?? "Your ride has been updated"
                ]
                
                // Add data object if available
                if let data = customData["data"] as? [String: Any] {
                    notificationData["data"] = data
                } else {
                    // Convert custom_data to data format
                    notificationData["data"] = customData
                }
                
                // Handle via socket service
                SimpleSocketIOService.shared.handleLiveRideNotificationFromFCM(notificationData)
            }
        }
        
        // Show notification even when app is in foreground
        completionHandler([.alert, .badge, .sound])
    }
    
    // Handle notification tap
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        print("🔔 ========== NOTIFICATION TAPPED ==========")
        print("🔔 User tapped on notification: \(userInfo)")
        print("🔔 Notification response action: \(response.actionIdentifier)")
        
        // Update Firebase service
        FirebasePushNotificationService.shared.lastNotification = userInfo["body"] as? String ?? "Notification tapped"
        
        // Handle notification tap logic here - Navigate to RideInProgressView
        handleNotificationNavigation(userInfo: userInfo)
        
        print("🔔 ==========================================")
        completionHandler()
    }
    
    // MARK: - Deep Link Handling for Notifications
    
    /// Handle navigation when notification is tapped (app killed or background)
    private func handleNotificationNavigation(userInfo: [AnyHashable: Any]) {
        print("🔗 ========== DEEP LINK PROCESSING ==========")
        print("🔗 Processing notification for navigation")
        print("🔗 Full userInfo: \(userInfo)")
        
        // Extract notification data
        guard let aps = userInfo["aps"] as? [String: Any] else {
            print("❌ No APS data in notification")
            print("🔗 Available keys in userInfo: \(Array(userInfo.keys))")
            return
        }
        
        print("🔗 APS data: \(aps)")
        
        // Check if this is a ride-related notification
        if let customData = userInfo["custom_data"] as? [String: Any] {
            let notificationType = customData["type"] as? String ?? ""
            let bookingId = customData["booking_id"] as? String ?? ""
            
            print("🔗 Deep Link: Notification type: \(notificationType), Booking ID: \(bookingId)")
            print("🔗 Custom data: \(customData)")
            
            // Handle different notification types
            switch notificationType {
            case "live_ride", "active_ride", "driver_assigned", "on_location":
                print("🚗 Deep Link: Ride notification detected - will navigate to RideInProgressView")
                handleRideNotificationNavigation(customData: customData)
                
            case "booking_confirmed", "booking_cancelled":
                print("📋 Deep Link: Booking notification detected - will navigate to MyBookingsView")
                handleBookingNotificationNavigation(customData: customData)
                
            default:
                print("📱 Deep Link: General notification - will navigate to DashboardView")
                handleGeneralNotificationNavigation()
            }
        } else {
            // Check if notification data is in a different format (maybe direct in userInfo)
            print("🔗 No custom_data found, checking for direct notification data...")
            
            // Check for common notification payload formats
            let notificationType = userInfo["type"] as? String ?? ""
            let message = userInfo["message"] as? String ?? ""
            let title = userInfo["title"] as? String ?? ""
            
            print("🔗 Direct data - Type: \(notificationType), Title: \(title), Message: \(message)")
            
            // Check if this looks like a ride notification based on message content
            let messageLower = message.lowercased()
            let titleLower = title.lowercased()
            
            print("🔗 Checking message content for ride keywords...")
            print("🔗 Title: '\(titleLower)'")
            print("🔗 Message: '\(messageLower)'")
            
            if messageLower.contains("driver") || messageLower.contains("location") || 
               messageLower.contains("arrived") || messageLower.contains("on the way") ||
               messageLower.contains("assigned") || messageLower.contains("pickup") ||
               titleLower.contains("driver") || titleLower.contains("location") ||
               titleLower.contains("arrived") || titleLower.contains("ride") {
                print("🚗 Deep Link: Ride notification detected from message content - will navigate to RideInProgressView")
                // Create minimal ride data for navigation
                handleRideNotificationFromMessage(title: title, message: message, userInfo: userInfo)
            } else {
                print("📱 Deep Link: No custom data - navigating to DashboardView")
                handleGeneralNotificationNavigation()
            }
        }
        
        print("🔗 ==========================================")
    }
    
    /// Handle ride-related notifications
    private func handleRideNotificationNavigation(customData: [String: Any]) {
        print("🚗 Deep Link: Processing ride notification navigation")
        
        // Extract ride data from notification
        let bookingId = customData["booking_id"] as? String ?? ""
        let status = customData["status"] as? String ?? "en_route_pu"
        
        // Create LiveRideData from notification data
        let liveRideData = createLiveRideDataFromNotification(customData: customData)
        
        // Store the data for when the app opens
        NotificationDataManager.shared.storePendingRideData(liveRideData)
        
        // Set flag to indicate app should open to RideInProgressView
        NotificationDataManager.shared.shouldOpenToRideInProgress = true
        
        print("✅ Deep Link: Ride data stored, app will open to RideInProgressView")
    }
    
    /// Create LiveRideData from notification custom data
    private func createLiveRideDataFromNotification(customData: [String: Any]) -> LiveRideData {
        let bookingId = customData["booking_id"] as? String ?? ""
        let driverId = customData["driver_id"] as? String ?? ""
        let customerId = customData["customer_id"] as? String ?? ""
        let status = customData["status"] as? String ?? "en_route_pu"
        
        // Extract location data
        let driverLat = customData["driver_lat"] as? Double ?? 0.0
        let driverLng = customData["driver_lng"] as? Double ?? 0.0
        let pickupLat = customData["pickup_lat"] as? Double ?? 0.0
        let pickupLng = customData["pickup_lng"] as? Double ?? 0.0
        let dropoffLat = customData["dropoff_lat"] as? Double ?? 0.0
        let dropoffLng = customData["dropoff_lng"] as? Double ?? 0.0
        
        let pickupAddress = customData["pickup_address"] as? String ?? ""
        let dropoffAddress = customData["dropoff_address"] as? String ?? ""
        let title = customData["title"] as? String ?? "Ride Update"
        let message = customData["message"] as? String ?? "Your ride has been updated"
        let timestamp = customData["timestamp"] as? String ?? ""
        
        func trimmedString(_ value: Any?) -> String? {
            switch value {
            case let string as String:
                let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
                return trimmed.isEmpty ? nil : trimmed
            case let number as NSNumber:
                let stringValue = number.stringValue
                return stringValue.isEmpty ? nil : stringValue
            default:
                return nil
            }
        }
        
        var driverName = trimmedString(customData["driver_name"]) ??
                         trimmedString(customData["driver_full_name"]) ??
                         trimmedString(customData["driverName"])
        if driverName == nil, let first = trimmedString(customData["driver_first_name"]),
           let last = trimmedString(customData["driver_last_name"]) {
            driverName = "\(first) \(last)"
        }
        
        var driverPhone = trimmedString(customData["driver_phone"]) ??
                          trimmedString(customData["driver_mobile"]) ??
                          trimmedString(customData["driver_contact"])
        if let isd = trimmedString(customData["driver_mobile_isd"]) ??
                     trimmedString(customData["driver_country_code"]) {
            let normalizedIsd = isd.hasPrefix("+") ? isd : "+" + isd
            if let currentPhone = driverPhone, !currentPhone.hasPrefix("+") {
                driverPhone = normalizedIsd + currentPhone.filter { $0.isNumber }
            }
        }
        
        return LiveRideData(
            bookingId: bookingId,
            driverId: driverId,
            customerId: customerId,
            status: status,
            driverLatitude: driverLat,
            driverLongitude: driverLng,
            pickupLatitude: pickupLat,
            pickupLongitude: pickupLng,
            dropoffLatitude: dropoffLat,
            dropoffLongitude: dropoffLng,
            pickupAddress: pickupAddress,
            dropoffAddress: dropoffAddress,
            timestamp: timestamp,
            title: title,
            message: message,
            driverName: driverName,
            driverPhone: driverPhone
        )
    }
    
    /// Handle booking-related notifications
    private func handleBookingNotificationNavigation(customData: [String: Any]) {
        print("📋 Deep Link: Processing booking notification navigation")
        NotificationDataManager.shared.shouldOpenToMyBookings = true
        NotificationDataManager.shared.storedBookingData = customData
    }
    
    /// Handle ride notifications from message content (fallback for different payload formats)
    private func handleRideNotificationFromMessage(title: String, message: String, userInfo: [AnyHashable: Any]) {
        print("🚗 Deep Link: Processing ride notification from message content")
        
        // Extract any available data from userInfo
        let bookingId = userInfo["bookingId"] as? String ?? userInfo["booking_id"] as? String ?? "unknown"
        let driverId = userInfo["driverId"] as? String ?? userInfo["driver_id"] as? String ?? "unknown"
        let customerId = userInfo["customerId"] as? String ?? userInfo["customer_id"] as? String ?? "unknown"
        
        // Try to extract location data with multiple possible keys
        let driverLat = userInfo["driverLat"] as? Double ?? 
                       userInfo["driver_lat"] as? Double ?? 
                       userInfo["driverLatitude"] as? Double ?? 
                       userInfo["driver_latitude"] as? Double ?? 30.6735
        let driverLng = userInfo["driverLng"] as? Double ?? 
                       userInfo["driver_lng"] as? Double ?? 
                       userInfo["driverLongitude"] as? Double ?? 
                       userInfo["driver_longitude"] as? Double ?? 76.7884
        let pickupLat = userInfo["pickupLat"] as? Double ?? 
                       userInfo["pickup_lat"] as? Double ?? 
                       userInfo["pickupLatitude"] as? Double ?? 
                       userInfo["pickup_latitude"] as? Double ?? 30.6942
        let pickupLng = userInfo["pickupLng"] as? Double ?? 
                       userInfo["pickup_lng"] as? Double ?? 
                       userInfo["pickupLongitude"] as? Double ?? 
                       userInfo["pickup_longitude"] as? Double ?? 76.7933
        let dropoffLat = userInfo["dropoffLat"] as? Double ?? 
                        userInfo["dropoff_lat"] as? Double ?? 
                        userInfo["dropoffLatitude"] as? Double ?? 
                        userInfo["dropoff_latitude"] as? Double ?? 30.7000
        let dropoffLng = userInfo["dropoffLng"] as? Double ?? 
                        userInfo["dropoff_lng"] as? Double ?? 
                        userInfo["dropoffLongitude"] as? Double ?? 
                        userInfo["dropoff_longitude"] as? Double ?? 76.8000
        
        let pickupAddress = userInfo["pickupAddress"] as? String ?? 
                           userInfo["pickup_address"] as? String ?? "Pickup address unavailable"
        let dropoffAddress = userInfo["dropoffAddress"] as? String ?? 
                            userInfo["dropoff_address"] as? String ?? "Dropoff address unavailable"
        
        func trimmedString(_ value: Any?) -> String? {
            switch value {
            case let string as String:
                let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
                return trimmed.isEmpty ? nil : trimmed
            case let number as NSNumber:
                let stringValue = number.stringValue
                return stringValue.isEmpty ? nil : stringValue
            default:
                return nil
            }
        }
        
        var driverName = trimmedString(userInfo["driver_name"]) ??
                         trimmedString(userInfo["driverName"]) ??
                         trimmedString(userInfo["driver_full_name"])
        if driverName == nil {
            let first = trimmedString(userInfo["driver_first_name"]) ?? trimmedString(userInfo["driverFirstName"])
            let last = trimmedString(userInfo["driver_last_name"]) ?? trimmedString(userInfo["driverLastName"])
            if let first = first {
                if let last = last {
                    driverName = "\(first) \(last)"
                } else {
                    driverName = first
                }
            } else {
                driverName = trimmedString(userInfo["driver_display_name"])
            }
        }
        
        var driverPhone = trimmedString(userInfo["driver_phone"]) ??
                          trimmedString(userInfo["driverPhone"]) ??
                          trimmedString(userInfo["driver_mobile"]) ??
                          trimmedString(userInfo["driverMobile"]) ??
                          trimmedString(userInfo["driver_contact"])
        if let isd = trimmedString(userInfo["driver_mobile_isd"]) ??
                     trimmedString(userInfo["driverMobileIsd"]) ??
                     trimmedString(userInfo["driver_country_code"]) ??
                     trimmedString(userInfo["driverCountryCode"]) {
            let normalizedIsd = isd.hasPrefix("+") ? isd : "+" + isd
            if let currentPhone = driverPhone, !currentPhone.hasPrefix("+") {
                driverPhone = normalizedIsd + currentPhone.filter { $0.isNumber }
            }
        }
        
        // Determine status from message content if not provided
        let titleLower = title.lowercased()
        let messageLower = message.lowercased()
        var status = (userInfo["status"] as? String) ?? "en_route_pu"
        
        print("🚗 Extracted data - Booking: \(bookingId), Status: \(status)")
        print("🚗 Driver Location: \(driverLat), \(driverLng)")
        print("🚗 Pickup: \(pickupAddress)")
        print("🚗 Dropoff: \(dropoffAddress)")
        
        // Create LiveRideData with extracted information
        let liveRideData = LiveRideData(
            bookingId: bookingId,
            driverId: driverId,
            customerId: customerId,
            status: status,
            driverLatitude: driverLat,
            driverLongitude: driverLng,
            pickupLatitude: pickupLat,
            pickupLongitude: pickupLng,
            dropoffLatitude: dropoffLat,
            dropoffLongitude: dropoffLng,
            pickupAddress: pickupAddress,
            dropoffAddress: dropoffAddress,
            timestamp: Date().iso8601String,
            title: title,
            message: message,
            driverName: driverName,
            driverPhone: driverPhone
        )
        
        // Store the data and set navigation flag
        NotificationDataManager.shared.storePendingRideData(liveRideData)
        NotificationDataManager.shared.setShouldOpenToRideInProgress()
        
        print("✅ Deep Link: Ride data stored from message content, app will open to RideInProgressView")
    }
    
    /// Handle general notifications
    private func handleGeneralNotificationNavigation() {
        print("📱 Deep Link: Processing general notification navigation")
        NotificationDataManager.shared.setShouldOpenToDashboard()
    }
}

// MARK: - MessagingDelegate
extension AppDelegate: MessagingDelegate {
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        print("Firebase: FCM registration token updated: \(fcmToken ?? "nil")")
        
        DispatchQueue.main.async {
            FirebasePushNotificationService.shared.fcmToken = fcmToken
        }
        
        // Send FCM token to your server if needed
        if let token = fcmToken {
            sendFCMTokenToServer(token)
        }
    }
    
    private func sendFCMTokenToServer(_ token: String) {
        // TODO: Implement sending FCM token to your backend server
        // This is where you would typically make an API call to register the token
        print("Firebase: Should send FCM token to server: \(token)")
    }
}






