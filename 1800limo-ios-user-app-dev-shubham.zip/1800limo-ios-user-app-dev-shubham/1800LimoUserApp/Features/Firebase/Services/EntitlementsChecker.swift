import Foundation
import UIKit

class EntitlementsChecker {
    static func checkEntitlements() {
        print("=== Entitlements Check ===")
        
        // Check if we can access the entitlements
        if let entitlementsPath = Bundle.main.path(forResource: "1800LimoUserApp", ofType: "entitlements") {
            print("✅ Entitlements file found at: \(entitlementsPath)")
            
            if let entitlementsData = NSData(contentsOfFile: entitlementsPath) {
                print("✅ Entitlements file is readable")
                
                // Try to parse the entitlements
                do {
                    if let entitlements = try PropertyListSerialization.propertyList(from: entitlementsData as Data, options: [], format: nil) as? [String: Any] {
                        print("✅ Entitlements parsed successfully")
                        
                        if let apsEnvironment = entitlements["aps-environment"] as? String {
                            print("✅ APS Environment: \(apsEnvironment)")
                        } else {
                            print("❌ APS Environment not found in entitlements")
                        }
                    } else {
                        print("❌ Failed to parse entitlements file")
                    }
                } catch {
                    print("❌ Error parsing entitlements: \(error)")
                }
            } else {
                print("❌ Entitlements file is not readable")
            }
        } else {
            print("❌ Entitlements file not found in bundle")
        }
        
        // Check bundle identifier
        if let bundleId = Bundle.main.bundleIdentifier {
            print("✅ Bundle ID: \(bundleId)")
        } else {
            print("❌ Bundle ID not found")
        }
        
        // Check if running on device or simulator
        #if targetEnvironment(simulator)
        print("⚠️  Running on Simulator - Push notifications may not work properly")
        #else
        print("✅ Running on Device")
        #endif
        
        print("==========================")
    }
    
    static func checkCodeSigning() {
        print("=== Code Signing Check ===")
        
        // Check if app is code signed
        if let codeSigningInfo = Bundle.main.infoDictionary?["CFBundleCodeSigningInfo"] {
            print("✅ Code signing info found: \(codeSigningInfo)")
        } else {
            print("⚠️  Code signing info not found")
        }
        
        // Check provisioning profile
        if let provisioningProfile = Bundle.main.infoDictionary?["CFBundleCodeSigningInfo"] {
            print("✅ Provisioning profile info found")
        } else {
            print("⚠️  Provisioning profile info not found")
        }
        
        print("==========================")
    }
}






