import Foundation
import Firebase
import FirebaseMessaging
import UserNotifications

class FirebasePushNotificationService: NSObject, ObservableObject {
    static let shared = FirebasePushNotificationService()
    
    @Published var fcmToken: String?
    @Published var isSubscribed = false
    @Published var lastNotification: String?
    @Published var subscriptionError: String?
    
    // Dynamic user ID from StorageManager
    private var userId: String? {
        return StorageManager.shared.getUserIdString()
    }
    
    private override init() {
        super.init()
        setupFirebase()
    }
    
    private func setupFirebase() {
        // Firebase should already be configured in your app
        // This is just for safety
        if FirebaseApp.app() == nil {
            FirebaseApp.configure()
        }
        
        // Set messaging delegate
        Messaging.messaging().delegate = self
        
        // Debug Firebase configuration
    }
    
    // MARK: - Notification Permissions
    func requestNotificationPermission() {
        UNUserNotificationCenter.current().delegate = self
        
        let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
        UNUserNotificationCenter.current().requestAuthorization(
            options: authOptions,
            completionHandler: { granted, error in
                DispatchQueue.main.async {
                    if granted {
                        self.registerForRemoteNotifications()
                    } else {
                        self.subscriptionError = "Notification permission denied"
                    }
                }
            }
        )
    }
    
    private func registerForRemoteNotifications() {
        DispatchQueue.main.async {
            UIApplication.shared.registerForRemoteNotifications()
        }
    }
    
    // Call this method when APNs token is received
    func setAPNsToken(_ deviceToken: Data) {
        Messaging.messaging().apnsToken = deviceToken
    }
    
    // MARK: - FCM Token Management
    func getFCMToken() {
        // First check if we have APNs token
        if Messaging.messaging().apnsToken == nil {
            return
        }
        
        Messaging.messaging().token { [weak self] token, error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.subscriptionError = "Failed to get FCM token: \(error.localizedDescription)"
                    return
                }
                
                if let token = token {
                    self?.fcmToken = token
                    
                    // Automatically subscribe to user topic after getting FCM token
                    self?.subscribeToUserTopic()
                }
            }
        }
    }
    
    // MARK: - Topic Subscription (Direct like Flutter)
    func subscribeToUserTopic(userId: String? = nil) {
        let targetUserId = userId ?? self.userId
        
        // Check if we have a valid user ID
        guard let validUserId = targetUserId, !validUserId.isEmpty else {
            subscriptionError = "No valid user ID available. Please ensure user is logged in."
            return
        }
        
        // Check prerequisites
        guard Messaging.messaging().apnsToken != nil else {
            subscriptionError = "APNs token not available"
            return
        }
        
        guard FirebaseApp.app() != nil else {
            subscriptionError = "Firebase not configured"
            return
        }
        
        // Direct subscription to user ID topic (exactly like Flutter)
        Messaging.messaging().subscribe(toTopic: validUserId) { [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.isSubscribed = false
                    self?.subscriptionError = "Subscription failed: \(error.localizedDescription)"
                    
                    // Try again after a short delay (like Flutter retry)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                        self?.subscribeToUserTopic(userId: validUserId)
                    }
                } else {
                    self?.isSubscribed = true
                    self?.subscriptionError = nil
                }
            }
        }
    }
    
    // MARK: - Unsubscribe
    func unsubscribeFromUserTopic(userId: String? = nil) {
        let targetUserId = userId ?? self.userId
        
        guard let validUserId = targetUserId, !validUserId.isEmpty else {
            subscriptionError = "No valid user ID available. Please ensure user is logged in."
            return
        }
        
        Messaging.messaging().unsubscribe(fromTopic: validUserId) { [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.subscriptionError = "Unsubscribe failed: \(error.localizedDescription)"
                } else {
                    self?.isSubscribed = false
                    self?.subscriptionError = nil
                }
            }
        }
    }
    
    // MARK: - Send Test Notification (for testing purposes)
    func sendTestNotification() {
        // This would typically be done from your backend
        // For testing, you can use Firebase Console or your server
    }
    
    // MARK: - Debug Information
    func printDebugInfo() {
        // Debug information method - no console output
    }
    
    // MARK: - Reset and Reinitialize
    func resetAndReinitialize() {
        isSubscribed = false
        subscriptionError = nil
        fcmToken = nil
        
        // Re-request permissions and tokens
        requestNotificationPermission()
    }
    
    // MARK: - Manual Testing Methods
    func manuallyTriggerSetup() {
        requestNotificationPermission()
    }
    
    func manuallyGetFCMToken() {
        getFCMToken()
    }
    
    func manuallySubscribeToTopic() {
        subscribeToUserTopic()
    }
    
    // MARK: - User ID Management
    func handleUserIdChange() {
        // Unsubscribe from old topic first
        if isSubscribed {
            unsubscribeFromUserTopic()
        }
        // Subscribe to new topic
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.subscribeToUserTopic()
        }
    }
    
    func getCurrentStatus() -> String {
        var status = "=== Firebase Status ===\n"
        status += "APNs Token: \(Messaging.messaging().apnsToken != nil ? "✅ Available" : "❌ Not Available")\n"
        status += "FCM Token: \(fcmToken != nil ? "✅ Available" : "❌ Not Available")\n"
        status += "Is Subscribed: \(isSubscribed ? "✅ Yes" : "❌ No")\n"
        status += "User ID: \(userId ?? "❌ Not Available")\n"
        status += "Firebase App: \(FirebaseApp.app() != nil ? "✅ Configured" : "❌ Not Configured")\n"
        if let error = subscriptionError {
            status += "Error: ❌ \(error)\n"
        }
        status += "======================"
        return status
    }
}

// MARK: - MessagingDelegate
extension FirebasePushNotificationService: MessagingDelegate {
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        DispatchQueue.main.async {
            self.fcmToken = fcmToken
            
            // If we get a new FCM token, try to subscribe again
            if fcmToken != nil && !self.isSubscribed {
                self.subscribeToUserTopic()
            }
        }
    }
}

// MARK: - UNUserNotificationCenterDelegate
extension FirebasePushNotificationService: UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let userInfo = notification.request.content.userInfo
        
        DispatchQueue.main.async {
            self.lastNotification = userInfo["body"] as? String ?? "New notification received"
        }
        
        // Show notification even when app is in foreground
        completionHandler([.alert, .badge, .sound])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        
        DispatchQueue.main.async {
            self.lastNotification = userInfo["body"] as? String ?? "Notification tapped"
        }
        
        completionHandler()
    }
}






