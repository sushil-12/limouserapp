import Foundation
import SwiftUI

/// Manages notification data and navigation state when app is opened from notifications
class NotificationDataManager: ObservableObject {
    static let shared = NotificationDataManager()
    
    // MARK: - Navigation Flags
    @Published var shouldOpenToRideInProgress = false
    @Published var shouldOpenToMyBookings = false
    @Published var shouldOpenToDashboard = false
    
    // MARK: - Stored Data
    @Published var pendingRideData: LiveRideData?
    @Published var storedBookingData: [String: Any]?
    
    private let userDefaults = UserDefaults.standard
    
    // Keys for UserDefaults storage
    private let shouldOpenToRideInProgressKey = "shouldOpenToRideInProgress"
    private let shouldOpenToMyBookingsKey = "shouldOpenToMyBookings"
    private let shouldOpenToDashboardKey = "shouldOpenToDashboard"
    private let pendingRideDataKey = "pendingRideData"
    private let storedBookingDataKey = "storedBookingData"
    
    private init() {
        loadPersistedState()
    }
    
    // MARK: - Ride Data Management
    
    /// Store pending ride data from notification
    func storePendingRideData(_ rideData: LiveRideData) {
        print("💾 NotificationDataManager: Storing pending ride data")
        
        DispatchQueue.main.async {
            self.pendingRideData = rideData
            
            // Persist to UserDefaults for app restart scenarios
            if let encodedData = try? JSONEncoder().encode(rideData) {
                self.userDefaults.set(encodedData, forKey: self.pendingRideDataKey)
                print("✅ NotificationDataManager: Ride data persisted to UserDefaults")
            }
        }
    }
    
    /// Retrieve and clear pending ride data
    func retrievePendingRideData() -> LiveRideData? {
        print("📤 NotificationDataManager: Retrieving pending ride data")
        
        let data = pendingRideData
        clearPendingRideData()
        return data
    }
    
    /// Clear pending ride data
    func clearPendingRideData() {
        print("🧹 NotificationDataManager: Clearing pending ride data")
        
        DispatchQueue.main.async {
            self.pendingRideData = nil
            self.userDefaults.removeObject(forKey: self.pendingRideDataKey)
        }
    }
    
    // MARK: - Navigation State Management
    
    /// Set flag to open to RideInProgressView
    func setShouldOpenToRideInProgress() {
        print("🚗 NotificationDataManager: Setting flag to open RideInProgressView")
        
        DispatchQueue.main.async {
            self.shouldOpenToRideInProgress = true
            self.shouldOpenToMyBookings = false
            self.shouldOpenToDashboard = false
            self.persistNavigationState()
        }
    }
    
    /// Set flag to open to MyBookingsView
    func setShouldOpenToMyBookings() {
        print("📋 NotificationDataManager: Setting flag to open MyBookingsView")
        
        DispatchQueue.main.async {
            self.shouldOpenToRideInProgress = false
            self.shouldOpenToMyBookings = true
            self.shouldOpenToDashboard = false
            self.persistNavigationState()
        }
    }
    
    /// Set flag to open to DashboardView
    func setShouldOpenToDashboard() {
        print("📱 NotificationDataManager: Setting flag to open DashboardView")
        
        DispatchQueue.main.async {
            self.shouldOpenToRideInProgress = false
            self.shouldOpenToMyBookings = false
            self.shouldOpenToDashboard = true
            self.persistNavigationState()
        }
    }
    
    /// Clear all navigation flags
    func clearNavigationFlags() {
        print("🧹 NotificationDataManager: Clearing all navigation flags")
        
        DispatchQueue.main.async {
            self.shouldOpenToRideInProgress = false
            self.shouldOpenToMyBookings = false
            self.shouldOpenToDashboard = false
            self.clearPersistedNavigationState()
        }
    }
    
    // MARK: - Persistence
    
    /// Persist navigation state to UserDefaults
    private func persistNavigationState() {
        userDefaults.set(shouldOpenToRideInProgress, forKey: shouldOpenToRideInProgressKey)
        userDefaults.set(shouldOpenToMyBookings, forKey: shouldOpenToMyBookingsKey)
        userDefaults.set(shouldOpenToDashboard, forKey: shouldOpenToDashboardKey)
        userDefaults.synchronize()
        
        print("💾 NotificationDataManager: Navigation state persisted")
    }
    
    /// Load persisted state from UserDefaults
    private func loadPersistedState() {
        shouldOpenToRideInProgress = userDefaults.bool(forKey: shouldOpenToRideInProgressKey)
        shouldOpenToMyBookings = userDefaults.bool(forKey: shouldOpenToMyBookingsKey)
        shouldOpenToDashboard = userDefaults.bool(forKey: shouldOpenToDashboardKey)
        
        // Load pending ride data
        if let data = userDefaults.data(forKey: pendingRideDataKey),
           let rideData = try? JSONDecoder().decode(LiveRideData.self, from: data) {
            pendingRideData = rideData
            print("📤 NotificationDataManager: Loaded persisted ride data")
        }
        
        // Load stored booking data
        if let bookingData = userDefaults.object(forKey: storedBookingDataKey) as? [String: Any] {
            storedBookingData = bookingData
            print("📤 NotificationDataManager: Loaded persisted booking data")
        }
        
        print("📤 NotificationDataManager: Loaded persisted state - RideInProgress: \(shouldOpenToRideInProgress), MyBookings: \(shouldOpenToMyBookings), Dashboard: \(shouldOpenToDashboard)")
    }
    
    /// Clear persisted navigation state
    private func clearPersistedNavigationState() {
        userDefaults.removeObject(forKey: shouldOpenToRideInProgressKey)
        userDefaults.removeObject(forKey: shouldOpenToMyBookingsKey)
        userDefaults.removeObject(forKey: shouldOpenToDashboardKey)
        userDefaults.synchronize()
        
        print("🧹 NotificationDataManager: Persisted navigation state cleared")
    }
    
    // MARK: - Debug Methods
    
    func printCurrentState() {
        print("=== NotificationDataManager Current State ===")
        print("Should open to RideInProgress: \(shouldOpenToRideInProgress)")
        print("Should open to MyBookings: \(shouldOpenToMyBookings)")
        print("Should open to Dashboard: \(shouldOpenToDashboard)")
        print("Pending ride data: \(pendingRideData != nil ? "Available" : "None")")
        if let rideData = pendingRideData {
            print("  - Booking ID: \(rideData.bookingId)")
            print("  - Status: \(rideData.status)")
            print("  - Title: \(rideData.title)")
            print("  - Message: \(rideData.message)")
        }
        print("Stored booking data: \(storedBookingData != nil ? "Available" : "None")")
        
        // Also check UserDefaults
        print("UserDefaults RideInProgress flag: \(userDefaults.bool(forKey: shouldOpenToRideInProgressKey))")
        print("UserDefaults MyBookings flag: \(userDefaults.bool(forKey: shouldOpenToMyBookingsKey))")
        print("UserDefaults Dashboard flag: \(userDefaults.bool(forKey: shouldOpenToDashboardKey))")
        print("=============================================")
    }
    
    /// Force clear all data (for debugging)
    func forceClearAllData() {
        print("🧹 NotificationDataManager: Force clearing all data")
        
        DispatchQueue.main.async {
            self.shouldOpenToRideInProgress = false
            self.shouldOpenToMyBookings = false
            self.shouldOpenToDashboard = false
            self.pendingRideData = nil
            self.storedBookingData = nil
            
            // Clear UserDefaults
            self.userDefaults.removeObject(forKey: self.shouldOpenToRideInProgressKey)
            self.userDefaults.removeObject(forKey: self.shouldOpenToMyBookingsKey)
            self.userDefaults.removeObject(forKey: self.shouldOpenToDashboardKey)
            self.userDefaults.removeObject(forKey: self.pendingRideDataKey)
            self.userDefaults.removeObject(forKey: self.storedBookingDataKey)
            self.userDefaults.synchronize()
            
            print("✅ NotificationDataManager: All data cleared")
        }
    }
    
    /// Test method to simulate a "driver is on location" notification
    func simulateDriverOnLocationNotification() {
        print("🧪 NotificationDataManager: Simulating driver on location notification")
        
        let testRideData = LiveRideData(
            bookingId: "TEST_12345",
            driverId: "DRIVER_67890",
            customerId: "CUSTOMER_11111",
            status: "on_location",
            driverLatitude: 30.6735,
            driverLongitude: 76.7884,
            pickupLatitude: 30.6942,
            pickupLongitude: 76.7933,
            dropoffLatitude: 30.7000,
            dropoffLongitude: 76.8000,
            pickupAddress: "Sector 17, Chandigarh",
            dropoffAddress: "Chandigarh Airport, Mohali",
            timestamp: Date().iso8601String,
            title: "Driver is on Location",
            message: "Your driver has arrived at the pickup location",
            driverName: "Test Driver",
            driverPhone: "+18571423652"
            
                        
        )
        
        storePendingRideData(testRideData)
        setShouldOpenToRideInProgress()
        
        print("✅ NotificationDataManager: Test notification data stored")
        printCurrentState()
    }
}

// MARK: - LiveRideData Codable Extension
extension LiveRideData: Codable {
    enum CodingKeys: String, CodingKey {
        case bookingId, driverId, customerId, status
        case driverLatitude, driverLongitude
        case pickupLatitude, pickupLongitude
        case dropoffLatitude, dropoffLongitude
        case pickupAddress, dropoffAddress
        case timestamp, title, message
        case driverName, driverPhone
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        self = LiveRideData(
            bookingId: try container.decode(String.self, forKey: .bookingId),
            driverId: try container.decode(String.self, forKey: .driverId),
            customerId: try container.decode(String.self, forKey: .customerId),
            status: try container.decode(String.self, forKey: .status),
            driverLatitude: try container.decode(Double.self, forKey: .driverLatitude),
            driverLongitude: try container.decode(Double.self, forKey: .driverLongitude),
            pickupLatitude: try container.decode(Double.self, forKey: .pickupLatitude),
            pickupLongitude: try container.decode(Double.self, forKey: .pickupLongitude),
            dropoffLatitude: try container.decode(Double.self, forKey: .dropoffLatitude),
            dropoffLongitude: try container.decode(Double.self, forKey: .dropoffLongitude),
            pickupAddress: try container.decode(String.self, forKey: .pickupAddress),
            dropoffAddress: try container.decode(String.self, forKey: .dropoffAddress),
            timestamp: try container.decode(String.self, forKey: .timestamp),
            title: try container.decode(String.self, forKey: .title),
            message: try container.decode(String.self, forKey: .message),
            driverName: try container.decodeIfPresent(String.self, forKey: .driverName),
            driverPhone: try container.decodeIfPresent(String.self, forKey: .driverPhone)
        )
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        try container.encode(bookingId, forKey: .bookingId)
        try container.encode(driverId, forKey: .driverId)
        try container.encode(customerId, forKey: .customerId)
        try container.encode(status, forKey: .status)
        try container.encode(driverLatitude, forKey: .driverLatitude)
        try container.encode(driverLongitude, forKey: .driverLongitude)
        try container.encode(pickupLatitude, forKey: .pickupLatitude)
        try container.encode(pickupLongitude, forKey: .pickupLongitude)
        try container.encode(dropoffLatitude, forKey: .dropoffLatitude)
        try container.encode(dropoffLongitude, forKey: .dropoffLongitude)
        try container.encode(pickupAddress, forKey: .pickupAddress)
        try container.encode(dropoffAddress, forKey: .dropoffAddress)
        try container.encode(timestamp, forKey: .timestamp)
        try container.encode(title, forKey: .title)
        try container.encode(message, forKey: .message)
        try container.encodeIfPresent(driverName, forKey: .driverName)
        try container.encodeIfPresent(driverPhone, forKey: .driverPhone)
    }
}
