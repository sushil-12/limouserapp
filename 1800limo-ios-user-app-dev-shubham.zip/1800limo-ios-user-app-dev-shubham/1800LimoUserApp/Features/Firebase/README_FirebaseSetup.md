# Firebase & Socket.IO Setup Guide - User App

## Overview
This guide covers the complete Firebase push notification and Socket.IO real-time notification setup for the 1800LIMO User iOS app.

## Setup Status ✅

### ✅ What's Configured:
1. **Firebase**: GoogleService-Info.plist present
2. **Entitlements**: `aps-environment` set to `development`
3. **Background Modes**: `remote-notification`, `processing`, `fetch` configured in Info.plist
4. **AppDelegate**: Proper notification handling implemented
5. **Topic Subscription**: User ID-based topic subscription
6. **Socket.IO**: Real-time notification service configured

## File Structure

```
Features/
├── Firebase/
│   ├── Services/
│   │   ├── AppDelegate.swift
│   │   ├── FirebasePushNotificationService.swift
│   │   └── EntitlementsChecker.swift
│   ├── Views/
│   │   └── FirebaseTestView.swift
│   └── README_FirebaseSetup.md
│
└── Notification/
    ├── Models/
    │   ├── NotificationModel.swift
    │   └── NotificationResponse.swift
    ├── Services/
    │   ├── LocalNotificationManager.swift
    │   └── SimpleSocketIOService.swift
    └── Views/
        ├── InAppNotificationView.swift
        └── SocketIOTestView.swift
```

## Key Features

### Firebase Push Notifications
- **APNs Integration**: Automatic APNs token handling
- **FCM Token Management**: Automatic FCM token retrieval and storage
- **Topic Subscription**: Subscribe to user-specific topics using user ID
- **Background Notifications**: Handle notifications when app is terminated
- **Foreground Notifications**: Show notifications even when app is active

### Socket.IO Real-Time Notifications
- **Auto-Connect**: Connects automatically with user ID after login
- **Reconnection**: Automatic reconnection with retry logic
- **User Type**: Configured for 'customer' user type
- **Event Handling**: Processes notification events in real-time
- **In-App Notifications**: Shows custom in-app notification UI

## Configuration Files

### 1. Info.plist
```xml
<key>UIBackgroundModes</key>
<array>
    <string>remote-notification</string>
    <string>processing</string>
    <string>fetch</string>
</array>

<key>FirebaseAppDelegateProxyEnabled</key>
<false/>

<key>FirebaseAutomaticScreenReportingEnabled</key>
<false/>
```

### 2. Entitlements (1800LimoUserApp.entitlements)
```xml
<key>aps-environment</key>
<string>development</string>
```

Note: Change to `production` before App Store release.

### 3. GoogleService-Info.plist
Already present in the project. Make sure it matches your Firebase project configuration.

## Usage

### Initialize on Login
After successful OTP verification, both Firebase and Socket.IO will automatically:
1. Subscribe to user-specific Firebase topic
2. Connect to Socket.IO with user ID

```swift
// In your login/OTP verification success handler:
FirebasePushNotificationService.shared.subscribeToUserTopic()
SimpleSocketIOService.shared.reconnectWithNewUserId()
```

### Test Views
Use the provided test views to verify setup:

```swift
// Firebase Test View
NavigationLink("Test Firebase") {
    FirebaseTestView()
}

// Socket.IO Test View
NavigationLink("Test Socket.IO") {
    SocketIOTestView()
}
```

## Testing

### 1. Firebase Push Notifications

#### From Firebase Console:
1. Go to Firebase Console → Cloud Messaging
2. Create a new notification
3. Send to topic: `{userId}` (e.g., "1234")
4. Test with app in different states:
   - Foreground
   - Background
   - Terminated

#### Test Payload:
```json
{
  "to": "/topics/1234",
  "notification": {
    "title": "New Booking",
    "body": "You have a new booking request",
    "sound": "default"
  },
  "data": {
    "type": "booking",
    "bookingId": "123"
  },
  "priority": "high"
}
```

### 2. Socket.IO Real-Time Notifications

The Socket.IO service connects to: `https://limortservice.infodevbox.com`

#### Connection Parameters:
- `client`: "ios_app"
- `secret`: "limoapi_notifications_secret_2024_xyz789"
- `userId`: Dynamic from StorageManager
- `userType`: "customer"

#### Test Connection:
1. Open SocketIOTestView
2. Verify user ID is shown
3. Tap "Connect"
4. Check console for connection success
5. Use "Send Test Event" to verify

## Troubleshooting

### Firebase Issues

#### "APNs token not available"
- **Solution**: Ensure notification permissions are granted
- **Check**: Settings → Notifications → 1800LIMO User App

#### "FCM token not available"
- **Solution**: Wait for APNs token first, then FCM token
- **Check**: Look for "FCM Token received" in console

#### "Subscription failed"
- **Solution**: Verify Firebase Console has the topic
- **Check**: Ensure user ID is valid and not empty

#### Notifications not received when app is terminated
- **Solution**: Verify background modes in Info.plist
- **Check**: Ensure `remote-notification` is enabled

### Socket.IO Issues

#### "User ID: unknown"
- **Solution**: User is not logged in or user ID not saved
- **Check**: Verify OTP verification completed successfully

#### "Cannot connect: Socket is nil"
- **Solution**: Socket initialization failed
- **Check**: Verify server URL is correct and reachable

#### Not receiving Socket.IO events
- **Solution**: Verify connection is established
- **Check**: Look for "Connected to server" in console

## Debug Commands

### Firebase:
```swift
// Print current status
FirebasePushNotificationService.shared.printDebugInfo()

// Get status string
let status = FirebasePushNotificationService.shared.getCurrentStatus()

// Reset and reinitialize
FirebasePushNotificationService.shared.resetAndReinitialize()
```

### Socket.IO:
```swift
// Debug user ID status
SimpleSocketIOService.shared.debugUserIDStatus()

// Reconnect with new user ID
SimpleSocketIOService.shared.reconnectWithNewUserId()

// Check connection status
print("Connected: \(SimpleSocketIOService.shared.isConnected)")
```

## Production Checklist

### Before Release:
- [ ] Change `aps-environment` to `production` in entitlements
- [ ] Update GoogleService-Info.plist for production
- [ ] Upload APNs certificate to Firebase Console
- [ ] Test with production APNs certificate
- [ ] Verify topic subscription works in production
- [ ] Update Socket.IO server URL if needed
- [ ] Test on real devices (not simulator)

### Server-Side Integration:
1. **Store FCM tokens** on backend when users log in
2. **Send notifications** to user-specific topics: `/topics/{userId}`
3. **Handle token refresh** - FCM tokens can change
4. **Implement retry logic** for failed notifications
5. **Socket.IO events** - Ensure server emits to correct user channels

## Important Notes

1. **User Type**: This is the **User App** (customer), not Driver App
   - Socket.IO uses `userType: "customer"`
   - Different from driver app which uses `userType: "driver"`

2. **User ID**: Retrieved dynamically from StorageManager
   - Must be logged in for notifications to work
   - User ID is set during OTP verification

3. **Permissions**: App requests notification permissions on startup
   - Handled automatically in AppDelegate
   - User must grant permissions for push notifications

4. **Testing**: Use provided test views for debugging
   - FirebaseTestView for Firebase testing
   - SocketIOTestView for Socket.IO testing
   - Check console logs for detailed information

## Expected Console Output

### Successful Setup:
```
Firebase: Setup completed
Firebase: App configured: true
Firebase: Messaging delegate set: true
Firebase: Notification permission granted
Firebase: Registering for remote notifications...
Firebase: APNs token set from AppDelegate
Firebase: FCM Token received: [token]
Firebase: Successfully subscribed to user topic: 1234
🔌 Socket.IO - User ID retrieved successfully: 1234
Socket.IO: Connected to server
```

### Error Cases:
```
Firebase: Notification permission denied
Firebase: Failed to register for remote notifications: [error]
Firebase: Error subscribing to user topic: [error]
❌ Socket.IO - CRITICAL: No valid user ID found!
```

## Support

If you encounter issues:
1. Check console logs for Firebase/Socket.IO debug messages
2. Use test views (FirebaseTestView, SocketIOTestView) to diagnose
3. Verify Firebase Console configuration
4. Test with different notification payloads
5. Ensure user is logged in before testing

## Next Steps

1. **Integrate with your UI**: Add notification handling to your views
2. **Handle notification taps**: Navigate to specific screens based on notification data
3. **Customize notification UI**: Update InAppNotificationView design
4. **Add notification history**: Store and display past notifications
5. **Test thoroughly**: Test in all app states and scenarios






