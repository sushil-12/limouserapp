import Foundation

// MARK: - Real-time Chat Message Model (matches backend API)
struct RealTimeChatMessage: Identifiable, Codable {
    let id: String
    let bookingId: Int
    let senderId: String
    let receiverId: String
    let senderRole: String
    let message: String
    let createdAt: Date
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case bookingId
        case senderId
        case receiverId
        case senderRole
        case message
        case createdAt
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decode(String.self, forKey: .id)
        bookingId = try container.decode(Int.self, forKey: .bookingId)
        senderId = try container.decode(String.self, forKey: .senderId)
        receiverId = try container.decode(String.self, forKey: .receiverId)
        senderRole = try container.decode(String.self, forKey: .senderRole)
        message = try container.decode(String.self, forKey: .message)
        
        // Handle date parsing with multiple formats
        let dateString = try container.decode(String.self, forKey: .createdAt)
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        
        if let date = formatter.date(from: dateString) {
            createdAt = date
        } else {
            // Fallback to standard ISO8601 format
            let fallbackFormatter = ISO8601DateFormatter()
            if let fallbackDate = fallbackFormatter.date(from: dateString) {
                createdAt = fallbackDate
            } else {
                // Last resort: use current date
                print("⚠️ ChatService: Failed to parse date '\(dateString)', using current date")
                createdAt = Date()
            }
        }
    }
    
    init(id: String, bookingId: Int, senderId: String, receiverId: String, senderRole: String, message: String, createdAt: Date) {
        self.id = id
        self.bookingId = bookingId
        self.senderId = senderId
        self.receiverId = receiverId
        self.senderRole = senderRole
        self.message = message
        self.createdAt = createdAt
    }
    
    // Helper to determine if message is from current user (customer)
    func isFromCustomer(customerId: String) -> Bool {
        return senderId == customerId
    }
}

// MARK: - Chat History Response Model
struct ChatHistoryResponse: Codable {
    let success: Bool
    let data: [RealTimeChatMessage]
}

// MARK: - User Chat Message Model (for UI compatibility)
struct ChatMessage: Identifiable, Codable {
    let id = UUID()
    let text: String
    let timestamp: Date
    let isFromUser: Bool
    let messageType: MessageType
    
    enum MessageType: String, Codable {
        case text
        case quickReply
        case system
    }
    
    init(text: String, isFromUser: Bool, messageType: MessageType = .text, timestamp: Date? = nil) {
        self.text = text
        self.timestamp = timestamp ?? Date()
        self.isFromUser = isFromUser
        self.messageType = messageType
    }
    
    // Convert from real-time RealTimeChatMessage
    init(from chatMessage: RealTimeChatMessage, customerId: String) {
        self.text = chatMessage.message
        self.timestamp = chatMessage.createdAt
        self.isFromUser = chatMessage.isFromCustomer(customerId: customerId)
        self.messageType = .text
    }
}

// MARK: - Chat Contact Model
struct ChatContact: Identifiable, Codable {
    let id = UUID()
    let name: String
    let subtitle: String
    let lastMessage: String?
    let lastMessageTime: Date?
    let unreadCount: Int
    let isOnline: Bool
    
    init(name: String, subtitle: String, lastMessage: String? = nil, lastMessageTime: Date? = nil, unreadCount: Int = 0, isOnline: Bool = false) {
        self.name = name
        self.subtitle = subtitle
        self.lastMessage = lastMessage
        self.lastMessageTime = lastMessageTime
        self.unreadCount = unreadCount
        self.isOnline = isOnline
    }
}

// MARK: - Quick Reply Model
struct QuickReply: Identifiable, Codable {
    let id = UUID()
    let text: String
    let isSelected: Bool
    
    init(text: String, isSelected: Bool = false) {
        self.text = text
        self.isSelected = isSelected
    }
}

// MARK: - Chat Sample Data
extension ChatMessage {
    static let sampleMessages: [ChatMessage] = [
        ChatMessage(text: "Hello Sir, I'm nearing the signal, reaching in 5 mins", isFromUser: false, timestamp: createDateFromTime(hour: 13, minute: 24)),
        ChatMessage(text: "I've Arrived", isFromUser: true, timestamp: createDateFromTime(hour: 13, minute: 25))
    ]
    
    private static func createDateFromTime(hour: Int, minute: Int) -> Date {
        let calendar = Calendar.current
        let now = Date()
        let components = calendar.dateComponents([.year, .month, .day], from: now)
        return calendar.date(bySettingHour: hour, minute: minute, second: 0, of: calendar.date(from: components)!) ?? now
    }
}

extension ChatContact {
    static let driverContact = ChatContact(
        name: "Driver",
        subtitle: "Chat",
        lastMessage: "Hello, I'm on my way to pickup location",
        lastMessageTime: Date().addingTimeInterval(-300), // 5 minutes ago
        unreadCount: 0,
        isOnline: true
    )
}

extension QuickReply {
    static let defaultReplies = [
        QuickReply(text: "Please wait, I'll be there soon"),
        QuickReply(text: "I'm at the pickup point"),
        QuickReply(text: "I'm on the way"),
        QuickReply(text: "Running a few minutes late"),
        QuickReply(text: "Can you share your location?"),
        QuickReply(text: "Thank you!")
    ]
}
