import SwiftUI

struct ChatView: View {
    @StateObject private var viewModel = ChatViewModel()
    @Environment(\.presentationMode) var presentationMode
    @State private var newMessageText: String = ""
    
    // Booking context for real-time chat
    let bookingId: Int
    let driverId: String
    let driverName: String
    
    init(bookingId: Int, driverId: String, driverName: String) {
        self.bookingId = bookingId
        self.driverId = driverId
        self.driverName = driverName
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            chatHeader
            
            // Connection Status
            if !viewModel.isConnected {
                connectionStatusView
            }
            
            // Error Message
            if let errorMessage = viewModel.errorMessage {
                errorMessageView(errorMessage)
            }
            
            // Messages List
            messagesList
            
            // Quick Replies
            quickRepliesSection
            
            // Input Area
            inputArea
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .onAppear {
            // CRITICAL: Ensure socket connection is established when chat view appears
            print("🔌 ChatView: onAppear - Ensuring socket connection")
            let socketService = SimpleSocketIOService.shared
            if !socketService.isConnected {
                print("⚠️ ChatView: Socket not connected, attempting to connect...")
                socketService.ensureConnectionForViewTransition()
            } else {
                print("✅ ChatView: Socket already connected, ensuring room membership...")
                socketService.ensureConnectionForViewTransition()
            }
            
            // Set up chat context for this booking
            viewModel.setupForBooking(
                bookingId: bookingId,
                driverId: driverId,
                driverName: driverName
            )
            // Track that user is on chat screen
            ScreenTracker.shared.setCurrentScreen(.chat(bookingId: bookingId))
            print("💬 ChatView: Set screen tracker to chat screen for booking \(bookingId)")
        }
        .onDisappear {
            // Don't disconnect - keep connection alive for the session
            print("💬 ChatView: Disappeared but keeping connection alive")
            // Clear screen tracker when leaving chat screen
            ScreenTracker.shared.clearScreen()
            print("💬 ChatView: Cleared screen tracker")
        }
    }
    
    // MARK: - Chat Header
    private var chatHeader: some View {
        VStack(spacing: 0) {
            // Main header
            HStack {
                // Back button
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                // Contact info
                VStack(spacing: 2) {
                    Text(viewModel.contact.name)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                    
                    Text(viewModel.contact.subtitle)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                }
                
                Spacer()
                
                // Placeholder for symmetry
                Color.clear
                    .frame(width: 18, height: 18)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            
            // Separator line
            Rectangle()
                .fill(Color.gray.opacity(0.2))
                .frame(height: 0.5)
        }
        .background(Color.white)
    }
    
    // MARK: - Messages List
    private var messagesList: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(viewModel.messages) { message in
                        MessageBubbleView(
                            message: message,
                            viewModel: viewModel
                        )
                        .id(message.id)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
            }
            .onChange(of: viewModel.messages.count) { newCount in
                // Only auto-scroll when message count increases (new message added)
                if newCount > 0, let lastMessage = viewModel.messages.last {
                    // Use a minimal delay to prevent flickering
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
            }
            .onAppear {
                // Scroll to bottom when view appears
                if let lastMessage = viewModel.messages.last {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        proxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
            }
        }
    }
    
    // MARK: - Quick Replies Section
    private var quickRepliesSection: some View {
        VStack(spacing: 12) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(viewModel.quickReplies) { reply in
                        Button(action: {
                            viewModel.sendQuickReply(reply)
                        }) {
                            Text(reply.text)
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.black)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 8)
                                .background(Color.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 16)
                                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                                )
                                .cornerRadius(16)
                        }
                    }
                }
                .padding(.horizontal, 20)
            }
        }
        .padding(.vertical, 12)
        .background(Color.gray.opacity(0.05))
    }
    
    // MARK: - Input Area
    private var inputArea: some View {
        VStack(spacing: 0) {
            // Text input field
            HStack(spacing: 12) {
                // Text input
                TextField("Type a message...", text: $newMessageText)
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(20)
                    .onSubmit {
                        if !newMessageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            viewModel.sendMessage(newMessageText)
                            newMessageText = ""
                        }
                    }
                
                // Send button
                Button(action: {
                    if !newMessageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        viewModel.sendMessage(newMessageText)
                        newMessageText = ""
                    }
                }) {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 32))
                        .foregroundColor(.orange)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 12)
            .background(Color.white)
        }
    }
    
    // MARK: - Connection Status View
    private var connectionStatusView: some View {
        VStack(spacing: 8) {
            HStack {
                Image(systemName: "wifi.slash")
                    .foregroundColor(.orange)
                Text("Connecting to chat...")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.orange)
                Spacer()
                Button("Retry") {
                    viewModel.connect()
                }
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.orange)
                .padding(.horizontal, 12)
                .padding(.vertical, 4)
                .background(Color.orange.opacity(0.2))
                .cornerRadius(8)
            }
            
            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .font(.system(size: 12))
                    .foregroundColor(.red)
                    .multilineTextAlignment(.leading)
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 8)
        .background(Color.orange.opacity(0.1))
    }
    
    // MARK: - Error Message View
    private func errorMessageView(_ message: String) -> some View {
        HStack {
            Image(systemName: "exclamationmark.triangle")
                .foregroundColor(.red)
            Text(message)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.red)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 8)
        .background(Color.red.opacity(0.1))
    }
}

// MARK: - Message Bubble View
struct MessageBubbleView: View {
    let message: ChatMessage
    let viewModel: ChatViewModel
    
    var body: some View {
        HStack {
            if message.isFromUser {
                Spacer()
                userMessageBubble
            } else {
                driverMessageBubble
                Spacer()
            }
        }
    }
    
    private var userMessageBubble: some View {
        VStack(alignment: .trailing, spacing: 4) {
            HStack(alignment: .bottom, spacing: 8) {
                Text(viewModel.formatMessageTime(message.timestamp))
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
                
                Image(systemName: "checkmark")
                    .font(.system(size: 10))
                    .foregroundColor(.gray)
            }
            
            Text(message.text)
                .font(.system(size: 16))
                .foregroundColor(.white)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.orange)
                .cornerRadius(20, corners: [.topLeft, .topRight, .bottomLeft])
        }
    }
    
    private var driverMessageBubble: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(message.text)
                .font(.system(size: 16))
                .foregroundColor(.black)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(20, corners: [.topLeft, .topRight, .bottomRight])
            
            Text(viewModel.formatMessageTime(message.timestamp))
                .font(.system(size: 12))
                .foregroundColor(.gray)
                .padding(.leading, 8)
        }
    }
}


#Preview {
    ChatView(bookingId: 123, driverId: "456", driverName: "John Doe")
}
