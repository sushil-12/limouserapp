import Foundation
import SocketIO
import Combine

class ChatService: ObservableObject {
    static let shared = ChatService()
    
    // Use SimpleSocketIOService for all socket operations (no duplicate socket)
    private let socketService = SimpleSocketIOService.shared
    private let serverURL = "https://limortservice.infodevbox.com"
    
    @Published var isConnected = false
    @Published var messages: [RealTimeChatMessage] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private var cancellables = Set<AnyCancellable>()
    
    private init() {
        setupConnectionObserver()
    }
    
    /// Observe connection status from SimpleSocketIOService
    private func setupConnectionObserver() {
        // Observe connection status changes from SimpleSocketIOService
        socketService.$isConnected
            .receive(on: DispatchQueue.main)
            .assign(to: &$isConnected)
        
        // Listen for chat message sent confirmation from SimpleSocketIOService
        // We'll need to add this event handler to SimpleSocketIOService
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("ChatMessageSent"),
            object: nil,
            queue: .main
        ) { [weak self] notification in
            print("✅ ChatService: Message sent confirmation received")
        }
        
        // Listen for chat errors from SimpleSocketIOService
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("ChatError"),
            object: nil,
            queue: .main
        ) { [weak self] notification in
            if let errorMessage = notification.userInfo?["message"] as? String {
                self?.errorMessage = errorMessage
                print("❌ ChatService: Chat error: \(errorMessage)")
            }
        }
    }
    
    // Public method to handle chat notification from external services
    func handleChatNotification(data: [Any]) {
        print("📨 ChatService: Received notification")
        
        guard let notificationData = data.first as? [String: Any] else {
            print("❌ ChatService: Could not parse notification data")
            return
        }
        
        // Check if this is a chat message notification
        if let data = notificationData["data"] as? [String: Any],
           let type = data["type"] as? String,
           type == "chat_message" {
            processChatMessage(data: data)
        }
    }
    
    // Public method to handle direct message data (from SimpleSocketIOService)
    func handleDirectChatMessage(data: [Any]) {
        print("📨 ChatService: Received direct chat message via user_notification")
        
        guard let messageData = data.first as? [String: Any] else {
            print("❌ ChatService: Could not parse direct message data")
            return
        }
        
        // Check if this is a chat message
        if let type = messageData["type"] as? String,
           type == "chat_message" {
            processChatMessage(data: messageData)
        }
    }
    
    // Public helper to process chat message data (called from SimpleSocketIOService)
    // skipNotificationCenterPost: If true, don't post .chatMessageReceived notification
    // (used when SimpleSocketIOService is handling notifications to prevent duplicates)
    func processChatMessage(data: [String: Any], skipNotificationCenterPost: Bool = false) {
        print("📨 ChatService: Processing chat message data")
        print("📨 ChatService: Raw data: \(data)")
        
        do {
            // Add missing receiverId if not present
            var messageData = data
            if messageData["receiverId"] == nil {
                messageData["receiverId"] = StorageManager.shared.getUserIdString() ?? "unknown"
                print("📨 ChatService: Added receiverId: \(messageData["receiverId"] ?? "unknown")")
            }
            
            print("📨 ChatService: Processing message data: \(messageData)")
            let jsonData = try JSONSerialization.data(withJSONObject: messageData)
            let chatMessage = try JSONDecoder().decode(RealTimeChatMessage.self, from: jsonData)
            print("📨 ChatService: Successfully decoded chat message: \(chatMessage.message)")
            print("📨 ChatService: Message bookingId: \(chatMessage.bookingId)")
            
            // Check if message already exists to prevent duplicates
            let messageExists = self.messages.contains { $0.id == chatMessage.id }
            if !messageExists {
                // Update UI on main thread
                DispatchQueue.main.async {
                    self.messages.append(chatMessage)
                    print("✅ ChatService: Added new message to list")
                    print("✅ ChatService: Total messages now: \(self.messages.count)")
                    print("✅ ChatService: Message ID: \(chatMessage.id)")
                    print("✅ ChatService: Message text: \(chatMessage.message)")
                }
                
                // Only post notification if not skipped (skip when SimpleSocketIOService handles it)
                if !skipNotificationCenterPost {
                    self.notifyChatMessageReceived(chatMessage)
                } else {
                    print("📨 ChatService: Skipping NotificationCenter post - SimpleSocketIOService handles notifications")
                }
            } else {
                print("⚠️ ChatService: Message already exists, skipping duplicate")
            }
        } catch {
            print("❌ ChatService: Failed to parse chat message: \(error)")
            print("❌ ChatService: Error details: \(error.localizedDescription)")
        }
    }
    
    
    private func notifyChatMessageReceived(_ chatMessage: RealTimeChatMessage) {
        // Post notification to open chat view
        NotificationCenter.default.post(
            name: .chatMessageReceived,
            object: nil,
            userInfo: [
                "bookingId": chatMessage.bookingId,
                "driverId": chatMessage.senderId,
                "driverName": "Driver", // Default driver name, can be enhanced later
                "message": chatMessage.message
            ]
        )
        print("📨 ChatService: Posted chat message received notification")
    }
    
    /// Connect - delegates to SimpleSocketIOService
    /// Note: Connection is managed at app level, not per service
    func connect() {
        // ChatService no longer manages its own socket
        // Connection is handled by SimpleSocketIOService at app level
        print("🔌 ChatService: Connect called - using SimpleSocketIOService connection")
        socketService.ensureConnection()
    }
    
    /// Disconnect - delegates to SimpleSocketIOService
    /// Note: Only called on logout, normal disconnection is handled at app level
    func disconnect() {
        // ChatService no longer manages its own socket
        // Only SimpleSocketIOService.disconnectForLogout() should be called
        print("🔌 ChatService: Disconnect called - connection managed by SimpleSocketIOService")
    }
    
    
    func sendMessage(bookingId: Int, receiverId: String, message: String) {
        guard socketService.isConnected else {
            print("❌ ChatService: Cannot send message - not connected")
            errorMessage = "Not connected to chat server"
            // Try to ensure connection
            socketService.ensureConnection()
            return
        }
        
        let messageData: [String: Any] = [
            "bookingId": bookingId,
            "receiverId": receiverId,
            "message": message
        ]
        
        print("📤 ChatService: Sending message via WebSocket via SimpleSocketIOService")
        print("   Booking ID: \(bookingId)")
        print("   Receiver ID: \(receiverId)")
        print("   Message: \(message)")
        
        // Add message immediately to UI for instant feedback
        let customerId = StorageManager.shared.getUserIdString() ?? "unknown"
        let tempMessage = RealTimeChatMessage(
            id: UUID().uuidString,
            bookingId: bookingId,
            senderId: customerId,
            receiverId: receiverId,
            senderRole: "customer",
            message: message,
            createdAt: Date()
        )
        
        DispatchQueue.main.async {
            self.messages.append(tempMessage)
            print("✅ ChatService: Message added to UI immediately")
        }
        
        // Use SimpleSocketIOService to emit the message
        socketService.emitEvent(eventName: "chat.message", data: messageData)
    }
    
    func fetchChatHistory(bookingId: Int, page: Int = 1, limit: Int = 50) {
        print("📥 ChatService: fetchChatHistory called for booking \(bookingId)")
        print("📥 ChatService: Current message count before fetch: \(messages.count)")
        
        isLoading = true
        errorMessage = nil
        
        let urlString = "\(serverURL)/api/messages/\(bookingId)?page=\(page)&limit=\(limit)"
        guard let url = URL(string: urlString) else {
            errorMessage = "Invalid URL"
            isLoading = false
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("limoapi_notifications_secret_2024_xyz789", forHTTPHeaderField: "x-secret")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        print("📥 ChatService: Fetching chat history for booking \(bookingId)")
        
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                if let error = error {
                    print("❌ ChatService: Network error: \(error.localizedDescription)")
                    self?.errorMessage = error.localizedDescription
                    return
                }
                
                guard let data = data else {
                    print("❌ ChatService: No data received")
                    self?.errorMessage = "No data received"
                    return
                }
                
                do {
                    // Print raw response for debugging
                    if let jsonString = String(data: data, encoding: .utf8) {
                        print("📥 ChatService: Raw response: \(jsonString)")
                    }
                    
                    let chatHistory = try JSONDecoder().decode(ChatHistoryResponse.self, from: data)
                    if chatHistory.success {
                        self?.mergeMessages(newMessages: chatHistory.data)
                        print("✅ ChatService: Loaded \(chatHistory.data.count) messages")
                    } else {
                        print("❌ ChatService: Server returned success: false")
                        self?.errorMessage = "Failed to load chat history"
                    }
                } catch {
                    print("❌ ChatService: Failed to parse chat history: \(error)")
                    print("❌ ChatService: Error details: \(error.localizedDescription)")
                    
                    // Try to parse as raw JSON to see what we're getting
                    if let jsonObject = try? JSONSerialization.jsonObject(with: data) {
                        print("📥 ChatService: Raw JSON object: \(jsonObject)")
                    }
                    
                    self?.errorMessage = "Failed to parse chat history: \(error.localizedDescription)"
                }
            }
        }.resume()
    }
    
    func sendMessageViaAPI(bookingId: Int, receiverId: String, message: String) {
        isLoading = true
        errorMessage = nil
        
        let urlString = "\(serverURL)/api/messages/send"
        guard let url = URL(string: urlString) else {
            errorMessage = "Invalid URL"
            isLoading = false
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("limoapi_notifications_secret_2024_xyz789", forHTTPHeaderField: "x-secret")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let requestBody: [String: Any] = [
            "bookingId": bookingId,
            "receiverId": receiverId,
            "message": message
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: requestBody)
        } catch {
            errorMessage = "Failed to create request body"
            isLoading = false
            return
        }
        
        print("📤 ChatService: Sending message via REST API")
        print("   Booking ID: \(bookingId)")
        print("   Receiver ID: \(receiverId)")
        print("   Message: \(message)")
        
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                if let error = error {
                    print("❌ ChatService: Network error: \(error.localizedDescription)")
                    self?.errorMessage = error.localizedDescription
                    return
                }
                
                guard let data = data else {
                    print("❌ ChatService: No data received")
                    self?.errorMessage = "No data received"
                    return
                }
                
                do {
                    let response = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                    if let success = response?["success"] as? Bool, success {
                        print("✅ ChatService: Message sent successfully via API")
                        // Don't refresh chat history - message will come via WebSocket
                    } else {
                        print("❌ ChatService: Server returned success: false")
                        self?.errorMessage = "Failed to send message"
                    }
                } catch {
                    print("❌ ChatService: Failed to parse API response: \(error)")
                    self?.errorMessage = "Failed to send message"
                }
            }
        }.resume()
    }
    
    func clearMessages() {
        messages.removeAll()
        errorMessage = nil
        print("📨 ChatService: Messages cleared")
    }
    
    private func mergeMessages(newMessages: [RealTimeChatMessage]) {
        // If messages array is empty, just assign the new messages
        if messages.isEmpty {
            messages = newMessages
            print("📨 ChatService: Initial message load - set \(newMessages.count) messages")
            return
        }
        
        // Merge new messages with existing ones, avoiding duplicates
        var mergedMessages = messages
        var addedCount = 0
        
        for newMessage in newMessages {
            let messageExists = mergedMessages.contains { $0.id == newMessage.id }
            if !messageExists {
                mergedMessages.append(newMessage)
                addedCount += 1
            }
        }
        
        // Sort messages by creation date to maintain chronological order
        mergedMessages.sort { $0.createdAt < $1.createdAt }
        
        messages = mergedMessages
        print("📨 ChatService: Merged messages - added \(addedCount) new, total \(messages.count)")
    }
}
