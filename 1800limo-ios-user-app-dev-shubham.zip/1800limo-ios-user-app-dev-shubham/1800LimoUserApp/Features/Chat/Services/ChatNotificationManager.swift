import Foundation
import SwiftUI

// MARK: - Chat Notification Manager
class ChatNotificationManager: ObservableObject {
    static let shared = ChatNotificationManager()
    
    @Published var shouldOpenChat = false
    @Published var chatData: ChatNotificationData?
    
    private init() {}
    
    func openChat(bookingId: Int, driverId: String, driverName: String) {
        DispatchQueue.main.async {
            self.chatData = ChatNotificationData(
                bookingId: bookingId,
                driverId: driverId,
                driverName: driverName
            )
            self.shouldOpenChat = true
            print("💬 ChatNotificationManager: Opening chat for booking \(bookingId)")
        }
    }
    
    func closeChat() {
        DispatchQueue.main.async {
            self.shouldOpenChat = false
            self.chatData = nil
        }
    }
}

// MARK: - Chat Notification Data
struct ChatNotificationData {
    let bookingId: Int
    let driverId: String
    let driverName: String
}

// MARK: - Notification Names
extension Notification.Name {
    static let chatMessageReceived = Notification.Name("chatMessageReceived")
    static let openChatView = Notification.Name("openChatView")
    static let chatToastTapped = Notification.Name("chatToastTapped")
}


