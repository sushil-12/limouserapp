import Foundation
import SwiftUI
import Combine

class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var quickReplies: [QuickReply] = []
    @Published var contact: ChatContact = ChatContact.driverContact
    @Published var newMessageText: String = ""
    @Published var isLoading: Bool = false
    @Published var isConnected: Bool = false
    @Published var errorMessage: String?
    
    private let chatService = ChatService.shared
    private var cancellables = Set<AnyCancellable>()
    
    // Booking context for real-time chat
    @Published var bookingId: Int?
    var driverId: String?
    var driverName: String = "Driver"
    
    init() {
        setupChatService()
        loadQuickReplies()
    }
    
    // MARK: - Chat Service Setup
    private func setupChatService() {
        // Subscribe to chat service updates
        chatService.$isConnected
            .assign(to: \.isConnected, on: self)
            .store(in: &cancellables)
        
        // Combine messages and bookingId so subscription updates when either changes
        Publishers.CombineLatest(chatService.$messages, $bookingId)
            .map { [weak self] chatMessages, currentBookingId in
                guard let self = self else { return [] }
                guard let bookingId = currentBookingId else {
                    print("💬 ChatViewModel: No bookingId set, returning empty messages")
                    return []
                }
                
                print("💬 ChatViewModel: Received \(chatMessages.count) messages from ChatService")
                print("💬 ChatViewModel: Filtering for bookingId: \(bookingId)")
                print("💬 ChatViewModel: Current UI messages count: \(self.messages.count)")
                
                // Filter messages by bookingId
                let filteredMessages = chatMessages.filter { $0.bookingId == bookingId }
                print("💬 ChatViewModel: Filtered to \(filteredMessages.count) messages for booking \(bookingId)")
                
                let customerId = StorageManager.shared.getUserIdString() ?? "unknown"
                let mappedMessages = filteredMessages.map { ChatMessage(from: $0, customerId: customerId) }
                // Sort messages by timestamp (oldest first, newest last)
                let sortedMessages = mappedMessages.sorted { $0.timestamp < $1.timestamp }
                print("💬 ChatViewModel: Mapped to \(sortedMessages.count) UI messages")
                
                // Check if this is a new message (count increased)
                if sortedMessages.count > self.messages.count {
                    print("💬 ChatViewModel: New message detected - count increased from \(self.messages.count) to \(sortedMessages.count)")
                }
                
                return sortedMessages
            }
            .assign(to: \.messages, on: self)
            .store(in: &cancellables)
        
        chatService.$isLoading
            .assign(to: \.isLoading, on: self)
            .store(in: &cancellables)
        
        chatService.$errorMessage
            .assign(to: \.errorMessage, on: self)
            .store(in: &cancellables)
    }
    
    // MARK: - Booking Context Setup
    func setupForBooking(bookingId: Int, driverId: String, driverName: String) {
        self.bookingId = bookingId
        self.driverId = driverId
        self.driverName = driverName
        
        // Update contact info
        contact = ChatContact(
            name: driverName,
            subtitle: "Chat",
            lastMessage: nil,
            lastMessageTime: nil,
            unreadCount: 0,
            isOnline: true
        )
        
        // Connect to chat service and load history (like driver app)
        chatService.connect()
        loadChatHistory()
    }
    
    // MARK: - Data Loading
    private func loadQuickReplies() {
        quickReplies = QuickReply.defaultReplies
    }
    
    private func loadChatHistory() {
        guard let bookingId = bookingId else { return }
        chatService.fetchChatHistory(bookingId: bookingId)
    }
    
    // MARK: - Message Actions
    func sendMessage(_ text: String) {
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        guard let bookingId = bookingId, let driverId = driverId else {
            print("❌ ChatViewModel: Cannot send message - missing booking or driver ID")
            return
        }
        
        // Send via WebSocket (preferred method)
        chatService.sendMessage(bookingId: bookingId, receiverId: driverId, message: text)
        
        // Clear input field
        newMessageText = ""
        
        print("📤 ChatViewModel: Sent message via WebSocket")
    }
    
    func sendQuickReply(_ reply: QuickReply) {
        sendMessage(reply.text)
    }
    
    // MARK: - Connection Management
    func connect() {
        chatService.connect()
    }
    
    func disconnect() {
        chatService.disconnect()
    }
    
    
    func clearChat() {
        chatService.clearMessages()
    }
    
    // MARK: - Date Formatting
    func formatMessageTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        return formatter.string(from: date).lowercased()
    }
    
    // MARK: - Message Width Calculation
    func calculateMessageWidth(for message: ChatMessage, screenWidth: CGFloat) -> CGFloat {
        let maxWidth = screenWidth * 0.65 // 65% of screen width as per requirement
        let minWidth: CGFloat = 80
        
        // Calculate text width based on character count
        let textWidth = CGFloat(message.text.count * 8) + 32 // Approximate width calculation
        
        return min(max(textWidth, minWidth), maxWidth)
    }
}
