import Foundation

// MARK: - Booking Audit Records Response
struct BookingAuditRecordsResponse: Codable {
    let success: Bool
    let message: String
    let data: BookingAuditRecordsData
    let timestamp: String
    let code: Int
}

// MARK: - Booking Audit Records Data
struct BookingAuditRecordsData: Codable {
    let success: Bool
    let total_events: Int
    let total_bookings: Int
    let events: [BookingAuditEvent]
    let pagination: AuditRecordsPagination
    let filters_applied: AuditRecordsFilters
    
    enum CodingKeys: String, CodingKey {
        case success, total_events, total_bookings, events, pagination, filters_applied
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        success = try container.decode(Bool.self, forKey: .success)
        
        // Handle total_events as either Int or String
        if let totalEventsInt = try? container.decode(Int.self, forKey: .total_events) {
            total_events = totalEventsInt
        } else if let totalEventsString = try? container.decode(String.self, forKey: .total_events),
                  let totalEventsInt = Int(totalEventsString) {
            total_events = totalEventsInt
        } else {
            total_events = 0
        }
        
        // Handle total_bookings as either Int or String
        if let totalBookingsInt = try? container.decode(Int.self, forKey: .total_bookings) {
            total_bookings = totalBookingsInt
        } else if let totalBookingsString = try? container.decode(String.self, forKey: .total_bookings),
                  let totalBookingsInt = Int(totalBookingsString) {
            total_bookings = totalBookingsInt
        } else {
            total_bookings = 0
        }
        
        events = try container.decode([BookingAuditEvent].self, forKey: .events)
        pagination = try container.decode(AuditRecordsPagination.self, forKey: .pagination)
        filters_applied = try container.decode(AuditRecordsFilters.self, forKey: .filters_applied)
    }
}

// MARK: - Booking Audit Event
struct BookingAuditEvent: Codable, Identifiable {
    let id: String
    let event_type: String
    let event_category: String
    let title: String
    let description: String
    let timestamp: String
    let timestamp_formatted: String
    let details: EventDetails?
    let user: EventUser
    let booking_id: Int
    
    // Custom decoder to handle ID as either String or Int
    enum CodingKeys: String, CodingKey {
        case id, event_type, event_category, title, description
        case timestamp, timestamp_formatted, details, user, booking_id
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Handle ID as either String or Int
        if let idString = try? container.decode(String.self, forKey: .id) {
            id = idString
        } else if let idInt = try? container.decode(Int.self, forKey: .id) {
            id = String(idInt)
        } else {
            id = UUID().uuidString
        }
        
        event_type = try container.decode(String.self, forKey: .event_type)
        event_category = try container.decode(String.self, forKey: .event_category)
        title = try container.decode(String.self, forKey: .title)
        description = try container.decode(String.self, forKey: .description)
        timestamp = try container.decode(String.self, forKey: .timestamp)
        timestamp_formatted = try container.decode(String.self, forKey: .timestamp_formatted)
        details = try container.decodeIfPresent(EventDetails.self, forKey: .details)
        user = try container.decode(EventUser.self, forKey: .user)
        
        // Handle booking_id as either Int or String
        if let bookingIdInt = try? container.decode(Int.self, forKey: .booking_id) {
            booking_id = bookingIdInt
        } else if let bookingIdString = try? container.decode(String.self, forKey: .booking_id),
                  let bookingIdInt = Int(bookingIdString) {
            booking_id = bookingIdInt
        } else {
            booking_id = 0
        }
    }
}

// MARK: - Event Details
struct EventDetails: Codable {
    let current_status: String?
    let status_display: String?
    let sender: String?
    let receiver: String?
    let receiver_type: String?
    let message: String?
    
    enum CodingKeys: String, CodingKey {
        case current_status, status_display, sender, receiver, receiver_type, message
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        current_status = try container.decodeIfPresent(String.self, forKey: .current_status)
        status_display = try container.decodeIfPresent(String.self, forKey: .status_display)
        sender = try container.decodeIfPresent(String.self, forKey: .sender)
        receiver = try container.decodeIfPresent(String.self, forKey: .receiver)
        receiver_type = try container.decodeIfPresent(String.self, forKey: .receiver_type)
        message = try container.decodeIfPresent(String.self, forKey: .message)
    }
}

// MARK: - Event User
struct EventUser: Codable {
    let id: Int?
    let name: String
    let role: String
}

// MARK: - Audit Records Pagination
struct AuditRecordsPagination: Codable {
    let current_page: Int
    let per_page: Int
    let total: Int
    let last_page: Int
    let from: Int?
    let to: Int?
    
    enum CodingKeys: String, CodingKey {
        case current_page, per_page, total, last_page, from, to
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Handle current_page as either Int or String
        if let currentPageInt = try? container.decode(Int.self, forKey: .current_page) {
            current_page = currentPageInt
        } else if let currentPageString = try? container.decode(String.self, forKey: .current_page),
                  let currentPageInt = Int(currentPageString) {
            current_page = currentPageInt
        } else {
            current_page = 1
        }
        
        // Handle per_page as either Int or String
        if let perPageInt = try? container.decode(Int.self, forKey: .per_page) {
            per_page = perPageInt
        } else if let perPageString = try? container.decode(String.self, forKey: .per_page),
                  let perPageInt = Int(perPageString) {
            per_page = perPageInt
        } else {
            per_page = 20
        }
        
        // Handle total as either Int or String
        if let totalInt = try? container.decode(Int.self, forKey: .total) {
            total = totalInt
        } else if let totalString = try? container.decode(String.self, forKey: .total),
                  let totalInt = Int(totalString) {
            total = totalInt
        } else {
            total = 0
        }
        
        // Handle last_page as either Int or String
        if let lastPageInt = try? container.decode(Int.self, forKey: .last_page) {
            last_page = lastPageInt
        } else if let lastPageString = try? container.decode(String.self, forKey: .last_page),
                  let lastPageInt = Int(lastPageString) {
            last_page = lastPageInt
        } else {
            last_page = 1
        }
        
        // Handle from as either Int or String or null
        if let fromInt = try? container.decode(Int.self, forKey: .from) {
            from = fromInt
        } else if let fromString = try? container.decode(String.self, forKey: .from),
                  let fromInt = Int(fromString) {
            from = fromInt
        } else {
            from = nil
        }
        
        // Handle to as either Int or String or null
        if let toInt = try? container.decode(Int.self, forKey: .to) {
            to = toInt
        } else if let toString = try? container.decode(String.self, forKey: .to),
                  let toInt = Int(toString) {
            to = toInt
        } else {
            to = nil
        }
    }
}

// MARK: - Audit Records Filters
struct AuditRecordsFilters: Codable {
    let from: String?
    let to: String?
    let event_type: String?
    let event_category: String?
    let search: String?
    let booking_id: Int?
    
    enum CodingKeys: String, CodingKey {
        case from, to, event_type, event_category, search, booking_id
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        from = try container.decodeIfPresent(String.self, forKey: .from)
        to = try container.decodeIfPresent(String.self, forKey: .to)
        event_type = try container.decodeIfPresent(String.self, forKey: .event_type)
        event_category = try container.decodeIfPresent(String.self, forKey: .event_category)
        search = try container.decodeIfPresent(String.self, forKey: .search)
        
        // Handle booking_id as either Int, String, or null
        if let bookingIdInt = try? container.decode(Int.self, forKey: .booking_id) {
            booking_id = bookingIdInt
        } else if let bookingIdString = try? container.decode(String.self, forKey: .booking_id),
                  let bookingIdInt = Int(bookingIdString) {
            booking_id = bookingIdInt
        } else {
            booking_id = nil
        }
    }
}











