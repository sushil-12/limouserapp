import Foundation

// MARK: - Recent Location Response Model
struct RecentLocationResponse: Codable {
    let success: Bool
    let message: String
    let data: RecentLocationData
    let timestamp: String
    let code: Int
}

struct RecentLocationData: Codable {
    let locations: [RecentLocation]
    let count: Int
    let search: String
    let type: String
    let limit: Int
}

struct RecentLocation: Codable, Identifiable, Hashable {
    let id: UUID
    let address: String
    let latitude: Double
    let longitude: Double
    let type: String
    let isAirport: Bool
    let lastUsed: String
    let airportId: String?
    let airportCode: String?
    let airportName: String?
    
    enum CodingKeys: String, CodingKey {
        case address
        case latitude
        case longitude
        case type
        case isAirport = "is_airport"
        case lastUsed = "last_used"
        case airportId = "airport_id"
        case airportCode = "airport_code"
        case airportName = "airport_name"
    }
    
    // Hashable conformance
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: RecentLocation, rhs: RecentLocation) -> Bool {
        return lhs.id == rhs.id
    }
    
    // Custom initializer to generate UUID from address and coordinates
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        address = try container.decode(String.self, forKey: .address)
        latitude = try container.decode(Double.self, forKey: .latitude)
        longitude = try container.decode(Double.self, forKey: .longitude)
        type = try container.decode(String.self, forKey: .type)
        isAirport = try container.decode(Bool.self, forKey: .isAirport)
        lastUsed = try container.decode(String.self, forKey: .lastUsed)
        airportId = try container.decodeIfPresent(String.self, forKey: .airportId)
        airportCode = try container.decodeIfPresent(String.self, forKey: .airportCode)
        airportName = try container.decodeIfPresent(String.self, forKey: .airportName)
        
        // Generate unique ID from address and coordinates
        let uniqueString = "\(address)-\(latitude)-\(longitude)"
        let cleanedString = uniqueString.replacingOccurrences(of: " ", with: "")
        id = UUID(uuidString: String(cleanedString.prefix(36))) ?? UUID()
    }
    
    // Convenience initializer for testing
    init(address: String, latitude: Double, longitude: Double, type: String, isAirport: Bool, airportId: String? = nil, airportCode: String? = nil, airportName: String? = nil) {
        self.address = address
        self.latitude = latitude
        self.longitude = longitude
        self.type = type
        self.isAirport = isAirport
        self.lastUsed = ""
        self.airportId = airportId
        self.airportCode = airportCode
        self.airportName = airportName
        
        let uniqueString = "\(address)-\(latitude)-\(longitude)"
        let cleanedString = uniqueString.replacingOccurrences(of: " ", with: "")
        self.id = UUID(uuidString: String(cleanedString.prefix(36))) ?? UUID()
    }
}
