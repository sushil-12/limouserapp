import Foundation

// MARK: - Request Models
struct VehicleListingRequest: Codable {
    let serviceType: String
    let bookingHour: Int
    let pickupType: String
    let dropoffType: String
    let pickupDate: String
    let pickupTime: String
    let pickupAirport: Int?
    let pickupAirportName: String?
    let pickupAirportLat: Double?
    let pickupAirportLong: Double?
    let pickupAddress: String?
    let pickupAddressLat: Double?
    let pickupAddressLong: Double?
    let dropoffAirport: Int?
    let dropoffAirportName: String?
    let dropoffAirportLat: Double?
    let dropoffAirportLong: Double?
    let dropoffAddress: String?
    let dropoffAddressLat: Double?
    let dropoffAddressLong: Double?
    let returnPickupDate: String
    let returnPickupTime: String
    let returnPickupAirport: Int?
    let returnPickupAirportName: String?
    let returnPickupAirportLat: Double?
    let returnPickupAirportLong: Double?
    let returnPickupAddress: String?
    let returnPickupAddressLat: Double?
    let returnPickupAddressLong: Double?
    let returnDropoffAirport: Int?
    let returnDropoffAirportName: String?
    let returnDropoffAirportLat: Double?
    let returnDropoffAirportLong: Double?
    let returnDropoffAddress: String?
    let returnDropoffAddressLat: Double?
    let returnDropoffAddressLong: Double?
    let noOfPassenger: Int
    let noOfLuggage: Int
    let locationInfo: [LocationInfo]
    let otherDetails: OtherDetails
    let filters: Filters
    let userId: Int
    
    enum CodingKeys: String, CodingKey {
        case serviceType = "service_type"
        case bookingHour = "booking_hour"
        case pickupType = "pickup_type"
        case dropoffType = "dropoff_type"
        case pickupDate = "pickup_date"
        case pickupTime = "pickup_time"
        case pickupAirport = "pickup_airport"
        case pickupAirportName = "pickup_airport_name"
        case pickupAirportLat = "pickup_airport_lat"
        case pickupAirportLong = "pickup_airport_long"
        case pickupAddress = "pickup_address"
        case pickupAddressLat = "pickup_address_lat"
        case pickupAddressLong = "pickup_address_long"
        case dropoffAirport = "dropoff_airport"
        case dropoffAirportName = "dropoff_airport_name"
        case dropoffAirportLat = "dropoff_airport_lat"
        case dropoffAirportLong = "dropoff_airport_long"
        case dropoffAddress = "dropoff_address"
        case dropoffAddressLat = "dropoff_address_lat"
        case dropoffAddressLong = "dropoff_address_long"
        case returnPickupDate = "return_pickup_date"
        case returnPickupTime = "return_pickup_time"
        case returnPickupAirport = "return_pickup_airport"
        case returnPickupAirportName = "return_pickup_airport_name"
        case returnPickupAirportLat = "return_pickup_airport_lat"
        case returnPickupAirportLong = "return_pickup_airport_long"
        case returnPickupAddress = "return_pickup_address"
        case returnPickupAddressLat = "return_pickup_address_lat"
        case returnPickupAddressLong = "return_pickup_address_long"
        case returnDropoffAirport = "return_dropoff_airport"
        case returnDropoffAirportName = "return_dropoff_airport_name"
        case returnDropoffAirportLat = "return_dropoff_airport_lat"
        case returnDropoffAirportLong = "return_dropoff_airport_long"
        case returnDropoffAddress = "return_dropoff_address"
        case returnDropoffAddressLat = "return_dropoff_address_lat"
        case returnDropoffAddressLong = "return_dropoff_address_long"
        case noOfPassenger = "no_of_passenger"
        case noOfLuggage = "no_of_luggage"
        case locationInfo = "location_info"
        case otherDetails = "other_details"
        case filters = "filters"
        case userId = "user_id"
    }
}

struct Filters: Codable {
    let vehicleType: [Int]?
    let driverDresses: [Int]?
    let driverLanguages: [Int]?
    let driverGender: [String]?
    let amenities: [Int]?
    let make: [Int]?
    let model: [Int]?
    let years: [Int]?
    let colors: [Int]?
    let interiors: [Int]?
    let specialAmenities: [Int]?
    let vehicleServiceArea: [String]?
    let affiliatePreferences: [String]?
    
    enum CodingKeys: String, CodingKey {
        case vehicleType = "vehicle-type"
        case driverDresses = "driver-dresses"
        case driverLanguages = "driver-languages"
        case driverGender = "driver-gender"
        case amenities
        case make
        case model
        case years
        case colors
        case interiors
        case specialAmenities = "special-amenities"
        case vehicleServiceArea = "vehicle-service-area"
        case affiliatePreferences = "affiliate-preferences"
    }
    
    // Create filters from FilterSelectionState, only including non-empty arrays
    static func from(selectionState: FilterSelectionState) -> Filters {
        return Filters(
            vehicleType: selectionState.selectedVehicleTypes.isEmpty ? nil : Array(selectionState.selectedVehicleTypes),
            driverDresses: selectionState.selectedDriverDresses.isEmpty ? nil : Array(selectionState.selectedDriverDresses),
            driverLanguages: selectionState.selectedDriverLanguages.isEmpty ? nil : Array(selectionState.selectedDriverLanguages),
            driverGender: selectionState.selectedDriverGenders.isEmpty ? nil : Array(selectionState.selectedDriverGenders),
            amenities: selectionState.selectedAmenities.isEmpty ? nil : Array(selectionState.selectedAmenities),
            make: selectionState.selectedMakes.isEmpty ? nil : Array(selectionState.selectedMakes),
            model: selectionState.selectedModels.isEmpty ? nil : Array(selectionState.selectedModels),
            years: selectionState.selectedYears.isEmpty ? nil : Array(selectionState.selectedYears),
            colors: selectionState.selectedColors.isEmpty ? nil : Array(selectionState.selectedColors),
            interiors: selectionState.selectedInteriors.isEmpty ? nil : Array(selectionState.selectedInteriors),
            specialAmenities: selectionState.selectedSpecialAmenities.isEmpty ? nil : Array(selectionState.selectedSpecialAmenities),
            vehicleServiceArea: selectionState.selectedVehicleServiceAreas.isEmpty ? nil : Array(selectionState.selectedVehicleServiceAreas),
            affiliatePreferences: selectionState.selectedAffiliatePreferences.isEmpty ? nil : Array(selectionState.selectedAffiliatePreferences)
        )
    }
}

// MARK: - Response Models
struct VehicleListingResponse: Codable {
    let success: Bool
    let data: [VehicleListingItem]
    let message: String
    let currency: VehicleListingCurrency?
}

struct VehicleListingItem: Codable, Identifiable, Equatable, Hashable {
    let id: Int
    let affiliateId: Int? // Changed to Int to match API
    let badgeCity: String?
    let affiliateType: String?
    let affiliateCompany: String?
    let affiliatePhone: String?
    let affiliateName: String?
    let name: String
    let vehicleTypeId: Int?
    let passenger: Int
    let luggage: Int
    let latitude: Double?
    let longitude: Double?
    let distance: Double?
    let createdBy: Int?
    let numberOfVehicles: Int?
    let cancellationPolicy: Int?
    let isMasterVehicle: Bool?
    let driverInformation: DriverInformation?
    let amenities: [Amenity]?
    let vehicleImages: [String]
    let vehicleDetails: VehicleDetails?
    
    // Rate breakdowns for different service types
    let rateBreakdownOneWay: VehicleListingRateBreakdown?
    let rateBreakdownRoundTrip: VehicleListingRateBreakdown?
    let rateBreakdownCharterTour: VehicleListingRateBreakdown?
    
    // Computed properties for pricing based on service type
    var charterTourPrice: Double? {
        return rateBreakdownCharterTour?.grandTotal
    }
    
    var oneWayPrice: Double? {
        return rateBreakdownOneWay?.grandTotal
    }
    
    var roundTripPrice: Double? {
        return rateBreakdownRoundTrip?.grandTotal
    }
    
    // Get price based on service type
    func getPrice(for serviceType: String) -> Double? {
        switch serviceType {
        case "charter_tour":
            return charterTourPrice
        case "one_way":
            return oneWayPrice
        case "round_trip":
            return roundTripPrice
        default:
            return nil
        }
    }
    
    // Equatable conformance - compare by id since it should be unique
    static func == (lhs: VehicleListingItem, rhs: VehicleListingItem) -> Bool {
        return lhs.id == rhs.id
    }
    
    // Hashable conformance - hash by id since it should be unique
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case affiliateId = "affiliate_id"
        case badgeCity = "badge_city"
        case affiliateType = "affiliate_type"
        case affiliateCompany = "affiliate_company"
        case affiliatePhone = "affiliate_phone"
        case affiliateName = "affiliate_name"
        case name
        case vehicleTypeId = "vehicle_type_id"
        case passenger
        case luggage
        case latitude
        case longitude
        case distance
        case createdBy = "created_by"
        case numberOfVehicles = "number_of_vehicles"
        case cancellationPolicy = "cancellation_policy"
        case isMasterVehicle = "is_master_vehicle"
        case driverInformation = "driverInformation"
        case amenities
        case vehicleImages = "vehicle_images"
        case vehicleDetails = "vehicle_details"
        case rateBreakdownOneWay = "rate_breakdown_one_way"
        case rateBreakdownRoundTrip = "rate_breakdown_round_trip"
        case rateBreakdownCharterTour = "rate_breakdown_charter_tour"
    }
    
    // Memberwise initializer
    init(id: Int, affiliateId: Int?, badgeCity: String?, affiliateType: String?, affiliateCompany: String?, affiliatePhone: String?, affiliateName: String?, name: String, vehicleTypeId: Int?, passenger: Int, luggage: Int, latitude: Double?, longitude: Double?, distance: Double?, createdBy: Int?, numberOfVehicles: Int?, cancellationPolicy: Int?, isMasterVehicle: Bool?, driverInformation: DriverInformation?, amenities: [Amenity]?, vehicleImages: [String], vehicleDetails: VehicleDetails?, rateBreakdownOneWay: VehicleListingRateBreakdown?, rateBreakdownRoundTrip: VehicleListingRateBreakdown?, rateBreakdownCharterTour: VehicleListingRateBreakdown?) {
        self.id = id
        self.affiliateId = affiliateId
        self.badgeCity = badgeCity
        self.affiliateType = affiliateType
        self.affiliateCompany = affiliateCompany
        self.affiliatePhone = affiliatePhone
        self.affiliateName = affiliateName
        self.name = name
        self.vehicleTypeId = vehicleTypeId
        self.passenger = passenger
        self.luggage = luggage
        self.latitude = latitude
        self.longitude = longitude
        self.distance = distance
        self.createdBy = createdBy
        self.numberOfVehicles = numberOfVehicles
        self.cancellationPolicy = cancellationPolicy
        self.isMasterVehicle = isMasterVehicle
        self.driverInformation = driverInformation
        self.amenities = amenities
        self.vehicleImages = vehicleImages
        self.vehicleDetails = vehicleDetails
        self.rateBreakdownOneWay = rateBreakdownOneWay
        self.rateBreakdownRoundTrip = rateBreakdownRoundTrip
        self.rateBreakdownCharterTour = rateBreakdownCharterTour
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Required fields
        id = try container.decode(Int.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        passenger = try container.decode(Int.self, forKey: .passenger)
        luggage = try container.decode(Int.self, forKey: .luggage)
        vehicleImages = try container.decode([String].self, forKey: .vehicleImages)
        
        // Optional fields that might not be present
        vehicleTypeId = try container.decodeIfPresent(Int.self, forKey: .vehicleTypeId)
        latitude = try container.decodeIfPresent(Double.self, forKey: .latitude)
        longitude = try container.decodeIfPresent(Double.self, forKey: .longitude)
        distance = try container.decodeIfPresent(Double.self, forKey: .distance)
        createdBy = try container.decodeIfPresent(Int.self, forKey: .createdBy)
        numberOfVehicles = try container.decodeIfPresent(Int.self, forKey: .numberOfVehicles)
        cancellationPolicy = try container.decodeIfPresent(Int.self, forKey: .cancellationPolicy)
        isMasterVehicle = try container.decodeIfPresent(Bool.self, forKey: .isMasterVehicle)
        driverInformation = try container.decodeIfPresent(DriverInformation.self, forKey: .driverInformation)
        amenities = try container.decodeIfPresent([Amenity].self, forKey: .amenities)
        vehicleDetails = try container.decodeIfPresent(VehicleDetails.self, forKey: .vehicleDetails)
        
        // Rate breakdowns - handle different service types
        rateBreakdownOneWay = try container.decodeIfPresent(VehicleListingRateBreakdown.self, forKey: .rateBreakdownOneWay)
        rateBreakdownRoundTrip = try container.decodeIfPresent(VehicleListingRateBreakdown.self, forKey: .rateBreakdownRoundTrip)
        rateBreakdownCharterTour = try container.decodeIfPresent(VehicleListingRateBreakdown.self, forKey: .rateBreakdownCharterTour)
        
        // Handle fields that might have different types or be missing
        badgeCity = try container.decodeIfPresent(String.self, forKey: .badgeCity)
        affiliateType = try container.decodeIfPresent(String.self, forKey: .affiliateType)
        affiliateCompany = try container.decodeIfPresent(String.self, forKey: .affiliateCompany)
        affiliatePhone = try container.decodeIfPresent(String.self, forKey: .affiliatePhone)
        affiliateName = try container.decodeIfPresent(String.self, forKey: .affiliateName)
        
        // Handle affiliateId which might be Int or String in the API
        if let affiliateIdInt = try? container.decode(Int.self, forKey: .affiliateId) {
            affiliateId = affiliateIdInt
        } else if let affiliateIdString = try? container.decode(String.self, forKey: .affiliateId) {
            // Convert string to int if possible
            affiliateId = Int(affiliateIdString)
        } else {
            affiliateId = nil
        }
    }
}

struct DriverInformation: Codable, Hashable {
    let insuranceLimit: String
    let id: Int? // Changed to Int to match API response
    let name: String
    let gender: String
    let email: String?
    let phone: String
    let cellIsd: String
    let cellNumber: String
    let starRating: String
    let background: String
    let dress: String
    let languages: String
    let experience: String
    let imageUrl: String
    
    enum CodingKeys: String, CodingKey {
        case insuranceLimit = "insurance_limit"
        case id
        case name
        case gender
        case email
        case phone
        case cellIsd = "cell_isd"
        case cellNumber = "cell_number"
        case starRating
        case background
        case dress
        case languages
        case experience
        case imageUrl
    }
    
    // Memberwise initializer
    init(insuranceLimit: String, id: Int?, name: String, gender: String, email: String?, phone: String, cellIsd: String, cellNumber: String, starRating: String, background: String, dress: String, languages: String, experience: String, imageUrl: String) {
        self.insuranceLimit = insuranceLimit
        self.id = id
        self.name = name
        self.gender = gender
        self.email = email
        self.phone = phone
        self.cellIsd = cellIsd
        self.cellNumber = cellNumber
        self.starRating = starRating
        self.background = background
        self.dress = dress
        self.languages = languages
        self.experience = experience
        self.imageUrl = imageUrl
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Handle fields that might have type mismatches
        insuranceLimit = try container.decode(String.self, forKey: .insuranceLimit)
        name = try container.decode(String.self, forKey: .name)
        gender = try container.decode(String.self, forKey: .gender)
        email = try container.decodeIfPresent(String.self, forKey: .email)
        phone = try container.decode(String.self, forKey: .phone)
        cellIsd = try container.decode(String.self, forKey: .cellIsd)
        cellNumber = try container.decode(String.self, forKey: .cellNumber)
        starRating = try container.decode(String.self, forKey: .starRating)
        background = try container.decode(String.self, forKey: .background)
        dress = try container.decode(String.self, forKey: .dress)
        languages = try container.decode(String.self, forKey: .languages)
        experience = try container.decode(String.self, forKey: .experience)
        imageUrl = try container.decode(String.self, forKey: .imageUrl)
        
        // Handle id which might be Int or String
        if let idInt = try? container.decode(Int.self, forKey: .id) {
            id = idInt
        } else if let idString = try? container.decode(String.self, forKey: .id) {
            id = Int(idString)
        } else {
            id = nil
        }
    }
}

struct Amenity: Codable, Hashable {
    let id: Int
    let name: String
    let chargeable: String
}

struct VehicleDetails: Codable, Hashable {
    let make: String
    let model: String
    let year: String
}

struct VehicleListingRateBreakdown: Codable, Hashable {
    let rateArray: VehicleListingRateArray
    let subTotal: Double
    let grandTotal: Double
    let total: Double
    
    enum CodingKeys: String, CodingKey {
        case rateArray = "rateArray"
        case subTotal = "sub_total"
        case grandTotal = "grand_total"
        case total
    }
}

struct VehicleListingRateArray: Codable, Hashable {
    let allInclusiveRates: VehicleListingAllInclusiveRates
    
    enum CodingKeys: String, CodingKey {
        case allInclusiveRates = "all_inclusive_rates"
    }
}

struct VehicleListingAllInclusiveRates: Codable, Hashable {
    let tripRate: RateComponent
    let gratuity: RateComponent
    let tripTax: RateComponent
    
    enum CodingKeys: String, CodingKey {
        case tripRate = "trip_rate"
        case gratuity
        case tripTax = "trip_tax"
    }
}

struct RateComponent: Codable, Hashable {
    let rateLabel: String
    let baserate: Double
    let multiple: String?
    let percentage: String?
    let amount: Double
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        rateLabel = try container.decode(String.self, forKey: .rateLabel)
        baserate = try container.decode(Double.self, forKey: .baserate)
        amount = try container.decode(Double.self, forKey: .amount)
        
        // Handle nullable fields that might be null in JSON
        multiple = try container.decodeIfPresent(String.self, forKey: .multiple)
        percentage = try container.decodeIfPresent(String.self, forKey: .percentage)
    }
    
    enum CodingKeys: String, CodingKey {
        case rateLabel = "rate_label"
        case baserate
        case multiple
        case percentage
        case amount
    }
}

struct VehicleListingCurrency: Codable {
    let countryName: String?
    let currency: String
    let currencyCountry: String
    let symbol: String
    let dateFormat: String? // Made optional since API doesn't always provide this
    
    enum CodingKeys: String, CodingKey {
        case countryName
        case currency
        case currencyCountry
        case symbol
        case dateFormat
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Handle required fields
        currency = try container.decode(String.self, forKey: .currency)
        currencyCountry = try container.decode(String.self, forKey: .currencyCountry)
        symbol = try container.decode(String.self, forKey: .symbol)
        
        // Handle optional fields that might not be present in API response
        countryName = try container.decodeIfPresent(String.self, forKey: .countryName)
        dateFormat = try container.decodeIfPresent(String.self, forKey: .dateFormat)
    }
}
