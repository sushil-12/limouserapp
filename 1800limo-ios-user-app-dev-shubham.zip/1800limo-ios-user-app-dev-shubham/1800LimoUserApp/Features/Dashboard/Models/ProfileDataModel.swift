import Foundation

// MARK: - Profile Data Response
struct ProfileDataResponse: Codable {
    let success: Bool
    let data: ProfileData
    let message: String
    let currency: CurrencyInfo
}

// MARK: - Profile Data
struct ProfileData: Codable {
    let id: Int
    let user_id: Int
    let title: String?
    let first_name: String
    let last_name: String
    let middle_name: String?
    let mobileIsd: String
    let mobile: String
    let mobileCountry: String
    let gender: String?
    let dob: String?
    let workIsd: String?
    let work_contact_number: String?
    let workCountry: String?
    let homeIsd: String?
    let home_phone: String?
    let officeIsd: String?
    let office_number: String?
    let officeCountry: String?
    let homeCountry: String?
    let email: String
    let email_verificaiton_opt: String?
    let phone_otp: String?
    let email_verificaiton_hash: String?
    let updating_email_id: String?
    let is_email_verified: String
    let address: String?
    let street: String?
    let unit: String?
    let city: String
    let state: String
    let country: String
    let zip: String
    let latitude: String?
    let longitude: String?
    let stripe_customer_id: String
    let travel_agency_account_id: String?
    let profile_pic: String?
    let status: String
    let enable_notification: String
    let accepted_auto_deduct: String
    let is_upgraded: Int
    let is_converted: Int
    let convert_currency: Int
    let created_by: Int
    let created_at: String
    let updated_at: String
    let soft_delete: String?
    let role: Int
    let is_profile_complete: Int?
    let sms_optin: Int
    let cards: [CardData]

    enum CodingKeys: String, CodingKey {
        case id
        case user_id
        case title
        case first_name
        case last_name
        case middle_name
        case mobileIsd
        case mobile
        case mobileCountry
        case gender
        case dob
        case workIsd
        case work_contact_number
        case workCountry
        case homeIsd
        case home_phone
        case officeIsd
        case office_number
        case officeCountry
        case homeCountry
        case email
        case email_verificaiton_opt
        case phone_otp
        case email_verificaiton_hash
        case updating_email_id
        case is_email_verified
        case address
        case street
        case unit
        case city
        case state
        case country
        case zip
        case latitude
        case longitude
        case stripe_customer_id
        case travel_agency_account_id
        case profile_pic
        case status
        case enable_notification
        case accepted_auto_deduct
        case is_upgraded
        case is_converted
        case convert_currency
        case created_by
        case created_at
        case updated_at
        case soft_delete
        case role
        case is_profile_complete
        case sms_optin
        case cards
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(Int.self, forKey: .id)
        user_id = try container.decode(Int.self, forKey: .user_id)
        title = try container.decodeIfPresent(String.self, forKey: .title)
        first_name = try container.decode(String.self, forKey: .first_name)
        last_name = try container.decode(String.self, forKey: .last_name)
        middle_name = try container.decodeIfPresent(String.self, forKey: .middle_name)
        mobileIsd = try container.decode(String.self, forKey: .mobileIsd)
        mobile = try container.decode(String.self, forKey: .mobile)
        mobileCountry = try container.decode(String.self, forKey: .mobileCountry)
        gender = try container.decodeIfPresent(String.self, forKey: .gender)
        dob = try container.decodeIfPresent(String.self, forKey: .dob)
        workIsd = try container.decodeIfPresent(String.self, forKey: .workIsd)
        work_contact_number = try container.decodeIfPresent(String.self, forKey: .work_contact_number)
        workCountry = try container.decodeIfPresent(String.self, forKey: .workCountry)
        homeIsd = try container.decodeIfPresent(String.self, forKey: .homeIsd)
        home_phone = try container.decodeIfPresent(String.self, forKey: .home_phone)
        officeIsd = try container.decodeIfPresent(String.self, forKey: .officeIsd)
        office_number = try container.decodeIfPresent(String.self, forKey: .office_number)
        officeCountry = try container.decodeIfPresent(String.self, forKey: .officeCountry)
        homeCountry = try container.decodeIfPresent(String.self, forKey: .homeCountry)
        email = try container.decode(String.self, forKey: .email)
        email_verificaiton_opt = try container.decodeIfPresent(String.self, forKey: .email_verificaiton_opt)
        phone_otp = try container.decodeIfPresent(String.self, forKey: .phone_otp)
        email_verificaiton_hash = try container.decodeIfPresent(String.self, forKey: .email_verificaiton_hash)
        updating_email_id = try container.decodeIfPresent(String.self, forKey: .updating_email_id)
        is_email_verified = try container.decode(String.self, forKey: .is_email_verified)
        address = try container.decodeIfPresent(String.self, forKey: .address)
        street = try container.decodeIfPresent(String.self, forKey: .street)
        unit = try container.decodeIfPresent(String.self, forKey: .unit)
        city = try container.decode(String.self, forKey: .city)
        state = try container.decode(String.self, forKey: .state)
        country = try container.decode(String.self, forKey: .country)
        zip = try container.decode(String.self, forKey: .zip)
        latitude = try container.decodeIfPresent(String.self, forKey: .latitude)
        longitude = try container.decodeIfPresent(String.self, forKey: .longitude)
        stripe_customer_id = try container.decode(String.self, forKey: .stripe_customer_id)
        travel_agency_account_id = try container.decodeIfPresent(String.self, forKey: .travel_agency_account_id)
        profile_pic = try container.decodeIfPresent(String.self, forKey: .profile_pic)
        status = try container.decode(String.self, forKey: .status)
        enable_notification = try container.decode(String.self, forKey: .enable_notification)
        accepted_auto_deduct = try container.decode(String.self, forKey: .accepted_auto_deduct)
        is_upgraded = try container.decode(Int.self, forKey: .is_upgraded)
        is_converted = try container.decode(Int.self, forKey: .is_converted)
        convert_currency = try container.decode(Int.self, forKey: .convert_currency)
        created_by = try container.decode(Int.self, forKey: .created_by)
        created_at = try container.decode(String.self, forKey: .created_at)
        updated_at = try container.decode(String.self, forKey: .updated_at)
        soft_delete = try container.decodeIfPresent(String.self, forKey: .soft_delete)
        role = try container.decode(Int.self, forKey: .role)
        is_profile_complete = try container.decodeIfPresent(Int.self, forKey: .is_profile_complete)
        sms_optin = try container.decode(Int.self, forKey: .sms_optin)
        // Default to empty array if the key is missing
        cards = (try? container.decode([CardData].self, forKey: .cards)) ?? []
    }

    // Convenience initializer to support existing construction sites
    init(
        id: Int,
        user_id: Int,
        title: String?,
        first_name: String,
        last_name: String,
        middle_name: String?,
        mobileIsd: String,
        mobile: String,
        mobileCountry: String,
        gender: String?,
        dob: String?,
        workIsd: String?,
        work_contact_number: String?,
        workCountry: String?,
        homeIsd: String?,
        home_phone: String?,
        officeIsd: String?,
        office_number: String?,
        officeCountry: String?,
        homeCountry: String?,
        email: String,
        email_verificaiton_opt: String?,
        phone_otp: String?,
        email_verificaiton_hash: String?,
        updating_email_id: String?,
        is_email_verified: String,
        address: String?,
        street: String?,
        unit: String?,
        city: String,
        state: String,
        country: String,
        zip: String,
        latitude: String?,
        longitude: String?,
        stripe_customer_id: String,
        travel_agency_account_id: String?,
        profile_pic: String?,
        status: String,
        enable_notification: String,
        accepted_auto_deduct: String,
        is_upgraded: Int,
        is_converted: Int,
        convert_currency: Int,
        created_by: Int,
        created_at: String,
        updated_at: String,
        soft_delete: String?,
        role: Int,
        is_profile_complete: Int?,
        sms_optin: Int,
        cards: [CardData]
    ) {
        self.id = id
        self.user_id = user_id
        self.title = title
        self.first_name = first_name
        self.last_name = last_name
        self.middle_name = middle_name
        self.mobileIsd = mobileIsd
        self.mobile = mobile
        self.mobileCountry = mobileCountry
        self.gender = gender
        self.dob = dob
        self.workIsd = workIsd
        self.work_contact_number = work_contact_number
        self.workCountry = workCountry
        self.homeIsd = homeIsd
        self.home_phone = home_phone
        self.officeIsd = officeIsd
        self.office_number = office_number
        self.officeCountry = officeCountry
        self.homeCountry = homeCountry
        self.email = email
        self.email_verificaiton_opt = email_verificaiton_opt
        self.phone_otp = phone_otp
        self.email_verificaiton_hash = email_verificaiton_hash
        self.updating_email_id = updating_email_id
        self.is_email_verified = is_email_verified
        self.address = address
        self.street = street
        self.unit = unit
        self.city = city
        self.state = state
        self.country = country
        self.zip = zip
        self.latitude = latitude
        self.longitude = longitude
        self.stripe_customer_id = stripe_customer_id
        self.travel_agency_account_id = travel_agency_account_id
        self.profile_pic = profile_pic
        self.status = status
        self.enable_notification = enable_notification
        self.accepted_auto_deduct = accepted_auto_deduct
        self.is_upgraded = is_upgraded
        self.is_converted = is_converted
        self.convert_currency = convert_currency
        self.created_by = created_by
        self.created_at = created_at
        self.updated_at = updated_at
        self.soft_delete = soft_delete
        self.role = role
        self.is_profile_complete = is_profile_complete
        self.sms_optin = sms_optin
        self.cards = cards
    }
}

// MARK: - Card Data
struct CardData: Codable {
    let id: String
    let ID: String
    let name: String
    let brand: String
    let exp_month: Int
    let exp_year: Int
    let last4: String
    let card_type: String
    let cc_prority: String?
}

// MARK: - Profile Card Data (Different structure from profile API)
struct ProfileCardData: Codable {
    let id: String
    let object: String
    let address_city: String?
    let address_country: String?
    let address_line1: String?
    let address_line1_check: String?
    let address_line2: String?
    let address_state: String?
    let address_zip: String?
    let address_zip_check: String?
    let allow_redisplay: String
    let brand: String
    let country: String
    let customer: String
    let cvc_check: String
    let dynamic_last4: String?
    let exp_month: Int
    let exp_year: Int
    let fingerprint: String
    let funding: String
    let last4: String
    let metadata: CardMetadata
    let name: String
    let regulated_status: String
    let tokenization_method: String?
    let wallet: String?
}


// MARK: - Add Credit Card Request
struct AddCreditCardRequest: Codable {
    let card_type: String
    let number: String
    let cvc: String
    let exp_month: String
    let exp_year: String
    let name: String
}

// MARK: - Add Credit Card Response
struct AddCreditCardResponse: Codable {
    let success: Bool
    let data: AddCreditCardData
    let message: String
    let currency: CurrencyInfo
}

struct AddCreditCardData: Codable {
    let id: String
}

// MARK: - Profile API Response (Different from get-profile-data)
struct ProfileAPIResponse: Codable {
    let success: Bool
    let message: String
    let data: ProfileAPIData
    let timestamp: String
    let code: Int
}

struct ProfileAPIData: Codable {
    let id: Int
    let user_id: Int
    let title: String?
    let first_name: String
    let last_name: String
    let middle_name: String?
    let mobileIsd: String
    let mobile: String
    let mobileCountry: String
    let gender: String?
    let dob: String?
    let workIsd: String?
    let work_contact_number: String?
    let workCountry: String?
    let homeIsd: String?
    let home_phone: String?
    let officeIsd: String?
    let office_number: String?
    let officeCountry: String?
    let homeCountry: String?
    let email: String
    let email_verificaiton_opt: String?
    let phone_otp: String?
    let email_verificaiton_hash: String?
    let updating_email_id: String?
    let is_email_verified: String
    let address: String?
    let street: String?
    let unit: String?
    let city: String
    let state: String
    let country: String
    let zip: String
    let latitude: String?
    let longitude: String?
    let stripe_customer_id: String
    let travel_agency_account_id: String?
    let profile_pic: String?
    let status: String
    let enable_notification: String
    let accepted_auto_deduct: String
    let is_upgraded: Int
    let is_converted: Int
    let convert_currency: Int
    let created_by: Int
    let created_at: String
    let updated_at: String
    let soft_delete: String?
    let role: Int
    let is_profile_complete: Int?
    let sms_optin: Int
    let cards: [ProfileCardData]
}

// MARK: - Update Profile
struct UpdateProfileRequest: Codable {
    let firstName: String
    let lastName: String
    let email: String
    let gender: String
    let dateOfBirth: String
    let address: String
    let city: String
    let state: String
    let country: String
    let zip: String
    let latitude: Double
    let longitude: Double
    
    enum CodingKeys: String, CodingKey {
        case firstName = "first_name"
        case lastName = "last_name"
        case email
        case gender
        case dateOfBirth = "date_of_birth"
        case address
        case city
        case state
        case country
        case zip
        case latitude
        case longitude
    }
}

struct UpdateProfileResponse: Codable {
    let success: Bool
    let message: String
    let data: UpdateProfileData
    let timestamp: String
    let code: Int
}

struct UpdateProfileData: Codable {
    let user: UpdateProfileUser
}

struct UpdateProfileUser: Codable {
    let id: Int
    let firstName: String
    let lastName: String
    let email: String
    let phone: String?
    let profileImage: String?
    let gender: String?
    let dob: String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case firstName = "first_name"
        case lastName = "last_name"
        case email
        case phone
        case profileImage = "profile_image"
        case gender
        case dob
    }
}

