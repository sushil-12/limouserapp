//
//  UserProfileModels.swift
//  1800LimoUserApp
//
//  Created by AI Assistant
//

import Foundation

// MARK: - User Profile Response Models

struct UserProfileResponse: Codable {
    let success: Bool
    let message: String
    let data: UserProfileData
    let timestamp: String
    let code: Int
}

struct UserProfileData: Codable {
    let id: Int
    let userId: Int
    let title: String?
    let firstName: String
    let lastName: String
    let middleName: String?
    let mobileIsd: String
    let mobile: String
    let mobileCountry: String
    let gender: String?
    let workIsd: String?
    let workContactNumber: String?
    let workCountry: String?
    let homeIsd: String?
    let homePhone: String?
    let officeIsd: String?
    let officeNumber: String?
    let officeCountry: String?
    let homeCountry: String?
    let email: String
    let emailVerificationOpt: String?
    let phoneOtp: String?
    let emailVerificationHash: String?
    let updatingEmailId: String?
    let isEmailVerified: String
    let address: String?
    let street: String?
    let unit: String?
    let city: String
    let state: String
    let country: String
    let zip: String
    let latitude: Double?
    let longitude: Double?
    let stripeCustomerId: String
    let travelAgencyAccountId: String?
    let profilePic: String?
    let status: String
    let enableNotification: String
    let acceptedAutoDeduct: String
    let isUpgraded: Int
    let isConverted: Int
    let convertCurrency: Int
    let createdBy: Int
    let createdAt: String
    let updatedAt: String
    let softDelete: String?
    let role: Int
    let isProfileComplete: Int?
    let smsOptin: Int
    let cards: [UserCard]
    
    // Custom decoder to handle latitude/longitude as strings
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decode(Int.self, forKey: .id)
        userId = try container.decode(Int.self, forKey: .userId)
        title = try container.decodeIfPresent(String.self, forKey: .title)
        firstName = try container.decode(String.self, forKey: .firstName)
        lastName = try container.decode(String.self, forKey: .lastName)
        middleName = try container.decodeIfPresent(String.self, forKey: .middleName)
        mobileIsd = try container.decode(String.self, forKey: .mobileIsd)
        mobile = try container.decode(String.self, forKey: .mobile)
        mobileCountry = try container.decode(String.self, forKey: .mobileCountry)
        gender = try container.decodeIfPresent(String.self, forKey: .gender)
        workIsd = try container.decodeIfPresent(String.self, forKey: .workIsd)
        workContactNumber = try container.decodeIfPresent(String.self, forKey: .workContactNumber)
        workCountry = try container.decodeIfPresent(String.self, forKey: .workCountry)
        homeIsd = try container.decodeIfPresent(String.self, forKey: .homeIsd)
        homePhone = try container.decodeIfPresent(String.self, forKey: .homePhone)
        officeIsd = try container.decodeIfPresent(String.self, forKey: .officeIsd)
        officeNumber = try container.decodeIfPresent(String.self, forKey: .officeNumber)
        officeCountry = try container.decodeIfPresent(String.self, forKey: .officeCountry)
        homeCountry = try container.decodeIfPresent(String.self, forKey: .homeCountry)
        email = try container.decode(String.self, forKey: .email)
        emailVerificationOpt = try container.decodeIfPresent(String.self, forKey: .emailVerificationOpt)
        phoneOtp = try container.decodeIfPresent(String.self, forKey: .phoneOtp)
        emailVerificationHash = try container.decodeIfPresent(String.self, forKey: .emailVerificationHash)
        updatingEmailId = try container.decodeIfPresent(String.self, forKey: .updatingEmailId)
        isEmailVerified = try container.decode(String.self, forKey: .isEmailVerified)
        address = try container.decodeIfPresent(String.self, forKey: .address)
        street = try container.decodeIfPresent(String.self, forKey: .street)
        unit = try container.decodeIfPresent(String.self, forKey: .unit)
        city = try container.decode(String.self, forKey: .city)
        state = try container.decode(String.self, forKey: .state)
        country = try container.decode(String.self, forKey: .country)
        zip = try container.decode(String.self, forKey: .zip)
        
        // Handle latitude as either String or Double
        if let latString = try? container.decodeIfPresent(String.self, forKey: .latitude) {
            latitude = Double(latString)
        } else {
            latitude = try container.decodeIfPresent(Double.self, forKey: .latitude)
        }
        
        // Handle longitude as either String or Double
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .longitude) {
            longitude = Double(lngString)
        } else {
            longitude = try container.decodeIfPresent(Double.self, forKey: .longitude)
        }
        
        stripeCustomerId = try container.decode(String.self, forKey: .stripeCustomerId)
        travelAgencyAccountId = try container.decodeIfPresent(String.self, forKey: .travelAgencyAccountId)
        profilePic = try container.decodeIfPresent(String.self, forKey: .profilePic)
        status = try container.decode(String.self, forKey: .status)
        enableNotification = try container.decode(String.self, forKey: .enableNotification)
        acceptedAutoDeduct = try container.decode(String.self, forKey: .acceptedAutoDeduct)
        isUpgraded = try container.decode(Int.self, forKey: .isUpgraded)
        isConverted = try container.decode(Int.self, forKey: .isConverted)
        convertCurrency = try container.decode(Int.self, forKey: .convertCurrency)
        createdBy = try container.decode(Int.self, forKey: .createdBy)
        createdAt = try container.decode(String.self, forKey: .createdAt)
        updatedAt = try container.decode(String.self, forKey: .updatedAt)
        softDelete = try container.decodeIfPresent(String.self, forKey: .softDelete)
        role = try container.decode(Int.self, forKey: .role)
        isProfileComplete = try container.decodeIfPresent(Int.self, forKey: .isProfileComplete)
        smsOptin = try container.decode(Int.self, forKey: .smsOptin)
        cards = (try? container.decode([UserCard].self, forKey: .cards)) ?? []
    }
    
    enum CodingKeys: String, CodingKey {
        case id
        case userId = "user_id"
        case title
        case firstName = "first_name"
        case lastName = "last_name"
        case middleName = "middle_name"
        case mobileIsd = "mobileIsd"
        case mobile
        case mobileCountry = "mobileCountry"
        case gender
        case workIsd = "workIsd"
        case workContactNumber = "work_contact_number"
        case workCountry = "workCountry"
        case homeIsd = "homeIsd"
        case homePhone = "home_phone"
        case officeIsd = "officeIsd"
        case officeNumber = "office_number"
        case officeCountry = "officeCountry"
        case homeCountry = "homeCountry"
        case email
        case emailVerificationOpt = "email_verificaiton_opt"
        case phoneOtp = "phone_otp"
        case emailVerificationHash = "email_verificaiton_hash"
        case updatingEmailId = "updating_email_id"
        case isEmailVerified = "is_email_verified"
        case address
        case street
        case unit
        case city
        case state
        case country
        case zip
        case latitude
        case longitude
        case stripeCustomerId = "stripe_customer_id"
        case travelAgencyAccountId = "travel_agency_account_id"
        case profilePic = "profile_pic"
        case status
        case enableNotification = "enable_notification"
        case acceptedAutoDeduct = "accepted_auto_deduct"
        case isUpgraded = "is_upgraded"
        case isConverted = "is_converted"
        case convertCurrency = "convert_currency"
        case createdBy = "created_by"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case softDelete = "soft_delete"
        case role
        case isProfileComplete = "is_profile_complete"
        case smsOptin = "sms_optin"
        case cards
    }
}

struct UserCard: Codable {
    let id: String
    let object: String
    let addressCity: String?
    let addressCountry: String?
    let addressLine1: String?
    let addressLine1Check: String?
    let addressLine2: String?
    let addressState: String?
    let addressZip: String?
    let addressZipCheck: String?
    let allowRedisplay: String
    let brand: String
    let country: String
    let customer: String
    let cvcCheck: String
    let dynamicLast4: String?
    let expMonth: Int
    let expYear: Int
    let fingerprint: String
    let funding: String
    let last4: String
    let metadata: CardMetadata
    let name: String
    let regulatedStatus: String
    let tokenizationMethod: String?
    let wallet: String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case object
        case addressCity = "address_city"
        case addressCountry = "address_country"
        case addressLine1 = "address_line1"
        case addressLine1Check = "address_line1_check"
        case addressLine2 = "address_line2"
        case addressState = "address_state"
        case addressZip = "address_zip"
        case addressZipCheck = "address_zip_check"
        case allowRedisplay = "allow_redisplay"
        case brand
        case country
        case customer
        case cvcCheck = "cvc_check"
        case dynamicLast4 = "dynamic_last4"
        case expMonth = "exp_month"
        case expYear = "exp_year"
        case fingerprint
        case funding
        case last4
        case metadata
        case name
        case regulatedStatus = "regulated_status"
        case tokenizationMethod = "tokenization_method"
        case wallet
    }
}

struct CardMetadata: Codable {
    let cardType: String
    let ccPriority: String?
    
    enum CodingKeys: String, CodingKey {
        case cardType = "card_type"
        case ccPriority = "cc_prority"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        cardType = try container.decode(String.self, forKey: .cardType)
        ccPriority = try container.decodeIfPresent(String.self, forKey: .ccPriority)
    }
    
    init(cardType: String, ccPriority: String?) {
        self.cardType = cardType
        self.ccPriority = ccPriority
    }
}

// MARK: - User Profile Service

class UserProfileService: ObservableObject {
    @Published var isLoading = false
    @Published var userProfile: UserProfileData?
    @Published var errorMessage: String?
    
    func fetchUserProfile() async -> (success: Bool, data: UserProfileData?, error: String?) {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        print("🚀 UserProfileService - Fetching user profile...")
        
        do {
            let response: UserProfileResponse = try await NetworkService.shared.request(
                endpoint: .userProfile,
                responseType: UserProfileResponse.self
            )
            
            await MainActor.run {
                self.userProfile = response.data
                self.isLoading = false
            
            }
            
            return (success: true, data: response.data, error: nil)
        } catch {
            let errorMessage = error.localizedDescription
            await MainActor.run {
                self.errorMessage = errorMessage
                self.isLoading = false
            }
            return (success: false, data: nil, error: errorMessage)
        }
    }
}

// MARK: - User Profile Extensions

extension UserProfileData {
    var fullName: String {
        let firstName = self.firstName
        let lastName = self.lastName
        let middleName = self.middleName ?? ""
        
        if middleName.isEmpty {
            return "\(firstName) \(lastName)"
        } else {
            return "\(firstName) \(middleName) \(lastName)"
        }
    }
    
    var fullMobileNumber: String {
        return "\(mobileIsd) \(mobile)"
    }
    
    var fullAddress: String {
        var addressComponents: [String] = []
        
        if let address = address, !address.isEmpty {
            addressComponents.append(address)
        }
        
        if let street = street, !street.isEmpty {
            addressComponents.append(street)
        }
        
        if let unit = unit, !unit.isEmpty {
            addressComponents.append(unit)
        }
        
        if !city.isEmpty {
            addressComponents.append(city)
        }
        
        if !state.isEmpty {
            addressComponents.append(state)
        }
        
        if !country.isEmpty {
            addressComponents.append(country)
        }
        
        if !zip.isEmpty {
            addressComponents.append(zip)
        }
        
        return addressComponents.joined(separator: ", ")
    }
    
    var primaryCard: UserCard? {
        return cards.first { card in
            card.metadata.ccPriority?.lowercased() == "primary"
        } ?? cards.first
    }
}

