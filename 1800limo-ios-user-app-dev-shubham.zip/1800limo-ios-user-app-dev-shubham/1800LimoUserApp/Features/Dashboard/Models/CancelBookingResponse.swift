//
//  CancelBookingResponse.swift
//  1800LimoUserApp
//
//  Created by ChatGPT on 10/11/25.
//

import Foundation

struct CancelBookingResponse: Codable {
    let success: Bool
    let data: [String]?
    let message: String
    let currency: CurrencyInfo?
}


