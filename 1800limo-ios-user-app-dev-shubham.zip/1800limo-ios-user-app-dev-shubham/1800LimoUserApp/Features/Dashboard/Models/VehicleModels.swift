import Foundation

// MARK: - Vehicle Quote Request
struct VehicleQuoteRequest: Codable {
    let serviceType: String
    let bookingHour: Int
    let pickupType: String
    let dropoffType: String
    let pickupDate: String
    let pickupTime: String
    let pickupAirport: Int?
    let pickupAirportName: String?
    let pickupAirportLat: Double?
    let pickupAirportLong: Double?
    let pickupAddress: String?
    let pickupAddressLat: Double?
    let pickupAddressLong: Double?
    let dropoffAirport: Int?
    let dropoffAirportName: String?
    let dropoffAirportLat: Double?
    let dropoffAirportLong: Double?
    let dropoffAddress: String?
    let dropoffAddressLat: Double?
    let dropoffAddressLong: Double?
    let returnPickupDate: String?
    let returnPickupTime: String?
    let returnPickupAirport: Int?
    let returnPickupAirportName: String?
    let returnPickupAirportLat: Double?
    let returnPickupAirportLong: Double?
    let returnPickupAddress: String?
    let returnPickupAddressLat: Double?
    let returnPickupAddressLong: Double?
    let returnDropoffAirport: Int?
    let returnDropoffAirportName: String?
    let returnDropoffAirportLat: Double?
    let returnDropoffAirportLong: Double?
    let returnDropoffAddress: String?
    let returnDropoffAddressLat: Double?
    let returnDropoffAddressLong: Double?
    let noOfPassenger: Int
    let noOfLuggage: Int
    let locationInfo: [LocationInfo]
    let otherDetails: OtherDetails?
    let filters: Filters?
    let userId: Int?
    
    enum CodingKeys: String, CodingKey {
        case serviceType = "service_type"
        case bookingHour = "booking_hour"
        case pickupType = "pickup_type"
        case dropoffType = "dropoff_type"
        case pickupDate = "pickup_date"
        case pickupTime = "pickup_time"
        case pickupAirport = "pickup_airport"
        case pickupAirportName = "pickup_airport_name"
        case pickupAirportLat = "pickup_airport_lat"
        case pickupAirportLong = "pickup_airport_long"
        case pickupAddress = "pickup_address"
        case pickupAddressLat = "pickup_address_lat"
        case pickupAddressLong = "pickup_address_long"
        case dropoffAirport = "dropoff_airport"
        case dropoffAirportName = "dropoff_airport_name"
        case dropoffAirportLat = "dropoff_airport_lat"
        case dropoffAirportLong = "dropoff_airport_long"
        case dropoffAddress = "dropoff_address"
        case dropoffAddressLat = "dropoff_address_lat"
        case dropoffAddressLong = "dropoff_address_long"
        case returnPickupDate = "return_pickup_date"
        case returnPickupTime = "return_pickup_time"
        case returnPickupAirport = "return_pickup_airport"
        case returnPickupAirportName = "return_pickup_airport_name"
        case returnPickupAirportLat = "return_pickup_airport_lat"
        case returnPickupAirportLong = "return_pickup_airport_long"
        case returnPickupAddress = "return_pickup_address"
        case returnPickupAddressLat = "return_pickup_address_lat"
        case returnPickupAddressLong = "return_pickup_address_long"
        case returnDropoffAirport = "return_dropoff_airport"
        case returnDropoffAirportName = "return_dropoff_airport_name"
        case returnDropoffAirportLat = "return_dropoff_airport_lat"
        case returnDropoffAirportLong = "return_dropoff_airport_long"
        case returnDropoffAddress = "return_dropoff_address"
        case returnDropoffAddressLat = "return_dropoff_address_lat"
        case returnDropoffAddressLong = "return_dropoff_address_long"
        case noOfPassenger = "no_of_passenger"
        case noOfLuggage = "no_of_luggage"
        case locationInfo = "location_info"
        case otherDetails = "other_details"
        case filters = "filters"
        case userId = "user_id"
    }
}

struct LocationInfo: Codable {
    let distance: Distance
    let duration: Duration
}

struct Distance: Codable {
    let text: String
    let value: Int
}

struct Duration: Codable {
    let text: String
    let value: Int
}

struct OtherDetails: Codable {
    let pickupAirportName: String?
    let dropoffAirportName: String?
    let returnPickupAirportName: String?
    let returnDropoffAirportName: String?
    
    enum CodingKeys: String, CodingKey {
        case pickupAirportName = "pickup_airport_name"
        case dropoffAirportName = "dropoff_airport_name"
        case returnPickupAirportName = "return_pickup_airport_name"
        case returnDropoffAirportName = "return_dropoff_airport_name"
    }
}

// MARK: - Vehicle Quote Response
struct VehicleQuoteResponse: Codable {
    let success: Bool
    let data: VehicleQuoteData
    let message: String
}

struct VehicleQuoteData: Codable {
    let vehicles: [Vehicle]
    let quote: QuoteInfo
}

// Alternative response model for different API structure
struct VehicleQuoteResponseAlt: Codable {
    let success: Bool
    let data: [Vehicle] // Direct array of vehicles
    let message: String
}

// Generic response model to handle different structures
struct GenericVehicleResponse: Codable {
    let success: Bool
    let message: String
    let data: AnyCodable // Flexible data structure
}

// MARK: - Actual API Response Model (Based on real API response)
struct VehicleQuoteResponseActual: Codable {
    let success: Bool
    let data: [VehicleActual]
    let message: String
    let currency: CurrencyInfo?
}

struct CurrencyInfo: Codable {
    let countryName: String?
    let currency: String
    let currencyCountry: String
    let symbol: String
    let dateFormat: String? // Made optional since API doesn't always provide this
    
    enum CodingKeys: String, CodingKey {
        case countryName
        case currency
        case currencyCountry
        case symbol
        case dateFormat
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Handle required fields
        currency = try container.decode(String.self, forKey: .currency)
        currencyCountry = try container.decode(String.self, forKey: .currencyCountry)
        symbol = try container.decode(String.self, forKey: .symbol)
        
        // Handle optional fields that might not be present in API response
        countryName = try container.decodeIfPresent(String.self, forKey: .countryName)
        dateFormat = try container.decodeIfPresent(String.self, forKey: .dateFormat)
    }
}

struct VehicleActual: Codable {
    let id: Int
    let vehicle_id: Int
    let name: String
    let passenger: Int
    let luggage: Int
    let cat_img: String?
    let rate_breakdown_charter_tour: RateBreakdown?
    let rate_breakdown_one_way: RateBreakdown?
    let rate_breakdown_round_trip: RateBreakdown?
    
    enum CodingKeys: String, CodingKey {
        case id
        case vehicle_id
        case name
        case passenger
        case luggage
        case cat_img
        case rate_breakdown_charter_tour
        case rate_breakdown_one_way
        case rate_breakdown_round_trip
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Handle required fields with type safety
        id = try container.decode(Int.self, forKey: .id)
        vehicle_id = try container.decode(Int.self, forKey: .vehicle_id)
        name = try container.decode(String.self, forKey: .name)
        passenger = try container.decode(Int.self, forKey: .passenger)
        luggage = try container.decode(Int.self, forKey: .luggage)
        
        // Handle optional fields
        cat_img = try container.decodeIfPresent(String.self, forKey: .cat_img)
        rate_breakdown_charter_tour = try container.decodeIfPresent(RateBreakdown.self, forKey: .rate_breakdown_charter_tour)
        rate_breakdown_one_way = try container.decodeIfPresent(RateBreakdown.self, forKey: .rate_breakdown_one_way)
        rate_breakdown_round_trip = try container.decodeIfPresent(RateBreakdown.self, forKey: .rate_breakdown_round_trip)
    }
}

struct RateBreakdown: Codable {
    let rateArray: RateArray?
    let sub_total: Double?
    let grand_total: Double?
    let total: Double?
    
    enum CodingKeys: String, CodingKey {
        case rateArray = "rateArray"
        case sub_total
        case grand_total
        case total
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Handle optional fields with type safety
        rateArray = try container.decodeIfPresent(RateArray.self, forKey: .rateArray)
        sub_total = try container.decodeIfPresent(Double.self, forKey: .sub_total)
        grand_total = try container.decodeIfPresent(Double.self, forKey: .grand_total)
        total = try container.decodeIfPresent(Double.self, forKey: .total)
    }
}

struct RateArray: Codable {
    let all_inclusive_rates: AllInclusiveRates?
    
    enum CodingKeys: String, CodingKey {
        case all_inclusive_rates
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        all_inclusive_rates = try container.decodeIfPresent(AllInclusiveRates.self, forKey: .all_inclusive_rates)
    }
}

struct AllInclusiveRates: Codable {
    let trip_rate: TripRate?
    let gratuity: Gratuity?
    let trip_tax: TripTax?
    
    enum CodingKeys: String, CodingKey {
        case trip_rate
        case gratuity
        case trip_tax
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        trip_rate = try container.decodeIfPresent(TripRate.self, forKey: .trip_rate)
        gratuity = try container.decodeIfPresent(Gratuity.self, forKey: .gratuity)
        trip_tax = try container.decodeIfPresent(TripTax.self, forKey: .trip_tax)
    }
}

struct TripRate: Codable {
    let rate_label: String?
    let baserate: Double?
    let multiple: Double?
    let percentage: Double?
    let amount: Double?
    
    enum CodingKeys: String, CodingKey {
        case rate_label
        case baserate
        case multiple
        case percentage
        case amount
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        rate_label = try container.decodeIfPresent(String.self, forKey: .rate_label)
        baserate = try container.decodeIfPresent(Double.self, forKey: .baserate)
        multiple = try container.decodeIfPresent(Double.self, forKey: .multiple)
        percentage = try container.decodeIfPresent(Double.self, forKey: .percentage)
        amount = try container.decodeIfPresent(Double.self, forKey: .amount)
    }
}

struct Gratuity: Codable {
    let rate_label: String?
    let baserate: Double?
    let multiple: Double?
    let percentage: Double?
    let amount: Double?
    
    enum CodingKeys: String, CodingKey {
        case rate_label
        case baserate
        case multiple
        case percentage
        case amount
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        rate_label = try container.decodeIfPresent(String.self, forKey: .rate_label)
        baserate = try container.decodeIfPresent(Double.self, forKey: .baserate)
        multiple = try container.decodeIfPresent(Double.self, forKey: .multiple)
        percentage = try container.decodeIfPresent(Double.self, forKey: .percentage)
        amount = try container.decodeIfPresent(Double.self, forKey: .amount)
    }
}

struct TripTax: Codable {
    let rate_label: String?
    let baserate: Double?
    let multiple: Double?
    let percentage: Double?
    let amount: Double?
    
    enum CodingKeys: String, CodingKey {
        case rate_label
        case baserate
        case multiple
        case percentage
        case amount
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        rate_label = try container.decodeIfPresent(String.self, forKey: .rate_label)
        baserate = try container.decodeIfPresent(Double.self, forKey: .baserate)
        multiple = try container.decodeIfPresent(Double.self, forKey: .multiple)
        percentage = try container.decodeIfPresent(Double.self, forKey: .percentage)
        amount = try container.decodeIfPresent(Double.self, forKey: .amount)
    }
}

// Helper struct for flexible JSON decoding
struct AnyCodable: Codable {
    let value: Any
    
    init(_ value: Any) {
        self.value = value
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        if let string = try? container.decode(String.self) {
            value = string
        } else if let int = try? container.decode(Int.self) {
            value = int
        } else if let double = try? container.decode(Double.self) {
            value = double
        } else if let bool = try? container.decode(Bool.self) {
            value = bool
        } else if let array = try? container.decode([AnyCodable].self) {
            value = array.map { $0.value }
        } else if let dictionary = try? container.decode([String: AnyCodable].self) {
            value = dictionary.mapValues { $0.value }
        } else {
            value = NSNull()
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        
        switch value {
        case let string as String:
            try container.encode(string)
        case let int as Int:
            try container.encode(int)
        case let double as Double:
            try container.encode(double)
        case let bool as Bool:
            try container.encode(bool)
        case let array as [Any]:
            try container.encode(array.map { AnyCodable($0) })
        case let dictionary as [String: Any]:
            try container.encode(dictionary.mapValues { AnyCodable($0) })
        default:
            try container.encodeNil()
        }
    }
}

struct Vehicle: Codable, Identifiable, Equatable {
    let id: Int
    let name: String
    let description: String?
    let image: String?
    let capacity: Int
    let luggage: Int
    let price: Double
    let currency: String
    let features: [String]?
    let isAvailable: Bool
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case description
        case image
        case capacity = "passenger" // Map API's "passenger" field to "capacity"
        case luggage
        case price
        case currency
        case features
        case isAvailable = "is_available"
    }
    
    // Equatable conformance - compare by id since it should be unique
    static func == (lhs: Vehicle, rhs: Vehicle) -> Bool {
        return lhs.id == rhs.id
    }
}

struct QuoteInfo: Codable {
    let totalDistance: String
    let totalDuration: String
    let basePrice: Double
    let taxes: Double
    let totalPrice: Double
    
    enum CodingKeys: String, CodingKey {
        case totalDistance = "total_distance"
        case totalDuration = "total_duration"
        case basePrice = "base_price"
        case taxes
        case totalPrice = "total_price"
    }
}
