//
//  UserBooking.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

struct UserBooking: Codable, Identifiable {
    let booking_id: Int
    let account_type: String?
    let sub_account_type: String?
    let lose_affiliate: Int?
    let pickup_date: String
    let pickup_time: String
    let service_type: String
    let transfer_type: String?
    let return_transfer_type: String?
    let payment_status: String
    let payment_method: String?
    let booking_status: String
    let status: Bool
    let affiliate_id: Int
    let is_transferred: Int
    let passenger_name: String?
    let passenger_email: String?
    let passenger_cell_isd: String?
    let passenger_cell_country: String?
    let passenger_cell: String?
    let pickup_address: String
    let dropoff_address: String
    let vehicle_cat_name: String?
    let affiliate_type: String?
    let company_name: String?
    let affiliate_dispatch_isd: String?
    let affiliate_dispatch_number: String?
    let dispatchEmail: String?
    let gig_cell_isd: String?
    let gig_cell_mobile: String?
    let gig_email: String?
    let driver_first_name: String?
    let driver_last_name: String?
    let driver_cell_isd: String?
    let driver_cell_number: String?
    let loose_affiliate_name: String?
    let loose_affiliate_phone_isd: String?
    let loose_affiliate_phone: String?
    let loose_affiliate_email: String?
    let loose_aff_driver_name: String?
    let reservation_type: String?
    let grand_total: Double?
    let currency: String?
    let farmout_affiliate: String?
    let pickup_day: String
    let pax_tel: String?
    let pax_isd: String?
    let currency_symbol: String?
    let driver_name: String?
    let agent_type: String
    let driver_tel: String?
    
    // Memberwise initializer for sample data and manual creation
    init(booking_id: Int, account_type: String?, sub_account_type: String?, lose_affiliate: Int?, pickup_date: String, pickup_time: String, service_type: String, transfer_type: String?, return_transfer_type: String?, payment_status: String, payment_method: String?, booking_status: String, status: Bool, affiliate_id: Int, is_transferred: Int, passenger_name: String?, passenger_email: String?, passenger_cell_isd: String?, passenger_cell_country: String?, passenger_cell: String?, pickup_address: String, dropoff_address: String, vehicle_cat_name: String?, affiliate_type: String?, company_name: String?, affiliate_dispatch_isd: String?, affiliate_dispatch_number: String?, dispatchEmail: String?, gig_cell_isd: String?, gig_cell_mobile: String?, gig_email: String?, driver_first_name: String?, driver_last_name: String?, driver_cell_isd: String?, driver_cell_number: String?, loose_affiliate_name: String?, loose_affiliate_phone_isd: String?, loose_affiliate_phone: String?, loose_affiliate_email: String?, loose_aff_driver_name: String?, reservation_type: String?, grand_total: Double?, currency: String?, farmout_affiliate: String?, pickup_day: String, pax_tel: String?, pax_isd: String?, currency_symbol: String?, driver_name: String?, agent_type: String, driver_tel: String?) {
        self.booking_id = booking_id
        self.account_type = account_type
        self.sub_account_type = sub_account_type
        self.lose_affiliate = lose_affiliate
        self.pickup_date = pickup_date
        self.pickup_time = pickup_time
        self.service_type = service_type
        self.transfer_type = transfer_type
        self.return_transfer_type = return_transfer_type
        self.payment_status = payment_status
        self.payment_method = payment_method
        self.booking_status = booking_status
        self.status = status
        self.affiliate_id = affiliate_id
        self.is_transferred = is_transferred
        self.passenger_name = passenger_name
        self.passenger_email = passenger_email
        self.passenger_cell_isd = passenger_cell_isd
        self.passenger_cell_country = passenger_cell_country
        self.passenger_cell = passenger_cell
        self.pickup_address = pickup_address
        self.dropoff_address = dropoff_address
        self.vehicle_cat_name = vehicle_cat_name
        self.affiliate_type = affiliate_type
        self.company_name = company_name
        self.affiliate_dispatch_isd = affiliate_dispatch_isd
        self.affiliate_dispatch_number = affiliate_dispatch_number
        self.dispatchEmail = dispatchEmail
        self.gig_cell_isd = gig_cell_isd
        self.gig_cell_mobile = gig_cell_mobile
        self.gig_email = gig_email
        self.driver_first_name = driver_first_name
        self.driver_last_name = driver_last_name
        self.driver_cell_isd = driver_cell_isd
        self.driver_cell_number = driver_cell_number
        self.loose_affiliate_name = loose_affiliate_name
        self.loose_affiliate_phone_isd = loose_affiliate_phone_isd
        self.loose_affiliate_phone = loose_affiliate_phone
        self.loose_affiliate_email = loose_affiliate_email
        self.loose_aff_driver_name = loose_aff_driver_name
        self.reservation_type = reservation_type
        self.grand_total = grand_total
        self.currency = currency
        self.farmout_affiliate = farmout_affiliate
        self.pickup_day = pickup_day
        self.pax_tel = pax_tel
        self.pax_isd = pax_isd
        self.currency_symbol = currency_symbol
        self.driver_name = driver_name
        self.agent_type = agent_type
        self.driver_tel = driver_tel
    }
    
    // Computed property for Identifiable
    var id: Int { booking_id }
    
    // NOTE: transfer_type and return_transfer_type are provided by the API (optional)
    
    // Computed property for driver rating (default value since API doesn't provide it)
    var driver_rating: Double {
        return 4.5 // Default rating as used in driver app
    }
    
    // Computed property for driver name (combines first and last name)
    var computed_driver_name: String? {
        if let firstName = driver_first_name, let lastName = driver_last_name,
           !firstName.isEmpty && !lastName.isEmpty {
            return "\(firstName) \(lastName)"
        } else {
            return "1800limo Chauffeurs"
        }
    }
    
    // Computed property for driver phone (combines ISD code and cell number)
    var driver_phone: String? {
        if let isd = driver_cell_isd, let number = driver_cell_number,
           !isd.isEmpty && !number.isEmpty {
            return "\(isd) \(number)"
        } else {
            return "+1 8005466266"
        }
    }
    
    // Computed property for passenger name (with fallback)
    var display_passenger_name: String {
        return passenger_name ?? "N/A"
    }
    
    // Computed property for passenger email (with fallback)
    var display_passenger_email: String {
        return passenger_email ?? "N/A"
    }
    
    // Computed property for passenger phone (with fallback)
    var display_passenger_phone: String {
        if let isd = passenger_cell_isd, let number = passenger_cell,
           !isd.isEmpty && !number.isEmpty {
            return "\(isd) \(number)"
        } else {
            return "N/A"
        }
    }
    
    // Computed property for grand total (with fallback)
    var display_grand_total: Double {
        return grand_total ?? 0.0
    }
    
    // Computed property for currency symbol (with fallback)
    var display_currency_symbol: String {
        return currency_symbol ?? "$"
    }
    
    // Computed property for currency (with fallback)
    var display_currency: String {
        return currency ?? "USD"
    }
    
    // Computed property for driver gender (default value)
    var driver_gender: String {
        return "Male" // Default gender as requested
    }
    
    // Computed property for account type (with fallback)
    var display_account_type: String {
        return account_type ?? "N/A"
    }
    
    // Computed property for vehicle category name (with fallback)
    var display_vehicle_cat_name: String {
        return vehicle_cat_name ?? "N/A"
    }
    
    enum CodingKeys: String, CodingKey {
        case booking_id
        case account_type
        case sub_account_type
        case lose_affiliate
        case pickup_date
        case pickup_time
        case service_type
        case transfer_type
        case return_transfer_type
        case payment_status
        case payment_method
        case booking_status
        case status
        case affiliate_id
        case is_transferred
        case passenger_name
        case passenger_email
        case passenger_cell_isd
        case passenger_cell_country
        case passenger_cell
        case pickup_address
        case dropoff_address
        case vehicle_cat_name
        case affiliate_type
        case company_name
        case affiliate_dispatch_isd
        case affiliate_dispatch_number
        case dispatchEmail
        case gig_cell_isd
        case gig_cell_mobile
        case gig_email
        case driver_first_name
        case driver_last_name
        case driver_cell_isd
        case driver_cell_number
        case loose_affiliate_name
        case loose_affiliate_phone_isd
        case loose_affiliate_phone
        case loose_affiliate_email
        case loose_aff_driver_name
        case reservation_type
        case grand_total
        case currency
        case farmout_affiliate
        case pickup_day
        case pax_tel
        case pax_isd
        case currency_symbol
        case driver_name
        case agent_type
        case driver_tel
    }
    
    // Custom decoder to handle type mismatches
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        booking_id = try container.decode(Int.self, forKey: .booking_id)
        account_type = try container.decodeIfPresent(String.self, forKey: .account_type)
        sub_account_type = try container.decodeIfPresent(String.self, forKey: .sub_account_type)
        lose_affiliate = try container.decodeIfPresent(Int.self, forKey: .lose_affiliate)
        pickup_date = try container.decode(String.self, forKey: .pickup_date)
        pickup_time = try container.decode(String.self, forKey: .pickup_time)
        service_type = try container.decode(String.self, forKey: .service_type)
        transfer_type = try container.decodeIfPresent(String.self, forKey: .transfer_type)
        return_transfer_type = try container.decodeIfPresent(String.self, forKey: .return_transfer_type)
        payment_status = try container.decode(String.self, forKey: .payment_status)
        payment_method = try container.decodeIfPresent(String.self, forKey: .payment_method)
        booking_status = try container.decode(String.self, forKey: .booking_status)
        status = try container.decode(Bool.self, forKey: .status)
        
        // Handle affiliate_id which might be Int or null
        if let affiliateIdValue = try? container.decodeIfPresent(Int.self, forKey: .affiliate_id) {
            affiliate_id = affiliateIdValue
        } else {
            affiliate_id = 0 // Default value when null
        }
        
        is_transferred = try container.decode(Int.self, forKey: .is_transferred)
        passenger_name = try container.decodeIfPresent(String.self, forKey: .passenger_name)
        passenger_email = try container.decodeIfPresent(String.self, forKey: .passenger_email)
        passenger_cell_isd = try container.decodeIfPresent(String.self, forKey: .passenger_cell_isd)
        passenger_cell_country = try container.decodeIfPresent(String.self, forKey: .passenger_cell_country)
        passenger_cell = try container.decodeIfPresent(String.self, forKey: .passenger_cell)
        pickup_address = try container.decode(String.self, forKey: .pickup_address)
        dropoff_address = try container.decode(String.self, forKey: .dropoff_address)
        vehicle_cat_name = try container.decodeIfPresent(String.self, forKey: .vehicle_cat_name)
        affiliate_type = try container.decodeIfPresent(String.self, forKey: .affiliate_type)
        company_name = try container.decodeIfPresent(String.self, forKey: .company_name)
        affiliate_dispatch_isd = try container.decodeIfPresent(String.self, forKey: .affiliate_dispatch_isd)
        affiliate_dispatch_number = try container.decodeIfPresent(String.self, forKey: .affiliate_dispatch_number)
        dispatchEmail = try container.decodeIfPresent(String.self, forKey: .dispatchEmail)
        gig_cell_isd = try container.decodeIfPresent(String.self, forKey: .gig_cell_isd)
        gig_cell_mobile = try container.decodeIfPresent(String.self, forKey: .gig_cell_mobile)
        gig_email = try container.decodeIfPresent(String.self, forKey: .gig_email)
        driver_first_name = try container.decodeIfPresent(String.self, forKey: .driver_first_name)
        driver_last_name = try container.decodeIfPresent(String.self, forKey: .driver_last_name)
        driver_cell_isd = try container.decodeIfPresent(String.self, forKey: .driver_cell_isd)
        driver_cell_number = try container.decodeIfPresent(String.self, forKey: .driver_cell_number)
        loose_affiliate_name = try container.decodeIfPresent(String.self, forKey: .loose_affiliate_name)
        loose_affiliate_phone_isd = try container.decodeIfPresent(String.self, forKey: .loose_affiliate_phone_isd)
        
        // Handle loose_affiliate_phone which might be a number or string
        if let phoneString = try? container.decodeIfPresent(String.self, forKey: .loose_affiliate_phone) {
            loose_affiliate_phone = phoneString
        } else if let phoneNumber = try? container.decodeIfPresent(Int.self, forKey: .loose_affiliate_phone) {
            loose_affiliate_phone = String(phoneNumber)
        } else {
            loose_affiliate_phone = nil
        }
        
        loose_affiliate_email = try container.decodeIfPresent(String.self, forKey: .loose_affiliate_email)
        loose_aff_driver_name = try container.decodeIfPresent(String.self, forKey: .loose_aff_driver_name)
        reservation_type = try container.decodeIfPresent(String.self, forKey: .reservation_type)
        grand_total = try container.decodeIfPresent(Double.self, forKey: .grand_total)
        currency = try container.decodeIfPresent(String.self, forKey: .currency)
        
        // farmout_affiliate occasionally arrives as a numeric id from the API
        farmout_affiliate = container.decodeLossyString(forKey: .farmout_affiliate)
        
        pickup_day = try container.decode(String.self, forKey: .pickup_day)
        pax_tel = try container.decodeIfPresent(String.self, forKey: .pax_tel)
        pax_isd = try container.decodeIfPresent(String.self, forKey: .pax_isd)
        currency_symbol = try container.decodeIfPresent(String.self, forKey: .currency_symbol)
        driver_name = try container.decodeIfPresent(String.self, forKey: .driver_name)
        agent_type = try container.decode(String.self, forKey: .agent_type)
        driver_tel = try container.decodeIfPresent(String.self, forKey: .driver_tel)
    }
}

// MARK: - API Response Models
struct UserBookingsResponse: Codable {
    let success: Bool
    let data: UserBookingsData
    let message: String
    let currency: CurrencyInfo
}

struct UserBookingsData: Codable {
    let current_page: Int
    let data: [UserBooking]
    let first_page_url: String
    let from: Int?
    let last_page: Int
    let last_page_url: String
    let links: [PageLink]
    let next_page_url: String?
    let path: String
    let per_page: Int
    let prev_page_url: String?
    let to: Int?
    let total: Int
}

struct PageLink: Codable {
    let url: String?
    let label: String
    let active: Bool
}


// MARK: - Sample Data for Static UI (Fallback)
extension UserBooking {
    static let sampleBookings: [UserBooking] = [
        UserBooking(
            booking_id: 1445,
            account_type: "individual",
            sub_account_type: nil,
            lose_affiliate: nil,
            pickup_date: "2025-01-15",
            pickup_time: "14:30:00",
            service_type: "oneway",
            transfer_type: nil,
            return_transfer_type: nil,
            payment_status: "paid",
            payment_method: nil,
            booking_status: "confirmed",
            status: true,
            affiliate_id: 543,
            is_transferred: 0,
            passenger_name: "Alexa Smith",
            passenger_email: "alexa.smith@email.com",
            passenger_cell_isd: "+1",
            passenger_cell_country: "us",
            passenger_cell: "9876543210",
            pickup_address: "123 Main Street, Beverly Hills, CA 90210, USA",
            dropoff_address: "Los Angeles International Airport, 1 World Way, Los Angeles, CA 90045, USA",
            vehicle_cat_name: "Luxury Sedan",
            affiliate_type: "gig_operator",
            company_name: "1800Limo",
            affiliate_dispatch_isd: nil,
            affiliate_dispatch_number: nil,
            dispatchEmail: nil,
            gig_cell_isd: "+1",
            gig_cell_mobile: "5551234567",
            gig_email: "john@1800limo.com",
            driver_first_name: "John",
            driver_last_name: "Smith",
            driver_cell_isd: "+1",
            driver_cell_number: "5551234567",
            loose_affiliate_name: nil,
            loose_affiliate_phone_isd: nil,
            loose_affiliate_phone: nil,
            loose_affiliate_email: nil,
            loose_aff_driver_name: nil,
            reservation_type: nil,
            grand_total: 125.50,
            currency: "USD",
            farmout_affiliate: nil,
            pickup_day: "Wednesday",
            pax_tel: "9876543210",
            pax_isd: "+1",
            currency_symbol: "$",
            driver_name: "John Smith",
            agent_type: "travel_agent",
            driver_tel: "5551234567"
        ),
        UserBooking(
            booking_id: 1446,
            account_type: "individual",
            sub_account_type: nil,
            lose_affiliate: nil,
            pickup_date: "2025-01-16",
            pickup_time: "09:15:00",
            service_type: "roundtrip",
            transfer_type: nil,
            return_transfer_type: nil,
            payment_status: "pending",
            payment_method: nil,
            booking_status: "pending",
            status: true,
            affiliate_id: 543,
            is_transferred: 0,
            passenger_name: "Alexa Smith",
            passenger_email: "alexa.smith@email.com",
            passenger_cell_isd: "+1",
            passenger_cell_country: "us",
            passenger_cell: "9876543210",
            pickup_address: "456 Oak Avenue, San Francisco, CA 94102, USA",
            dropoff_address: "San Francisco International Airport, San Francisco, CA 94128, USA",
            vehicle_cat_name: "Premium SUV",
            affiliate_type: "gig_operator",
            company_name: "1800Limo",
            affiliate_dispatch_isd: nil,
            affiliate_dispatch_number: nil,
            dispatchEmail: nil,
            gig_cell_isd: "+1",
            gig_cell_mobile: "5559876543",
            gig_email: "mike@1800limo.com",
            driver_first_name: "Mike",
            driver_last_name: "Johnson",
            driver_cell_isd: "+1",
            driver_cell_number: "5559876543",
            loose_affiliate_name: nil,
            loose_affiliate_phone_isd: nil,
            loose_affiliate_phone: nil,
            loose_affiliate_email: nil,
            loose_aff_driver_name: nil,
            reservation_type: nil,
            grand_total: 285.75,
            currency: "USD",
            farmout_affiliate: nil,
            pickup_day: "Thursday",
            pax_tel: "9876543210",
            pax_isd: "+1",
            currency_symbol: "$",
            driver_name: "Mike Johnson",
            agent_type: "travel_agent",
            driver_tel: "5559876543"
        )
    ]
}