import Foundation

// MARK: - Extra Stop Model for API
struct ExtraStopRequest: Codable {
    let address: String
    let latitude: Double
    let longitude: Double
    let rate: String
    let bookingInstructions: String
    
    enum CodingKeys: String, CodingKey {
        case address
        case latitude
        case longitude
        case rate
        case bookingInstructions = "booking_instructions"
    }
}

// MARK: - Booking Rates Request Model
struct BookingRatesRequest: Codable {
    let vehicleId: Int
    let transferType: String
    let serviceType: String
    let numberOfVehicles: Int
    let distance: Int
    let returnDistance: Int
    let noOfHours: String
    let isMasterVehicle: Bool
    let extraStops: [ExtraStopRequest]
    let returnExtraStops: [ExtraStopRequest]
    let pickupTime: String
    let returnPickupTime: String
    let returnVehicleId: Int
    let returnAffiliateType: String
    
    enum CodingKeys: String, CodingKey {
        case vehicleId = "vehicle_id"
        case transferType = "transfer_type"
        case serviceType = "service_type"
        case numberOfVehicles
        case distance
        case returnDistance = "return_distance"
        case noOfHours = "no_of_hours"
        case isMasterVehicle = "is_master_vehicle"
        case extraStops = "extra_stops"
        case returnExtraStops = "return_extra_stops"
        case pickupTime = "pickup_time"
        case returnPickupTime = "return_pickup_time"
        case returnVehicleId = "return_vehicle_id"
        case returnAffiliateType = "return_affiliate_type"
    }
}

// MARK: - Booking Rates Response Models
struct BookingRatesResponse: Codable {
    let success: Bool
    let data: BookingRatesData
    let message: String
    let currency: BookingRatesCurrency?
}

struct BookingRatesData: Codable {
    let subTotal: Double
    let grandTotal: Double
    let minRateInvolved: Bool?
    let rateArray: BookingRateArray
    let retrunRateArray: BookingRateArray?
    
    enum CodingKeys: String, CodingKey {
        case subTotal = "sub_total"
        case grandTotal = "grand_total"
        case minRateInvolved = "min_rate_involved"
        case rateArray
        case retrunRateArray
    }
}

struct BookingRateArray: Codable {
    let allInclusiveRates: [String: RateItem]
    let amenities: [String: RateItem]
    let taxes: [String: TaxItem]
    let misc: [String: RateItem]
    
    enum CodingKeys: String, CodingKey {
        case allInclusiveRates = "all_inclusive_rates"
        case amenities
        case taxes
        case misc
    }
}


struct RateItem: Codable {
    let rateLabel: String
    let baserate: Double
    let multiple: Double?
    let percentage: Double?
    let amount: Double
    let type: String?
    let flatBaserate: Double?
    
    enum CodingKeys: String, CodingKey {
        case rateLabel = "rate_label"
        case baserate
        case multiple
        case percentage
        case amount
        case type
        case flatBaserate = "flat_baserate"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        rateLabel = try container.decode(String.self, forKey: .rateLabel)
        baserate = try container.decode(Double.self, forKey: .baserate)
        amount = try container.decode(Double.self, forKey: .amount)
        
        // Handle null values that come as "null" strings
        multiple = try container.decodeIfPresent(Double.self, forKey: .multiple)
        percentage = try container.decodeIfPresent(Double.self, forKey: .percentage)
        
        // Handle flatBaserate that can be either string or double
        if let flatBaserateDouble = try? container.decodeIfPresent(Double.self, forKey: .flatBaserate) {
            flatBaserate = flatBaserateDouble
        } else if let flatBaserateString = try? container.decodeIfPresent(String.self, forKey: .flatBaserate),
                  let flatBaserateValue = Double(flatBaserateString) {
            flatBaserate = flatBaserateValue
        } else {
            flatBaserate = nil
        }
        
        // Handle type field that can be "null" string or actual null
        if let typeString = try container.decodeIfPresent(String.self, forKey: .type) {
            type = typeString == "null" ? nil : typeString
        } else {
            type = nil
        }
    }
}

struct TaxItem: Codable {
    let rateLabel: String
    let baserate: Double
    let flatBaserate: Double?
    let multiple: Double?
    let percentage: Double?
    let amount: Double
    let type: String?
    
    enum CodingKeys: String, CodingKey {
        case rateLabel = "rate_label"
        case baserate
        case flatBaserate = "flat_baserate"
        case multiple
        case percentage
        case amount
        case type
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        rateLabel = try container.decode(String.self, forKey: .rateLabel)
        baserate = try container.decode(Double.self, forKey: .baserate)
        amount = try container.decode(Double.self, forKey: .amount)
        
        // Handle flatBaserate that can be either string or double
        if let flatBaserateDouble = try? container.decodeIfPresent(Double.self, forKey: .flatBaserate) {
            flatBaserate = flatBaserateDouble
        } else if let flatBaserateString = try? container.decodeIfPresent(String.self, forKey: .flatBaserate),
                  let flatBaserateValue = Double(flatBaserateString) {
            flatBaserate = flatBaserateValue
        } else {
            flatBaserate = nil
        }
        
        // Handle optional fields that can be null
        multiple = try container.decodeIfPresent(Double.self, forKey: .multiple)
        percentage = try container.decodeIfPresent(Double.self, forKey: .percentage)
        
        // Handle type field that can be "null" string or actual null
        if let typeString = try container.decodeIfPresent(String.self, forKey: .type) {
            type = typeString == "null" ? nil : typeString
        } else {
            type = nil
        }
    }
}

struct BookingRatesCurrency: Codable {
    let countryName: String
    let currency: String
    let currencyCountry: String
    let symbol: String
    let dateFormat: String
    
    enum CodingKeys: String, CodingKey {
        case countryName
        case currency
        case currencyCountry
        case symbol
        case dateFormat
    }
}

// MARK: - Booking Rates Service
@MainActor
class BookingRatesService: ObservableObject {
    @Published var ratesData: BookingRatesData?
    @Published var returnRatesData: BookingRatesData?
    @Published var currency: BookingRatesCurrency?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func fetchBookingRates(request: BookingRatesRequest) async {
        isLoading = true
        errorMessage = nil
        
        let endpoint = APIEndpoints.bookingRates(request: request)
        
        print("🚀 BOOKING RATES API REQUEST:")
        print("URL: \(endpoint.path)")
        print("Method: \(endpoint.method.rawValue)")
        
        if let bodyData = endpoint.body {
            print("Request Body:")
            if let jsonString = String(data: bodyData, encoding: .utf8) {
                print(jsonString)
            }
            
            // Also print as dictionary for better readability
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: bodyData)
                let prettyData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
                if let prettyString = String(data: prettyData, encoding: .utf8) {
                    print("Pretty Request Body:")
                    print(prettyString)
                }
            } catch {
                print("Error formatting request body: \(error)")
            }
        }
        
        // Print individual request parameters for debugging
        print("📋 REQUEST PARAMETERS:")
        print("Vehicle ID: \(request.vehicleId)")
        print("Transfer Type: \(request.transferType)")
        print("Service Type: \(request.serviceType)")
        print("Number of Vehicles: \(request.numberOfVehicles)")
        print("Distance: \(request.distance)")
        print("Return Distance: \(request.returnDistance)")
        print("No of Hours: \(request.noOfHours)")
        print("Is Master Vehicle: \(request.isMasterVehicle)")
        print("Pickup Time: \(request.pickupTime)")
        print("Return Pickup Time: \(request.returnPickupTime)")
        print("Return Vehicle ID: \(request.returnVehicleId)")
        print("Return Affiliate Type: \(request.returnAffiliateType)")
        print("Extra Stops: \(request.extraStops)")
        print("Return Extra Stops: \(request.returnExtraStops)")
        
        do {
            // Try to decode the response first
            let response: BookingRatesResponse = try await NetworkService.shared.request(
                endpoint: endpoint,
                body: nil, // Body is already included in the endpoint
                responseType: BookingRatesResponse.self
            )
            
            // Print raw response for debugging (we'll get it from the decoded response)
            print("🔍 DECODED API RESPONSE:")
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            if let responseData = try? encoder.encode(response),
               let responseString = String(data: responseData, encoding: .utf8) {
                print(responseString)
            }
            
            print("📋 COMPLETE BOOKING RATES API RESPONSE:")
            print("Success: \(response.success)")
            print("Message: \(response.message)")
            print("Sub Total: \(response.data.subTotal)")
            print("Grand Total: \(response.data.grandTotal)")
            print("Min Rate Involved: \(response.data.minRateInvolved ?? false)")
            print("Currency: \(response.currency?.symbol ?? "Unknown")")
            
            // Print detailed rate breakdown
            print("📊 RATE BREAKDOWN:")
            print("Base Rate: \(response.data.rateArray.allInclusiveRates["Base_Rate"]?.amount ?? 0)")
            print("Stops: \(response.data.rateArray.allInclusiveRates["Stops"]?.amount ?? 0)")
            print("Wait: \(response.data.rateArray.allInclusiveRates["Wait"]?.amount ?? 0)")
            print("ELH Charges: \(response.data.rateArray.allInclusiveRates["ELH_Charges"]?.amount ?? 0)")
            
            // Print taxes
            print("💰 TAXES:")
            print("Airport Arrival Tax: \(response.data.rateArray.taxes["Airport_Arrival_Tax_Per_US"]?.amount ?? 0)")
            print("Airport Departure Tax: \(response.data.rateArray.taxes["Airport_Departure_Tax_Per_US"]?.amount ?? 0)")
            print("City Congestion Tax: \(response.data.rateArray.taxes["City_Congestion_Tax_Per_US"]?.amount ?? 0)")
            print("City Tax: \(response.data.rateArray.taxes["City_Tax"]?.amount ?? 0)")
            print("State Tax: \(response.data.rateArray.taxes["State_Tax"]?.amount ?? 0)")
            print("VAT Tax: \(response.data.rateArray.taxes["VAT_Tax"]?.amount ?? 0)")
            print("Workman Comp Tax: \(response.data.rateArray.taxes["Workman_Comp_Tax"]?.amount ?? 0)")
            print("Other Transportation Tax: \(response.data.rateArray.taxes["Other_Transportation_Tax"]?.amount ?? 0)")
            print("Tolls: \(response.data.rateArray.taxes["Tolls"]?.amount ?? 0)")
            
            if response.success {
                ratesData = response.data
                currency = response.currency
                print("✅ Booking rates loaded successfully")
            } else {
                errorMessage = response.message
                print("❌ Failed to fetch booking rates: \(response.message)")
            }
        } catch {
            errorMessage = error.localizedDescription
            print("❌ Failed to fetch booking rates: \(error)")
            
            // Print error details
            print("🔍 DECODING ERROR DETAILS:")
            if let decodingError = error as? DecodingError {
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("Type Mismatch: Expected \(type), found at path: \(context.codingPath)")
                    print("Debug Description: \(context.debugDescription)")
                case .keyNotFound(let key, let context):
                    print("Key Not Found: \(key) at path: \(context.codingPath)")
                case .valueNotFound(let type, let context):
                    print("Value Not Found: Expected \(type) at path: \(context.codingPath)")
                case .dataCorrupted(let context):
                    print("Data Corrupted: \(context.debugDescription)")
                @unknown default:
                    print("Unknown decoding error")
                }
            }
        }
        
        isLoading = false
    }
    
    func fetchReturnBookingRates(request: BookingRatesRequest) async {
        isLoading = true
        errorMessage = nil
        
        let endpoint = APIEndpoints.bookingRates(request: request)
        
        print("🚀 RETURN BOOKING RATES API REQUEST:")
        print("URL: \(endpoint.path)")
        print("Method: \(endpoint.method.rawValue)")
        
        if let bodyData = endpoint.body {
            print("Return Request Body:")
            if let jsonString = String(data: bodyData, encoding: .utf8) {
                print(jsonString)
            }
        }
        
        // Print individual request parameters for debugging
        print("📋 RETURN REQUEST PARAMETERS:")
        print("Vehicle ID: \(request.vehicleId)")
        print("Transfer Type: \(request.transferType)")
        print("Service Type: \(request.serviceType)")
        print("Number of Vehicles: \(request.numberOfVehicles)")
        print("Distance: \(request.distance)")
        print("Return Distance: \(request.returnDistance)")
        print("No of Hours: \(request.noOfHours)")
        print("Is Master Vehicle: \(request.isMasterVehicle)")
        print("Pickup Time: \(request.pickupTime)")
        print("Return Pickup Time: \(request.returnPickupTime)")
        print("Return Vehicle ID: \(request.returnVehicleId)")
        print("Return Affiliate Type: \(request.returnAffiliateType)")
        print("Extra Stops: \(request.extraStops)")
        print("Return Extra Stops: \(request.returnExtraStops)")
        
        do {
            // Try to decode the response first
            let response: BookingRatesResponse = try await NetworkService.shared.request(
                endpoint: endpoint,
                body: nil, // Body is already included in the endpoint
                responseType: BookingRatesResponse.self
            )
            
            // Print raw response for debugging (we'll get it from the decoded response)
            print("🔍 DECODED RETURN API RESPONSE:")
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            if let responseData = try? encoder.encode(response),
               let responseString = String(data: responseData, encoding: .utf8) {
                print(responseString)
            }
            
            print("📋 COMPLETE RETURN BOOKING RATES API RESPONSE:")
            print("Success: \(response.success)")
            print("Message: \(response.message)")
            print("Sub Total: \(response.data.subTotal)")
            print("Grand Total: \(response.data.grandTotal)")
            print("Min Rate Involved: \(response.data.minRateInvolved ?? false)")
            print("Currency: \(response.currency?.symbol ?? "Unknown")")
            
            // Print detailed rate breakdown
            print("📊 RETURN RATE BREAKDOWN:")
            print("Base Rate: \(response.data.rateArray.allInclusiveRates["Base_Rate"]?.amount ?? 0)")
            print("Stops: \(response.data.rateArray.allInclusiveRates["Stops"]?.amount ?? 0)")
            print("Wait: \(response.data.rateArray.allInclusiveRates["Wait"]?.amount ?? 0)")
            print("ELH Charges: \(response.data.rateArray.allInclusiveRates["ELH_Charges"]?.amount ?? 0)")
            
            if response.success {
                returnRatesData = response.data
                currency = response.currency
                print("✅ Return booking rates loaded successfully")
            } else {
                errorMessage = response.message
                print("❌ Failed to fetch return booking rates: \(response.message)")
            }
        } catch {
            errorMessage = error.localizedDescription
            print("❌ Failed to fetch return booking rates: \(error)")
        }
        
        isLoading = false
    }
    
    func fetchReservationRates(bookingId: Int) async {
        isLoading = true
        errorMessage = nil
        
        let endpoint = APIEndpoints.reservationRates(bookingId: bookingId)
        
        print("🚀 RESERVATION RATES API REQUEST:")
        print("URL: \(endpoint.path)")
        print("Method: \(endpoint.method.rawValue)")
        print("Booking ID: \(bookingId)")
        
        do {
            let response: BookingRatesResponse = try await NetworkService.shared.request(
                endpoint: endpoint,
                body: nil,
                responseType: BookingRatesResponse.self
            )
            
            // Print raw response for debugging
            print("🔍 DECODED RESERVATION RATES API RESPONSE:")
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            if let responseData = try? encoder.encode(response),
               let responseString = String(data: responseData, encoding: .utf8) {
                print(responseString)
            }
            
            print("📋 COMPLETE RESERVATION RATES API RESPONSE:")
            print("Success: \(response.success)")
            print("Message: \(response.message)")
            print("Sub Total: \(response.data.subTotal)")
            print("Grand Total: \(response.data.grandTotal)")
            print("Min Rate Involved: \(response.data.minRateInvolved ?? false)")
            print("Currency: \(response.currency?.symbol ?? "Unknown")")
            
            if response.success {
                ratesData = response.data
                currency = response.currency
                print("✅ Reservation rates loaded successfully for booking ID: \(bookingId)")
            } else {
                errorMessage = response.message
                print("❌ Failed to fetch reservation rates: \(response.message)")
            }
        } catch {
            errorMessage = error.localizedDescription
            print("❌ Failed to fetch reservation rates: \(error)")
            
            // Print error details
            print("🔍 DECODING ERROR DETAILS:")
            if let decodingError = error as? DecodingError {
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("Type Mismatch: Expected \(type), found at path: \(context.codingPath)")
                    print("Debug Description: \(context.debugDescription)")
                case .keyNotFound(let key, let context):
                    print("Key Not Found: \(key) at path: \(context.codingPath)")
                case .valueNotFound(let type, let context):
                    print("Value Not Found: Expected \(type) at path: \(context.codingPath)")
                case .dataCorrupted(let context):
                    print("Data Corrupted: \(context.debugDescription)")
                @unknown default:
                    print("Unknown decoding error")
                }
            }
        }
        
        isLoading = false
    }
}

