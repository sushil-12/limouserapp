//
//  Invoice.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

struct Invoice: Codable, Identifiable {
    let booking_id: Int
    let driver_id: Int
    let aff_vehicle_type: String
    let status: String
    let invoice_number: Int
    let reservation_preferences_id: Int?
    let date: String
    let pickup_address: String
    let dropoff_address: String
    let driver_company: String?
    let account_first_name: String
    let currency: String
    let stripe_customer_id: String
    let account_last_name: String
    let account_email: String
    let payment_method: String
    let booking_total: Double
    let card_id: String?
    let address: String?
    let city: String
    let state: String
    let zip: String
    let charge_object_id: String?
    let driver_name: String
    let driver_phone: String
    let passenger_name: String
    let passenger_phone: String
    
    // Computed property for Identifiable
    var id: Int { booking_id }
    
    // Computed property for formatted date
    var formattedDate: String {
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "MMM dd, yyyy"
        
        guard let date = inputFormatter.date(from: date) else {
            return date
        }
        
        let outputFormatter = DateFormatter()
        outputFormatter.dateFormat = "MMM dd, yyyy"
        return outputFormatter.string(from: date)
    }
    
    // Computed property for formatted total
    var formattedTotal: String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = currency.uppercased()
        formatter.currencySymbol = getCurrencySymbol()
        return formatter.string(from: NSNumber(value: booking_total / 100)) ?? "$\(String(format: "%.2f", booking_total / 100))"
    }
    
    // Computed property for status color
    var statusColor: String {
        switch status.lowercased() {
        case "paid":
            return "green"
        case "paid_cash":
            return "blue"
        case "pending":
            return "orange"
        case "failed":
            return "red"
        default:
            return "gray"
        }
    }
    
    // Computed property for payment method display
    var paymentMethodDisplay: String {
        switch payment_method.lowercased() {
        case "credit_card":
            return "Credit Card"
        case "cash":
            return "Cash"
        case "debit_card":
            return "Debit Card"
        default:
            return payment_method.capitalized
        }
    }
    
    // Helper function to get currency symbol
    private func getCurrencySymbol() -> String {
        switch currency.uppercased() {
        case "USD":
            return "$"
        case "EUR":
            return "€"
        case "GBP":
            return "£"
        case "CAD":
            return "C$"
        case "AUD":
            return "A$"
        default:
            return "$"
        }
    }
    
    enum CodingKeys: String, CodingKey {
        case booking_id
        case driver_id
        case aff_vehicle_type
        case status
        case invoice_number
        case reservation_preferences_id
        case date
        case pickup_address
        case dropoff_address
        case driver_company
        case account_first_name
        case currency
        case stripe_customer_id
        case account_last_name
        case account_email
        case payment_method
        case booking_total
        case card_id
        case address
        case city
        case state
        case zip
        case charge_object_id
        case driver_name
        case driver_phone
        case passenger_name
        case passenger_phone
    }
}

// MARK: - API Response Models
struct InvoiceResponse: Codable {
    let success: Bool
    let data: InvoiceData
    let message: String
    let currency: CurrencyInfo
}

struct InvoiceData: Codable {
    let current_page: Int
    let data: [Invoice]
    let first_page_url: String
    let from: Int?
    let last_page: Int
    let last_page_url: String
    let links: [PageLink]
    let next_page_url: String?
    let path: String
    let per_page: Int
    let prev_page_url: String?
    let to: Int?
    let total: Int
}


// MARK: - Sample Data for Static UI (Fallback)
extension Invoice {
    static let sampleInvoices: [Invoice] = [
        Invoice(
            booking_id: 1605,
            driver_id: 398,
            aff_vehicle_type: "Full-Size SUV",
            status: "paid",
            invoice_number: 1007,
            reservation_preferences_id: nil,
            date: "Sep 11, 2025",
            pickup_address: "ATL - Hartsfield Jackson Atlanta Intl, Atlanta, United States",
            dropoff_address: "Chicago Riverwalk, Chicago, IL, USA",
            driver_company: nil,
            account_first_name: "sushil",
            currency: "USD",
            stripe_customer_id: "cus_So1eHEil8FdhCJ",
            account_last_name: "kumar",
            account_email: "sushil124maurya@gmail.com",
            payment_method: "credit_card",
            booking_total: 25000,
            card_id: "card_1RsPbHKoNaQmPl6mGorXylJb",
            address: "Mohali Airport Chowk, Gmada Aerocity, Punjab 140306, India",
            city: "Sahibzada Ajit Singh Nagar",
            state: "Punjab",
            zip: "140306",
            charge_object_id: "ch_3S63ziKoNaQmPl6m0xur7crc",
            driver_name: "Sunny Sharmaaaa",
            driver_phone: "+1 9560141195",
            passenger_name: "sushil kumar",
            passenger_phone: "+1 7089991123"
        ),
        Invoice(
            booking_id: 1596,
            driver_id: 397,
            aff_vehicle_type: "Full-Size SUV",
            status: "paid",
            invoice_number: 1006,
            reservation_preferences_id: nil,
            date: "Sep 10, 2025",
            pickup_address: "ATL - Hartsfield Jackson Atlanta Intl, Atlanta, United States",
            dropoff_address: "Chicago Riverwalk, Chicago, IL, USA",
            driver_company: nil,
            account_first_name: "sushil",
            currency: "usd",
            stripe_customer_id: "cus_So1eHEil8FdhCJ",
            account_last_name: "kumar",
            account_email: "sushil124maurya@gmail.com",
            payment_method: "credit_card",
            booking_total: 3683.8,
            card_id: "card_1RsPbHKoNaQmPl6mGorXylJb",
            address: "Mohali Airport Chowk, Gmada Aerocity, Punjab 140306, India",
            city: "Sahibzada Ajit Singh Nagar",
            state: "Punjab",
            zip: "140306",
            charge_object_id: "ch_3S5mRmKoNaQmPl6m1pyz7DXE",
            driver_name: "Sara sh Sharma",
            driver_phone: "+1 9877205702",
            passenger_name: "sushil kumar",
            passenger_phone: "+1 7089991123"
        ),
        Invoice(
            booking_id: 1577,
            driver_id: 213,
            aff_vehicle_type: "Full-Size Sedan",
            status: "paid",
            invoice_number: 1004,
            reservation_preferences_id: nil,
            date: "Sep 08, 2025",
            pickup_address: "1122 King Rd, Moscow, ID 83843, USA",
            dropoff_address: "Chicago Ridge Mall, Oak Lawn, IL, USA",
            driver_company: nil,
            account_first_name: "sushil",
            currency: "usd",
            stripe_customer_id: "cus_So1eHEil8FdhCJ",
            account_last_name: "kumar",
            account_email: "sushil124maurya@gmail.com",
            payment_method: "credit_card",
            booking_total: 8018.3375,
            card_id: "card_1RsPbHKoNaQmPl6mGorXylJb",
            address: "Mohali Airport Chowk, Gmada Aerocity, Punjab 140306, India",
            city: "Sahibzada Ajit Singh Nagar",
            state: "Punjab",
            zip: "140306",
            charge_object_id: "ch_3S537yKoNaQmPl6m1hz5Arkh",
            driver_name: "Ji Sharma",
            driver_phone: "+1 8295274496",
            passenger_name: "sushil kumar",
            passenger_phone: "+1 7089991123"
        )
    ]
}
