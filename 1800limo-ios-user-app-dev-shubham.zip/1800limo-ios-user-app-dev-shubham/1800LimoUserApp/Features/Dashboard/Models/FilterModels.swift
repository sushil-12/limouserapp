import Foundation

// MARK: - Filter Item Protocol
protocol FilterItem: Identifiable {
    var displayName: String { get }
}

// MARK: - Filter Response Models
struct FilterResponse: Codable {
    let success: Bool
    let data: FilterData
    let message: String
    let currency: Currency
}

struct FilterData: Codable {
    let affiliatePreferences: [AffiliatePreference]
    let vehicleType: [VehicleTypeFilter]
    let amenities: [AmenityFilter]
    let specialAmenities: [SpecialAmenityFilter]
    let interiors: [InteriorFilter]
    let make: [MakeFilter]
    let model: [ModelFilter]
    let years: [YearFilter]
    let colors: [ColorFilter]
    let driverLanguages: [DriverLanguageFilter]
    let driverDresses: [DriverDressFilter]
    let driverGender: [DriverGenderFilter]
    let vehicleServiceArea: [VehicleServiceAreaFilter]
    
    enum CodingKeys: String, CodingKey {
        case affiliatePreferences = "affiliate-preferences"
        case vehicleType = "vehicle-type"
        case specialAmenities = "special-amenities"
        case driverLanguages = "driver-languages"
        case driverDresses = "driver-dresses"
        case driverGender = "driver-gender"
        case vehicleServiceArea = "vehicle-service-area"
        case amenities, interiors, make, model, years, colors
    }
}


// MARK: - Filter Item Models
struct AffiliatePreference: Codable, Identifiable, FilterItem {
    let id = UUID()
    let slug: String
    let name: String
    
    var displayName: String { name }
    
    enum CodingKeys: String, CodingKey {
        case slug, name
    }
}

struct VehicleTypeFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    let status: String
    let sortOrder: Int?
    
    var displayName: String { name }
    
    enum CodingKeys: String, CodingKey {
        case id, name, status
        case sortOrder = "sort_order"
    }
}

struct AmenityFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    let chargeable: String
    let category: String
    
    var displayName: String { name }
}

struct SpecialAmenityFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    let chargeable: String?
    let category: String?
    
    var displayName: String { name }
}

struct InteriorFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    
    var displayName: String { name }
}

struct MakeFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    
    var displayName: String { name }
}

struct ModelFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let makeId: Int
    let name: String
    
    var displayName: String { name }
    
    enum CodingKeys: String, CodingKey {
        case id, name
        case makeId = "make_id"
    }
}

struct YearFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    
    var displayName: String { name }
}

struct ColorFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    
    var displayName: String { name }
}

struct DriverLanguageFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    
    var displayName: String { name }
}

struct DriverDressFilter: Codable, Identifiable, FilterItem {
    let id: Int
    let name: String
    
    var displayName: String { name }
}

struct DriverGenderFilter: Codable, Identifiable, FilterItem {
    let id = UUID()
    let slug: String
    let name: String
    
    var displayName: String { name }
    
    enum CodingKeys: String, CodingKey {
        case slug, name
    }
}

struct VehicleServiceAreaFilter: Codable, Identifiable, FilterItem {
    let id = UUID()
    let slug: String
    let name: String
    
    var displayName: String { name }
    
    enum CodingKeys: String, CodingKey {
        case slug, name
    }
}

// MARK: - Filter Category Enum
enum FilterCategory: String, CaseIterable {
    case vehicleType = "Vehicle Type Preferences"
    case driverPreferences = "Driver Preferences"
    case extraAmenities = "Extra $ Amenities"
    case years = "Years"
    case colors = "Colors"
    case interiors = "Interiors"
    case amenities = "Amenities"
    case makeModel = "Make Model"
    case vehicleServiceArea = "Vehicle Service Area Type"
    case operatorPreferences = "Operator Preferences"
    
    // Sub-categories for Driver Preferences
    case driverDresses = "Dresses"
    case driverBackground = "Background"
    case driverLanguages = "Languages"
    case driverGender = "Gender"
    
    // Sub-categories for Make Model
    case make = "Make"
    case model = "Model"
    
    var displayName: String {
        return self.rawValue
    }
    
    // Main categories that appear in the top level
    static var mainCategories: [FilterCategory] {
        return [.vehicleType, .driverPreferences, .extraAmenities, .years, .colors, .interiors, .amenities, .makeModel, .vehicleServiceArea, .operatorPreferences]
    }
    
    // Sub-categories for Driver Preferences
    static var driverPreferencesSubCategories: [FilterCategory] {
        return [.driverDresses, .driverLanguages, .driverGender]
    }
    
    // Sub-categories for Make Model
    static var makeModelSubCategories: [FilterCategory] {
        return [.make, .model]
    }
}

// MARK: - Filter Selection State
class FilterSelectionState: ObservableObject, Hashable {
    static func == (lhs: FilterSelectionState, rhs: FilterSelectionState) -> Bool {
        return lhs.selectedVehicleTypes == rhs.selectedVehicleTypes &&
               lhs.selectedAmenities == rhs.selectedAmenities &&
               lhs.selectedSpecialAmenities == rhs.selectedSpecialAmenities &&
               lhs.selectedInteriors == rhs.selectedInteriors &&
               lhs.selectedMakes == rhs.selectedMakes &&
               lhs.selectedModels == rhs.selectedModels &&
               lhs.selectedYears == rhs.selectedYears &&
               lhs.selectedColors == rhs.selectedColors &&
               lhs.selectedDriverLanguages == rhs.selectedDriverLanguages &&
               lhs.selectedDriverDresses == rhs.selectedDriverDresses &&
               lhs.selectedDriverGenders == rhs.selectedDriverGenders &&
               lhs.selectedDriverBackgrounds == rhs.selectedDriverBackgrounds &&
               lhs.selectedVehicleServiceAreas == rhs.selectedVehicleServiceAreas &&
               lhs.selectedAffiliatePreferences == rhs.selectedAffiliatePreferences
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(selectedVehicleTypes)
        hasher.combine(selectedAmenities)
        hasher.combine(selectedSpecialAmenities)
        hasher.combine(selectedInteriors)
        hasher.combine(selectedMakes)
        hasher.combine(selectedModels)
        hasher.combine(selectedYears)
        hasher.combine(selectedColors)
        hasher.combine(selectedDriverLanguages)
        hasher.combine(selectedDriverDresses)
        hasher.combine(selectedDriverGenders)
        hasher.combine(selectedDriverBackgrounds)
        hasher.combine(selectedVehicleServiceAreas)
        hasher.combine(selectedAffiliatePreferences)
    }
    @Published var selectedVehicleTypes: Set<Int> = []
    @Published var selectedAmenities: Set<Int> = []
    @Published var selectedSpecialAmenities: Set<Int> = []
    @Published var selectedInteriors: Set<Int> = []
    @Published var selectedMakes: Set<Int> = []
    @Published var selectedModels: Set<Int> = []
    @Published var selectedYears: Set<Int> = []
    @Published var selectedColors: Set<Int> = []
    @Published var selectedDriverLanguages: Set<Int> = []
    @Published var selectedDriverDresses: Set<Int> = []
    @Published var selectedDriverGenders: Set<String> = []
    @Published var selectedDriverBackgrounds: Set<Int> = []
    @Published var selectedVehicleServiceAreas: Set<String> = []
    @Published var selectedAffiliatePreferences: Set<String> = []
    
    func clearAll() {
        selectedVehicleTypes.removeAll()
        selectedAmenities.removeAll()
        selectedSpecialAmenities.removeAll()
        selectedInteriors.removeAll()
        selectedMakes.removeAll()
        selectedModels.removeAll()
        selectedYears.removeAll()
        selectedColors.removeAll()
        selectedDriverLanguages.removeAll()
        selectedDriverDresses.removeAll()
        selectedDriverGenders.removeAll()
        selectedDriverBackgrounds.removeAll()
        selectedVehicleServiceAreas.removeAll()
        selectedAffiliatePreferences.removeAll()
    }
    
    func hasAnySelection() -> Bool {
        return !selectedVehicleTypes.isEmpty ||
               !selectedAmenities.isEmpty ||
               !selectedSpecialAmenities.isEmpty ||
               !selectedInteriors.isEmpty ||
               !selectedMakes.isEmpty ||
               !selectedModels.isEmpty ||
               !selectedYears.isEmpty ||
               !selectedColors.isEmpty ||
               !selectedDriverLanguages.isEmpty ||
               !selectedDriverDresses.isEmpty ||
               !selectedDriverGenders.isEmpty ||
               !selectedVehicleServiceAreas.isEmpty ||
               !selectedAffiliatePreferences.isEmpty
    }
}
