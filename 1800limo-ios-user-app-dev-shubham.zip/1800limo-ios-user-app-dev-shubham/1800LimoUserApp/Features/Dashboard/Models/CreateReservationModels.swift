import Foundation

// MARK: - Create Reservation Request Models

struct CreateReservationRequest: Codable {
    let serviceType: String
    let transferType: String
    let returnTransferType: String
    let numberOfHours: Int
    let accountType: String
    let changeIndividualData: Bool
    let passengerName: String
    let passengerEmail: String
    let passengerCell: String
    let passengerCellIsd: String
    let passengerCellCountry: String
    let totalPassengers: Int
    let luggageCount: Int
    let bookingInstructions: String
    let returnBookingInstructions: String
    let affiliateType: String
    let affiliateId: String
    let loseAffiliateName: String
    let loseAffiliatePhone: String
    let loseAffiliatePhoneIsd: String
    let loseAffiliatePhoneCountry: String
    let loseAffiliateEmail: String
    let vehicleType: String
    let vehicleTypeName: String
    let vehicleId: Int
    let vehicleMake: String
    let vehicleMakeName: String
    let vehicleModel: String
    let vehicleModelName: String
    let vehicleYear: String
    let vehicleYearName: String
    let vehicleColor: String
    let vehicleColorName: String
    let vehicleLicensePlate: String
    let vehicleSeats: String
    let driverId: String
    let driverName: String
    let driverGender: String
    let driverCell: String
    let driverCellIsd: String
    let driverCellCountry: String
    let driverEmail: String
    let driverPhoneType: String
    let driverImageId: String
    let vehicleImageId: String
    let meetGreetChoices: Int
    let meetGreetChoicesName: String
    let numberOfVehicles: Int
    let pickupDate: String
    let pickupTime: String
    let extraStops: [ExtraStopRequest]
    let pickup: String
    let pickupLatitude: String
    let pickupLongitude: String
    let pickupAirportOption: AirportOption?
    let pickupAirport: Int
    let pickupAirportName: String
    let pickupAirportLatitude: Double
    let pickupAirportLongitude: Double
    let pickupAirlineOption: AirlineOption?
    let pickupAirline: Int
    let pickupAirlineName: String
    let pickupFlight: String
    let originAirportCity: String
    let cruisePort: String
    let cruiseName: String
    let cruiseTime: String
    let dropoff: String
    let dropoffLatitude: String
    let dropoffLongitude: String
    let dropoffAirportOption: AirportOption?
    let dropoffAirport: Int
    let dropoffAirportName: String
    let dropoffAirportLatitude: Double
    let dropoffAirportLongitude: Double
    let dropoffAirlineOption: AirlineOption?
    let dropoffAirline: Int
    let dropoffAirlineName: String
    let dropoffFlight: String
    let returnMeetGreetChoices: Int
    let returnMeetGreetChoicesName: String
    let returnPickupDate: String
    let returnPickupTime: String
    let returnExtraStops: [ExtraStopRequest]
    let returnPickup: String
    let returnPickupLatitude: Double
    let returnPickupLongitude: Double
    let returnPickupAirportOption: AirportOption?
    let returnPickupAirport: Int
    let returnPickupAirportName: String
    let returnPickupAirportLatitude: Double
    let returnPickupAirportLongitude: Double
    let returnPickupAirlineOption: AirlineOption?
    let returnPickupAirline: Int
    let returnPickupAirlineName: String
    let returnPickupFlight: String
    let returnCruisePort: String
    let returnCruiseName: String
    let returnCruiseTime: String
    let returnDropoff: String
    let returnDropoffLatitude: Double
    let returnDropoffLongitude: Double
    let returnDropoffAirportOption: AirportOption?
    let returnDropoffAirport: Int
    let returnDropoffAirportName: String
    let returnDropoffAirportLatitude: Double
    let returnDropoffAirportLongitude: Double
    let returnDropoffAirlineOption: AirlineOption?
    let returnDropoffAirline: Int
    let returnDropoffAirlineName: String
    let returnDropoffFlight: String
    let driverLanguages: [Int]
    let driverDresses: [String]
    let amenities: [String]
    let chargedAmenities: [String]
    let journeyDistance: Int
    let journeyTime: Int
    let returnJourneyDistance: Int
    let returnJourneyTime: Int
    let reservationId: String
    let updateType: String
    let departingAirportCity: String
    let currency: String
    let isMasterVehicle: Bool
    let proceed: Bool
    let rateArray: BookingRateArray
    let returnRateArray: BookingRateArray?
    let grandTotal: Double
    let subTotal: Double
    let returnSubTotal: Double?
    let returnGrandTotal: Double?
    let minRateInvolved: Bool
    let sharesArray: SharesArray
    let returnSharesArray: SharesArray?
    let returnAffiliateType: String
    let returnDistance: Int
    let returnVehicleId: Int
    let noOfHours: String
    let fboAddress: String
    let fboName: String
    let returnFboAddress: String
    let returnFboName: String
    
    enum CodingKeys: String, CodingKey {
        case serviceType = "service_type"
        case transferType = "transfer_type"
        case returnTransferType = "return_transfer_type"
        case numberOfHours = "number_of_hours"
        case accountType = "account_type"
        case changeIndividualData = "change_individual_data"
        case passengerName = "passenger_name"
        case passengerEmail = "passenger_email"
        case passengerCell = "passenger_cell"
        case passengerCellIsd = "passenger_cell_isd"
        case passengerCellCountry = "passenger_cell_country"
        case totalPassengers = "total_passengers"
        case luggageCount = "luggage_count"
        case bookingInstructions = "booking_instructions"
        case returnBookingInstructions = "return_booking_instructions"
        case affiliateType = "affiliate_type"
        case affiliateId = "affiliate_id"
        case loseAffiliateName = "lose_affiliate_name"
        case loseAffiliatePhone = "lose_affiliate_phone"
        case loseAffiliatePhoneIsd = "lose_affiliate_phone_isd"
        case loseAffiliatePhoneCountry = "lose_affiliate_phone_country"
        case loseAffiliateEmail = "lose_affiliate_email"
        case vehicleType = "vehicle_type"
        case vehicleTypeName = "vehicle_type_name"
        case vehicleId = "vehicle_id"
        case vehicleMake = "vehicle_make"
        case vehicleMakeName = "vehicle_make_name"
        case vehicleModel = "vehicle_model"
        case vehicleModelName = "vehicle_model_name"
        case vehicleYear = "vehicle_year"
        case vehicleYearName = "vehicle_year_name"
        case vehicleColor = "vehicle_color"
        case vehicleColorName = "vehicle_color_name"
        case vehicleLicensePlate = "vehicle_license_plate"
        case vehicleSeats = "vehicle_seats"
        case driverId = "driver_id"
        case driverName = "driver_name"
        case driverGender = "driver_gender"
        case driverCell = "driver_cell"
        case driverCellIsd = "driver_cell_isd"
        case driverCellCountry = "driver_cell_country"
        case driverEmail = "driver_email"
        case driverPhoneType = "driver_phone_type"
        case driverImageId = "driver_image_id"
        case vehicleImageId = "vehicle_image_id"
        case meetGreetChoices = "meet_greet_choices"
        case meetGreetChoicesName = "meet_greet_choices_name"
        case numberOfVehicles = "number_of_vehicles"
        case pickupDate = "pickup_date"
        case pickupTime = "pickup_time"
        case extraStops = "extra_stops"
        case pickup
        case pickupLatitude = "pickup_latitude"
        case pickupLongitude = "pickup_longitude"
        case pickupAirportOption = "pickup_airport_option"
        case pickupAirport = "pickup_airport"
        case pickupAirportName = "pickup_airport_name"
        case pickupAirportLatitude = "pickup_airport_latitude"
        case pickupAirportLongitude = "pickup_airport_longitude"
        case pickupAirlineOption = "pickup_airline_option"
        case pickupAirline = "pickup_airline"
        case pickupAirlineName = "pickup_airline_name"
        case pickupFlight = "pickup_flight"
        case originAirportCity = "origin_airport_city"
        case cruisePort = "cruise_port"
        case cruiseName = "cruise_name"
        case cruiseTime = "cruise_time"
        case dropoff
        case dropoffLatitude = "dropoff_latitude"
        case dropoffLongitude = "dropoff_longitude"
        case dropoffAirportOption = "dropoff_airport_option"
        case dropoffAirport = "dropoff_airport"
        case dropoffAirportName = "dropoff_airport_name"
        case dropoffAirportLatitude = "dropoff_airport_latitude"
        case dropoffAirportLongitude = "dropoff_airport_longitude"
        case dropoffAirlineOption = "dropoff_airline_option"
        case dropoffAirline = "dropoff_airline"
        case dropoffAirlineName = "dropoff_airline_name"
        case dropoffFlight = "dropoff_flight"
        case returnMeetGreetChoices = "return_meet_greet_choices"
        case returnMeetGreetChoicesName = "return_meet_greet_choices_name"
        case returnPickupDate = "return_pickup_date"
        case returnPickupTime = "return_pickup_time"
        case returnExtraStops = "return_extra_stops"
        case returnPickup = "return_pickup"
        case returnPickupLatitude = "return_pickup_latitude"
        case returnPickupLongitude = "return_pickup_longitude"
        case returnPickupAirportOption = "return_pickup_airport_option"
        case returnPickupAirport = "return_pickup_airport"
        case returnPickupAirportName = "return_pickup_airport_name"
        case returnPickupAirportLatitude = "return_pickup_airport_latitude"
        case returnPickupAirportLongitude = "return_pickup_airport_longitude"
        case returnPickupAirlineOption = "return_pickup_airline_option"
        case returnPickupAirline = "return_pickup_airline"
        case returnPickupAirlineName = "return_pickup_airline_name"
        case returnPickupFlight = "return_pickup_flight"
        case returnCruisePort = "return_cruise_port"
        case returnCruiseName = "return_cruise_name"
        case returnCruiseTime = "return_cruise_time"
        case returnDropoff = "return_dropoff"
        case returnDropoffLatitude = "return_dropoff_latitude"
        case returnDropoffLongitude = "return_dropoff_longitude"
        case returnDropoffAirportOption = "return_dropoff_airport_option"
        case returnDropoffAirport = "return_dropoff_airport"
        case returnDropoffAirportName = "return_dropoff_airport_name"
        case returnDropoffAirportLatitude = "return_dropoff_airport_latitude"
        case returnDropoffAirportLongitude = "return_dropoff_airport_longitude"
        case returnDropoffAirlineOption = "return_dropoff_airline_option"
        case returnDropoffAirline = "return_dropoff_airline"
        case returnDropoffAirlineName = "return_dropoff_airline_name"
        case returnDropoffFlight = "return_dropoff_flight"
        case driverLanguages = "driver_languages"
        case driverDresses = "driver_dresses"
        case amenities
        case chargedAmenities
        case journeyDistance = "journeyDistance"
        case journeyTime
        case returnJourneyDistance
        case returnJourneyTime
        case reservationId = "reservation_id"
        case updateType
        case departingAirportCity = "departing_airport_city"
        case currency
        case isMasterVehicle = "is_master_vehicle"
        case proceed
        case rateArray
        case grandTotal = "grand_total"
        case subTotal = "sub_total"
        case minRateInvolved = "min_rate_involved"
        case sharesArray = "shares_array"
        case returnAffiliateType = "return_affiliate_type"
        case returnDistance = "return_distance"
        case returnVehicleId = "return_vehicle_id"
        case noOfHours = "no_of_hours"
        case returnRateArray = "returnRateArray"
        case returnSubTotal = "return_sub_total"
        case returnGrandTotal = "return_grand_total"
        case returnSharesArray = "return_shares_array"
        case fboAddress = "fbo_address"
        case fboName = "fbo_name"
        case returnFboAddress = "return_fbo_address"
        case returnFboName = "return_fbo_name"
    }
}

struct AirlineOption: Codable {
    let id: Int
    let code: String
    let name: String
    let country: String
    let formattedName: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case code
        case name
        case country
        case formattedName = "formatted_name"
    }
}

struct AirportOption: Codable {
    let id: Int
    let code: String
    let name: String
    let city: String
    let country: String
    let lat: Double
    let long: Double
    let formattedName: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case code
        case name
        case city
        case country
        case lat
        case long
        case formattedName = "formatted_name"
    }
}

struct SharesArray: Codable {
    let baseRate: Double
    let grandTotal: Double
    let stripeFee: Double
    let adminShare: Double
    let deductedAdminShare: Double
    let affiliateShare: Double
    let travelAgentShare: Double?
    let farmoutShare: Double?
    let returnGrandTotal: Double?
    
    enum CodingKeys: String, CodingKey {
        case baseRate
        case grandTotal
        case stripeFee
        case adminShare
        case deductedAdminShare = "deducted_admin_share"
        case affiliateShare
        case travelAgentShare
        case farmoutShare
        case returnGrandTotal
    }
}

// MARK: - Create Reservation Response Models

struct CreateReservationResponse: Codable {
    let success: Bool
    let data: CreateReservationData
    let message: String
    let currency: ReservationCurrencyInfo
}

struct CreateReservationData: Codable {
    let reservationId: Int
    let orderId: Int
    
    enum CodingKeys: String, CodingKey {
        case reservationId = "reservation_id"
        case orderId = "order_id"
    }
}

struct ReservationCurrencyInfo: Codable {
    let countryName: String
    let currency: String
    let currencyCountry: String
    let symbol: String
    let dateFormat: String
    
    enum CodingKeys: String, CodingKey {
        case countryName
        case currency
        case currencyCountry
        case symbol
        case dateFormat
    }
}
