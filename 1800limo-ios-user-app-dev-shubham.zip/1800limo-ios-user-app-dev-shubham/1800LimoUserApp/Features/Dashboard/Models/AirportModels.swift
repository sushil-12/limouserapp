import Foundation

// MARK: - Airport Response Models
struct AirportResponse: Codable {
    let success: Bool
    let data: AirportData
    let message: String
    let currency: Currency
    let pagination: PaginationInfo?
}

struct AirportData: Codable {
    let airportsData: [Airport]
}

struct PaginationInfo: Codable {
    let currentPage: Int
    let totalPages: Int
    let totalItems: Int
    let itemsPerPage: Int
    let hasNextPage: Bool
    let hasPreviousPage: Bool
}

struct Airport: Codable, Identifiable, Hashable {
    let id: Int
    let code: String
    let name: String
    let city: String
    let country: String
    let lat: Double?
    let long: Double?
    
    // Computed property for display
    var displayName: String {
        return "\(code) - \(name)"
    }
    
    var fullDisplayName: String {
        return "\(code) - \(name), \(city), \(country)"
    }
    
    // Hashable conformance
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Airport, rhs: Airport) -> Bool {
        return lhs.id == rhs.id
    }
}

struct Currency: Codable {
    let countryName: String
    let currency: String
    let currencyCountry: String
    let symbol: String
    let dateFormat: String
}




