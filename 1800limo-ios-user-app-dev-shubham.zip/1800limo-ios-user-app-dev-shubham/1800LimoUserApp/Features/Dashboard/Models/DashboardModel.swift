import Foundation
import CoreLocation
import MapKit

struct LocationItem: Identifiable {
    let id = UUID()
    let name: String
    let address: String
    let type: LocationType
    let icon: String
}

enum LocationType {
    case home
    case work
    case recent
    case saved
}

struct CarLocation: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
    let isUserLocation: Bool
}

struct MapRegion {
    let center: CLLocationCoordinate2D
    let span: MKCoordinateSpan
}
