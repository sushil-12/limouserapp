import Foundation

// MARK: - Airline Response Models
struct AirlineResponse: Codable {
    let success: Bool
    let data: AirlineData
    let message: String
}

struct AirlineData: Codable {
    let airlinesData: [Airline]
}

struct Airline: Codable, Identifiable, Hashable {
    let id: Int
    let code: String
    let name: String
    let country: String?
    
    // Computed property for display
    var displayName: String {
        return "\(code) - \(name)"
    }
    
    var fullDisplayName: String {
        if let country = country {
            return "\(code) - \(name), \(country)"
        }
        return "\(code) - \(name)"
    }
    
    // Hashable conformance
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Airline, rhs: Airline) -> Bool {
        return lhs.id == rhs.id
    }
}

// MARK: - Meet and Greet Models
struct MeetGreetChoice: Codable, Identifiable, Hashable {
    let id: Int
    let message: String
    
    static func == (lhs: MeetGreetChoice, rhs: MeetGreetChoice) -> Bool {
        return lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

struct MeetGreetResponse: Codable {
    let success: Bool
    let data: MeetGreetData
    let message: String
}

struct MeetGreetData: Codable {
    let meetGreets: [MeetGreetChoice]
}




