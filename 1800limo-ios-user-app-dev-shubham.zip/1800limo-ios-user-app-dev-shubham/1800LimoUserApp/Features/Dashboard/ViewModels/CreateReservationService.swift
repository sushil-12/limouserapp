import Foundation
import Combine

class CreateReservationService: ObservableObject {
    @Published var isLoading = false
    @Published var reservationData: CreateReservationData?
    @Published var currency: ReservationCurrencyInfo?
    @Published var errorMessage: String?
    
    func createReservation(request: CreateReservationRequest) async -> (success: Bool, data: CreateReservationData?, currency: ReservationCurrencyInfo?, error: String?) {
        DispatchQueue.main.async {
            self.isLoading = true
            self.errorMessage = nil
        }
        
        print("🚀 CreateReservationService - Creating reservation...")
        print("📋 Request details:")
        print("  Service Type: \(request.serviceType)")
        print("  Transfer Type: \(request.transferType)")
        print("  Pickup: \(request.pickup)")
        print("  Dropoff: \(request.dropoff)")
        print("  Grand Total: \(request.grandTotal)")
        
        do {
            // Convert request to dictionary
            let jsonData = try JSONEncoder().encode(request)
            let bodyDict = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] ?? [:]
            
            // Print the complete payload being sent
            print("🚀 COMPLETE API PAYLOAD BEING SENT:")
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print(jsonString)
            }
            print("📋 PAYLOAD DICTIONARY:")
            print(bodyDict)
            
            // Make the actual API call
            let response: CreateReservationResponse = try await NetworkService.shared.request(
                endpoint: .createReservation,
                body: bodyDict,
                responseType: CreateReservationResponse.self
            )
            
            DispatchQueue.main.async {
                self.reservationData = response.data
                self.currency = response.currency
                self.isLoading = false
                print("✅ CreateReservationService - API call successful!")
                print("  Reservation ID: \(response.data.reservationId)")
                print("  Order ID: \(response.data.orderId)")
                print("  Message: \(response.message)")
                print("  Success: \(response.success)")
            }
            
            return (success: true, data: response.data, currency: response.currency, error: nil)
        } catch {
            let errorMessage = error.localizedDescription
            DispatchQueue.main.async {
                self.errorMessage = errorMessage
                self.isLoading = false
                print("❌ CreateReservationService - Failed to create reservation: \(errorMessage)")
            }
            return (success: false, data: nil, currency: nil, error: errorMessage)
        }
    }

    func duplicateReservation(request: CreateReservationRequest) async -> (success: Bool, data: CreateReservationData?, currency: ReservationCurrencyInfo?, error: String?) {
        DispatchQueue.main.async {
            self.isLoading = true
            self.errorMessage = nil
        }
        
        print("🚀 CreateReservationService - Duplicating reservation...")
        
        do {
            let jsonData = try JSONEncoder().encode(request)
            let bodyDict = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] ?? [:]
            
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print("🚀 DUPLICATE API PAYLOAD BEING SENT:")
                print(jsonString)
            }
            print("📋 DUPLICATE PAYLOAD DICTIONARY:")
            print(bodyDict)
            
            let response: CreateReservationResponse = try await NetworkService.shared.request(
                endpoint: .duplicateReservation,
                body: bodyDict,
                responseType: CreateReservationResponse.self
            )
            
            DispatchQueue.main.async {
                self.reservationData = response.data
                self.currency = response.currency
                self.isLoading = false
                print("✅ Duplicate reservation API call successful!")
                print("  Reservation ID: \(response.data.reservationId)")
                print("  Order ID: \(response.data.orderId)")
                print("  Message: \(response.message)")
                print("  Success: \(response.success)")
            }
            
            return (success: true, data: response.data, currency: response.currency, error: nil)
        } catch {
            let errorMessage = error.localizedDescription
            DispatchQueue.main.async {
                self.errorMessage = errorMessage
                self.isLoading = false
                print("❌ Duplicate reservation failed: \(errorMessage)")
            }
            return (success: false, data: nil, currency: nil, error: errorMessage)
        }
    }
}
