//
//  UserBookingsViewModel.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation
import SwiftUI

class UserBookingsViewModel: ObservableObject {
    @Published var bookings: [UserBooking] = []
    @Published var isLoading = false
    @Published var showError = false
    @Published var errorMessage: String?
    
    // Date range properties
    @Published var selectedWeekStart = Date()
    @Published var selectedWeekEnd = Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date()
    @Published var selectedTimePeriod: TimePeriod = .weekly
    
    // Search functionality
    @Published var searchText = ""
    
    // Pagination
    @Published var currentPage = 1
    @Published var totalPages = 1
    @Published var totalBookings = 0
    
    private let networkService = NetworkService.shared
    private let calendar = Calendar.current
    
    init() {
        print("🚀 UserBookingsViewModel initialized")
        setupInitialDateRange()
    }
    
    private func setupInitialDateRange() {
        let today = Date()
        let weekStart = calendar.dateInterval(of: .weekOfYear, for: today)?.start ?? today
        let weekEnd = calendar.date(byAdding: .day, value: 6, to: weekStart) ?? today
        
        selectedWeekStart = weekStart
        selectedWeekEnd = weekEnd
        
        print("📅 Initial date range setup:")
        print("   Week start: \(formatDate(weekStart))")
        print("   Week end: \(formatDate(weekEnd))")
    }
    
    // MARK: - API Calls
    
    func fetchBookings(append: Bool = false) {
    
        isLoading = true
        if !append {
            currentPage = 1
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let fromDate = dateFormatter.string(from: selectedWeekStart)
        let toDate = dateFormatter.string(from: selectedWeekEnd)
        
        let currentDate = dateFormatter.string(from: Date())
        let currentTime = getCurrentTimeString()
        
        // useDateFilter should be true for all time periods (weekly, monthly, yearly, custom)
        // but false when searching (when searchText is not empty)
        let useDateFilter = searchText.isEmpty ? "true" : "false"
        
        let parameters = [
            "from": fromDate,
            "to": toDate,
            "search": searchText,
            "useDateFilter": useDateFilter,
            "current_date": currentDate,
            "current_time": currentTime,
            "page": "\(currentPage)"
        ]
        
        print("🌐 API Call Parameters:")
        print("   from: \(fromDate)")
        print("   to: \(toDate)")
        print("   search: \(searchText)")
        print("   useDateFilter: \(useDateFilter) (true for date periods, false when searching)")
        print("   current_date: \(currentDate)")
        print("   current_time: \(currentTime)")
        print("   page: \(currentPage)")
        print("   selectedTimePeriod: \(selectedTimePeriod.rawValue)")
        
        Task {
            do {
                let response = try await networkService.request(
                    endpoint: .getAllReservations,
                    queryParameters: parameters,
                    responseType: UserBookingsResponse.self
                )
                
                await MainActor.run {
                    self.isLoading = false
                    
                    if response.success {
                        if append {
                            self.bookings.append(contentsOf: response.data.data)
                        } else {
                            self.bookings = response.data.data
                        }
                        self.currentPage = response.data.current_page
                        self.totalPages = response.data.last_page
                        self.totalBookings = response.data.total
                    } else {
                        self.showError = true
                        self.errorMessage = response.message
                    }
                }
            } catch {
                await MainActor.run {
                    self.isLoading = false
                    self.showError = true
                    self.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    func refreshBookings() {
        currentPage = 1
        fetchBookings()
    }
    
    func cancelBooking(bookingId: Int) async throws -> CancelBookingResponse {
        try await networkService.request(
            endpoint: .cancelBooking(bookingId: bookingId),
            responseType: CancelBookingResponse.self
        )
    }
    
    func loadNextPage() {
        if currentPage < totalPages {
            currentPage += 1
            fetchBookings(append: true)
        }
    }
    
    // MARK: - Date Range Management
    
    var dateRangeString: String {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        
        let daysDifference = calendar.dateComponents([.day], from: selectedWeekStart, to: selectedWeekEnd).day ?? 0
        
        // Check if it's a full year (364+ days and same year)
        if daysDifference >= 364 && calendar.isDate(selectedWeekStart, equalTo: selectedWeekEnd, toGranularity: .year) {
            dateFormatter.dateFormat = "yyyy"
            return dateFormatter.string(from: selectedWeekStart)
        }
        
        // Check if it's a full month (28-31 days and same month)
        if daysDifference >= 28 && calendar.isDate(selectedWeekStart, equalTo: selectedWeekEnd, toGranularity: .month) {
            dateFormatter.dateFormat = "MMMM yyyy"
            return dateFormatter.string(from: selectedWeekStart)
        }
        
        // Default to date range format (for weekly and custom ranges)
        dateFormatter.dateFormat = "MMM dd"
        let startString = dateFormatter.string(from: selectedWeekStart)
        let endString = dateFormatter.string(from: selectedWeekEnd)
        return "\(startString) - \(endString)"
    }
    
    // MARK: - Navigation Functions
    
    func goToPreviousWeek() {
        selectedWeekStart = calendar.date(byAdding: .day, value: -7, to: selectedWeekStart) ?? selectedWeekStart
        selectedWeekEnd = calendar.date(byAdding: .day, value: -7, to: selectedWeekEnd) ?? selectedWeekEnd
        refreshBookings()
    }
    
    func goToNextWeek() {
        selectedWeekStart = calendar.date(byAdding: .day, value: 7, to: selectedWeekStart) ?? selectedWeekStart
        selectedWeekEnd = calendar.date(byAdding: .day, value: 7, to: selectedWeekEnd) ?? selectedWeekEnd
        refreshBookings()
    }
    
    func goToPreviousMonth() {
        let currentYear = calendar.component(.year, from: selectedWeekStart)
        let currentMonth = calendar.component(.month, from: selectedWeekStart)
        
        let previousMonth = currentMonth == 1 ? 12 : currentMonth - 1
        let previousYear = currentMonth == 1 ? currentYear - 1 : currentYear
        
        let previousMonthStart = calendar.date(from: DateComponents(year: previousYear, month: previousMonth, day: 1)) ?? selectedWeekStart
        let previousMonthEnd = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: previousMonthStart) ?? selectedWeekStart
        
        selectedWeekStart = previousMonthStart
        selectedWeekEnd = previousMonthEnd
        refreshBookings()
    }
    
    func goToNextMonth() {
        let currentYear = calendar.component(.year, from: selectedWeekStart)
        let currentMonth = calendar.component(.month, from: selectedWeekStart)
        
        let nextMonth = currentMonth == 12 ? 1 : currentMonth + 1
        let nextYear = currentMonth == 12 ? currentYear + 1 : currentYear
        
        let nextMonthStart = calendar.date(from: DateComponents(year: nextYear, month: nextMonth, day: 1)) ?? selectedWeekStart
        let nextMonthEnd = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: nextMonthStart) ?? selectedWeekStart
        
        selectedWeekStart = nextMonthStart
        selectedWeekEnd = nextMonthEnd
        refreshBookings()
    }
    
    func goToPreviousYear() {
        let currentYear = calendar.component(.year, from: selectedWeekStart)
        let previousYear = currentYear - 1
        
        let previousYearStart = calendar.date(from: DateComponents(year: previousYear, month: 1, day: 1)) ?? selectedWeekStart
        let previousYearEnd = calendar.date(from: DateComponents(year: previousYear, month: 12, day: 31)) ?? selectedWeekStart
        
        selectedWeekStart = previousYearStart
        selectedWeekEnd = previousYearEnd
        refreshBookings()
    }
    
    func goToNextYear() {
        let currentYear = calendar.component(.year, from: selectedWeekStart)
        let nextYear = currentYear + 1
        
        let nextYearStart = calendar.date(from: DateComponents(year: nextYear, month: 1, day: 1)) ?? selectedWeekStart
        let nextYearEnd = calendar.date(from: DateComponents(year: nextYear, month: 12, day: 31)) ?? selectedWeekStart
        
        selectedWeekStart = nextYearStart
        selectedWeekEnd = nextYearEnd
        refreshBookings()
    }
    
    func handleTimePeriodChange(_ newPeriod: TimePeriod) {
        print("🔄 handleTimePeriodChange called with: \(newPeriod.rawValue)")
        
        selectedTimePeriod = newPeriod
        let today = Date()
        
        print("🔄 Time period changed to: \(newPeriod.rawValue)")
        
        switch newPeriod {
        case .weekly:
            let weekStart = calendar.dateInterval(of: .weekOfYear, for: today)?.start ?? today
            let weekEnd = calendar.date(byAdding: .day, value: 6, to: weekStart) ?? today
            selectedWeekStart = weekStart
            selectedWeekEnd = weekEnd
            print("📅 Weekly: \(formatDate(weekStart)) to \(formatDate(weekEnd))")
        case .monthly:
            let monthStart = calendar.dateInterval(of: .month, for: today)?.start ?? today
            let monthEnd = calendar.date(byAdding: .day, value: -1, to: calendar.date(byAdding: .month, value: 1, to: monthStart) ?? today) ?? today
            selectedWeekStart = monthStart
            selectedWeekEnd = monthEnd
            print("📅 Monthly: \(formatDate(monthStart)) to \(formatDate(monthEnd))")
        case .yearly:
            let yearStart = calendar.dateInterval(of: .year, for: today)?.start ?? today
            let yearEnd = calendar.date(byAdding: .day, value: -1, to: calendar.date(byAdding: .year, value: 1, to: yearStart) ?? today) ?? today
            selectedWeekStart = yearStart
            selectedWeekEnd = yearEnd
            print("📅 Yearly: \(formatDate(yearStart)) to \(formatDate(yearEnd))")
        case .custom:
            // Keep current selection for custom
            print("📅 Custom: \(formatDate(selectedWeekStart)) to \(formatDate(selectedWeekEnd))")
            break
        }
        
        print("🌐 Calling refreshBookings() for \(newPeriod.rawValue)")
        DispatchQueue.main.async {
            self.refreshBookings()
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }
    
    func handleDateRangeSelection(startDate: Date, endDate: Date) {
        selectedWeekStart = startDate
        selectedWeekEnd = endDate
        refreshBookings()
    }
    
    // MARK: - Search
    
    func handleSearch(_ searchText: String) {
        self.searchText = searchText
        // Debounce search to avoid too many API calls
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            if self.searchText == searchText {
                self.refreshBookings()
            }
        }
    }
    
    // MARK: - Computed Properties
    
    var totalSpent: Double {
        bookings.reduce(0) { total, booking in
            total + (booking.grand_total ?? 0.0)
        }
    }
    
    var completedRides: Int {
        bookings.filter { $0.booking_status.lowercased() == "completed" }.count
    }
    
    var pendingRides: Int {
        bookings.filter { $0.booking_status.lowercased() == "pending" }.count
    }
    
    // MARK: - Helper Functions
    
    private func getCurrentTimeString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: Date())
    }
}
