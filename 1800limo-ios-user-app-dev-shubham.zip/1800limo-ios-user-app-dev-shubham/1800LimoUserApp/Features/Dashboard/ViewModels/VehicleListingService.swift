import Foundation

@MainActor
class VehicleListingService: ObservableObject {
    @Published var vehicles: [VehicleListingItem] = []
    @Published var currency: VehicleListingCurrency?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func fetchVehicleListing(request: VehicleListingRequest) async {
        isLoading = true
        errorMessage = nil
        
        let endpoint = APIEndpoints.vehicleListing(request: request)
        
        // Print the request payload for debugging
        print("🚀 VEHICLE LISTING API REQUEST:")
        print("URL: \(endpoint.path)")
        print("Method: \(endpoint.method.rawValue)")
        
        if let bodyData = endpoint.body {
            print("Request Body:")
            if let jsonString = String(data: bodyData, encoding: .utf8) {
                print(jsonString)
            }
            
            // Also print as dictionary for better readability
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: bodyData)
                let prettyData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
                if let prettyString = String(data: prettyData, encoding: .utf8) {
                    print("Pretty Request Body:")
                    print(prettyString)
                }
            } catch {
                print("Error formatting request body: \(error)")
            }
        }
        
        do {
            print("🔍 ATTEMPTING TO DECODE VEHICLE LISTING RESPONSE...")
            let response: VehicleListingResponse = try await NetworkService.performRequest(
                endpoint: endpoint,
                body: request
            )
            
            print("✅ VEHICLE LISTING API RESPONSE:")
            print("Success: \(response.success)")
            print("Message: \(response.message)")
            print("Vehicles count: \(response.data.count)")
            print("Currency: \(response.currency?.symbol ?? "Unknown")")
            
            vehicles = response.data
            currency = response.currency
            
            print("🖼️ Vehicle Images:")
            for (index, vehicle) in vehicles.enumerated() {
                print("  \(index + 1). \(vehicle.name): \(vehicle.vehicleImages.first ?? "No image")")
                print("     Driver: \(vehicle.driverInformation?.name ?? "No driver info")")
                
                // Get the appropriate price based on service type using the new structure
                let price = vehicle.charterTourPrice ?? 
                           vehicle.roundTripPrice ?? 
                           vehicle.oneWayPrice ?? 0.0
                print("     Price: \(response.currency?.symbol ?? "$")\(price)")
            }
            
        } catch {
            print("❌ VEHICLE LISTING API ERROR:")
            print("Error: \(error)")
            print("Error Type: \(type(of: error))")
            
            if let decodingError = error as? DecodingError {
                print("🔍 DECODING ERROR DETAILS:")
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("  Type Mismatch: Expected \(type), found at path: \(context.codingPath)")
                    print("  Debug Description: \(context.debugDescription)")
                case .keyNotFound(let key, let context):
                    print("  Key Not Found: \(key) at path: \(context.codingPath)")
                case .valueNotFound(let type, let context):
                    print("  Value Not Found: Expected \(type) at path: \(context.codingPath)")
                case .dataCorrupted(let context):
                    print("  Data Corrupted: \(context.debugDescription)")
                @unknown default:
                    print("  Unknown decoding error")
                }
            }
            
            errorMessage = "Failed to fetch vehicle listing: \(error.localizedDescription)"
            
            // Try to get raw response for debugging
            do {
                let jsonData = try JSONEncoder().encode(request)
                let bodyDict = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] ?? [:]
                let rawResponse = try await NetworkService.getRawResponse(endpoint: endpoint, body: bodyDict)
                print("Raw response data:")
                if let responseString = String(data: rawResponse, encoding: .utf8) {
                    print(responseString)
                    
                    // Try to parse as JSON to see the structure
                    if let jsonObject = try? JSONSerialization.jsonObject(with: rawResponse) {
                        let prettyData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
                        if let prettyString = String(data: prettyData, encoding: .utf8) {
                            print("Pretty Response:")
                            print(prettyString)
                            
                            // Analyze the structure of the first vehicle item
                            if let responseDict = jsonObject as? [String: Any],
                               let dataArray = responseDict["data"] as? [[String: Any]],
                               let firstVehicle = dataArray.first {
                                print("🔍 FIRST VEHICLE STRUCTURE ANALYSIS:")
                                print("Available keys: \(firstVehicle.keys.sorted())")
                                
                                // Check for specific fields we're looking for
                                if let id = firstVehicle["id"] {
                                    print("✅ id: \(id) (type: \(type(of: id)))")
                                } else {
                                    print("❌ id: missing")
                                }
                                
                                if let name = firstVehicle["name"] {
                                    print("✅ name: \(name) (type: \(type(of: name)))")
                                } else {
                                    print("❌ name: missing")
                                }
                                
                                if let latitude = firstVehicle["latitude"] {
                                    print("✅ latitude: \(latitude) (type: \(type(of: latitude)))")
                                } else {
                                    print("❌ latitude: missing")
                                }
                                
                                if let longitude = firstVehicle["longitude"] {
                                    print("✅ longitude: \(longitude) (type: \(type(of: longitude)))")
                                } else {
                                    print("❌ longitude: missing")
                                }
                                
                                if let affiliateId = firstVehicle["affiliate_id"] {
                                    print("✅ affiliate_id: \(affiliateId) (type: \(type(of: affiliateId)))")
                                } else {
                                    print("❌ affiliate_id: missing")
                                }
                                
                                if let distance = firstVehicle["distance"] {
                                    print("✅ distance: \(distance) (type: \(type(of: distance)))")
                                } else {
                                    print("❌ distance: missing")
                                }
                                
                                if let driverInfo = firstVehicle["driverInformation"] {
                                    print("✅ driverInformation: \(driverInfo) (type: \(type(of: driverInfo)))")
                                    
                                    // If driverInfo is a dictionary, check its structure
                                    if let driverDict = driverInfo as? [String: Any] {
                                        print("🔍 DRIVER INFORMATION STRUCTURE:")
                                        print("Available keys: \(driverDict.keys.sorted())")
                                        
                                        if let driverId = driverDict["id"] {
                                            print("✅ driver.id: \(driverId) (type: \(type(of: driverId)))")
                                        } else {
                                            print("❌ driver.id: missing")
                                        }
                                        
                                        if let driverName = driverDict["name"] {
                                            print("✅ driver.name: \(driverName) (type: \(type(of: driverName)))")
                                        } else {
                                            print("❌ driver.name: missing")
                                        }
                                    }
                                } else {
                                    print("❌ driverInformation: missing")
                                }
                            }
                        }
                    }
                }
            } catch {
                print("Could not get raw response: \(error)")
            }
        }
        
        isLoading = false
    }
}
