import Foundation
import CoreLocation

// MARK: - Google Maps Directions API Models
struct GoogleMapsDirectionsResponse: Codable {
    let status: String
    let routes: [GoogleMapsRoute]
}

struct GoogleMapsRoute: Codable {
    let legs: [GoogleMapsLeg]
}

struct GoogleMapsLeg: Codable {
    let distance: GoogleMapsDistance
    let duration: GoogleMapsDuration
}

struct GoogleMapsDistance: Codable {
    let value: Double
    let text: String
}

struct GoogleMapsDuration: Codable {
    let value: Double
    let text: String
}

@MainActor
class VehicleService: ObservableObject {
    @Published var vehicles: [Vehicle] = []
    @Published var quoteInfo: QuoteInfo?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func fetchVehicleQuote(request: VehicleQuoteRequest) async {
        isLoading = true
        errorMessage = nil
        
        let endpoint = APIEndpoints.vehicleQuote(request: request)
        
        // Print the request payload with service type emphasis
        print("🚀 VEHICLE QUOTE API REQUEST:")
        print("🔴 SERVICE TYPE: \(request.serviceType.uppercased())")
        print("URL: \(endpoint.path)")
        print("Method: \(endpoint.method.rawValue)")
        
        // Print service-specific details
        print("📋 SERVICE DETAILS:")
        print("  - Service Type: \(request.serviceType)")
        print("  - Pickup Type: \(request.pickupType)")
        print("  - Dropoff Type: \(request.dropoffType)")
        print("  - Has Return Trip: \(request.returnPickupDate != nil)")
        print("  - Return Pickup Date: \(request.returnPickupDate ?? "N/A")")
        print("  - Return Pickup Time: \(request.returnPickupTime ?? "N/A")")
        print("  - Location Info Count: \(request.locationInfo.count)")
        
        if let bodyData = endpoint.body {
            print("Request Body:")
            if let jsonString = String(data: bodyData, encoding: .utf8) {
                print(jsonString)
            }
            
            // Also print as dictionary for better readability
            do {
                let jsonObject = try JSONSerialization.jsonObject(with: bodyData)
                let prettyData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
                if let prettyString = String(data: prettyData, encoding: .utf8) {
                    print("Pretty Request Body:")
                    print(prettyString)
                }
            } catch {
                print("Error formatting request body: \(error)")
            }
        }
        
        // Try the actual API response model first (this should work for all service types)
        do {
            let response: VehicleQuoteResponseActual = try await NetworkService.performRequest(
                endpoint: endpoint,
                body: request
            )
            
            print("✅ VEHICLE QUOTE API RESPONSE (Actual Model):")
            print("🔴 SERVICE TYPE: \(request.serviceType.uppercased())")
            print("Success: \(response.success)")
            print("Message: \(response.message)")
            print("Vehicles count: \(response.data.count)")
            print("Currency: \(response.currency?.currency ?? "Unknown")")
            
            // Print complete raw response for debugging
            print("🔍 COMPLETE RAW API RESPONSE:")
            print("==========================================")
            print("SUCCESS: \(response.success)")
            print("MESSAGE: \(response.message)")
            print("CURRENCY: \(response.currency?.currency ?? "Unknown")")
            print("VEHICLES COUNT: \(response.data.count)")
            print("==========================================")
            
            // Print each vehicle's complete data
            for (index, vehicle) in response.data.enumerated() {
                print("🚗 VEHICLE \(index + 1): \(vehicle.name)")
                print("  - ID: \(vehicle.id)")
                print("  - Vehicle ID: \(vehicle.vehicle_id)")
                print("  - Passenger: \(vehicle.passenger)")
                print("  - Luggage: \(vehicle.luggage)")
                print("  - Image: \(vehicle.cat_img ?? "No image")")
                
                // Print charter tour rate breakdown
                if let charterRate = vehicle.rate_breakdown_charter_tour {
                    print("  📊 CHARTER TOUR RATE BREAKDOWN:")
                    print("    - Sub Total: $\(charterRate.sub_total ?? 0)")
                    print("    - Total: $\(charterRate.total ?? 0)")
                    print("    - Grand Total: $\(charterRate.grand_total ?? 0)")
                    
                    if let rateArray = charterRate.rateArray {
                        print("    - Has Rate Array: Yes")
                        if let allInclusive = rateArray.all_inclusive_rates {
                            print("    - Has All Inclusive Rates: Yes")
                            if let tripRate = allInclusive.trip_rate {
                                print("    - Trip Rate Amount: $\(tripRate.amount ?? 0)")
                                print("    - Trip Rate Base Rate: $\(tripRate.baserate ?? 0)")
                            }
                            if let gratuity = allInclusive.gratuity {
                                print("    - Gratuity Amount: $\(gratuity.amount ?? 0)")
                            }
                            if let tripTax = allInclusive.trip_tax {
                                print("    - Trip Tax Amount: $\(tripTax.amount ?? 0)")
                            }
                        } else {
                            print("    - Has All Inclusive Rates: No")
                        }
                    } else {
                        print("    - Has Rate Array: No")
                    }
                } else {
                    print("  📊 CHARTER TOUR RATE BREAKDOWN: NIL")
                }
                
                // Print one way rate breakdown
                if let oneWayRate = vehicle.rate_breakdown_one_way {
                    print("  📊 ONE WAY RATE BREAKDOWN:")
                    print("    - Sub Total: $\(oneWayRate.sub_total ?? 0)")
                    print("    - Total: $\(oneWayRate.total ?? 0)")
                    print("    - Grand Total: $\(oneWayRate.grand_total ?? 0)")
                } else {
                    print("  📊 ONE WAY RATE BREAKDOWN: NIL")
                }
                
                // Print round trip rate breakdown
                if let roundTripRate = vehicle.rate_breakdown_round_trip {
                    print("  📊 ROUND TRIP RATE BREAKDOWN:")
                    print("    - Sub Total: $\(roundTripRate.sub_total ?? 0)")
                    print("    - Total: \(roundTripRate.total ?? 0)")
                    print("    - Grand Total: $\(roundTripRate.grand_total ?? 0)")
                } else {
                    print("  📊 ROUND TRIP RATE BREAKDOWN: NIL")
                }
                
                print("  ----------------------------------------")
            }
            
            // Convert VehicleActual to Vehicle with proper pricing
            vehicles = response.data.compactMap { vehicleActual in
                var price: Double = 0.0
                
                // Extract price based on service type
                switch request.serviceType {
                case "one_way":
                    if let rateBreakdown = vehicleActual.rate_breakdown_one_way {
                        price = rateBreakdown.grand_total ?? rateBreakdown.total ?? rateBreakdown.sub_total ?? 0.0
                        print("💰 ONE_WAY: \(vehicleActual.name) - Price: $\(price)")
                    }
                    
                case "round_trip":
                    if let rateBreakdown = vehicleActual.rate_breakdown_round_trip {
                        price = rateBreakdown.grand_total ?? rateBreakdown.total ?? rateBreakdown.sub_total ?? 0.0
                        print("💰 ROUND_TRIP: \(vehicleActual.name) - Price: $\(price)")
                    }
                    
                case "charter_tour":
                    if let rateBreakdown = vehicleActual.rate_breakdown_charter_tour {
                        price = rateBreakdown.grand_total ?? rateBreakdown.total ?? rateBreakdown.sub_total ?? 0.0
                        print("💰 CHARTER_TOUR: \(vehicleActual.name) - Price: $\(price)")
                    }
                    
                default:
                    print("⚠️ Unknown service type: \(request.serviceType)")
                }
                
                // Create Vehicle object
                    return Vehicle(
                    id: vehicleActual.id,
                    name: vehicleActual.name,
                        description: nil,
                    image: vehicleActual.cat_img,
                    capacity: vehicleActual.passenger,
                    luggage: vehicleActual.luggage,
                        price: price,
                    currency: response.currency?.currency ?? "USD",
                        features: nil,
                        isAvailable: true
                    )
                }
                
            print("✅ Successfully parsed \(vehicles.count) vehicles using Actual Model")
            print("🚗 PARSED VEHICLE DETAILS:")
                for (index, vehicle) in vehicles.enumerated() {
                print("  \(index + 1). \(vehicle.name)")
                print("     - ID: \(vehicle.id)")
                print("     - Capacity: \(vehicle.capacity)")
                print("     - Luggage: \(vehicle.luggage)")
                print("     - Price: $\(vehicle.price)")
                print("     - Image: \(vehicle.image ?? "No image")")
            }
            
            // Summary of pricing for this service type
            print("💰 PRICING SUMMARY FOR \(request.serviceType.uppercased()):")
            let totalPrice = vehicles.reduce(0) { $0 + $1.price }
            let avgPrice = vehicles.isEmpty ? 0 : totalPrice / Double(vehicles.count)
            print("  - Total vehicles: \(vehicles.count)")
            print("  - Total price: $\(String(format: "%.2f", totalPrice))")
            print("  - Average price: $\(String(format: "%.2f", avgPrice))")
            print("  - Price range: $\(String(format: "%.2f", vehicles.map { $0.price }.min() ?? 0)) - $\(String(format: "%.2f", vehicles.map { $0.price }.max() ?? 0))")
            
                isLoading = false
                return
        } catch {
            print("❌ Actual model failed for \(request.serviceType): \(error)")
            print("🔍 ERROR DETAILS: \(error)")
        }
        
        // Note: We now use the Actual Model above which should handle all cases properly
        // The generic model parsing below is kept as a fallback but should not be needed
        
        print("⚠️ Actual model failed, trying generic fallback...")
        
        // If all models fail, set error message
        errorMessage = "Failed to decode response from all models"
        print("❌ All response models failed")
        
        // Try to get raw response for debugging
        do {
            let jsonData = try JSONEncoder().encode(request)
            let bodyDict = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] ?? [:]
            let rawResponse = try await NetworkService.getRawResponse(endpoint: endpoint, body: bodyDict)
            print("🔍 RAW API RESPONSE FOR \(request.serviceType.uppercased()):")
            if let responseString = String(data: rawResponse, encoding: .utf8) {
                print("Raw response string:")
                print(responseString)
                
                // Try to parse as JSON to see the structure
                if let jsonObject = try? JSONSerialization.jsonObject(with: rawResponse) {
                    let prettyData = try JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted)
                    if let prettyString = String(data: prettyData, encoding: .utf8) {
                        print("🔍 PRETTY FORMATTED RESPONSE:")
                        print(prettyString)
                        
                        // Analyze the response structure
                        if let responseDict = jsonObject as? [String: Any] {
                            print("📊 RESPONSE STRUCTURE ANALYSIS:")
                            print("  - Has 'success': \(responseDict["success"] != nil)")
                            print("  - Has 'message': \(responseDict["message"] != nil)")
                            print("  - Has 'data': \(responseDict["data"] != nil)")
                            
                            if let data = responseDict["data"] {
                                print("  - Data type: \(type(of: data))")
                                if let dataArray = data as? [[String: Any]] {
                                    print("  - Data is array with \(dataArray.count) items")
                                    if let firstItem = dataArray.first {
                                        print("  - First item keys: \(Array(firstItem.keys))")
                                    }
                                } else if let dataDict = data as? [String: Any] {
                                    print("  - Data is dictionary with keys: \(Array(dataDict.keys))")
                                }
                            }
                        }
                    }
                }
            }
        } catch {
            print("❌ Could not get raw response for \(request.serviceType): \(error)")
        }
        
        // Final summary for this service type
        print("📊 FINAL SUMMARY FOR \(request.serviceType.uppercased()):")
        print("  - Total vehicles received: \(vehicles.count)")
        print("  - Has quote info: \(quoteInfo != nil)")
        print("  - Error message: \(errorMessage ?? "None")")
        print("  - Loading state: \(isLoading)")
        print("🔚 END OF VEHICLE QUOTE FOR \(request.serviceType.uppercased())")
        
        isLoading = false
    }
    
    // Helper function to calculate distance between two coordinates
    func calculateDistance(
        from: CLLocationCoordinate2D,
        to: CLLocationCoordinate2D,
        waypoints: [CLLocationCoordinate2D] = []
    ) async -> (distance: CLLocationDistance, duration: TimeInterval) {
        // Use Google Maps Directions API for accurate road distance calculation
        return await calculateRoadDistance(from: from, to: to, waypoints: waypoints)
    }
    
    @MainActor
    private func calculateRoadDistance(
        from: CLLocationCoordinate2D,
        to: CLLocationCoordinate2D,
        waypoints: [CLLocationCoordinate2D]
    ) async -> (distance: CLLocationDistance, duration: TimeInterval) {
        let apiKey = "AIzaSyDjV38fI9kDAaVJKqEq2sdgLAHXQPC3Up4"
        var components = URLComponents(string: "https://maps.googleapis.com/maps/api/directions/json")!
        
        var queryItems = [
            URLQueryItem(name: "origin", value: "\(from.latitude),\(from.longitude)"),
            URLQueryItem(name: "destination", value: "\(to.latitude),\(to.longitude)"),
            URLQueryItem(name: "key", value: apiKey)
        ]
        
        if !waypoints.isEmpty {
            let waypointValue = waypoints
                .map { "via:\($0.latitude),\($0.longitude)" }
                .joined(separator: "|")
            queryItems.append(URLQueryItem(name: "waypoints", value: waypointValue))
        }
        
        components.queryItems = queryItems.compactMap { item in
            guard let value = item.value else { return nil }
            return URLQueryItem(name: item.name, value: value)
        }
        
        guard let url = components.url else {
            print("❌ Invalid Google Maps Directions API URL")
            return fallbackToStraightLineDistance(from: from, to: to)
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(GoogleMapsDirectionsResponse.self, from: data)
            
            if response.status == "OK", let route = response.routes.first {
                var totalDistance: Double = 0
                var totalDuration: Double = 0
                
                if let invalidLeg = route.legs.first(where: { $0.distance.value == 0 }) {
                    print("❌ Invalid leg detected in Google route: \(invalidLeg)")
                    return fallbackToStraightLineDistance(from: from, to: to)
                }
                
                for leg in route.legs {
                    totalDistance += leg.distance.value
                    totalDuration += leg.duration.value
                }
                
                print("🗺️ GOOGLE MAPS DIRECTIONS API:")
                print("Origin: \(from.latitude),\(from.longitude)")
                print("Destination: \(to.latitude),\(to.longitude)")
                if !waypoints.isEmpty {
                    print("Waypoints count: \(waypoints.count)")
                }
                print("Road Distance: \(totalDistance) meters")
                print("Road Duration: \(totalDuration) seconds")
                
                return (totalDistance, totalDuration)
            } else {
                print("❌ Google Maps Directions API error: \(response.status)")
                return fallbackToStraightLineDistance(from: from, to: to)
            }
        } catch {
            print("❌ Google Maps Directions API request failed: \(error)")
            return fallbackToStraightLineDistance(from: from, to: to)
        }
    }
    
    private func fallbackToStraightLineDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> (distance: CLLocationDistance, duration: TimeInterval) {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        
        let distance = fromLocation.distance(from: toLocation)
        // Estimate duration: assume average speed of 60 km/h for city, 100 km/h for highway
        let averageSpeed: Double = distance > 50000 ? 100000.0 : 60000.0 // meters per hour
        let duration = (distance / averageSpeed) * 3600 // convert to seconds
        
        print("⚠️ Using fallback straight-line distance: \(distance) meters")
        return (distance, duration)
    }
    
    // Helper function to format distance and duration
    func formatDistance(_ distance: CLLocationDistance) -> (text: String, value: Int) {
        if distance >= 1000 {
            let km = distance / 1000
            return ("\(String(format: "%.1f", km)) km", Int(distance))
        } else {
            return ("\(Int(distance)) m", Int(distance))
        }
    }
    
    func formatDuration(_ duration: TimeInterval) -> (text: String, value: Int) {
        let hours = Int(duration) / 3600
        let minutes = Int(duration) % 3600 / 60
        
        if hours > 0 {
            return ("\(hours) hours \(minutes) mins", Int(duration))
        } else {
            return ("\(minutes) mins", Int(duration))
        }
    }
    
    // Helper function to create location info array
    // Uses fast fallback calculation instead of blocking Google Maps API call for better performance
    func createLocationInfo(pickupLat: Double?, pickupLong: Double?, dropoffLat: Double?, dropoffLong: Double?) async -> [LocationInfo] {
        print("🗺️ LOCATION CALCULATION DEBUG:")
        print("Pickup Lat: \(pickupLat ?? 0)")
        print("Pickup Long: \(pickupLong ?? 0)")
        print("Dropoff Lat: \(dropoffLat ?? 0)")
        print("Dropoff Long: \(dropoffLong ?? 0)")
        
        guard let pickupLat = pickupLat, let pickupLong = pickupLong,
              let dropoffLat = dropoffLat, let dropoffLong = dropoffLong else {
            print("❌ Missing coordinates, returning empty location info")
            return []
        }
        
        let pickupCoord = CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong)
        let dropoffCoord = CLLocationCoordinate2D(latitude: dropoffLat, longitude: dropoffLong)
        
        // Use fast fallback calculation instead of slow Google Maps API call
        // This allows the vehicle API call to start immediately without blocking
        let (distance, duration) = fallbackToStraightLineDistance(from: pickupCoord, to: dropoffCoord)
        let distanceFormatted = formatDistance(distance)
        let durationFormatted = formatDuration(duration)
        
        print("📏 CALCULATED VALUES (Fast Fallback):")
        print("Distance: \(distance) meters")
        print("Duration: \(duration) seconds")
        print("Formatted Distance: \(distanceFormatted.text)")
        print("Formatted Duration: \(durationFormatted.text)")
        
        let locationInfo = [
            LocationInfo(
                distance: Distance(text: distanceFormatted.text, value: distanceFormatted.value),
                duration: Duration(text: durationFormatted.text, value: durationFormatted.value)
            )
        ]
        
        print("📍 FINAL LOCATION INFO: \(locationInfo)")
        return locationInfo
    }
}
