import Foundation

@MainActor
class AirlineService: ObservableObject {
    @Published var airlines: [Airline] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func fetchAirlines(search: String? = nil) async {
        isLoading = true
        errorMessage = nil
        
        let endpoint = APIEndpoints.airlines(search: search)
        
        do {
            let response: AirlineResponse = try await NetworkService.shared.request(
                endpoint: endpoint,
                responseType: AirlineResponse.self
            )
            airlines = response.data.airlinesData
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    func searchAirlines(query: String) async {
        guard !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            await fetchAirlines() // Fetch all airlines if query is empty
            return
        }
        
        await fetchAirlines(search: query)
    }
    
    func getAirlineById(_ id: Int) -> Airline? {
        return airlines.first { $0.id == id }
    }
    
    func getAirlineByCode(_ code: String) -> Airline? {
        return airlines.first { $0.code == code }
    }
}
