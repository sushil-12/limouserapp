//
//  UserProfileViewModel.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation
import SwiftUI

@MainActor
class UserProfileViewModel: ObservableObject {
    @Published var isLoading = false
    @Published var showError = false
    @Published var errorMessage: String?
    
    // User Profile Data
    @Published var userFullName: String = "User"
    @Published var userPhoneNumber: String = ""
    @Published var userRating: Double = 4.2
    @Published var userImageURL: String?
    
    init() {
        loadUserProfile()
    }
    
    func loadUserProfile() {
        // Load immediately from storage (no delay)
        loadFromStorage()
    }
    
    private func loadFromStorage() {
        // Load user data from storage
        if let userData = StorageManager.shared.getUserData() {
            // Get phone number from user data
            self.userPhoneNumber = userData.phone
            
            // Try to get stored profile name
            if let name = StorageManager.shared.getUserName(), !name.isEmpty {
                self.userFullName = name
                print("✅ [UserProfileViewModel] Loaded name from storage: \(name)")
            } else {
                // If no name in storage, use first name from phone or default
                self.userFullName = "User"
                print("⚠️ [UserProfileViewModel] No name in storage, using default")
            }
            
            // Try to get email
            if let email = StorageManager.shared.getUserEmail() {
                print("✅ [UserProfileViewModel] Email: \(email)")
            }
            
            // Get profile image if available
            if let profileData = StorageManager.shared.getUserProfileData() {
                self.userImageURL = profileData.profilePic
            }
            
            self.userRating = 4.2 // Default rating
        } else {
            // Fallback values if no user data
            self.userFullName = "User"
            self.userPhoneNumber = ""
            self.userRating = 4.2
            print("⚠️ [UserProfileViewModel] No user data found in storage")
        }
    }
    
    func refreshProfile() {
        print("🔄 [UserProfileViewModel] Refreshing profile...")
        loadFromStorage()
    }
}
