import Foundation
import Combine
import SwiftUI

class BookingAuditRecordsViewModel: ObservableObject {
    @Published var events: [BookingAuditEvent] = []
    @Published var isLoading = false
    @Published var showError = false
    @Published var errorMessage: String?
    @Published var totalEvents: Int = 0
    @Published var totalBookings: Int = 0
    @Published var pagination: AuditRecordsPagination?
    @Published var searchText: String = "" {
        didSet {
            // Debounce search
            searchCancellable?.cancel()
            searchCancellable = Just(searchText)
                .delay(for: .milliseconds(500), scheduler: DispatchQueue.main)
                .sink { [weak self] searchValue in
                    self?.performSearch(searchValue)
                }
        }
    }
    
    private var activeDataTask: URLSessionDataTask?
    private var cancellables = Set<AnyCancellable>()
    private var searchCancellable: AnyCancellable?
    private let storageManager = StorageManager.shared
    
    var currentPage: Int = 1
    let perPage: Int = 20
    
    private func performSearch(_ searchValue: String) {
        // Reset to page 1 when searching
        fetchAuditRecords(page: 1, append: false, search: searchValue.isEmpty ? nil : searchValue)
    }
    
    func fetchAuditRecords(page: Int = 1, append: Bool = false, search: String? = nil) {
        // Cancel any existing request
        activeDataTask?.cancel()
        
        isLoading = true
        showError = false
        errorMessage = nil
        
        guard let token = storageManager.getAuthToken() else {
            handleError("Authentication token not found")
            return
        }
        
        currentPage = page
        
        var urlComponents = URLComponents(string: "\(APIConfig.baseURL)\(APIEndpoints.bookingAuditRecords.path)")!
        var queryItems = [
            URLQueryItem(name: "page", value: "\(page)"),
            URLQueryItem(name: "per_page", value: "\(perPage)")
        ]
        
        // Add search query parameter if provided
        if let searchQuery = search, !searchQuery.isEmpty {
            queryItems.append(URLQueryItem(name: "search", value: searchQuery))
        }
        
        urlComponents.queryItems = queryItems
        
        guard let url = urlComponents.url else {
            handleError("Invalid URL")
            return
        }
        
        print("🔍 BookingAuditRecordsViewModel - Fetching audit records from: \(url)")
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let dataTask = URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                if let error = error {
                    // Don't show error if request was cancelled
                    if (error as NSError).code != NSURLErrorCancelled {
                        self?.handleError("Network error: \(error.localizedDescription)")
                    }
                    return
                }
                
                guard let data = data else {
                    self?.handleError("No data received")
                    return
                }
                
                // Log response for debugging
                if let responseString = String(data: data, encoding: .utf8) {
                    print("📡 BookingAuditRecordsViewModel - Raw response:")
                    print(responseString.prefix(500))
                }
                
                do {
                    let response = try JSONDecoder().decode(BookingAuditRecordsResponse.self, from: data)
                    
                    if response.success {
                        self?.handleSuccess(response.data, append: append)
                    } else {
                        self?.handleError(response.message)
                    }
                } catch {
                    print("❌ BookingAuditRecordsViewModel - Decoding error: \(error)")
                    self?.handleError("Failed to parse response: \(error.localizedDescription)")
                }
            }
        }
        
        activeDataTask = dataTask
        dataTask.resume()
    }
    
    private func handleSuccess(_ data: BookingAuditRecordsData, append: Bool) {
        print("✅ BookingAuditRecordsViewModel - Successfully fetched \(data.events.count) events")
        print("📊 Total events: \(data.total_events), Total bookings: \(data.total_bookings)")
        
        if append {
            self.events.append(contentsOf: data.events)
        } else {
            self.events = data.events
        }
        
        self.totalEvents = data.total_events
        self.totalBookings = data.total_bookings
        self.pagination = data.pagination
        self.showError = false
        self.errorMessage = nil
    }
    
    private func handleError(_ message: String) {
        isLoading = false
        showError = true
        errorMessage = message
        print("❌ BookingAuditRecordsViewModel - Error: \(message)")
    }
    
    func loadNextPage() {
        guard let pagination = pagination else { return }
        
        if currentPage < pagination.last_page {
            fetchAuditRecords(page: currentPage + 1, append: true, search: searchText.isEmpty ? nil : searchText)
        }
    }
    
    func refresh() {
        fetchAuditRecords(page: 1, append: false, search: searchText.isEmpty ? nil : searchText)
    }
    
    func clearSearch() {
        searchText = ""
        fetchAuditRecords(page: 1, append: false, search: nil)
    }
    
    var hasMorePages: Bool {
        guard let pagination = pagination else { return false }
        return currentPage < pagination.last_page
    }
    
    // Get icon name based on event type
    func getIconName(for eventType: String) -> String {
        if eventType == "status_changed" {
            return "info.circle.fill"
        } else if eventType.hasSuffix("_sent") {
            return "envelope.fill"
        } else {
            return "bell.fill"
        }
    }
    
    // Get icon color based on event type
    func getIconColor(for eventType: String) -> Color {
        if eventType == "status_changed" {
            return .blue
        } else if eventType.hasSuffix("_sent") {
            return AppColors.primaryOrange
        } else {
            return .gray
        }
    }
    
    // Get category color
    func getCategoryColor(for category: String) -> Color {
        switch category.lowercased() {
        case "booking":
            return .blue
        case "communication":
            return .green
        case "system":
            return .purple
        default:
            return .gray
        }
    }
    
    // MARK: - Date Grouping
    func groupEventsByDate() -> [String: [BookingAuditEvent]] {
        let calendar = Calendar.current
        let now = Date()
        
        var grouped: [String: [BookingAuditEvent]] = [:]
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        
        for event in events {
            guard let eventDate = dateFormatter.date(from: event.timestamp) else {
                continue
            }
            
            let dateKey: String
            if calendar.isDateInToday(eventDate) {
                dateKey = "Today"
            } else if calendar.isDateInYesterday(eventDate) {
                dateKey = "Yesterday"
            } else {
                dateKey = "Last Week"
            }
            
            if grouped[dateKey] == nil {
                grouped[dateKey] = []
            }
            grouped[dateKey]?.append(event)
        }
        
        // Sort events within each group by timestamp (most recent first)
        for key in grouped.keys {
            grouped[key]?.sort { event1, event2 in
                guard let date1 = dateFormatter.date(from: event1.timestamp),
                      let date2 = dateFormatter.date(from: event2.timestamp) else {
                    return false
                }
                return date1 > date2
            }
        }
        
        return grouped
    }
    
    var todayEvents: [BookingAuditEvent] {
        return groupEventsByDate()["Today"] ?? []
    }
    
    var yesterdayEvents: [BookingAuditEvent] {
        return groupEventsByDate()["Yesterday"] ?? []
    }
    
    var lastWeekEvents: [BookingAuditEvent] {
        return groupEventsByDate()["Last Week"] ?? []
    }
}











