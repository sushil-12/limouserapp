import Foundation
import Combine

@MainActor
class AirportService: ObservableObject {
    @Published var airports: [Airport] = []
    @Published var isLoading = false
    @Published var isLoadingMore = false
    @Published var errorMessage: String?
    @Published var hasMoreData = true
    @Published var suggestions: [String] = []
    @Published var isSearchPending = false // Track when search is queued but not yet executed (during debounce)
    
    private let pageSize = 50 // Load 50 airports per page
    private var currentPage = 1
    private var currentSearchQuery: String?
    private var cancellables = Set<AnyCancellable>()
    private var searchSubject = PassthroughSubject<String, Never>()
    private var currentSearchTask: Task<Void, Never>?
    private var lastProcessedQuery: String? // Track last processed query to allow re-searching after clear
    
    // Store original airports for when search is cleared
    private var originalAirports: [Airport] = []
    
    init() {
        // Set up debounced search with optimized delay for smooth UX
        // Use custom duplicate removal that allows re-searching after clear
        searchSubject
            .debounce(for: .milliseconds(500), scheduler: RunLoop.main) // Reduced to 500ms for faster response
            .sink { [weak self] searchText in
                Task { @MainActor in
                    await self?.searchAirportsDebounced(query: searchText)
                }
            }
            .store(in: &cancellables)
    }
    
    func searchAirportsDebounced(query: String) async {
        // Cancel any existing search task
        currentSearchTask?.cancel()
        
        let trimmedQuery = query.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Don't search for very short queries to improve performance
        guard !trimmedQuery.isEmpty && trimmedQuery.count >= 2 else {
            await MainActor.run {
                isSearchPending = false
                suggestions = []
                lastProcessedQuery = nil // Reset last processed query when clearing
            }
            return
        }
        
        // Update last processed query before starting search
        // Note: We don't check for duplicates here because:
        // 1. The debounce already handles rapid duplicate typing
        // 2. We want to allow re-searching the same query after clearing (lastProcessedQuery is reset in clearSuggestions)
        await MainActor.run {
            lastProcessedQuery = trimmedQuery
            isSearchPending = false
        }
        
        // Create new search task
        currentSearchTask = Task {
            do {
                await fetchAirports(search: trimmedQuery, page: 1, append: false)
                
                // Convert airports to suggestion strings on main actor
                await MainActor.run {
                    if !Task.isCancelled {
                        suggestions = airports.map { $0.displayName }
                        print("🔍 AIRPORT SEARCH COMPLETED: Found \(suggestions.count) suggestions for '\(trimmedQuery)'")
                    } else {
                        // Task was cancelled, ensure pending state is cleared
                        isSearchPending = false
                    }
                }
            } catch {
                await MainActor.run {
                    if !Task.isCancelled {
                        suggestions = []
                        errorMessage = "Search failed. Please try again."
                        print("❌ AIRPORT SEARCH ERROR: \(error.localizedDescription)")
                    }
                    // Ensure pending state is cleared even if cancelled or errored
                    isSearchPending = false
                }
            }
        }
        
        await currentSearchTask?.value
    }
    
    func searchAirports(query: String) {
        let trimmedQuery = query.trimmingCharacters(in: .whitespacesAndNewlines)
        // Only set pending state for valid search queries (2+ characters)
        if !trimmedQuery.isEmpty && trimmedQuery.count >= 2 {
            isSearchPending = true
            searchSubject.send(query)
        } else if !trimmedQuery.isEmpty {
            // For 1 character, just send to subject without setting pending
            searchSubject.send(query)
        } else {
            // Clear everything when search is empty
            isSearchPending = false
            suggestions = []
            currentSearchTask?.cancel()
            currentSearchTask = nil
        }
    }
    
    func fetchAirports(search: String? = nil, page: Int = 1, append: Bool = false) async {
        if page == 1 {
            isLoading = true
            // Don't clear airports immediately - wait for new data
        } else {
            isLoadingMore = true
        }
        
        errorMessage = nil
        currentSearchQuery = search
        currentPage = page
        
        let endpoint = APIEndpoints.airports(search: search, page: page, limit: pageSize)
        
        do {
            let response: AirportResponse = try await NetworkService.shared.request(
                endpoint: endpoint,
                responseType: AirportResponse.self
            )
            
            if append {
                airports.append(contentsOf: response.data.airportsData)
            } else {
                airports = response.data.airportsData // Only update after getting new data
            }
            
            // Check if there's more data using pagination info or fallback to count
            if let pagination = response.pagination {
                hasMoreData = pagination.hasNextPage
            } else {
                hasMoreData = response.data.airportsData.count == pageSize
            }
            
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
        isLoadingMore = false
    }
    
    func searchAirports(query: String) async {
        guard !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            await fetchAirports() // Fetch all airports if query is empty
            return
        }
        
        await fetchAirports(search: query)
    }
    
    func loadMoreAirports() async {
        guard hasMoreData && !isLoadingMore else { return }
        
        let nextPage = currentPage + 1
        await fetchAirports(search: currentSearchQuery, page: nextPage, append: true)
    }
    
    func resetPagination() {
        currentPage = 1
        hasMoreData = true
        airports = []
        suggestions = []
    }
    
    func selectAirportSuggestion(_ suggestion: String) -> Airport? {
        // Find the airport that matches the selected suggestion
        let selectedAirport = airports.first { $0.displayName == suggestion }
        suggestions = [] // Clear suggestions after selection
        return selectedAirport
    }
    
    func fetchAllAirports() async {
        // Try to fetch all airports with a very large limit
        let endpoint = APIEndpoints.airports(search: nil, page: 1, limit: 5000)
        
        isLoading = true
        errorMessage = nil
        airports = [] // Clear existing data
        
        do {
            let response: AirportResponse = try await NetworkService.shared.request(
                endpoint: endpoint,
                responseType: AirportResponse.self
            )
            
            airports = response.data.airportsData
            originalAirports = airports // Store original airports
            hasMoreData = false // We got all airports
            
            print("🛫 FETCHED ALL AIRPORTS: \(airports.count) airports loaded")
            
        } catch {
            errorMessage = error.localizedDescription
            print("❌ ERROR FETCHING ALL AIRPORTS: \(error.localizedDescription)")
        }
        
        isLoading = false
    }
    
    func searchAirportsAPI(query: String) async {
        guard !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            // If search is empty, restore original airports
            airports = originalAirports
            print("🔍 SEARCH CLEARED: Restored \(originalAirports.count) original airports")
            return
        }
        
        // Perform API search
        await fetchAirports(search: query, page: 1, append: false)
        print("🔍 API SEARCH COMPLETED: Found \(airports.count) airports for '\(query)'")
    }
    
    func clearSuggestions() {
        suggestions = []
        isSearchPending = false
        currentSearchTask?.cancel()
        currentSearchTask = nil
        lastProcessedQuery = nil // Reset last processed query to allow re-searching same query
        print("🔍 CLEARED SUGGESTIONS: Reset last processed query to allow re-searching")
    }
}
