import Foundation

struct AirportMapping {
    // Static mapping of airport names to IDs
    // This should ideally come from the API response, but for now we'll use a static mapping
    private static let airportMapping: [String: Int] = [
        "ORD - Chicago Ohare Intl": 1,
        "ATL - Hartsfield Jackson Atlanta Intl": 2,
        "LAX - Los Angeles Intl": 3,
        "JFK - John F Kennedy Intl": 4,
        "LHR - Heathrow": 5,
        "CDG - Charles De Gaulle": 6,
        "FRA - Frankfurt": 7,
        "AMS - Amsterdam Schiphol": 8,
        "MAD - Madrid Barajas": 9,
        "BCN - Barcelona": 10,
        "MIA - Miami Intl": 11,
        "DFW - Dallas Fort Worth Intl": 12,
        "DEN - Denver Intl": 13,
        "SFO - San Francisco Intl": 14,
        "CLT - Charlotte Douglas Intl": 15,
        "LAS - Las Vegas McCarran Intl": 16,
        "PHX - Phoenix Sky Harbor Intl": 17,
        "IAH - George Bush Intercontinental": 18,
        "MCO - Orlando Intl": 19,
        "SEA - Seattle Tacoma Intl": 20,
        "EWR - Newark Liberty Intl": 21,
        "DTW - Detroit Metropolitan": 22,
        "BOS - Boston Logan Intl": 23,
        "MSP - Minneapolis Saint Paul Intl": 24,
        "FLL - Fort Lauderdale Hollywood Intl": 25,
        "BWI - Baltimore Washington Intl": 26,
        "IAD - Washington Dulles Intl": 27,
        "SLC - Salt Lake City Intl": 28,
        "HNL - Honolulu Intl": 29,
        "PDX - Portland Intl": 30,
        "ABE - Lehigh Valley Intl": 785, // From sample payload
        "MDW - Chicago Midway Intl": 31,
        "CLE - Cleveland Hopkins Intl": 32,
        "PIT - Pittsburgh Intl": 33,
        "CVG - Cincinnati Northern Kentucky Intl": 34,
        "IND - Indianapolis Intl": 35,
        "CMH - Columbus Intl": 36,
        "BNA - Nashville Intl": 37,
        "MEM - Memphis Intl": 38,
        "MSY - New Orleans Louis Armstrong Intl": 39,
        "RSW - Southwest Florida Intl": 40,
        "PBI - Palm Beach Intl": 41,
        "TPA - Tampa Intl": 42,
        "JAX - Jacksonville Intl": 43,
        "CHS - Charleston Intl": 44,
        "SAV - Savannah Hilton Head Intl": 45,
        "GSP - Greenville Spartanburg Intl": 46,
        "RDU - Raleigh Durham Intl": 48,
        "GSO - Piedmont Triad Intl": 49,
        "AVL - Asheville Regional": 50,
        "PEK - Capital Intl": 1001, // Beijing Capital International Airport
        "AAR - Aarhus": 1042, // Aarhus Airport
        "AAE - Annaba": 1001 // Annaba Airport (same ID as PEK for now)
    ]
    
    /// Get airport ID from airport name
    /// - Parameter airportName: Full airport name (e.g., "ORD - Chicago Ohare Intl")
    /// - Returns: Airport ID if found, nil otherwise
    static func getAirportId(from airportName: String) -> Int? {
        print("🔍 Looking up airport ID for: \(airportName)")
        
        // Try to find the airport by exact name
        if let airportId = airportMapping[airportName] {
            print("✅ Found airport ID: \(airportId) for exact match")
            return airportId
        }
        
        // If not found, try to extract airport code and find by code
        if let airportCode = airportName.components(separatedBy: " - ").first {
            print("🔍 Trying to find by airport code: \(airportCode)")
            for (name, id) in airportMapping {
                if name.hasPrefix(airportCode) {
                    print("✅ Found airport ID: \(id) for code match: \(name)")
                    return id
                }
            }
        }
        
        // If still not found, log for debugging and return nil
        print("⚠️ Airport not found in mapping: \(airportName)")
        return nil
    }
    
    /// Get airport ID from airport name with fallback to default
    /// - Parameter airportName: Full airport name (e.g., "ORD - Chicago Ohare Intl")
    /// - Returns: Airport ID if found, default ID (1) otherwise
    static func getAirportIdWithFallback(from airportName: String) -> Int {
        return getAirportId(from: airportName) ?? 1
    }
}
