import Foundation

class CardValidationService {
    
    // MARK: - Card Number Validation and Formatting
    
    static func formatCardNumber(_ cardNumber: String) -> String {
        // Remove all non-digit characters
        let digits = cardNumber.filter { $0.isNumber }
        
        // Limit to 16 digits
        let limitedDigits = String(digits.prefix(16))
        
        // Add spaces every 4 digits
        var formatted = ""
        for (index, digit) in limitedDigits.enumerated() {
            if index > 0 && index % 4 == 0 {
                formatted += " "
            }
            formatted += String(digit)
        }
        
        return formatted
    }
    
    static func validateCardNumber(_ cardNumber: String) -> (isValid: Bool, message: String?) {
        let digits = cardNumber.filter { $0.isNumber }
        
        // Check length
        if digits.count < 13 || digits.count > 19 {
            return (false, "Card number must be between 13 and 19 digits")
        }
        
        // Check if all non-space characters are digits
        let allowedCharacters = cardNumber.filter { $0.isNumber || $0 == " " }
        if allowedCharacters.count != cardNumber.count {
            return (false, "Card number can only contain numbers and spaces")
        }
        
        // Luhn algorithm validation
        if !isValidLuhn(digits) {
            return (false, "Invalid card number")
        }
        
        return (true, nil)
    }
    
    // MARK: - CVV Validation
    
    static func formatCVV(_ cvv: String) -> String {
        // Remove all non-digit characters and limit to 4 digits
        let digits = cvv.filter { $0.isNumber }
        return String(digits.prefix(4))
    }
    
    static func validateCVV(_ cvv: String) -> (isValid: Bool, message: String?) {
        let digits = cvv.filter { $0.isNumber }
        
        // CVV should be 3 or 4 digits
        if digits.count < 3 || digits.count > 4 {
            return (false, "CVV must be 3 or 4 digits")
        }
        
        // Check if all characters are digits
        if digits.count != cvv.filter({ $0.isNumber }).count {
            return (false, "CVV can only contain numbers")
        }
        
        return (true, nil)
    }
    
    // MARK: - Expiry Date Validation
    
    static func validateExpiryDate(month: String, year: String) -> (isValid: Bool, message: String?) {
        guard let monthInt = Int(month), let yearInt = Int(year) else {
            return (false, "Invalid expiry date")
        }
        
        // Check month range
        if monthInt < 1 || monthInt > 12 {
            return (false, "Invalid month")
        }
        
        let calendar = Calendar.current
        let currentYear = calendar.component(.year, from: Date())
        let currentMonth = calendar.component(.month, from: Date())
        
        if yearInt < currentYear {
            return (false, "Card has expired")
        }
        
        if yearInt == currentYear && monthInt <= currentMonth {
            return (false, "Expiry date must be in the future")
        }
        
        return (true, nil)
    }
    
    // MARK: - Card Type Detection
    
    static func detectCardType(_ cardNumber: String) -> String {
        let digits = cardNumber.filter { $0.isNumber }
        
        if digits.hasPrefix("4") {
            return "visa"
        } else if digits.hasPrefix("5") || digits.hasPrefix("2") {
            return "mastercard"
        } else if digits.hasPrefix("3") {
            return "amex"
        } else if digits.hasPrefix("6") {
            return "discover"
        }
        
        return "unknown"
    }
    
    // MARK: - Helper Methods
    
    private static func isValidLuhn(_ cardNumber: String) -> Bool {
        let digits = cardNumber.filter { $0.isNumber }
        var sum = 0
        var alternate = false
        
        // Process digits from right to left
        for digit in digits.reversed() {
            guard let value = Int(String(digit)) else { return false }
            
            if alternate {
                let doubled = value * 2
                sum += doubled > 9 ? doubled - 9 : doubled
            } else {
                sum += value
            }
            
            alternate.toggle()
        }
        
        return sum % 10 == 0
    }
    
    // MARK: - Complete Form Validation
    
    static func validateCardForm(
        cardNumber: String,
        cvv: String,
        expMonth: String,
        expYear: String,
        cardHolderName: String
    ) -> (isValid: Bool, message: String?) {
        
        print("🔍 CardValidationService - Starting form validation...")
        print("   - Card Number: '\(cardNumber)'")
        print("   - CVV: '\(cvv)'")
        print("   - Exp Month: '\(expMonth)'")
        print("   - Exp Year: '\(expYear)'")
        print("   - Card Holder: '\(cardHolderName)'")
        
        // Validate card holder name
        if cardHolderName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            print("❌ Validation failed: Card holder name is empty")
            return (false, "Card holder name is required")
        }
        print("✅ Card holder name validation passed")
        
        // Validate card number
        let cardValidation = validateCardNumber(cardNumber)
        if !cardValidation.isValid {
            print("❌ Card number validation failed: \(cardValidation.message ?? "Unknown error")")
            return cardValidation
        }
        print("✅ Card number validation passed")
        
        // Validate CVV
        let cvvValidation = validateCVV(cvv)
        if !cvvValidation.isValid {
            print("❌ CVV validation failed: \(cvvValidation.message ?? "Unknown error")")
            return cvvValidation
        }
        print("✅ CVV validation passed")
        
        // Validate expiry date
        let expiryValidation = validateExpiryDate(month: expMonth, year: expYear)
        if !expiryValidation.isValid {
            print("❌ Expiry date validation failed: \(expiryValidation.message ?? "Unknown error")")
            return expiryValidation
        }
        print("✅ Expiry date validation passed")
        
        print("🎉 All validations passed!")
        return (true, nil)
    }
}
