//
//  EditReservationService.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation
import Combine

// Import the models from CreateReservationModels to access AirportOption and AirlineOption
// These structs are defined in CreateReservationModels.swift

// MARK: - Edit Reservation Response Models
struct EditReservationResponse: Codable {
    let success: Bool?
    let data: EditReservationData
    let message: String?
    let currency: EditReservationCurrency?
}

struct EditReservationData: Codable {
    let reservationId: Int
    let id: Int
    let relatedTo: String?
    let minRateInvolved: Int
    let confId: String?
    let accId: Int
    let travelClientId: Int?
    let passengerId: Int
    let accountType: String?
    let subAccountType: String?
    let subAccountId: String?
    let affiliateId: Int
    let farmoutAffiliate: String?
    let reservationType: String?
    let referralAffiliate: String?
    let loseAffiliate: String?
    let cancellationHours: Int?
    let reservationPreferencesId: String?
    let transferType: String
    let returnTransferType: String?
    let pickup: String?
    let pickupAddress: String?
    let pickupAirport: String?
    let pickupAirline: String?
    let pickupFlight: String?
    let originAirportCity: String?
    let pickupLatitude: Double?
    let pickupLongitude: Double?
    let dropoff: String?
    let dropoffAddress: String?
    let dropoffAirport: String?
    let dropoffAirline: String?
    let dropoffFlight: String?
    let dropoffLatitude: Double?
    let dropoffLongitude: Double?
    let returnPickup: String?
    let returnPickupAddress: String?
    let returnCruiseName: String?
    let returnCruisePort: String?
    let returnCruiseTime: String?
    let cruiseName: String?
    let cruisePort: String?
    let cruiseTime: String?
    let returnPickupAirport: String?
    let returnPickupAirline: String?
    let returnPickupFlight: String?
    let returnOriginAirportCity: String?
    let returnPickupLatitude: Double?
    let returnPickupLongitude: Double?
    let returnDropoff: String?
    let fboAddress: String?
    let fboName: String?
    let returnDropoffAddress: String?
    let returnDropoffAirport: String?
    let returnDropoffAirline: String?
    let returnDropoffFlight: String?
    let returnDropoffLatitude: Double?
    let returnDropoffLongitude: Double?
    let meetGreetChoices: Int
    let returnMeetGreetChoices: Int?
    let extraStops: String?
    let returnExtraStops: String?
    let serviceType: String
    let pickupDate: String
    let pickupTime: String
    let returnPickupDate: String?
    let returnPickupTime: String?
    let totalPassengers: Int
    let luggageCount: Int
    let childCertified: String?
    let babySeat: String?
    let boosterSeat: String?
    let petFriendly: String?
    let handicap: String?
    let vehicleType: Int?
    let vehicleId: Int?
    let driverId: Int?
    let paymentId: String?
    let quoteAmount: String?
    let hourlyRate: String?
    let numberOfHours: Int?
    let numberOfVehicles: Int?
    let distance: String?
    let duration: String?
    let amenities: String?
    let driverLanguages: String?
    let driverDresses: String?
    let bookingInstructions: String?
    let acceptedOn: String?
    let paymentStatus: String?
    let bookingStatus: String?
    let chargedAmount: String?
    let affiliateChargedAmount: String?
    let statusChangeFlag: String?
    let emailToken: String?
    let createdByRole: String?
    let createdBy: Int?
    let cancellationReason: String?
    let departingAirportCity: String?
    let status: String?
    let reservationShares: String?
    let shareArray: String?
    let reminderBeforeOneHour: String?
    let reminderBeforeOneDay: String?
    let reminderEmailSent: String?
    let reminderSmsSent: String?
    let cancellationReminderSmsSent: String?
    let changedFields: String?
    let bookingRelatedTo: Int?
    let isTransferred: Int?
    let waitingTimeInMins: Int?
    let createdAt: String?
    let updatedAt: String?
    let passengerName: String?
    let passengerCellIsd: String?
    let passengerCellCountry: String?
    let passengerCell: String?
    let passengerEmail: String?
    let passengerImage: String?
    let chargedAmenities: String?
    let vehicleYear: String?
    let vehicleMake: Int?
    let vehicleModel: Int?
    let vehicleColor: Int?
    let vehicleLicensePlate: String?
    let vehicleSeats: Int?
    let driverName: String?
    let driverGender: String?
    let driverCellIsd: String?
    let driverCellCountry: String?
    let driverCell: String?
    let driverEmail: String?
    let driverPhoneType: String?
    let driverVeteran: String?
    let driverDod: String?
    let driverFoidCard: String?
    let driverExLawOfficer: String?
    let driverBackgroundCertified: String?
    let vehicleImageId: String?
    let driverImageId: String?
    let loseAffiliateName: String?
    let loseAffiliatePhoneIsd: String?
    let loseAffiliatePhoneCountry: String?
    let loseAffiliatePhone: String?
    let loseAffiliateEmail: String?
    let currency: String?
    let pickupAirportLatitude: Double?
    let pickupAirportLongitude: Double?
    let dropoffAirportLatitude: Double?
    let dropoffAirportLongitude: Double?
    let returnPickupAirportLatitude: Double?
    let returnPickupAirportLongitude: Double?
    let returnDropoffAirportLatitude: Double?
    let returnDropoffAirportLongitude: Double?
    let affiliateType: String?
    let looseCustomer: LooseCustomer?
    let vehicleCreatedBy: Int?
    let vehicleYearName: String?
    let vehicleMakeName: String?
    let vehicleModelName: String?
    let vehicleColorName: String?
    let vehicleLicensePlateName: String?
    let vehicleSeatsName: Int?
    let vehicleTypeName: String?
    let vehicleImages: [String]?
    let driverImage: String?
    let meetGreetChoiceName: String?
    
    enum CodingKeys: String, CodingKey {
        case reservationId = "reservation_id"
        case id
        case relatedTo = "related_to"
        case minRateInvolved = "min_rate_involved"
        case confId = "conf_id"
        case accId = "acc_id"
        case travelClientId = "travel_client_id"
        case passengerId = "passenger_id"
        case accountType = "account_type"
        case subAccountType = "sub_account_type"
        case subAccountId = "sub_account_id"
        case affiliateId = "affiliate_id"
        case farmoutAffiliate = "farmout_affiliate"
        case reservationType = "reservation_type"
        case referralAffiliate = "referral_affiliate"
        case loseAffiliate = "lose_affiliate"
        case cancellationHours = "cancellation_hours"
        case reservationPreferencesId = "reservation_preferences_id"
        case transferType = "transfer_type"
        case returnTransferType = "return_transfer_type"
        case pickup
        case pickupAddress = "pickup_address"
        case pickupAirport = "pickup_airport"
        case pickupAirline = "pickup_airline"
        case pickupFlight = "pickup_flight"
        case originAirportCity = "origin_airport_city"
        case pickupLatitude = "pickup_latitude"
        case pickupLongitude = "pickup_longitude"
        case dropoff
        case dropoffAddress = "dropoff_address"
        case dropoffAirport = "dropoff_airport"
        case dropoffAirline = "dropoff_airline"
        case dropoffFlight = "dropoff_flight"
        case dropoffLatitude = "dropoff_latitude"
        case dropoffLongitude = "dropoff_longitude"
        case returnPickup = "return_pickup"
        case returnPickupAddress = "return_pickup_address"
        case returnCruiseName = "return_cruise_name"
        case returnCruisePort = "return_cruise_port"
        case returnCruiseTime = "return_cruise_time"
        case cruiseName = "cruise_name"
        case cruisePort = "cruise_port"
        case cruiseTime = "cruise_time"
        case returnPickupAirport = "return_pickup_airport"
        case returnPickupAirline = "return_pickup_airline"
        case returnPickupFlight = "return_pickup_flight"
        case returnOriginAirportCity = "return_origin_airport_city"
        case returnPickupLatitude = "return_pickup_latitude"
        case returnPickupLongitude = "return_pickup_longitude"
        case returnDropoff = "return_dropoff"
        case fboAddress = "fbo_address"
        case fboName = "fbo_name"
        case returnDropoffAddress = "return_dropoff_address"
        case returnDropoffAirport = "return_dropoff_airport"
        case returnDropoffAirline = "return_dropoff_airline"
        case returnDropoffFlight = "return_dropoff_flight"
        case returnDropoffLatitude = "return_dropoff_latitude"
        case returnDropoffLongitude = "return_dropoff_longitude"
        case meetGreetChoices = "meet_greet_choices"
        case returnMeetGreetChoices = "return_meet_greet_choices"
        case extraStops = "extra_stops"
        case returnExtraStops = "return_extra_stops"
        case serviceType = "service_type"
        case pickupDate = "pickup_date"
        case pickupTime = "pickup_time"
        case returnPickupDate = "return_pickup_date"
        case returnPickupTime = "return_pickup_time"
        case totalPassengers = "total_passengers"
        case luggageCount = "luggage_count"
        case childCertified = "child_certified"
        case babySeat = "baby_seat"
        case boosterSeat = "booster_seat"
        case petFriendly = "pet_friendly"
        case handicap = "handicap"
        case vehicleType = "vehicle_type"
        case vehicleId = "vehicle_id"
        case driverId = "driver_id"
        case paymentId = "payment_id"
        case quoteAmount = "quote_amount"
        case hourlyRate = "hourly_rate"
        case numberOfHours = "number_of_hours"
        case numberOfVehicles = "number_of_vehicles"
        case distance
        case duration
        case amenities
        case driverLanguages = "driver_languages"
        case driverDresses = "driver_dresses"
        case bookingInstructions = "booking_instructions"
        case acceptedOn = "accepted_on"
        case paymentStatus = "payment_status"
        case bookingStatus = "booking_status"
        case chargedAmount = "charged_amount"
        case affiliateChargedAmount = "affiliate_charged_amount"
        case statusChangeFlag = "status_change_flag"
        case emailToken = "email_token"
        case createdByRole = "created_by_role"
        case createdBy = "created_by"
        case cancellationReason = "cancellation_reason"
        case departingAirportCity = "departing_airport_city"
        case status
        case reservationShares = "reservation_shares"
        case shareArray = "share_array"
        case reminderBeforeOneHour = "reminder_before_one_hour"
        case reminderBeforeOneDay = "reminder_before_one_day"
        case reminderEmailSent = "reminder_email_sent"
        case reminderSmsSent = "reminder_sms_sent"
        case cancellationReminderSmsSent = "cancellation_reminder_sms_sent"
        case changedFields = "changed_fields"
        case bookingRelatedTo = "booking_related_to"
        case isTransferred = "is_transferred"
        case waitingTimeInMins = "waiting_time_in_mins"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case passengerName = "passenger_name"
        case passengerCellIsd = "passenger_cell_isd"
        case passengerCellCountry = "passenger_cell_country"
        case passengerCell = "passenger_cell"
        case passengerEmail = "passenger_email"
        case passengerImage = "passenger_image"
        case chargedAmenities = "chargedAmenities"
        case vehicleYear = "vehicle_year"
        case vehicleMake = "vehicle_make"
        case vehicleModel = "vehicle_model"
        case vehicleColor = "vehicle_color"
        case vehicleLicensePlate = "vehicle_license_plate"
        case vehicleSeats = "vehicle_seats"
        case driverName = "driver_name"
        case driverGender = "driver_gender"
        case driverCellIsd = "driver_cell_isd"
        case driverCellCountry = "driver_cell_country"
        case driverCell = "driver_cell"
        case driverEmail = "driver_email"
        case driverPhoneType = "driver_phone_type"
        case driverVeteran = "driver_veteran"
        case driverDod = "driver_dod"
        case driverFoidCard = "driver_foid_card"
        case driverExLawOfficer = "driver_ex_law_officer"
        case driverBackgroundCertified = "driver_background_certified"
        case vehicleImageId = "vehicle_image_id"
        case driverImageId = "driver_image_id"
        case loseAffiliateName = "lose_affiliate_name"
        case loseAffiliatePhoneIsd = "lose_affiliate_phone_isd"
        case loseAffiliatePhoneCountry = "lose_affiliate_phone_country"
        case loseAffiliatePhone = "lose_affiliate_phone"
        case loseAffiliateEmail = "lose_affiliate_email"
        case currency
        case pickupAirportLatitude = "pickup_airport_latitude"
        case pickupAirportLongitude = "pickup_airport_longitude"
        case dropoffAirportLatitude = "dropoff_airport_latitude"
        case dropoffAirportLongitude = "dropoff_airport_longitude"
        case returnPickupAirportLatitude = "return_pickup_airport_latitude"
        case returnPickupAirportLongitude = "return_pickup_airport_longitude"
        case returnDropoffAirportLatitude = "return_dropoff_airport_latitude"
        case returnDropoffAirportLongitude = "return_dropoff_airport_longitude"
        case affiliateType = "affiliate_type"
        case looseCustomer = "loose_customer"
        case vehicleCreatedBy = "vehicle_created_by"
        case vehicleYearName = "vehicle_year_name"
        case vehicleMakeName = "vehicle_make_name"
        case vehicleModelName = "vehicle_model_name"
        case vehicleColorName = "vehicle_color_name"
        case vehicleLicensePlateName = "vehicle_license_plate_name"
        case vehicleSeatsName = "vehicle_seats_name"
        case vehicleTypeName = "vehicle_type_name"
        case vehicleImages = "vehicle_images"
        case driverImage = "driver_image"
        case meetGreetChoiceName = "meet_greet_choice_name"
    }
    
    // Custom decoder to handle type mismatches - Updated to handle empty string coordinates
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        // Handle fields that might be numbers but are expected as strings
        reservationId = try container.decode(Int.self, forKey: .reservationId)
        id = try container.decode(Int.self, forKey: .id)
        
        // Handle relatedTo which might be a number or string
        if let relatedToString = try? container.decodeIfPresent(String.self, forKey: .relatedTo) {
            relatedTo = relatedToString
        } else if let relatedToNumber = try? container.decodeIfPresent(Int.self, forKey: .relatedTo) {
            relatedTo = String(relatedToNumber)
        } else {
            relatedTo = nil
        }
        
        // Handle minRateInvolved which might be a string or int
        if let minRateString = try? container.decodeIfPresent(String.self, forKey: .minRateInvolved), !minRateString.isEmpty, let minRate = Int(minRateString) {
            minRateInvolved = minRate
        } else if let minRateInt = try? container.decodeIfPresent(Int.self, forKey: .minRateInvolved) {
            minRateInvolved = minRateInt
        } else {
            minRateInvolved = 0 // Default to 0 if not found
        }
        confId = try container.decodeIfPresent(String.self, forKey: .confId)
        accId = try container.decode(Int.self, forKey: .accId)
        travelClientId = try container.decodeIfPresent(Int.self, forKey: .travelClientId)
        passengerId = try container.decode(Int.self, forKey: .passengerId)
        accountType = try container.decodeIfPresent(String.self, forKey: .accountType)
        subAccountType = try container.decodeIfPresent(String.self, forKey: .subAccountType)
        subAccountId = try container.decodeIfPresent(String.self, forKey: .subAccountId)
        affiliateId = try container.decode(Int.self, forKey: .affiliateId)
        
        farmoutAffiliate = container.decodeLossyString(forKey: .farmoutAffiliate)
        
        reservationType = try container.decodeIfPresent(String.self, forKey: .reservationType)
        referralAffiliate = try container.decodeIfPresent(String.self, forKey: .referralAffiliate)
        
        // Handle loseAffiliate which might be a number or string
        if let loseAffiliateString = try? container.decodeIfPresent(String.self, forKey: .loseAffiliate) {
            loseAffiliate = loseAffiliateString
        } else if let loseAffiliateNumber = try? container.decodeIfPresent(Int.self, forKey: .loseAffiliate) {
            loseAffiliate = String(loseAffiliateNumber)
        } else {
            loseAffiliate = nil
        }
        
        // Handle cancellationHours which might be a number or string
        if let cancellationHoursString = try? container.decodeIfPresent(String.self, forKey: .cancellationHours), !cancellationHoursString.isEmpty, let hours = Int(cancellationHoursString) {
            cancellationHours = hours
        } else if let cancellationHoursInt = try? container.decodeIfPresent(Int.self, forKey: .cancellationHours) {
            cancellationHours = cancellationHoursInt
        } else {
            cancellationHours = nil
        }
        reservationPreferencesId = try container.decodeIfPresent(String.self, forKey: .reservationPreferencesId)
        transferType = try container.decode(String.self, forKey: .transferType)
        returnTransferType = try container.decodeIfPresent(String.self, forKey: .returnTransferType)
        pickup = try container.decodeIfPresent(String.self, forKey: .pickup)
        pickupAddress = try container.decodeIfPresent(String.self, forKey: .pickupAddress)
        pickupAirport = try container.decodeIfPresent(String.self, forKey: .pickupAirport)
        pickupAirline = try container.decodeIfPresent(String.self, forKey: .pickupAirline)
        pickupFlight = try container.decodeIfPresent(String.self, forKey: .pickupFlight)
        originAirportCity = try container.decodeIfPresent(String.self, forKey: .originAirportCity)
        // Handle coordinates that might be String or Double
        if let latString = try? container.decodeIfPresent(String.self, forKey: .pickupLatitude), !latString.isEmpty, let lat = Double(latString) {
            pickupLatitude = lat
            print("🔍 Pickup Latitude: Decoded as String '\(latString)' -> Double \(lat)")
        } else if let latDouble = try? container.decodeIfPresent(Double.self, forKey: .pickupLatitude) {
            pickupLatitude = latDouble
            print("🔍 Pickup Latitude: Decoded as Double \(latDouble)")
        } else {
            pickupLatitude = nil
            print("🔍 Pickup Latitude: Not found or invalid")
        }
        
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .pickupLongitude), !lngString.isEmpty, let lng = Double(lngString) {
            pickupLongitude = lng
            print("🔍 Pickup Longitude: Decoded as String '\(lngString)' -> Double \(lng)")
        } else if let lngDouble = try? container.decodeIfPresent(Double.self, forKey: .pickupLongitude) {
            pickupLongitude = lngDouble
            print("🔍 Pickup Longitude: Decoded as Double \(lngDouble)")
        } else {
            pickupLongitude = nil
            print("🔍 Pickup Longitude: Not found or invalid")
        }
        dropoff = try container.decodeIfPresent(String.self, forKey: .dropoff)
        dropoffAddress = try container.decodeIfPresent(String.self, forKey: .dropoffAddress)
        dropoffAirport = try container.decodeIfPresent(String.self, forKey: .dropoffAirport)
        dropoffAirline = try container.decodeIfPresent(String.self, forKey: .dropoffAirline)
        dropoffFlight = try container.decodeIfPresent(String.self, forKey: .dropoffFlight)
        // Handle dropoff coordinates that might be String or Double
        if let latString = try? container.decodeIfPresent(String.self, forKey: .dropoffLatitude), !latString.isEmpty, let lat = Double(latString) {
            dropoffLatitude = lat
        } else if let latDouble = try? container.decodeIfPresent(Double.self, forKey: .dropoffLatitude) {
            dropoffLatitude = latDouble
        } else {
            dropoffLatitude = nil
        }
        
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .dropoffLongitude), !lngString.isEmpty, let lng = Double(lngString) {
            dropoffLongitude = lng
        } else if let lngDouble = try? container.decodeIfPresent(Double.self, forKey: .dropoffLongitude) {
            dropoffLongitude = lngDouble
        } else {
            dropoffLongitude = nil
        }
        returnPickup = try container.decodeIfPresent(String.self, forKey: .returnPickup)
        returnPickupAddress = try container.decodeIfPresent(String.self, forKey: .returnPickupAddress)
        returnCruiseName = try container.decodeIfPresent(String.self, forKey: .returnCruiseName)
        returnCruisePort = try container.decodeIfPresent(String.self, forKey: .returnCruisePort)
        returnCruiseTime = try container.decodeIfPresent(String.self, forKey: .returnCruiseTime)
        cruiseName = try container.decodeIfPresent(String.self, forKey: .cruiseName)
        cruisePort = try container.decodeIfPresent(String.self, forKey: .cruisePort)
        cruiseTime = try container.decodeIfPresent(String.self, forKey: .cruiseTime)
        returnPickupAirport = try container.decodeIfPresent(String.self, forKey: .returnPickupAirport)
        returnPickupAirline = try container.decodeIfPresent(String.self, forKey: .returnPickupAirline)
        returnPickupFlight = try container.decodeIfPresent(String.self, forKey: .returnPickupFlight)
        returnOriginAirportCity = try container.decodeIfPresent(String.self, forKey: .returnOriginAirportCity)
        // Handle return pickup coordinates that might be String or Double
        if let latString = try? container.decodeIfPresent(String.self, forKey: .returnPickupLatitude), !latString.isEmpty, let lat = Double(latString) {
            returnPickupLatitude = lat
        } else if let latDouble = try? container.decodeIfPresent(Double.self, forKey: .returnPickupLatitude) {
            returnPickupLatitude = latDouble
        } else {
            returnPickupLatitude = nil
        }
        
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .returnPickupLongitude), !lngString.isEmpty, let lng = Double(lngString) {
            returnPickupLongitude = lng
        } else if let lngDouble = try? container.decodeIfPresent(Double.self, forKey: .returnPickupLongitude) {
            returnPickupLongitude = lngDouble
        } else {
            returnPickupLongitude = nil
        }
        returnDropoff = try container.decodeIfPresent(String.self, forKey: .returnDropoff)
        fboAddress = try container.decodeIfPresent(String.self, forKey: .fboAddress)
        fboName = try container.decodeIfPresent(String.self, forKey: .fboName)
        returnDropoffAddress = try container.decodeIfPresent(String.self, forKey: .returnDropoffAddress)
        returnDropoffAirport = try container.decodeIfPresent(String.self, forKey: .returnDropoffAirport)
        returnDropoffAirline = try container.decodeIfPresent(String.self, forKey: .returnDropoffAirline)
        returnDropoffFlight = try container.decodeIfPresent(String.self, forKey: .returnDropoffFlight)
        // Handle return dropoff coordinates that might be String or Double
        if let latString = try? container.decodeIfPresent(String.self, forKey: .returnDropoffLatitude), !latString.isEmpty, let lat = Double(latString) {
            returnDropoffLatitude = lat
        } else if let latDouble = try? container.decodeIfPresent(Double.self, forKey: .returnDropoffLatitude) {
            returnDropoffLatitude = latDouble
        } else {
            returnDropoffLatitude = nil
        }
        
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .returnDropoffLongitude), !lngString.isEmpty, let lng = Double(lngString) {
            returnDropoffLongitude = lng
        } else if let lngDouble = try? container.decodeIfPresent(Double.self, forKey: .returnDropoffLongitude) {
            returnDropoffLongitude = lngDouble
        } else {
            returnDropoffLongitude = nil
        }
        meetGreetChoices = try container.decode(Int.self, forKey: .meetGreetChoices)
        returnMeetGreetChoices = try container.decodeIfPresent(Int.self, forKey: .returnMeetGreetChoices)
        
        // Handle extraStops that might be String, Array of Strings, or Array of Objects
        if let extraStopsString = try? container.decodeIfPresent(String.self, forKey: .extraStops) {
            extraStops = extraStopsString
        } else if let extraStopsArray = try? container.decodeIfPresent([String].self, forKey: .extraStops) {
            extraStops = extraStopsArray.joined(separator: ", ")
        } else if let extraStopsObjects = try? container.decodeIfPresent([ExtraStopObject].self, forKey: .extraStops) {
            // Convert array of objects to JSON string for storage
            do {
                let jsonData = try JSONEncoder().encode(extraStopsObjects)
                extraStops = String(data: jsonData, encoding: .utf8)
            } catch {
                print("Error encoding extra stops objects: \(error)")
                extraStops = nil
            }
        } else {
            extraStops = nil
        }
        
        // Handle returnExtraStops that might be String, Array of Strings, or Array of Objects
        if let returnExtraStopsString = try? container.decodeIfPresent(String.self, forKey: .returnExtraStops) {
            returnExtraStops = returnExtraStopsString
        } else if let returnExtraStopsArray = try? container.decodeIfPresent([String].self, forKey: .returnExtraStops) {
            returnExtraStops = returnExtraStopsArray.joined(separator: ", ")
        } else if let returnExtraStopsObjects = try? container.decodeIfPresent([ExtraStopObject].self, forKey: .returnExtraStops) {
            // Convert array of objects to JSON string for storage
            do {
                let jsonData = try JSONEncoder().encode(returnExtraStopsObjects)
                returnExtraStops = String(data: jsonData, encoding: .utf8)
            } catch {
                print("Error encoding return extra stops objects: \(error)")
                returnExtraStops = nil
            }
        } else {
            returnExtraStops = nil
        }
        serviceType = try container.decode(String.self, forKey: .serviceType)
        
        print("🔍 DECODING EDIT RESERVATION DATA:")
        print("  Transfer Type: \(transferType)")
        print("  Service Type: \(serviceType)")
        print("  Lose Affiliate: \(loseAffiliate ?? "nil")")
        
        pickupDate = try container.decode(String.self, forKey: .pickupDate)
        pickupTime = try container.decode(String.self, forKey: .pickupTime)
        returnPickupDate = try container.decodeIfPresent(String.self, forKey: .returnPickupDate)
        returnPickupTime = try container.decodeIfPresent(String.self, forKey: .returnPickupTime)
        totalPassengers = try container.decode(Int.self, forKey: .totalPassengers)
        luggageCount = try container.decode(Int.self, forKey: .luggageCount)
        childCertified = try container.decodeIfPresent(String.self, forKey: .childCertified)
        babySeat = try container.decodeIfPresent(String.self, forKey: .babySeat)
        boosterSeat = try container.decodeIfPresent(String.self, forKey: .boosterSeat)
        petFriendly = try container.decodeIfPresent(String.self, forKey: .petFriendly)
        handicap = try container.decodeIfPresent(String.self, forKey: .handicap)
        vehicleType = try container.decodeIfPresent(Int.self, forKey: .vehicleType)
        vehicleId = try container.decodeIfPresent(Int.self, forKey: .vehicleId)
        driverId = try container.decodeIfPresent(Int.self, forKey: .driverId)
        paymentId = try container.decodeIfPresent(String.self, forKey: .paymentId)
        quoteAmount = try container.decodeIfPresent(String.self, forKey: .quoteAmount)
        hourlyRate = try container.decodeIfPresent(String.self, forKey: .hourlyRate)
        numberOfHours = try container.decodeIfPresent(Int.self, forKey: .numberOfHours)
        numberOfVehicles = try container.decodeIfPresent(Int.self, forKey: .numberOfVehicles)
        distance = try container.decodeIfPresent(String.self, forKey: .distance)
        duration = try container.decodeIfPresent(String.self, forKey: .duration)
        // Handle amenities that might be String or Array
        if let amenitiesString = try? container.decodeIfPresent(String.self, forKey: .amenities) {
            amenities = amenitiesString
        } else if let amenitiesArray = try? container.decodeIfPresent([String].self, forKey: .amenities) {
            amenities = amenitiesArray.joined(separator: ", ")
        } else {
            amenities = nil
        }
        // Handle driverLanguages that might be String or Array
        if let driverLanguagesString = try? container.decodeIfPresent(String.self, forKey: .driverLanguages) {
            driverLanguages = driverLanguagesString
        } else if let driverLanguagesArray = try? container.decodeIfPresent([String].self, forKey: .driverLanguages) {
            driverLanguages = driverLanguagesArray.joined(separator: ", ")
        } else {
            driverLanguages = nil
        }
        
        // Handle driverDresses that might be String or Array
        if let driverDressesString = try? container.decodeIfPresent(String.self, forKey: .driverDresses) {
            driverDresses = driverDressesString
        } else if let driverDressesArray = try? container.decodeIfPresent([String].self, forKey: .driverDresses) {
            driverDresses = driverDressesArray.joined(separator: ", ")
        } else {
            driverDresses = nil
        }
        bookingInstructions = try container.decodeIfPresent(String.self, forKey: .bookingInstructions)
        acceptedOn = try container.decodeIfPresent(String.self, forKey: .acceptedOn)
        paymentStatus = try container.decodeIfPresent(String.self, forKey: .paymentStatus)
        bookingStatus = try container.decodeIfPresent(String.self, forKey: .bookingStatus)
        chargedAmount = try container.decodeIfPresent(String.self, forKey: .chargedAmount)
        affiliateChargedAmount = try container.decodeIfPresent(String.self, forKey: .affiliateChargedAmount)
        statusChangeFlag = try container.decodeIfPresent(String.self, forKey: .statusChangeFlag)
        emailToken = try container.decodeIfPresent(String.self, forKey: .emailToken)
        createdByRole = try container.decodeIfPresent(String.self, forKey: .createdByRole)
        createdBy = try container.decodeIfPresent(Int.self, forKey: .createdBy)
        cancellationReason = try container.decodeIfPresent(String.self, forKey: .cancellationReason)
        departingAirportCity = try container.decodeIfPresent(String.self, forKey: .departingAirportCity)
        status = try container.decodeIfPresent(String.self, forKey: .status)
        reservationShares = try container.decodeIfPresent(String.self, forKey: .reservationShares)
        shareArray = try container.decodeIfPresent(String.self, forKey: .shareArray)
        reminderBeforeOneHour = try container.decodeIfPresent(String.self, forKey: .reminderBeforeOneHour)
        reminderBeforeOneDay = try container.decodeIfPresent(String.self, forKey: .reminderBeforeOneDay)
        reminderEmailSent = try container.decodeIfPresent(String.self, forKey: .reminderEmailSent)
        reminderSmsSent = try container.decodeIfPresent(String.self, forKey: .reminderSmsSent)
        cancellationReminderSmsSent = try container.decodeIfPresent(String.self, forKey: .cancellationReminderSmsSent)
        changedFields = try container.decodeIfPresent(String.self, forKey: .changedFields)
        bookingRelatedTo = try container.decodeIfPresent(Int.self, forKey: .bookingRelatedTo)
        isTransferred = try container.decodeIfPresent(Int.self, forKey: .isTransferred)
        waitingTimeInMins = try container.decodeIfPresent(Int.self, forKey: .waitingTimeInMins)
        createdAt = try container.decodeIfPresent(String.self, forKey: .createdAt)
        updatedAt = try container.decodeIfPresent(String.self, forKey: .updatedAt)
        passengerName = try container.decodeIfPresent(String.self, forKey: .passengerName)
        passengerCellIsd = try container.decodeIfPresent(String.self, forKey: .passengerCellIsd)
        passengerCellCountry = try container.decodeIfPresent(String.self, forKey: .passengerCellCountry)
        passengerCell = try container.decodeIfPresent(String.self, forKey: .passengerCell)
        passengerEmail = try container.decodeIfPresent(String.self, forKey: .passengerEmail)
        passengerImage = try container.decodeIfPresent(String.self, forKey: .passengerImage)
        // Handle chargedAmenities that might be String or Array
        if let chargedAmenitiesString = try? container.decodeIfPresent(String.self, forKey: .chargedAmenities) {
            chargedAmenities = chargedAmenitiesString
        } else if let chargedAmenitiesArray = try? container.decodeIfPresent([String].self, forKey: .chargedAmenities) {
            chargedAmenities = chargedAmenitiesArray.joined(separator: ", ")
        } else {
            chargedAmenities = nil
        }
        vehicleYear = try container.decodeIfPresent(String.self, forKey: .vehicleYear)
        vehicleMake = try container.decodeIfPresent(Int.self, forKey: .vehicleMake)
        vehicleModel = try container.decodeIfPresent(Int.self, forKey: .vehicleModel)
        // Handle vehicleColor that might be String or Int
        if let colorString = try? container.decodeIfPresent(String.self, forKey: .vehicleColor), let color = Int(colorString) {
            vehicleColor = color
        } else {
            vehicleColor = try container.decodeIfPresent(Int.self, forKey: .vehicleColor)
        }
        vehicleLicensePlate = try container.decodeIfPresent(String.self, forKey: .vehicleLicensePlate)
        vehicleSeats = try container.decodeIfPresent(Int.self, forKey: .vehicleSeats)
        driverName = try container.decodeIfPresent(String.self, forKey: .driverName)
        driverGender = try container.decodeIfPresent(String.self, forKey: .driverGender)
        driverCellIsd = try container.decodeIfPresent(String.self, forKey: .driverCellIsd)
        driverCellCountry = try container.decodeIfPresent(String.self, forKey: .driverCellCountry)
        driverCell = try container.decodeIfPresent(String.self, forKey: .driverCell)
        driverEmail = try container.decodeIfPresent(String.self, forKey: .driverEmail)
        driverPhoneType = try container.decodeIfPresent(String.self, forKey: .driverPhoneType)
        driverVeteran = try container.decodeIfPresent(String.self, forKey: .driverVeteran)
        driverDod = try container.decodeIfPresent(String.self, forKey: .driverDod)
        driverFoidCard = try container.decodeIfPresent(String.self, forKey: .driverFoidCard)
        driverExLawOfficer = try container.decodeIfPresent(String.self, forKey: .driverExLawOfficer)
        driverBackgroundCertified = try container.decodeIfPresent(String.self, forKey: .driverBackgroundCertified)
        vehicleImageId = try container.decodeIfPresent(String.self, forKey: .vehicleImageId)
        driverImageId = try container.decodeIfPresent(String.self, forKey: .driverImageId)
        loseAffiliateName = try container.decodeIfPresent(String.self, forKey: .loseAffiliateName)
        loseAffiliatePhoneIsd = try container.decodeIfPresent(String.self, forKey: .loseAffiliatePhoneIsd)
        loseAffiliatePhoneCountry = try container.decodeIfPresent(String.self, forKey: .loseAffiliatePhoneCountry)
        
        // Handle loseAffiliatePhone which might be a number or string
        if let phoneString = try? container.decodeIfPresent(String.self, forKey: .loseAffiliatePhone) {
            loseAffiliatePhone = phoneString
        } else if let phoneNumber = try? container.decodeIfPresent(Int.self, forKey: .loseAffiliatePhone) {
            loseAffiliatePhone = String(phoneNumber)
        } else {
            loseAffiliatePhone = nil
        }
        
        loseAffiliateEmail = try container.decodeIfPresent(String.self, forKey: .loseAffiliateEmail)
        currency = try container.decodeIfPresent(String.self, forKey: .currency)
        // Handle airport coordinates that might be String or Double or missing
        if let latString = try? container.decodeIfPresent(String.self, forKey: .pickupAirportLatitude), !latString.isEmpty, let lat = Double(latString) {
            pickupAirportLatitude = lat
        } else if let latDouble = try? container.decodeIfPresent(Double.self, forKey: .pickupAirportLatitude) {
            pickupAirportLatitude = latDouble
        } else {
            pickupAirportLatitude = nil
        }
        
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .pickupAirportLongitude), !lngString.isEmpty, let lng = Double(lngString) {
            pickupAirportLongitude = lng
        } else if let lngDouble = try? container.decodeIfPresent(Double.self, forKey: .pickupAirportLongitude) {
            pickupAirportLongitude = lngDouble
        } else {
            pickupAirportLongitude = nil
        }
        
        if let latString = try? container.decodeIfPresent(String.self, forKey: .dropoffAirportLatitude), !latString.isEmpty, let lat = Double(latString) {
            dropoffAirportLatitude = lat
        } else if let latDouble = try? container.decodeIfPresent(Double.self, forKey: .dropoffAirportLatitude) {
            dropoffAirportLatitude = latDouble
        } else {
            dropoffAirportLatitude = nil
        }
        
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .dropoffAirportLongitude), !lngString.isEmpty, let lng = Double(lngString) {
            dropoffAirportLongitude = lng
        } else if let lngDouble = try? container.decodeIfPresent(Double.self, forKey: .dropoffAirportLongitude) {
            dropoffAirportLongitude = lngDouble
        } else {
            dropoffAirportLongitude = nil
        }
        
        // Handle return pickup airport coordinates that might be String or Double
        if let latString = try? container.decodeIfPresent(String.self, forKey: .returnPickupAirportLatitude), !latString.isEmpty, let lat = Double(latString) {
            returnPickupAirportLatitude = lat
        } else if let latDouble = try? container.decodeIfPresent(Double.self, forKey: .returnPickupAirportLatitude) {
            returnPickupAirportLatitude = latDouble
        } else {
            returnPickupAirportLatitude = nil
        }
        
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .returnPickupAirportLongitude), !lngString.isEmpty, let lng = Double(lngString) {
            returnPickupAirportLongitude = lng
        } else if let lngDouble = try? container.decodeIfPresent(Double.self, forKey: .returnPickupAirportLongitude) {
            returnPickupAirportLongitude = lngDouble
        } else {
            returnPickupAirportLongitude = nil
        }
        
        // Handle return dropoff airport coordinates that might be String or Double
        if let latString = try? container.decodeIfPresent(String.self, forKey: .returnDropoffAirportLatitude), !latString.isEmpty, let lat = Double(latString) {
            returnDropoffAirportLatitude = lat
        } else if let latDouble = try? container.decodeIfPresent(Double.self, forKey: .returnDropoffAirportLatitude) {
            returnDropoffAirportLatitude = latDouble
        } else {
            returnDropoffAirportLatitude = nil
        }
        
        if let lngString = try? container.decodeIfPresent(String.self, forKey: .returnDropoffAirportLongitude), !lngString.isEmpty, let lng = Double(lngString) {
            returnDropoffAirportLongitude = lng
        } else if let lngDouble = try? container.decodeIfPresent(Double.self, forKey: .returnDropoffAirportLongitude) {
            returnDropoffAirportLongitude = lngDouble
        } else {
            returnDropoffAirportLongitude = nil
        }
        
        affiliateType = try container.decodeIfPresent(String.self, forKey: .affiliateType)
        looseCustomer = try container.decodeIfPresent(LooseCustomer.self, forKey: .looseCustomer)
        vehicleCreatedBy = try container.decodeIfPresent(Int.self, forKey: .vehicleCreatedBy)
        vehicleYearName = try container.decodeIfPresent(String.self, forKey: .vehicleYearName)
        vehicleMakeName = try container.decodeIfPresent(String.self, forKey: .vehicleMakeName)
        vehicleModelName = try container.decodeIfPresent(String.self, forKey: .vehicleModelName)
        vehicleColorName = try container.decodeIfPresent(String.self, forKey: .vehicleColorName)
        vehicleLicensePlateName = try container.decodeIfPresent(String.self, forKey: .vehicleLicensePlateName)
        vehicleSeatsName = try container.decodeIfPresent(Int.self, forKey: .vehicleSeatsName)
        vehicleTypeName = try container.decodeIfPresent(String.self, forKey: .vehicleTypeName)
        vehicleImages = try container.decodeIfPresent([String].self, forKey: .vehicleImages)
        driverImage = try container.decodeIfPresent(String.self, forKey: .driverImage)
        meetGreetChoiceName = try container.decodeIfPresent(String.self, forKey: .meetGreetChoiceName)
    }
}

struct LooseCustomer: Codable {
    let firstName: String?
    let lastName: String?
    let mobileIsd: String?
    let mobile: String?
    let gender: String?
    let email: String?
    let address: String?
    let city: String?
    let state: String?
    let country: String?
    
    enum CodingKeys: String, CodingKey {
        case firstName = "first_name"
        case lastName = "last_name"
        case mobileIsd = "mobileIsd"
        case mobile
        case gender
        case email
        case address
        case city
        case state
        case country
    }
    
    // Custom decoder to handle optional fields
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        firstName = try container.decodeIfPresent(String.self, forKey: .firstName)
        lastName = try container.decodeIfPresent(String.self, forKey: .lastName)
        mobileIsd = try container.decodeIfPresent(String.self, forKey: .mobileIsd)
        mobile = try container.decodeIfPresent(String.self, forKey: .mobile)
        gender = try container.decodeIfPresent(String.self, forKey: .gender)
        email = try container.decodeIfPresent(String.self, forKey: .email)
        address = try container.decodeIfPresent(String.self, forKey: .address)
        city = try container.decodeIfPresent(String.self, forKey: .city)
        state = try container.decodeIfPresent(String.self, forKey: .state)
        country = try container.decodeIfPresent(String.self, forKey: .country)
    }
}

struct EditReservationCurrency: Codable {
    let countryName: String?
    let currency: String?
    let currencyCountry: String?
    let symbol: String?
    let dateFormat: String?
}

// MARK: - Extra Stop Object Model
struct ExtraStopObject: Codable {
    let rate: String?
    let address: String?
    let latitude: String?
    let longitude: String?
    let bookingInstructions: String?
    
    enum CodingKeys: String, CodingKey {
        case rate
        case address
        case latitude
        case longitude
        case bookingInstructions = "booking_instructions"
    }
}

// MARK: - Edit Reservation Service
class EditReservationService: ObservableObject {
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var editData: EditReservationData?
    @Published var repeatData: EditReservationData?
    @Published var currency: EditReservationCurrency?
    @Published var repeatCurrency: EditReservationCurrency?
    
    private var cancellables = Set<AnyCancellable>()
    
    func fetchEditReservation(bookingId: Int) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        guard let url = URL(string: "\(APIConfig.baseURL)/api/individual/get-reservation/\(bookingId)/edit") else {
            await MainActor.run {
                isLoading = false
                errorMessage = "Invalid URL"
            }
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Add authorization header if available
        if let token = StorageManager.shared.getAuthToken() {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw NetworkError.invalidResponse
            }
            
            if httpResponse.statusCode == 200 {
                // Print the raw JSON response for debugging
                if let jsonString = String(data: data, encoding: .utf8) {
                    print("🔍 RAW API RESPONSE:")
                    print(jsonString)
                    print("🔍 END RAW API RESPONSE")
                }
                
                let editResponse = try JSONDecoder().decode(EditReservationResponse.self, from: data)
                
                await MainActor.run {
                    self.editData = editResponse.data
                    self.currency = editResponse.currency
                    self.isLoading = false
                }
                
                print("✅ Edit reservation data fetched successfully for booking ID: \(bookingId)")
                print("🔍 DECODED EDIT DATA:")
                print("  Transfer Type: \(editResponse.data.transferType)")
                print("  Service Type: \(editResponse.data.serviceType)")
                print("  Vehicle Type: \(editResponse.data.vehicleType ?? -1)")
                print("  Vehicle ID: \(editResponse.data.vehicleId ?? -1)")
                print("  Vehicle Year: \(editResponse.data.vehicleYear ?? "nil")")
                print("  Vehicle Make: \(editResponse.data.vehicleMake ?? -1)")
                print("  Vehicle Model: \(editResponse.data.vehicleModel ?? -1)")
                print("  Vehicle Type Name: \(editResponse.data.vehicleTypeName ?? "nil")")
                print("  Vehicle Make Name: \(editResponse.data.vehicleMakeName ?? "nil")")
                print("  Vehicle Model Name: \(editResponse.data.vehicleModelName ?? "nil")")
                print("  Vehicle Year Name: \(editResponse.data.vehicleYearName ?? "nil")")
                print("  Vehicle Color Name: \(editResponse.data.vehicleColorName ?? "nil")")
                print("  Vehicle License Plate: \(editResponse.data.vehicleLicensePlate ?? "nil")")
                print("  Vehicle Seats: \(editResponse.data.vehicleSeats ?? -1)")
                print("  Driver Name: \(editResponse.data.driverName ?? "nil")")
                print("  Driver Cell: \(editResponse.data.driverCell ?? "nil")")
                print("  Driver Email: \(editResponse.data.driverEmail ?? "nil")")
                print("  Pickup Address: \(editResponse.data.pickupAddress)")
                print("  Dropoff Address: \(editResponse.data.dropoffAddress)")
                print("  Pickup Date: \(editResponse.data.pickupDate)")
                print("  Pickup Time: \(editResponse.data.pickupTime)")
                print("  Total Passengers: \(editResponse.data.totalPassengers)")
                print("  Luggage Count: \(editResponse.data.luggageCount)")
                print("  Number of Vehicles: \(editResponse.data.numberOfVehicles ?? -1)")
                print("  Booking Instructions: \(editResponse.data.bookingInstructions ?? "nil")")
                print("🔍 END DECODED EDIT DATA")
            } else {
                let errorData = try JSONDecoder().decode(ErrorResponse.self, from: data)
                await MainActor.run {
                    self.errorMessage = errorData.message ?? "Failed to fetch edit reservation data"
                    self.isLoading = false
                }
            }
        } catch {
            print("❌ Error fetching edit reservation data: \(error)")
            if let decodingError = error as? DecodingError {
                print("🔍 Decoding Error Details:")
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("  Type Mismatch: Expected \(type), found at path: \(context.codingPath)")
                case .valueNotFound(let type, let context):
                    print("  Value Not Found: Expected \(type), found null at path: \(context.codingPath)")
                case .keyNotFound(let key, let context):
                    print("  Key Not Found: Missing key '\(key)' at path: \(context.codingPath)")
                case .dataCorrupted(let context):
                    print("  Data Corrupted: \(context.debugDescription)")
                @unknown default:
                    print("  Unknown decoding error")
                }
            }
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
            }
        }
    }

    func fetchRepeatReservation(bookingId: Int) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        guard let url = URL(string: "\(APIConfig.baseURL)/api/individual/get-reservation/\(bookingId)/repeat") else {
            await MainActor.run {
                isLoading = false
                errorMessage = "Invalid URL"
            }
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if let token = StorageManager.shared.getAuthToken() {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw NetworkError.invalidResponse
            }
            
            if httpResponse.statusCode == 200 {
                if let jsonString = String(data: data, encoding: .utf8) {
                    print("🔍 RAW REPEAT API RESPONSE:")
                    print(jsonString)
                    print("🔍 END RAW REPEAT API RESPONSE")
                }
                
                let repeatResponse = try JSONDecoder().decode(EditReservationResponse.self, from: data)
                
                await MainActor.run {
                    self.repeatData = repeatResponse.data
                    self.repeatCurrency = repeatResponse.currency
                    self.isLoading = false
                }
                
                print("✅ Repeat reservation data fetched successfully for booking ID: \(bookingId)")
            } else {
                let errorString = String(data: data, encoding: .utf8) ?? "Unknown error"
                print("❌ Failed to fetch repeat reservation. Status code: \(httpResponse.statusCode). Response: \(errorString)")
                await MainActor.run {
                    self.isLoading = false
                    self.errorMessage = "Failed to fetch repeat reservation."
                }
            }
        } catch {
            print("❌ Error fetching repeat reservation: \(error)")
            await MainActor.run {
                self.isLoading = false
                self.errorMessage = error.localizedDescription
            }
        }
    }
    
    func fetchReturnReservation(bookingId: Int) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        do {
            let response: EditReservationResponse = try await NetworkService.shared.request(
                endpoint: .returnReservation(bookingId: bookingId),
                body: nil,
                responseType: EditReservationResponse.self
            )
            
            if let jsonString = try? JSONEncoder().encode(response),
               let json = String(data: jsonString, encoding: .utf8) {
                print("🔍 RAW RETURN API RESPONSE:")
                print(json)
                print("🔍 END RAW RETURN API RESPONSE")
            }
            
            await MainActor.run {
                self.repeatData = response.data
                self.repeatCurrency = response.currency
                self.isLoading = false
            }
            
            print("✅ Return reservation data fetched successfully for booking ID: \(bookingId)")
        } catch {
            print("❌ Error fetching return reservation: \(error)")
            await MainActor.run {
                self.isLoading = false
                self.errorMessage = error.localizedDescription
            }
        }
    }
    
    func fetchRoundTripReservation(bookingId: Int) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        guard let url = URL(string: "\(APIConfig.baseURL)/api/individual/get-reservation/\(bookingId)/round") else {
            await MainActor.run {
                isLoading = false
                errorMessage = "Invalid URL"
            }
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        if let token = StorageManager.shared.getAuthToken() {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw NetworkError.invalidResponse
            }
            
            // Print RAW response BEFORE decoding
            if let jsonString = String(data: data, encoding: .utf8) {
                print("🔍 RAW ROUND TRIP API RESPONSE (BEFORE DECODING):")
                print(jsonString)
                print("🔍 END RAW ROUND TRIP API RESPONSE")
            }
            
            if httpResponse.statusCode == 200 {
                let roundTripResponse = try JSONDecoder().decode(EditReservationResponse.self, from: data)
                
                await MainActor.run {
                    self.repeatData = roundTripResponse.data
                    self.repeatCurrency = roundTripResponse.currency
                    self.isLoading = false
                }
                
                print("✅ Round trip reservation data fetched successfully for booking ID: \(bookingId)")
                print("🔍 DECODED SERVICE TYPE: \(roundTripResponse.data.serviceType)")
            } else {
                let errorString = String(data: data, encoding: .utf8) ?? "Unknown error"
                print("❌ Failed to fetch round trip reservation. Status code: \(httpResponse.statusCode). Response: \(errorString)")
                await MainActor.run {
                    self.isLoading = false
                    self.errorMessage = "Failed to fetch round trip reservation."
                }
            }
        } catch {
            print("❌ Error fetching round trip reservation: \(error)")
            if let decodingError = error as? DecodingError {
                print("🔍 Decoding Error Details:")
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("  Type Mismatch: Expected \(type), found at path: \(context.codingPath)")
                case .valueNotFound(let type, let context):
                    print("  Value Not Found: Expected \(type), found null at path: \(context.codingPath)")
                case .keyNotFound(let key, let context):
                    print("  Key Not Found: Missing key '\(key)' at path: \(context.codingPath)")
                case .dataCorrupted(let context):
                    print("  Data Corrupted: \(context.debugDescription)")
                @unknown default:
                    print("  Unknown decoding error")
                }
            }
            await MainActor.run {
                self.isLoading = false
                self.errorMessage = error.localizedDescription
            }
        }
    }
    
    func updateReservation(request: EditReservationRequest) async -> (success: Bool, data: EditReservationUpdateData?, currency: EditReservationCurrency?, error: String?) {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        print("🚀 EDIT RESERVATION API REQUEST:")
        print("  Reservation ID: \(request.reservationId)")
        print("  Service Type: \(request.serviceType)")
        print("  Transfer Type: \(request.transferType)")
        print("  Vehicle ID: \(request.vehicleId)")
        print("  Driver ID: \(request.driverId)")
        print("  Grand Total: \(request.grandTotal)")
        
        do {
            // Convert request to dictionary with null values included
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let jsonData = try encoder.encode(request)
            let bodyDict = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] ?? [:]
            
            // Print the complete payload being sent
            print("🚀 COMPLETE EDIT API PAYLOAD BEING SENT:")
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print(jsonString)
            }
            print("📋 EDIT PAYLOAD DICTIONARY:")
            print(bodyDict)
            
            let response: EditReservationUpdateResponse = try await NetworkService.shared.request(
                endpoint: .editReservation,
                body: bodyDict,
                responseType: EditReservationUpdateResponse.self
            )
            
            DispatchQueue.main.async {
                self.currency = response.currency
                self.isLoading = false
                print("✅ EditReservationService - Reservation updated successfully!")
                if let data = response.data {
                    print("  Reservation ID: \(data.reservationId)")
                }
                print("  Message: \(response.message ?? "No message")")
            }
            
            return (success: response.success ?? true, data: response.data, currency: response.currency, error: nil)
        } catch {
            let errorMessage = error.localizedDescription
            DispatchQueue.main.async {
                self.errorMessage = errorMessage
                self.isLoading = false
                print("❌ EditReservationService - Failed to update reservation: \(errorMessage)")
            }
            return (success: false, data: nil, currency: nil, error: errorMessage)
        }
    }
}

// MARK: - Edit Reservation Request Models
struct EditReservationRequest: Codable {
    let serviceType: String
    let transferType: String
    let returnTransferType: String
    let numberOfHours: String  // Changed to String to match web
    let accountType: String
    let changeIndividualData: String  // Changed to String to match web
    let passengerName: String
    let passengerEmail: String
    let passengerCell: String
    let passengerCellIsd: String
    let passengerCellCountry: String
    let totalPassengers: String  // Changed to String to match web
    let luggageCount: String  // Changed to String to match web
    let bookingInstructions: String
    let returnBookingInstructions: String
    let affiliateType: String
    let affiliateId: String
    let loseAffiliateName: String
    let loseAffiliatePhone: String
    let loseAffiliatePhoneIsd: String
    let loseAffiliatePhoneCountry: String
    let loseAffiliateEmail: String
    let vehicleType: String
    let vehicleTypeName: String
    let vehicleId: String  // Changed to String to match web
    let vehicleMake: String
    let vehicleMakeName: String
    let vehicleModel: String
    let vehicleModelName: String
    let vehicleYear: String
    let vehicleYearName: String
    let vehicleColor: String
    let vehicleColorName: String
    let vehicleLicensePlate: String
    let vehicleSeats: String
    let driverId: String
    let driverName: String
    let driverGender: String
    let driverCell: String
    let driverCellIsd: String
    let driverCellCountry: String
    let driverEmail: String
    let driverPhoneType: String
    let driverImageId: String
    let vehicleImageId: String
    let meetGreetChoices: String  // Changed to String to match web
    let meetGreetChoicesName: String
    let numberOfVehicles: String  // Changed to String to match web
    let pickupDate: String
    let pickupTime: String
    let extraStops: [ExtraStopRequest]
    let pickup: String
    let pickupLatitude: String
    let pickupLongitude: String
    let pickupAirportOption: AirportOption?
    let pickupAirport: String  // Changed to String to match web
    let pickupAirportName: String
    let pickupAirportLatitude: String  // Changed to String to match web
    let pickupAirportLongitude: String  // Changed to String to match web
    let pickupAirlineOption: AirlineOption?
    let pickupAirline: String  // Changed to String to match web
    let pickupAirlineName: String
    let pickupFlight: String
    let originAirportCity: String
    let cruisePort: String
    let cruiseName: String
    let cruiseTime: String
    let dropoff: String
    let dropoffLatitude: String
    let dropoffLongitude: String
    let dropoffAirportOption: AirportOption?
    let dropoffAirport: String  // Changed to String to match web
    let dropoffAirportName: String
    let dropoffAirportLatitude: String  // Changed to String to match web
    let dropoffAirportLongitude: String  // Changed to String to match web
    let dropoffAirlineOption: AirlineOption?
    let dropoffAirline: String  // Changed to String to match web
    let dropoffAirlineName: String
    let dropoffFlight: String
    let returnMeetGreetChoices: String  // Changed to String to match web
    let returnMeetGreetChoicesName: String
    let returnPickupDate: String
    let returnPickupTime: String
    let returnExtraStops: [ExtraStopRequest]
    let returnPickup: String
    let returnPickupLatitude: String  // Changed to String to match web
    let returnPickupLongitude: String  // Changed to String to match web
    let returnPickupAirportOption: AirportOption?
    let returnPickupAirport: String  // Changed to String to match web
    let returnPickupAirportName: String
    let returnPickupAirportLatitude: String  // Changed to String to match web
    let returnPickupAirportLongitude: String  // Changed to String to match web
    let returnPickupAirlineOption: AirlineOption?
    let returnPickupAirline: String  // Changed to String to match web
    let returnPickupAirlineName: String
    let returnPickupFlight: String
    let returnCruisePort: String
    let returnCruiseName: String
    let returnCruiseTime: String
    let returnDropoff: String
    let returnDropoffLatitude: String  // Changed to String to match web
    let returnDropoffLongitude: String  // Changed to String to match web
    let returnDropoffAirportOption: AirportOption?
    let returnDropoffAirport: String  // Changed to String to match web
    let returnDropoffAirportName: String
    let returnDropoffAirportLatitude: String  // Changed to String to match web
    let returnDropoffAirportLongitude: String  // Changed to String to match web
    let returnDropoffAirlineOption: AirlineOption?
    let returnDropoffAirline: String  // Changed to String to match web
    let returnDropoffAirlineName: String
    let returnDropoffFlight: String
    let driverLanguages: [String]  // Changed to [String] to match web
    let driverDresses: [String]
    let amenities: [String]
    let chargedAmenities: [String]
    let journeyDistance: String  // Changed to String to match web
    let journeyTime: String  // Changed to String to match web
    let returnJourneyDistance: String  // Changed to String to match web
    let returnJourneyTime: String  // Changed to String to match web
    let reservationId: String
    let updateType: String
    let departingAirportCity: String
    let currency: String
    let isMasterVehicle: String  // Changed to String to match web
    let proceed: String  // Changed to String to match web
    let rateArray: BookingRateArray
    let returnRateArray: BookingRateArray?
    let grandTotal: String  // Changed to String to match web
    let subTotal: String  // Changed to String to match web
    let returnSubTotal: String?  // Changed to String to match web
    let returnGrandTotal: String?  // Changed to String to match web
    let minRateInvolved: String  // Changed to String to match web
    let sharesArray: SharesArray
    let returnSharesArray: SharesArray?
    let returnAffiliateType: String
    let returnAffiliateId: String
    let returnDistance: String  // Changed to String to match web
    let returnVehicleId: String  // Changed to String to match web
    let noOfHours: String
    let fboAddress: String
    let fboName: String
    let returnFboAddress: String
    let returnFboName: String
    let createdByRole: String?  // Added to match web payload
    
    enum CodingKeys: String, CodingKey {
        case serviceType = "service_type"
        case transferType = "transfer_type"
        case returnTransferType = "return_transfer_type"
        case numberOfHours = "number_of_hours"
        case accountType = "account_type"
        case changeIndividualData = "change_individual_data"
        case passengerName = "passenger_name"
        case passengerEmail = "passenger_email"
        case passengerCell = "passenger_cell"
        case passengerCellIsd = "passenger_cell_isd"
        case passengerCellCountry = "passenger_cell_country"
        case totalPassengers = "total_passengers"
        case luggageCount = "luggage_count"
        case bookingInstructions = "booking_instructions"
        case returnBookingInstructions = "return_booking_instructions"
        case affiliateType = "affiliate_type"
        case affiliateId = "affiliate_id"
        case loseAffiliateName = "lose_affiliate_name"
        case loseAffiliatePhone = "lose_affiliate_phone"
        case loseAffiliatePhoneIsd = "lose_affiliate_phone_isd"
        case loseAffiliatePhoneCountry = "lose_affiliate_phone_country"
        case loseAffiliateEmail = "lose_affiliate_email"
        case vehicleType = "vehicle_type"
        case vehicleTypeName = "vehicle_type_name"
        case vehicleId = "vehicle_id"
        case vehicleMake = "vehicle_make"
        case vehicleMakeName = "vehicle_make_name"
        case vehicleModel = "vehicle_model"
        case vehicleModelName = "vehicle_model_name"
        case vehicleYear = "vehicle_year"
        case vehicleYearName = "vehicle_year_name"
        case vehicleColor = "vehicle_color"
        case vehicleColorName = "vehicle_color_name"
        case vehicleLicensePlate = "vehicle_license_plate"
        case vehicleSeats = "vehicle_seats"
        case driverId = "driver_id"
        case driverName = "driver_name"
        case driverGender = "driver_gender"
        case driverCell = "driver_cell"
        case driverCellIsd = "driver_cell_isd"
        case driverCellCountry = "driver_cell_country"
        case driverEmail = "driver_email"
        case driverPhoneType = "driver_phone_type"
        case driverImageId = "driver_image_id"
        case vehicleImageId = "vehicle_image_id"
        case meetGreetChoices = "meet_greet_choices"
        case meetGreetChoicesName = "meet_greet_choices_name"
        case numberOfVehicles = "number_of_vehicles"
        case pickupDate = "pickup_date"
        case pickupTime = "pickup_time"
        case extraStops = "extra_stops"
        case pickup
        case pickupLatitude = "pickup_latitude"
        case pickupLongitude = "pickup_longitude"
        case pickupAirportOption = "pickup_airport_option"
        case pickupAirport = "pickup_airport"
        case pickupAirportName = "pickup_airport_name"
        case pickupAirportLatitude = "pickup_airport_latitude"
        case pickupAirportLongitude = "pickup_airport_longitude"
        case pickupAirlineOption = "pickup_airline_option"
        case pickupAirline = "pickup_airline"
        case pickupAirlineName = "pickup_airline_name"
        case pickupFlight = "pickup_flight"
        case originAirportCity = "origin_airport_city"
        case cruisePort = "cruise_port"
        case cruiseName = "cruise_name"
        case cruiseTime = "cruise_time"
        case dropoff
        case dropoffLatitude = "dropoff_latitude"
        case dropoffLongitude = "dropoff_longitude"
        case dropoffAirportOption = "dropoff_airport_option"
        case dropoffAirport = "dropoff_airport"
        case dropoffAirportName = "dropoff_airport_name"
        case dropoffAirportLatitude = "dropoff_airport_latitude"
        case dropoffAirportLongitude = "dropoff_airport_longitude"
        case dropoffAirlineOption = "dropoff_airline_option"
        case dropoffAirline = "dropoff_airline"
        case dropoffAirlineName = "dropoff_airline_name"
        case dropoffFlight = "dropoff_flight"
        case returnMeetGreetChoices = "return_meet_greet_choices"
        case returnMeetGreetChoicesName = "return_meet_greet_choices_name"
        case returnPickupDate = "return_pickup_date"
        case returnPickupTime = "return_pickup_time"
        case returnExtraStops = "return_extra_stops"
        case returnPickup = "return_pickup"
        case returnPickupLatitude = "return_pickup_latitude"
        case returnPickupLongitude = "return_pickup_longitude"
        case returnPickupAirportOption = "return_pickup_airport_option"
        case returnPickupAirport = "return_pickup_airport"
        case returnPickupAirportName = "return_pickup_airport_name"
        case returnPickupAirportLatitude = "return_pickup_airport_latitude"
        case returnPickupAirportLongitude = "return_pickup_airport_longitude"
        case returnPickupAirlineOption = "return_pickup_airline_option"
        case returnPickupAirline = "return_pickup_airline"
        case returnPickupAirlineName = "return_pickup_airline_name"
        case returnPickupFlight = "return_pickup_flight"
        case returnCruisePort = "return_cruise_port"
        case returnCruiseName = "return_cruise_name"
        case returnCruiseTime = "return_cruise_time"
        case returnDropoff = "return_dropoff"
        case returnDropoffLatitude = "return_dropoff_latitude"
        case returnDropoffLongitude = "return_dropoff_longitude"
        case returnDropoffAirportOption = "return_dropoff_airport_option"
        case returnDropoffAirport = "return_dropoff_airport"
        case returnDropoffAirportName = "return_dropoff_airport_name"
        case returnDropoffAirportLatitude = "return_dropoff_airport_latitude"
        case returnDropoffAirportLongitude = "return_dropoff_airport_longitude"
        case returnDropoffAirlineOption = "return_dropoff_airline_option"
        case returnDropoffAirline = "return_dropoff_airline"
        case returnDropoffAirlineName = "return_dropoff_airline_name"
        case returnDropoffFlight = "return_dropoff_flight"
        case driverLanguages = "driver_languages"
        case driverDresses = "driver_dresses"
        case amenities
        case chargedAmenities = "charged_amenities"
        case journeyDistance = "journey_distance"
        case journeyTime = "journey_time"
        case returnJourneyDistance = "return_journey_distance"
        case returnJourneyTime = "return_journey_time"
        case reservationId = "reservation_id"
        case updateType = "update_type"
        case departingAirportCity = "departing_airport_city"
        case currency
        case isMasterVehicle = "is_master_vehicle"
        case proceed
        case rateArray = "rateArray"
        case grandTotal = "grand_total"
        case subTotal = "sub_total"
        case minRateInvolved = "min_rate_involved"
        case sharesArray = "shares_array"
        case returnAffiliateType = "return_affiliate_type"
        case returnAffiliateId = "return_affiliate_id"
        case returnDistance = "return_distance"
        case returnVehicleId = "return_vehicle_id"
        case noOfHours = "no_of_hours"
        case returnRateArray = "return_rate_array"
        case returnSubTotal = "return_sub_total"
        case returnGrandTotal = "return_grand_total"
        case returnSharesArray = "return_shares_array"
        case fboAddress = "fbo_address"
        case fboName = "fbo_name"
        case returnFboAddress = "return_fbo_address"
        case returnFboName = "return_fbo_name"
        case createdByRole = "created_by_role"
    }
}

// MARK: - Edit Reservation Response Models
struct EditReservationUpdateResponse: Codable {
    let success: Bool?
    let data: EditReservationUpdateData?
    let message: String?
    let currency: EditReservationCurrency?
}

struct EditReservationUpdateData: Codable {
    let reservationId: String
    
    enum CodingKeys: String, CodingKey {
        case reservationId = "reservation_id"
    }
}

// MARK: - Error Response
struct ErrorResponse: Codable {
    let success: Bool?
    let message: String?
}
