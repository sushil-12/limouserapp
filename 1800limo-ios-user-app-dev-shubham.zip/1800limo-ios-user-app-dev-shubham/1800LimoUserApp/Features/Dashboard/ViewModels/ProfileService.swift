import Foundation

@MainActor
class ProfileService: ObservableObject {
    @Published var profileData: ProfileData?
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var showError = false
    
    func fetchProfileData() async {
        isLoading = true
        errorMessage = nil
        
        print("🧾 [ProfileService] Starting fetchProfileData (endpoint: getProfileData)")
        
        do {
            let response: ProfileDataResponse = try await NetworkService.shared.request(
                endpoint: .getProfileData,
                body: nil,
                responseType: ProfileDataResponse.self
            )
            
            print("📥 [ProfileService] getProfileData response:")
            print("   • success: \(response.success)")
            print("   • message: \(response.message)")
            
            if response.success {
                if let data = response.data as ProfileData? {
                    print("   • profile id: \(data.id)")
                    print("   • user_id: \(data.user_id)")
                    print("   • name: \(data.first_name) \(data.last_name)")
                    print("   • mobile: \(data.mobileIsd) \(data.mobile)")
                } else {
                    print("   • ⚠️ response.success == true but data is nil")
                }
                
                profileData = response.data
                // Save to storage for persistence
                StorageManager.shared.saveProfileData(response.data)
                print("✅ [ProfileService] Profile data fetched successfully from getProfileData")
            } else {
                print("❌ [ProfileService] getProfileData failed with message: \(response.message)")
                errorMessage = response.message
                showError = true
            }
            
        } catch {
            print("❌ [ProfileService] Error fetching profile data from getProfileData: \(error)")
            // Provide more context on decoding errors
            if let decodingError = error as? DecodingError {
                print("🔍 [ProfileService] Decoding error details for getProfileData:")
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("   • typeMismatch for \(type): \(context.debugDescription)")
                    errorMessage = "Response format changed (type mismatch for \(type)): \(context.debugDescription)"
                case .valueNotFound(let type, let context):
                    print("   • valueNotFound for \(type): \(context.debugDescription)")
                    errorMessage = "Missing value for \(type): \(context.debugDescription)"
                case .keyNotFound(let key, let context):
                    print("   • keyNotFound '\(key.stringValue)': \(context.debugDescription)")
                    errorMessage = "Missing key '\(key.stringValue)': \(context.debugDescription)"
                case .dataCorrupted(let context):
                    print("   • dataCorrupted: \(context.debugDescription)")
                    errorMessage = "Corrupted data: \(context.debugDescription)"
                @unknown default:
                    print("   • unknown decoding error")
                    errorMessage = "Unknown decoding error"
                }
            } else {
                errorMessage = error.localizedDescription
            }
            showError = true

            // Fallback: try alternate profile endpoint with conversion
            print("🔁 [ProfileService] Falling back to profile API endpoint due to error. Trying alternate structure...")
            await fetchProfileDataFromProfileAPI()
        }
        
        isLoading = false
    }
    
    // MARK: - Fetch Profile Data from Profile API (Different endpoint)
    func fetchProfileDataFromProfileAPI() async {
        isLoading = true
        errorMessage = nil
        
        print("🧾 [ProfileService] Starting fetchProfileDataFromProfileAPI (endpoint: userProfile)")
        
        do {
            let response: ProfileAPIResponse = try await NetworkService.shared.request(
                endpoint: .userProfile,
                body: nil,
                responseType: ProfileAPIResponse.self
            )
            
            print("📥 [ProfileService] userProfile response:")
            print("   • success: \(response.success)")
            print("   • message: \(response.message)")
            
            if response.success {
                // Convert ProfileAPIData to ProfileData
                let convertedProfileData = convertProfileAPIToProfileData(response.data)
                print("   • converted profile id: \(convertedProfileData.id)")
                print("   • user_id: \(convertedProfileData.user_id)")
                print("   • name: \(convertedProfileData.first_name) \(convertedProfileData.last_name)")
                print("   • mobile: \(convertedProfileData.mobileIsd) \(convertedProfileData.mobile)")
                print("   • cards count: \(convertedProfileData.cards.count)")
                
                profileData = convertedProfileData
                // Save to storage for persistence
                StorageManager.shared.saveProfileData(convertedProfileData)
                print("✅ [ProfileService] Profile data fetched successfully from userProfile")
            } else {
                print("❌ [ProfileService] userProfile failed with message: \(response.message)")
                errorMessage = response.message
                showError = true
            }
            
        } catch {
            print("❌ [ProfileService] Error fetching profile data from userProfile: \(error)")
            if let decodingError = error as? DecodingError {
                print("🔍 [ProfileService] Decoding error details for userProfile:")
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("   • typeMismatch for \(type): \(context.debugDescription)")
                    errorMessage = "Response format changed (type mismatch for \(type)): \(context.debugDescription)"
                case .valueNotFound(let type, let context):
                    print("   • valueNotFound for \(type): \(context.debugDescription)")
                    errorMessage = "Missing value for \(type): \(context.debugDescription)"
                case .keyNotFound(let key, let context):
                    print("   • keyNotFound '\(key.stringValue)': \(context.debugDescription)")
                    errorMessage = "Missing key '\(key.stringValue)': \(context.debugDescription)"
                case .dataCorrupted(let context):
                    print("   • dataCorrupted: \(context.debugDescription)")
                    errorMessage = "Corrupted data: \(context.debugDescription)"
                @unknown default:
                    print("   • unknown decoding error")
                    errorMessage = "Unknown decoding error"
                }
            } else {
                errorMessage = error.localizedDescription
            }
            showError = true
        }
        
        isLoading = false
    }
    
    // MARK: - Update Profile
    func updateUserProfile(request: UpdateProfileRequest) async -> (success: Bool, message: String?) {
        isLoading = true
        errorMessage = nil
        
        print("📝 [ProfileService] Starting updateUserProfile with payload: \(request)")
        
        do {
            let response: UpdateProfileResponse = try await NetworkService.performRequest(
                endpoint: .updateUserProfile,
                body: request
            )
            
            print("📥 [ProfileService] updateUserProfile response success: \(response.success) message: \(response.message)")
            
            if response.success {
                await fetchProfileData()
                isLoading = false
                return (true, response.message)
            } else {
                errorMessage = response.message
                showError = true
                isLoading = false
                return (false, response.message)
            }
        } catch {
            print("❌ [ProfileService] updateUserProfile error: \(error)")
            errorMessage = error.localizedDescription
            showError = true
            isLoading = false
            return (false, error.localizedDescription)
        }
    }
    
    // MARK: - Convert ProfileAPI to ProfileData
    private func convertProfileAPIToProfileData(_ apiData: ProfileAPIData) -> ProfileData {
        // Convert ProfileCardData to CardData
        let convertedCards = apiData.cards.map { profileCard in
            CardData(
                id: profileCard.id,
                ID: profileCard.id,
                name: profileCard.name,
                brand: profileCard.brand,
                exp_month: profileCard.exp_month,
                exp_year: profileCard.exp_year,
                last4: "XXXX-XXXX-XXXX-\(profileCard.last4)",
                card_type: profileCard.metadata.cardType,
                cc_prority: profileCard.metadata.ccPriority
            )
        }
        
        return ProfileData(
            id: apiData.id,
            user_id: apiData.user_id,
            title: apiData.title,
            first_name: apiData.first_name,
            last_name: apiData.last_name,
            middle_name: apiData.middle_name,
            mobileIsd: apiData.mobileIsd,
            mobile: apiData.mobile,
            mobileCountry: apiData.mobileCountry,
            gender: apiData.gender,
            dob: apiData.dob,
            workIsd: apiData.workIsd,
            work_contact_number: apiData.work_contact_number,
            workCountry: apiData.workCountry,
            homeIsd: apiData.homeIsd,
            home_phone: apiData.home_phone,
            officeIsd: apiData.officeIsd,
            office_number: apiData.office_number,
            officeCountry: apiData.officeCountry,
            homeCountry: apiData.homeCountry,
            email: apiData.email,
            email_verificaiton_opt: apiData.email_verificaiton_opt,
            phone_otp: apiData.phone_otp,
            email_verificaiton_hash: apiData.email_verificaiton_hash,
            updating_email_id: apiData.updating_email_id,
            is_email_verified: apiData.is_email_verified,
            address: apiData.address,
            street: apiData.street,
            unit: apiData.unit,
            city: apiData.city,
            state: apiData.state,
            country: apiData.country,
            zip: apiData.zip,
            latitude: apiData.latitude,
            longitude: apiData.longitude,
            stripe_customer_id: apiData.stripe_customer_id,
            travel_agency_account_id: apiData.travel_agency_account_id,
            profile_pic: apiData.profile_pic,
            status: apiData.status,
            enable_notification: apiData.enable_notification,
            accepted_auto_deduct: apiData.accepted_auto_deduct,
            is_upgraded: apiData.is_upgraded,
            is_converted: apiData.is_converted,
            convert_currency: apiData.convert_currency,
            created_by: apiData.created_by,
            created_at: apiData.created_at,
            updated_at: apiData.updated_at,
            soft_delete: apiData.soft_delete,
            role: apiData.role,
            is_profile_complete: apiData.is_profile_complete,
            sms_optin: apiData.sms_optin,
            cards: convertedCards
        )
    }
    
    // MARK: - Helper Methods for AccountSettingsView
    
    // Helper method to get country from country code
    func getCountryFromCode(_ countryCode: String) -> Country {
        let upperCode = countryCode.uppercased()
        return countries.first { $0.shortCode == upperCode } ?? 
               Country(name: "United States", code: "+1", flag: "🇺🇸", phoneLength: 10, shortCode: "US")
    }
    
    // Helper method to get country name from code
    func getCountryName() -> String {
        guard let profileData = profileData else { return "United States" }
        
        let country = getCountryFromCode(profileData.country)
        return country.name
    }
    
    // MARK: - Add Credit Card
    func addCreditCard(request: AddCreditCardRequest) async -> (success: Bool, message: String?) {
        print("🔄 Setting isLoading to true")
        isLoading = true
        errorMessage = nil
        
        print("🚀 Starting add credit card request...")
        print("📝 Request details:")
        print("   - Card Type: \(request.card_type)")
        print("   - Number: \(request.number)")
        print("   - CVC: \(request.cvc)")
        print("   - Exp Month: \(request.exp_month)")
        print("   - Exp Year: \(request.exp_year)")
        print("   - Name: \(request.name)")
        
        do {
            // Convert request to dictionary
            let requestBody: [String: Any] = [
                "card_type": request.card_type,
                "number": request.number,
                "cvc": request.cvc,
                "exp_month": request.exp_month,
                "exp_year": request.exp_year,
                "name": request.name
            ]
            
            print("📤 Sending request body: \(requestBody)")
            
            let response: AddCreditCardResponse = try await NetworkService.shared.request(
                endpoint: .addCreditCard,
                body: requestBody,
                responseType: AddCreditCardResponse.self
            )
            
            print("📥 Received response:")
            print("   - Success: \(response.success)")
            print("   - Message: \(response.message)")
            print("   - Card ID: \(response.data.id)")
            print("   - Currency: \(response.currency.countryName) (\(response.currency.symbol))")
            
            if response.success {
                // Refresh profile data to get updated cards
                print("🔄 Refreshing profile data...")
                await fetchProfileData()
                print("✅ Credit card added successfully")
                print("🔄 Setting isLoading to false (success)")
                isLoading = false
                return (true, response.message)
            } else {
                print("❌ API returned success: false")
                print("❌ Error message: \(response.message)")
                errorMessage = response.message
                showError = true
                print("🔄 Setting isLoading to false (API error)")
                isLoading = false
                return (false, response.message)
            }
            
        } catch {
            print("❌ Network/Decoding Error adding credit card:")
            print("   - Error: \(error)")
            print("   - Localized Description: \(error.localizedDescription)")
            
            // Print more detailed error information
            if let decodingError = error as? DecodingError {
                print("🔍 Decoding Error Details:")
                switch decodingError {
                case .typeMismatch(let type, let context):
                    print("   - Type Mismatch: Expected \(type), got different type")
                    print("   - Context: \(context.debugDescription)")
                case .valueNotFound(let type, let context):
                    print("   - Value Not Found: Expected \(type)")
                    print("   - Context: \(context.debugDescription)")
                case .keyNotFound(let key, let context):
                    print("   - Key Not Found: \(key)")
                    print("   - Context: \(context.debugDescription)")
                case .dataCorrupted(let context):
                    print("   - Data Corrupted: \(context.debugDescription)")
                @unknown default:
                    print("   - Unknown decoding error")
                }
            }
            
            errorMessage = error.localizedDescription
            showError = true
            isLoading = false // Reset loading state on error
            return (false, error.localizedDescription)
        }
        
        isLoading = false
    }
}