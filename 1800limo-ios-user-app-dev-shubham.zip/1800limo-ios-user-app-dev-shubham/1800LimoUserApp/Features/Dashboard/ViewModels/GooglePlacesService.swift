import Foundation

struct LocationCoordinate: Equatable {
    let latitude: Double
    let longitude: Double
}

class GooglePlacesService {
    private let apiKey = "AIzaSyDjV38fI9kDAaVJKqEq2sdgLAHXQPC3Up4"
    private let session = URLSession.shared
    
    func fetchSuggestions(for input: String, completion: @escaping ([String]) -> Void) {
        guard let inputEncoded = input.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            print("[GooglePlacesService] Failed to encode input: \(input)")
            completion([])
            return
        }
        // Request all place types (addresses + establishments/landmarks) like web autocomplete.
        // Avoid passing a types filter because the REST API allows only a single type,
        // and setting it would exclude other results.
        let urlString = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=\(inputEncoded)&key=\(apiKey)"
        print("[GooglePlacesService] Request URL: \(urlString)")
        guard let url = URL(string: urlString) else {
            print("[GooglePlacesService] Invalid URL: \(urlString)")
            completion([])
            return
        }
        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("[GooglePlacesService] Network error: \(error)")
                completion([])
                return
            }
            guard let data = data else {
                print("[GooglePlacesService] No data received")
                completion([])
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("[GooglePlacesService] HTTP status: \(httpResponse.statusCode)")
            }
            if let jsonString = String(data: data, encoding: .utf8) {
                print("[GooglePlacesService] Response JSON: \(jsonString)")
            }
            do {
                let result = try JSONDecoder().decode(GooglePlacesAutocompleteResponse.self, from: data)
                let suggestions = result.predictions.map { $0.description }
                print("[GooglePlacesService] Suggestions: \(suggestions)")
                completion(suggestions)
            } catch {
                print("[GooglePlacesService] Decoding error: \(error)")
                completion([])
            }
        }
        task.resume()
    }
    
    func fetchCoordinates(for address: String, completion: @escaping (LocationCoordinate?) -> Void) {
        guard let addressEncoded = address.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            print("[GooglePlacesService] Failed to encode address: \(address)")
            completion(nil)
            return
        }
        
        let urlString = "https://maps.googleapis.com/maps/api/geocode/json?address=\(addressEncoded)&key=\(apiKey)"
        print("[GooglePlacesService] Geocoding URL: \(urlString)")
        
        guard let url = URL(string: urlString) else {
            print("[GooglePlacesService] Invalid geocoding URL")
            completion(nil)
            return
        }
        
        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("[GooglePlacesService] Geocoding network error: \(error)")
                completion(nil)
                return
            }
            
            guard let data = data else {
                print("[GooglePlacesService] No geocoding data received")
                completion(nil)
                return
            }
            
            if let jsonString = String(data: data, encoding: .utf8) {
                print("[GooglePlacesService] Geocoding Response JSON: \(jsonString)")
            }
            
            do {
                let result = try JSONDecoder().decode(GoogleGeocodingResponse.self, from: data)
                if let firstResult = result.results.first,
                   let location = firstResult.geometry.location {
                    let coordinate = LocationCoordinate(
                        latitude: location.lat,
                        longitude: location.lng
                    )
                    print("[GooglePlacesService] Coordinates for \(address): \(coordinate.latitude), \(coordinate.longitude)")
                    completion(coordinate)
                } else {
                    print("[GooglePlacesService] No coordinates found for address: \(address)")
                    completion(nil)
                }
            } catch {
                print("[GooglePlacesService] Geocoding decoding error: \(error)")
                completion(nil)
            }
        }
        task.resume()
    }
    
    func fetchLocationDetails(for address: String, completion: @escaping (LocationDetails?) -> Void) {
        guard let addressEncoded = address.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            print("[GooglePlacesService] Failed to encode address: \(address)")
            completion(nil)
            return
        }
        
        let urlString = "https://maps.googleapis.com/maps/api/geocode/json?address=\(addressEncoded)&key=\(apiKey)"
        print("[GooglePlacesService] Location Details URL: \(urlString)")
        
        guard let url = URL(string: urlString) else {
            print("[GooglePlacesService] Invalid location details URL")
            completion(nil)
            return
        }
        
        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("[GooglePlacesService] Location details network error: \(error)")
                completion(nil)
                return
            }
            
            guard let data = data else {
                print("[GooglePlacesService] No location details data received")
                completion(nil)
                return
            }
            
            if let jsonString = String(data: data, encoding: .utf8) {
                print("[GooglePlacesService] Location Details Response JSON: \(jsonString)")
            }
            
            do {
                let result = try JSONDecoder().decode(GoogleGeocodingResponse.self, from: data)
                if let firstResult = result.results.first {
                    let locationDetails = LocationDetails(
                        coordinate: firstResult.geometry.location.map { 
                            LocationCoordinate(latitude: $0.lat, longitude: $0.lng) 
                        },
                        postalCode: self.extractPostalCode(from: firstResult.address_components),
                        country: self.extractCountry(from: firstResult.address_components)
                    )
                    print("[GooglePlacesService] Location details for \(address): postal code = \(locationDetails.postalCode ?? "nil")")
                    completion(locationDetails)
                } else {
                    print("[GooglePlacesService] No location details found for address: \(address)")
                    completion(nil)
                }
            } catch {
                print("[GooglePlacesService] Location details decoding error: \(error)")
                completion(nil)
            }
        }
        task.resume()
    }
    
    private func extractPostalCode(from addressComponents: [AddressComponent]) -> String? {
        for component in addressComponents {
            if component.types.contains("postal_code") {
                return component.long_name
            }
        }
        return nil
    }
    
    private func extractCountry(from addressComponents: [AddressComponent]) -> String? {
        for component in addressComponents {
            if component.types.contains("country") {
                return component.long_name
            }
        }
        return nil
    }

    func fetchCitySuggestions(for input: String, completion: @escaping ([String]) -> Void) {
        guard let inputEncoded = input.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            print("[GooglePlacesService] Failed to encode input: \(input)")
            completion([])
            return
        }
        let urlString = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=\(inputEncoded)&key=\(apiKey)&types=(cities)"
        print("[GooglePlacesService] Request URL (cities): \(urlString)")
        guard let url = URL(string: urlString) else {
            print("[GooglePlacesService] Invalid URL: \(urlString)")
            completion([])
            return
        }
        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("[GooglePlacesService] Network error: \(error)")
                completion([])
            }
            guard let data = data else {
                print("[GooglePlacesService] No data received")
                completion([])
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("[GooglePlacesService] HTTP status: \(httpResponse.statusCode)")
            }
            if let jsonString = String(data: data, encoding: .utf8) {
                print("[GooglePlacesService] Response JSON: \(jsonString)")
            }
            do {
                let result = try JSONDecoder().decode(GooglePlacesAutocompleteResponse.self, from: data)
                let suggestions = result.predictions.map { $0.description }
                print("[GooglePlacesService] City Suggestions: \(suggestions)")
                completion(suggestions)
            } catch {
                print("[GooglePlacesService] Decoding error: \(error)")
                completion([])
            }
        }
        task.resume()
    }
    
    func fetchBankSuggestions(for input: String, completion: @escaping ([BankPlaceInfo]) -> Void) {
        guard let inputEncoded = input.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            print("[GooglePlacesService] Failed to encode input: \(input)")
            completion([])
            return
        }
        
        // Use establishment type to get businesses, and add "bank" keyword to filter for banks
        let urlString = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=\(inputEncoded)&key=\(apiKey)&types=establishment&keyword=bank"
        print("[GooglePlacesService] Bank Request URL: \(urlString)")
        
        guard let url = URL(string: urlString) else {
            print("[GooglePlacesService] Invalid URL: \(urlString)")
            completion([])
            return
        }
        
        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("[GooglePlacesService] Bank network error: \(error)")
                completion([])
                return
            }
            
            guard let data = data else {
                print("[GooglePlacesService] No bank data received")
                completion([])
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("[GooglePlacesService] Bank HTTP status: \(httpResponse.statusCode)")
            }
            
            if let jsonString = String(data: data, encoding: .utf8) {
                print("[GooglePlacesService] Bank Response JSON: \(jsonString)")
            }
            
            do {
                let result = try JSONDecoder().decode(GooglePlacesAutocompleteResponse.self, from: data)
                let bankInfos = result.predictions.map { [weak self] prediction in
                    // Parse the description to separate bank name from address
                    let (bankName, address) = self?.parseBankDescription(prediction.description) ?? (prediction.description, prediction.description)
                    print("[GooglePlacesService] Raw description: '\(prediction.description)'")
                    print("[GooglePlacesService] Parsed - Name: '\(bankName)', Address: '\(address)'")
                    return BankPlaceInfo(
                        name: bankName,
                        placeId: prediction.place_id,
                        address: address
                    )
                }
                print("[GooglePlacesService] Bank Suggestions: \(bankInfos.count)")
                completion(bankInfos)
            } catch {
                print("[GooglePlacesService] Bank decoding error: \(error)")
                completion([])
            }
        }
        task.resume()
    }
    
    func fetchBankDetails(for placeId: String, completion: @escaping (BankPlaceInfo?) -> Void) {
        let urlString = "https://maps.googleapis.com/maps/api/place/details/json?place_id=\(placeId)&fields=name,formatted_address&key=\(apiKey)"
        print("[GooglePlacesService] Bank Details URL: \(urlString)")
        
        guard let url = URL(string: urlString) else {
            print("[GooglePlacesService] Invalid bank details URL")
            completion(nil)
            return
        }
        
        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("[GooglePlacesService] Bank details network error: \(error)")
                completion(nil)
                return
            }
            
            guard let data = data else {
                print("[GooglePlacesService] No bank details data received")
                completion(nil)
                return
            }
            
            do {
                let result = try JSONDecoder().decode(GooglePlaceDetailsResponse.self, from: data)
                if let placeDetails = result.result {
                    // For place details, the name and address are already separated
                    let bankInfo = BankPlaceInfo(
                        name: placeDetails.name,
                        placeId: placeId,
                        address: placeDetails.formatted_address
                    )
                    print("[GooglePlacesService] Bank Details: \(bankInfo.name) - \(bankInfo.address)")
                    completion(bankInfo)
                } else {
                    print("[GooglePlacesService] No bank details found")
                    completion(nil)
                }
            } catch {
                print("[GooglePlacesService] Bank details decoding error: \(error)")
                completion(nil)
            }
        }
        task.resume()
    }
    
    // Helper method to parse bank description and separate name from address
    private func parseBankDescription(_ description: String) -> (name: String, address: String) {
        // Google Places API description format is typically: "Bank Name, Address, City, State"
        // We need to separate the bank name from the rest of the address
        
        let components = description.components(separatedBy: ",")
        
        if components.count >= 2 {
            // First component is usually the bank name
            let bankName = components[0].trimmingCharacters(in: .whitespacesAndNewlines)
            
            // Rest of the components form the address
            let addressComponents = components.dropFirst()
            let address = addressComponents.joined(separator: ",").trimmingCharacters(in: .whitespacesAndNewlines)
            
            // If the address is the same as the bank name, try a different approach
            if address == bankName {
                // Try to find common bank name patterns and extract them
                let commonBankNames = [
                    "Bank of America", "Chase", "Wells Fargo", "Citibank", "US Bank", "PNC Bank",
                    "Capital One", "TD Bank", "Goldman Sachs", "Morgan Stanley", "American Express",
                    "HSBC", "Citizens Bank", "Fifth Third Bank", "KeyBank", "Regions Bank",
                    "BB&T", "SunTrust", "BMO Harris", "Huntington Bank"
                ]
                
                for bankNamePattern in commonBankNames {
                    if description.lowercased().contains(bankNamePattern.lowercased()) {
                        let bankNameStart = description.range(of: bankNamePattern, options: .caseInsensitive)
                        if let start = bankNameStart {
                            let bankNameEnd = start.upperBound
                            let addressStart = description.index(bankNameEnd, offsetBy: 0)
                            let address = String(description[addressStart...]).trimmingCharacters(in: .whitespacesAndNewlines)
                            if address.hasPrefix(",") {
                                let cleanAddress = String(address.dropFirst()).trimmingCharacters(in: .whitespacesAndNewlines)
                                return (bankNamePattern, cleanAddress)
                            }
                        }
                    }
                }
            }
            
            return (bankName, address)
        } else {
            // If there's only one component, use it as both name and address
            return (description, description)
        }
    }
}

struct GooglePlacesAutocompleteResponse: Codable {
    let predictions: [Prediction]
    struct Prediction: Codable {
        let description: String
        let place_id: String
    }
}

struct GooglePlaceDetailsResponse: Codable {
    let result: PlaceDetails?
}

struct PlaceDetails: Codable {
    let name: String
    let formatted_address: String
}

struct BankPlaceInfo {
    let name: String
    let placeId: String
    let address: String
}

struct GoogleGeocodingResponse: Codable {
    let results: [GeocodingResult]
    let status: String
}

struct GeocodingResult: Codable {
    let geometry: Geometry
    let address_components: [AddressComponent]
}

struct Geometry: Codable {
    let location: Location?
}

struct Location: Codable {
    let lat: Double
    let lng: Double
}

struct LocationDetails {
    let coordinate: LocationCoordinate?
    let postalCode: String?
    let country: String?
}

struct AddressComponent: Codable {
    let long_name: String
    let short_name: String
    let types: [String]
} 