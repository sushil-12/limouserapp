import Foundation
import CoreLocation
import MapKit
import Combine

class DashboardViewModel: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var userLocation: CLLocationCoordinate2D?
    @Published var userLocationAddress: String?
    @Published var mapRegion: MKCoordinateRegion
    @Published var carLocations: [CarLocation] = []
    @Published var searchText: String = ""
    @Published var isBottomSheetExpanded: Bool = false
    @Published var isLoading: Bool = false
    @Published var locationPermissionStatus: CLAuthorizationStatus = .notDetermined
    
    private let locationManager = CLLocationManager()
    private var cancellables = Set<AnyCancellable>()
    private let geocoder = CLGeocoder()
    
    override init() {
        // Default region (New York City)
        self.mapRegion = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 40.7128, longitude: -74.0060),
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        )
        
        super.init()
        setupLocationManager()
        loadCarLocations()
    }
    
    private func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 10 // Update location when user moves 10 meters
        
        locationPermissionStatus = locationManager.authorizationStatus
        
        switch locationPermissionStatus {
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .denied, .restricted:
            // Use default location if permission denied
            setDefaultLocation()
        case .authorizedWhenInUse, .authorizedAlways:
            startLocationUpdates()
        @unknown default:
            setDefaultLocation()
        }
    }
    
    private func startLocationUpdates() {
        guard CLLocationManager.locationServicesEnabled() else {
            setDefaultLocation()
            return
        }
        
        locationManager.startUpdatingLocation()
    }
    
    private func setDefaultLocation() {
        userLocation = CLLocationCoordinate2D(latitude: 40.7128, longitude: -74.0060)
        userLocationAddress = "Manhattan, New York, NY, USA"
        mapRegion.center = userLocation ?? mapRegion.center
    }
    
    private func reverseGeocodeLocation(_ location: CLLocationCoordinate2D) {
        let clLocation = CLLocation(latitude: location.latitude, longitude: location.longitude)
        
        geocoder.reverseGeocodeLocation(clLocation) { [weak self] placemarks, error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.userLocationAddress = "Current Location"
                    return
                }
                
                guard let placemark = placemarks?.first else {
                    self?.userLocationAddress = "Current Location"
                    return
                }
                
                var addressComponents: [String] = []
                
                if let streetNumber = placemark.subThoroughfare {
                    addressComponents.append(streetNumber)
                }
                
                if let streetName = placemark.thoroughfare {
                    addressComponents.append(streetName)
                }
                
                if let city = placemark.locality {
                    addressComponents.append(city)
                }
                
                if let state = placemark.administrativeArea {
                    addressComponents.append(state)
                }
                
                if let postalCode = placemark.postalCode {
                    addressComponents.append(postalCode)
                }
                
                if let country = placemark.country {
                    addressComponents.append(country)
                }
                
                self?.userLocationAddress = addressComponents.joined(separator: ", ")
            }
        }
    }
    
    // MARK: - CLLocationManagerDelegate
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        
        let coordinate = location.coordinate
        userLocation = coordinate
        mapRegion.center = coordinate
        
        // Stop updating after getting first location to save battery
        locationManager.stopUpdatingLocation()
        
        // Get human-readable address
        reverseGeocodeLocation(coordinate)
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        setDefaultLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        locationPermissionStatus = status
        
        switch status {
        case .denied, .restricted:
            setDefaultLocation()
        case .authorizedWhenInUse, .authorizedAlways:
            startLocationUpdates()
        case .notDetermined:
            // Wait for user decision
            break
        @unknown default:
            setDefaultLocation()
        }
    }
    
    
    private func loadCarLocations() {
        // Simulate car locations on the map
        carLocations = [
            CarLocation(
                coordinate: CLLocationCoordinate2D(latitude: 40.7150, longitude: -74.0080),
                isUserLocation: false
            ),
            CarLocation(
                coordinate: CLLocationCoordinate2D(latitude: 40.7100, longitude: -74.0040),
                isUserLocation: false
            ),
            CarLocation(
                coordinate: CLLocationCoordinate2D(latitude: 40.7128, longitude: -74.0060),
                isUserLocation: true
            )
        ]
    }
    
    func toggleBottomSheet() {
        isBottomSheetExpanded.toggle()
    }
    
    func centerOnUserLocation() {
        guard let userLocation = userLocation else { return }
        mapRegion.center = userLocation
    }
    
    func refreshCurrentLocation() {
        if locationPermissionStatus == .authorizedWhenInUse || locationPermissionStatus == .authorizedAlways {
            startLocationUpdates()
        } else {
            locationManager.requestWhenInUseAuthorization()
        }
    }
    
    func refreshLocationPermissionStatus() {
        // Immediately refresh the location permission status
        let newStatus = locationManager.authorizationStatus
        if locationPermissionStatus != newStatus {
            locationPermissionStatus = newStatus
            
            // Handle status change
            switch newStatus {
            case .denied, .restricted:
                setDefaultLocation()
            case .authorizedWhenInUse, .authorizedAlways:
                startLocationUpdates()
            case .notDetermined:
                break
            @unknown default:
                setDefaultLocation()
            }
        }
    }
    
    func getCurrentLocationForPickup() -> (address: String?, coordinate: CLLocationCoordinate2D?) {
        return (userLocationAddress, userLocation)
    }
    
    func isLocationAvailable() -> Bool {
        return userLocation != nil && userLocationAddress != nil
    }
    
    func getLocationStatus() -> String {
        switch locationPermissionStatus {
        case .notDetermined:
            return "Location permission not determined"
        case .denied, .restricted:
            return "Location access denied"
        case .authorizedWhenInUse, .authorizedAlways:
            return "Location access granted"
        @unknown default:
            return "Unknown location status"
        }
    }
    
    func searchDestination() {
        // Implement search functionality
    }
}
