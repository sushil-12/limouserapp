import Foundation

class SharesArrayBuilder {
    static func buildSharesArray(
        from rateArray: BookingRateArray,
        serviceType: String,
        numberOfHours: String = "",
        accountType: String = "individual",
        returnGrandTotal: Double? = nil
    ) -> SharesArray {
        print("🔄 SharesArrayBuilder - Building shares array for serviceType: \(serviceType), numberOfHours: \(numberOfHours)")
        
        // Calculate total baserates (same as calculateTotalsFromRates)
        var totalBaserates: Double = 0.0
        
        // Sum all_inclusive_rates baserates
        for (key, item) in rateArray.allInclusiveRates {
            let baserate = item.baserate ?? 0.0
            
            // For Charter/Tour, multiply Base Rate by number of hours
            if serviceType == "Charter/Tour ?" && key.contains("BASE_RATE") {
                let hours = Int(numberOfHours) ?? 0
                let adjustedBaserate = baserate * Double(hours)
                totalBaserates += adjustedBaserate
                print("🔄 SharesArrayBuilder - Adding Charter/Tour Base Rate: \(key) = \(baserate) × \(hours) hours = \(adjustedBaserate)")
            } else {
                totalBaserates += baserate
                print("🔄 SharesArrayBuilder - Adding all_inclusive_rate: \(key) = \(baserate)")
            }
        }
        
        // Sum taxes baserates
        for (key, item) in rateArray.taxes {
            let baserate = item.baserate ?? 0.0
            totalBaserates += baserate
            print("🔄 SharesArrayBuilder - Adding tax: \(key) = \(baserate)")
        }
        
        // Sum amenities baserates
        for (key, item) in rateArray.amenities {
            let baserate = item.baserate ?? 0.0
            totalBaserates += baserate
            print("🔄 SharesArrayBuilder - Adding amenity: \(key) = \(baserate)")
        }
        
        // Sum misc baserates
        for (key, item) in rateArray.misc {
            let baserate = item.baserate ?? 0.0
            totalBaserates += baserate
            print("🔄 SharesArrayBuilder - Adding misc: \(key) = \(baserate)")
        }
        
        print("🔄 SharesArrayBuilder - Total baserates sum: \(totalBaserates)")
        
        // Calculate admin share baserates (same as calculateTotalsFromRates)
        var adminShareBaserates: Double = 0.0
        for (key, item) in rateArray.allInclusiveRates {
            let baserate = item.baserate ?? 0.0
            
            // For Charter/Tour, multiply Base Rate by number of hours for admin share calculation
            if serviceType == "Charter/Tour ?" && key.contains("BASE_RATE") {
                let hours = Int(numberOfHours) ?? 0
                let adjustedBaserate = baserate * Double(hours)
                adminShareBaserates += adjustedBaserate
                print("🔄 SharesArrayBuilder - Adding Charter/Tour Base Rate to admin share: \(key) = \(baserate) × \(hours) hours = \(adjustedBaserate)")
            } else {
                adminShareBaserates += baserate
                print("🔄 SharesArrayBuilder - Adding to admin share calculation: \(key) = \(baserate)")
            }
        }
        
        // Determine admin share percentage based on account_type
        let adminSharePercentage: Double
        let isTravelPlannerSpecialCase: Bool
        let isFarmoutCase: Bool
        
        // For individual account type, use standard 25%
        if accountType == "individual" {
            adminSharePercentage = 0.25 // Default 25%
            isTravelPlannerSpecialCase = false
            isFarmoutCase = false
            print("🔄 SharesArrayBuilder - Individual account type -> Admin share: 25%")
        } else {
            // For other account types, use standard 25% (can be extended later)
            adminSharePercentage = 0.25
            isTravelPlannerSpecialCase = false
            isFarmoutCase = false
            print("🔄 SharesArrayBuilder - Other account type (\(accountType)) -> Admin share: 25%")
        }
        
        let adminShare = adminShareBaserates * adminSharePercentage
        print("🔄 SharesArrayBuilder - Admin share (\(Int(adminSharePercentage * 100))% of all_inclusive_rates): \(adminShare)")
        
        // Calculate additional shares
        let shouldIncludeTravelAgentShare = isTravelPlannerSpecialCase
        let shouldIncludeFarmoutShare = isFarmoutCase
        
        // Calculate additional shares based on all_inclusive_rates only (just like admin share)
        let travelAgentShare = shouldIncludeTravelAgentShare ? adminShareBaserates * 0.10 : 0.0 // 10% of all_inclusive_rates for travel planner case
        let farmoutShare = shouldIncludeFarmoutShare ? adminShareBaserates * 0.10 : 0.0 // 10% of all_inclusive_rates for farmout case
        
        // Calculate subtotal (same as calculateTotalsFromRates)
        let subTotal = totalBaserates + adminShare + travelAgentShare + farmoutShare
        print("🔄 SharesArrayBuilder - Subtotal (total baserates + admin share + additional shares): \(subTotal)")
        if shouldIncludeTravelAgentShare {
            print("🔄 SharesArrayBuilder - Added travel agent share (10%): \(travelAgentShare)")
        }
        if shouldIncludeFarmoutShare {
            print("🔄 SharesArrayBuilder - Added farmout share (10%): \(farmoutShare)")
        }
        
        // For individual bookings, assume 1 vehicle
        let numberOfVehicles = 1
        print("🔄 SharesArrayBuilder - Number of vehicles: \(numberOfVehicles)")
        
        let calculatedGrandTotal = subTotal * Double(numberOfVehicles)
        print("🔄 SharesArrayBuilder - Calculated grand total (subtotal × vehicles): \(calculatedGrandTotal)")
        
        let finalGrandTotal = calculatedGrandTotal
        
        let actualBaseRate = rateArray.allInclusiveRates["Base_Rate"]?.baserate ?? 0.0
        print("🔄 SharesArrayBuilder - Actual Base_Rate from all_inclusive_rates: \(actualBaseRate)")
        
        let baseRate = actualBaseRate // Use the actual Base_Rate value
        
        let extraGratuityAmount = rateArray.misc["Extra_Gratuity"]?.amount ?? 0.0
        let extraGratuityShare = extraGratuityAmount * 0.25 // 25% of Extra_Gratuity
        print("🔄 SharesArrayBuilder - Extra_Gratuity amount: \(extraGratuityAmount), 25% share: \(extraGratuityShare)")
        
        let affiliateShare: Double
        if shouldIncludeFarmoutShare {
            affiliateShare = finalGrandTotal - (adminShare + extraGratuityShare) - farmoutShare
            print("🔄 SharesArrayBuilder - Farmout case: Affiliate share = Grand Total - Admin Share - Extra_Gratuity 25% - Farmout Share")
        } else if shouldIncludeTravelAgentShare {
            affiliateShare = finalGrandTotal - (adminShare + extraGratuityShare) - travelAgentShare
            print("🔄 SharesArrayBuilder - Travel Agent case: Affiliate share = Grand Total - Admin Share - Extra_Gratuity 25% - Travel Agent Share")
        } else {
            affiliateShare = finalGrandTotal - (adminShare + extraGratuityShare)
            print("🔄 SharesArrayBuilder - Standard case: Affiliate share = Grand Total - Admin Share - Extra_Gratuity 25%")
        }
        
        let stripeFee = finalGrandTotal * 0.05 + 0.30
        let deductedAdminShare = adminShare - stripeFee
        
        print("🔄 SharesArrayBuilder - Final calculations:")
        print("  Base rate: \(baseRate)")
        print("  Admin share: \(adminShare)")
        print("  Extra_Gratuity amount: \(extraGratuityAmount)")
        print("  Extra_Gratuity 25% share: \(extraGratuityShare)")
        print("  Affiliate share: \(affiliateShare)")
        if shouldIncludeTravelAgentShare {
            print("  Travel agent share: \(travelAgentShare)")
        }
        if shouldIncludeFarmoutShare {
            print("  Farmout share: \(farmoutShare)")
        }
        print("  Stripe fee: \(stripeFee)")
        print("  Deducted admin share: \(deductedAdminShare)")
        print("  Final grand total: \(finalGrandTotal)")
        
        return SharesArray(
            baseRate: baseRate,
            grandTotal: finalGrandTotal,
            stripeFee: stripeFee,
            adminShare: adminShare,
            deductedAdminShare: deductedAdminShare,
            affiliateShare: affiliateShare,
            travelAgentShare: shouldIncludeTravelAgentShare ? travelAgentShare : nil,
            farmoutShare: shouldIncludeFarmoutShare ? farmoutShare : nil,
            returnGrandTotal: returnGrandTotal
        )
    }
}
