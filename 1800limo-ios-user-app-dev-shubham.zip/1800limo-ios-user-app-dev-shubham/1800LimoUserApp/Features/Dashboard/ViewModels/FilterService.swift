import Foundation
import SwiftUI

class FilterService: ObservableObject {
    @Published var filterData: FilterData?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private let networkService = NetworkService.shared
    
    func fetchFilters() async {
        DispatchQueue.main.async {
            self.isLoading = true
            self.errorMessage = nil
        }
        
        do {
            let response: FilterResponse = try await networkService.request(
                endpoint: .filters,
                responseType: FilterResponse.self
            )
            
            DispatchQueue.main.async {
                self.filterData = response.data
                self.isLoading = false
            }
        } catch {
            DispatchQueue.main.async {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
            }
        }
    }
    
    // MARK: - Pagination Helper
    func getPaginatedItems<T: Identifiable>(from items: [T], page: Int, itemsPerPage: Int = 12) -> [T] {
        let startIndex = page * itemsPerPage
        let endIndex = min(startIndex + itemsPerPage, items.count)
        
        guard startIndex < items.count else { return [] }
        
        return Array(items[startIndex..<endIndex])
    }
    
    func hasMoreItems<T>(totalItems: [T], currentPage: Int, itemsPerPage: Int = 12) -> Bool {
        let startIndex = (currentPage + 1) * itemsPerPage
        return startIndex < totalItems.count
    }
}
