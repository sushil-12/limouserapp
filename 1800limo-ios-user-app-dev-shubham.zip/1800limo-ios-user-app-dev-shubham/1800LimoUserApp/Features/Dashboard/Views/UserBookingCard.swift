//
//  UserBookingCard.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct UserBookingCard: View {
    let booking: UserBooking
    let onEditBooking: (() -> Void)?
    let onCancelBooking: (() -> Void)?
    let onRepeatBooking: (() -> Void)?
    let onReturnBooking: (() -> Void)?
    let onRoundTripBooking: (() -> Void)?
    
    // State for driver actions bottom sheet
    @State private var showDriverActions = false
    
    var body: some View {
        VStack(spacing: 0) {
            // 1. Top Header (Dark Grey/Black)
            topHeaderView
            
            // 2. Booking Summary (Light Grey)
            bookingSummaryView
            
            // 3. Route Details (White)
            routeDetailsView
            
            // 4. Driver Information (Light Grey)
            driverInfoView
            
            // 5. Action Buttons (White)
            actionButtonsView
        }
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
        )
        .sheet(isPresented: $showDriverActions) {
            DriverActionsBottomSheet(booking: booking, isPresented: $showDriverActions)
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(20)
                .presentationBackground(Color.white)
        }
    }
    
    // MARK: - Top Header View
    private var topHeaderView: some View {
        HStack {
            // Left side - Clock icon and date/time
            HStack(spacing: 8) {
                Image(systemName: "clock.fill")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.orange)
                
                Text("\(formatDate(booking.pickup_date)), \(formatTime(booking.pickup_time))")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white)
            }
            
            Spacer()
            
            // Right side - Service type / Transfer type
            Text("\(formatServiceType(booking.service_type))/ \(formatTransferType(booking.transfer_type ?? ""))")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.black)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color.white)
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(Color.black, lineWidth: 1)
                )
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.black)
    }
    
    // MARK: - Booking Summary View
    private var bookingSummaryView: some View {
        HStack {
            // Booking ID - format without comma separator
            Text("#\(String(format: "%d", booking.id))")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.black)

            // Separator
            Spacer()

            // Booking Status
            Text(booking.booking_status.capitalized)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(getBookingStatusColor(booking.booking_status))

            // Separator
            Spacer()

            // Total Cost
            HStack(spacing: 8) {
                Text("Total")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.black)

                Text(formatCurrency(booking.grand_total ?? 0.0, symbol: booking.currency_symbol ?? "$"))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.orange)
                    .cornerRadius(8)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(red: 230/255, green: 230/255, blue: 230/255)) // #E6E6E6
    }
    
    // MARK: - Route Details View
    private var routeDetailsView: some View {
        HStack(alignment: .top, spacing: 12) {
            // Left side - Visual route indicator
            VStack(spacing: 0) {
                // Pickup circle
                Circle()
                    .fill(Color.black)
                    .frame(width: 12, height: 12)
                
                // Connecting line - black color with flexible height
                Rectangle()
                    .fill(Color.black)
                    .frame(width: 2)
                    .frame(minHeight: 10, maxHeight: 40)
                
                // Dropoff square
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.black)
                    .frame(width: 12, height: 12)
            }
            .padding(.top, 4)
            
            // Right side - Location text
            VStack(alignment: .leading, spacing: 12) {
                // Pickup location
                Text(booking.pickup_address)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.black)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                
                // Dropoff location
                Text(booking.dropoff_address)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.black)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.white)
    }
    
    // MARK: - Driver Information View
    private var driverInfoView: some View {
        HStack(spacing: 12) {
            Text("DRIVER")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.gray)
                .textCase(.uppercase)

            HStack(spacing: 12) {
                Text(booking.computed_driver_name ?? "1800limo Chauffeurs")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.black)

                Rectangle()
                    .fill(Color.gray.opacity(0.4))
                    .frame(width: 1, height: 20)

                Button(action: {
                    showDriverActions = true
                }) {
                    Text(booking.driver_phone ?? "+1 8005466266")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.black)
                }
                .buttonStyle(PlainButtonStyle())
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color.white)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.gray.opacity(0.1))
    }
    
    // MARK: - Action Buttons View
    private var actionButtonsView: some View {
        Group {
            // Only show action buttons if payment status is not "paid" or "paid_cash"
            let paymentStatus = booking.payment_status.lowercased()
            let bookingStatus = booking.booking_status.lowercased()
            let isCancelled = bookingStatus == "cancelled"
            
            if paymentStatus != "paid" && paymentStatus != "paid_cash" {
                HStack(spacing: 12) {
                    Button(action: {
                        onEditBooking?()
                    }) {
                        Text("Edit/Change")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 36)
                            .background(Color.black)
                            .cornerRadius(8)
                    }
                    
                    // Only show Cancel Ride button if booking is not cancelled
                    if !isCancelled {
                        Button(action: {
                            onCancelBooking?()
                        }) {
                            Text("Cancel Ride")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .frame(height: 40)
                                .background(Color.red)
                                .cornerRadius(8)
                        }
                    }
                    
                    Menu {
                        Button("Repeat") {
                            onRepeatBooking?()
                        }
                        Button("Return") {
                            onReturnBooking?()
                        }
                        Button("Round Trip") {
                            onRoundTripBooking?()
                        }
                    } label: {
                        HStack {
                            Image(systemName: "ellipsis.circle")
                                .font(.system(size: 12, weight: .semibold))
                            Text("More")
                                .font(.system(size: 11, weight: .semibold))
                        }
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .frame(height: 32)
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(8)
                    }
                    .menuStyle(BorderlessButtonMenuStyle())
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.white)
            } else {
                // Show a message for paid bookings
                VStack(spacing: 8) {
                    Text("Booking is paid and cannot be modified")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.white)
            }
        }
    }
    

    
    // MARK: - Helper Methods
    
    private func formatDate(_ dateString: String) -> String {
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd"
        
        guard let date = inputFormatter.date(from: dateString) else {
            return dateString
        }
        
        let outputFormatter = DateFormatter()
        outputFormatter.dateFormat = "EEE, MMM dd"
        return outputFormatter.string(from: date)
    }
    
    private func formatTime(_ timeString: String) -> String {
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "HH:mm:ss"
        
        guard let date = inputFormatter.date(from: timeString) else {
            return timeString
        }
        
        let outputFormatter = DateFormatter()
        outputFormatter.dateFormat = "h:mm a"
        return outputFormatter.string(from: date)
    }
    
    private func formatServiceType(_ serviceType: String) -> String {
        switch serviceType.lowercased() {
        case "oneway":
            return "One Way"
        case "roundtrip":
            return "Round Trip"
        case "chartertour", "charter_tour":
            return "Charter Tour"
        case "hourly":
            return "Hourly"
        default:
            return serviceType.capitalized
        }
    }
    
    private func formatTransferType(_ transferType: String) -> String {
        return transferType.replacingOccurrences(of: "_", with: " ").capitalized
    }
    
    private func formatCurrency(_ amount: Double, symbol: String) -> String {
        return "\(symbol)\(String(format: "%.2f", amount))"
    }
    
    private func getBookingStatusColor(_ status: String) -> Color {
        switch status.lowercased() {
        case "pending":
            return Color(hex: "#0474fc")
        case "partial_paid":
            return Color(hex: "#00CCCC")
        case "partial_refund":
            return Color(hex: "#212529")
        case "paid_cash":
            return Color(hex: "#D1B000")
        case "paid":
            return Color(hex: "#D1B000")
        case "driver_unassigned":
            return Color(hex: "#dc3545")
        case "assigned":
            return Color(hex: "#28a745") // var(--green-color) - using standard green
        case "rejected":
            return Color(hex: "#dc3545")
        case "cancelled":
            return Color(hex: "#FF69B4")
        case "en_route_pu":
            return Color(hex: "#6454ac")
        case "on_location":
            return Color(hex: "#7289da")
        case "en_route_do":
            return Color(hex: "#1abc9c")
        case "ended":
            return Color(hex: "#8cc43c")
        case "finalized":
            return Color(hex: "#71c5e8")
        case "non_payable":
            return Color(hex: "#ec4c8c")
        case "comped":
            return Color(hex: "#C4A484")
        case "refund":
            return Color(hex: "#A020F0")
        case "confirmed":
            return Color(hex: "#28a745") // keeping confirmed as green for backward compatibility
        case "completed":
            return Color(hex: "#28a745") // keeping completed as green for backward compatibility
        default:
            return .gray
        }
    }
}

// MARK: - Preview
#Preview {
    UserBookingCard(
        booking: UserBooking.sampleBookings[0],
        onEditBooking: {},
        onCancelBooking: {},
        onRepeatBooking: {},
        onReturnBooking: {},
        onRoundTripBooking: {}
    )
    .padding()
    .background(Color(.systemGroupedBackground))
}
