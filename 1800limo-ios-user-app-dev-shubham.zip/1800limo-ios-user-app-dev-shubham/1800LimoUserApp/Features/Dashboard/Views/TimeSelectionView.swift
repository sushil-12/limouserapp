import SwiftUI
import CoreLocation
import UIKit

struct TimeSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: [Screen]
    @State private var selectedDate = Date()
    @State private var selectedTime = Calendar.current.date(from: DateComponents(hour: 12, minute: 15)) ?? Date()
    @State private var showDatePicker = false
    @State private var showTimePicker = false
    @State private var showReturnDatePicker = false
    @State private var showReturnTimePicker = false
    @State private var showPaxLuggageVehicleView = false
    @State private var showCancellationPolicy = false
    @StateObject private var sheetDismissalManager = SheetDismissalManager.shared
    
    // Return trip states (for round trip)
    @State private var returnDate = Date()
    @State private var returnTime = Calendar.current.date(from: DateComponents(hour: 12, minute: 15)) ?? Date()
    
    // Tab selection for round trips
    @State private var selectedTab: TimeTab = .pickupAt
    
    // Trip calculation states
    @State private var tripDistance: Double? = nil
    @State private var tripDuration: TimeInterval? = nil
    @State private var isLoadingTripData = false
    
    // Computed property to check if it's a round trip
    private var isRoundTrip: Bool {
        rideData.serviceType == "round_trip"
    }
    
    enum TimeTab: String, CaseIterable {
        case pickupAt = "Pickup at"
        case returnAt = "Return at"
    }
    
    // Parameters passed from previous screens
    let rideData: VehicleSelectionView.RideData
    let onDataUpdated: ((Date, Date) -> Void)?
    let onPaxDataUpdated: ((Int, Int, Int) -> Void)?
    
    // Store updated ride data with selected date and time
    @State private var updatedRideData: VehicleSelectionView.RideData
    
    // Convenience initializer for path-based navigation
    init(rideData: VehicleSelectionView.RideData, path: Binding<[Screen]>, onDataUpdated: ((Date, Date) -> Void)? = nil, onPaxDataUpdated: ((Int, Int, Int) -> Void)? = nil) {
        self.rideData = rideData
        self._path = path
        self.onDataUpdated = onDataUpdated
        self.onPaxDataUpdated = onPaxDataUpdated
        
        print("🕐 TimeSelectionView init - RideData pickupDate: \(rideData.pickupDate)")
        print("🕐 TimeSelectionView init - RideData pickupTime: \(rideData.pickupTime)")
        
        // Initialize updated ride data with the original data first
        self._updatedRideData = State(initialValue: rideData)
        
        // Initialize with data from rideData if available
        var parsedDate: Date
        if let pickupDate = parseDate(from: rideData.pickupDate) {
            print("🕐 TimeSelectionView init - Parsed pickupDate: \(pickupDate)")
            parsedDate = pickupDate
            self._selectedDate = State(initialValue: pickupDate)
        } else {
            print("🕐 TimeSelectionView init - Failed to parse pickupDate, using current date")
            parsedDate = Date()
            self._selectedDate = State(initialValue: Date())
        }
        
        if let pickupTime = parseTime(from: rideData.pickupTime) {
            print("🕐 TimeSelectionView init - Parsed pickupTime: \(pickupTime)")
            // Combine the parsed time with the parsed date to create a proper Date object
            let calendar = Calendar.current
            let timeComponents = calendar.dateComponents([.hour, .minute, .second], from: pickupTime)
            let dateComponents = calendar.dateComponents([.year, .month, .day], from: parsedDate)
            
            var combinedComponents = DateComponents()
            combinedComponents.year = dateComponents.year
            combinedComponents.month = dateComponents.month
            combinedComponents.day = dateComponents.day
            combinedComponents.hour = timeComponents.hour
            combinedComponents.minute = timeComponents.minute
            combinedComponents.second = timeComponents.second
            
            if let combinedDate = calendar.date(from: combinedComponents) {
                self._selectedTime = State(initialValue: combinedDate)
                print("🕐 TimeSelectionView init - Combined time with date: \(combinedDate)")
            } else {
                print("🕐 TimeSelectionView init - Failed to combine time with date, using current time")
                self._selectedTime = State(initialValue: Date())
            }
        } else {
            print("🕐 TimeSelectionView init - Failed to parse pickupTime, using current time")
            self._selectedTime = State(initialValue: Date())
        }
        
        // Initialize return date and time for round trips (default to pickup date/time + 1 day)
        let calendar = Calendar.current
        var initialReturnDate = parsedDate
        var initialReturnTime: Date
        
        if let pickupTime = parseTime(from: rideData.pickupTime) {
            let timeComponents = calendar.dateComponents([.hour, .minute, .second], from: pickupTime)
            var combinedComponents = DateComponents()
            combinedComponents.year = calendar.component(.year, from: parsedDate)
            combinedComponents.month = calendar.component(.month, from: parsedDate)
            combinedComponents.day = calendar.component(.day, from: parsedDate)
            combinedComponents.hour = timeComponents.hour
            combinedComponents.minute = timeComponents.minute
            combinedComponents.second = timeComponents.second
            initialReturnTime = calendar.date(from: combinedComponents) ?? Date()
        } else {
            initialReturnTime = Date()
        }
        
        if rideData.serviceType == "round_trip" {
            // For round trips, default return date to pickup date + 1 day
            if let nextDay = calendar.date(byAdding: .day, value: 1, to: parsedDate) {
                initialReturnDate = nextDay
                
                // Combine return time with return date
                let timeComponents = calendar.dateComponents([.hour, .minute, .second], from: initialReturnTime)
                var returnComponents = DateComponents()
                returnComponents.year = calendar.component(.year, from: nextDay)
                returnComponents.month = calendar.component(.month, from: nextDay)
                returnComponents.day = calendar.component(.day, from: nextDay)
                returnComponents.hour = timeComponents.hour
                returnComponents.minute = timeComponents.minute
                returnComponents.second = timeComponents.second
                
                if let combinedReturnTime = calendar.date(from: returnComponents) {
                    initialReturnTime = combinedReturnTime
                }
            }
        }
        
        self._returnDate = State(initialValue: initialReturnDate)
        self._returnTime = State(initialValue: initialReturnTime)
    }
    
    private var disclaimerText: some View {
        Text(disclaimerAttributedString)
            .font(.system(size: 12, weight: .regular))
            .lineSpacing(6)
            .multilineTextAlignment(.leading)
            .onTapGesture {
                // Handle tap on "Cancellation Policy" part
                showCancellationPolicy = true
            }
    }
    
    private var disclaimerAttributedString: AttributedString {
        var attributedString = AttributedString("Pick-up and drop-off times may vary due to traffic conditions in the area. Vehicles and rates are subject to availability. Mountain rates may differ, and toll charges are additional. Read our Cancellation Policy here.")
        
        // Set default color to gray
        attributedString.foregroundColor = .gray
        
        // Find and color "Cancellation Policy" in orange
        if let range = attributedString.range(of: "Cancellation Policy") {
            attributedString[range].foregroundColor = AppColors.primaryOrange
            // Make it bold and increase size by 2 (base is 12 → 14)
            attributedString[range].font = .system(size: 14, weight: .bold)
        }
        
        return attributedString
    }
    

    
    var body: some View {
        print("🕐 TimeSelectionView body called")
        return VStack(spacing: 0) {
            // Drag Handle
            RoundedRectangle(cornerRadius: 2.5)
                .fill(Color.gray.opacity(0.3))
                .frame(width: 36, height: 5)
                .padding(.top, 8)
                .padding(.bottom, 16)
            
            // Header with back button and title
            HStack {
                Button(action: {
                    path.removeLast()
                }) {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Text("Choose a time")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
                
                Spacer()
                
                // Invisible spacer to center the title
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.clear)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 16)
            
            // Divider after header
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(height: 1)
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            
            // Tab Selector (only for round trips)
            if isRoundTrip {
                // Segmented Control
                HStack(spacing: 8) {
                    ForEach(TimeTab.allCases, id: \.self) { tab in
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                selectedTab = tab
                            }
                        }) {
                            Text(tab.rawValue)
                                .font(.system(size: 16, weight: .bold))
                                .foregroundColor(selectedTab == tab ? .white : .black)
                                .padding(.top, 4)
                                .padding(.trailing, 12)
                                .padding(.bottom, 4)
                                .padding(.leading, 12)
                        }
                        .frame(width: 105, height: 30)
                        .background(
                            RoundedRectangle(cornerRadius: 4)
                                .fill(selectedTab == tab ? AppColors.primaryOrange : Color.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(selectedTab == tab ? Color.clear : Color.black, lineWidth: 1)
                                )
                        )
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
                
                // Divider after tabs
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 1)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
            }
            
            // Date and Time Display - Based on selected tab for round trips or always pickup for one-way
            if isRoundTrip && selectedTab == .returnAt {
                // Return Date and Time (for round trips when Return tab is selected)
                VStack(spacing: 16) {
                    // Return Date - Tappable
                    Button(action: {
                        showReturnDatePicker = true
                    }) {
                        Text(formatDate(returnDate))
                            .font(.system(size: 19, weight: .bold))
                            .foregroundColor(.black)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 16)
                
                // Divider after return date
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 1)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                
                // Return Time - Tappable
                VStack(spacing: 16) {
                    Button(action: {
                        showReturnTimePicker = true
                    }) {
                        Text(formatTime(returnTime))
                            .font(.system(size: 21, weight: .bold))
                            .foregroundColor(.black)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 16)
                
                // Divider after return time
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 1)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
            } else {
                // Pickup Date and Time (for pickup tab in round trips or always for one-way)
                VStack(spacing: 16) {
                    // Selected Date - Tappable
                    Button(action: {
                        showDatePicker = true
                    }) {
                        Text(formatDate(selectedDate))
                            .font(.system(size: 19, weight: .bold))
                            .foregroundColor(.black)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 16)
                
                // Divider after date
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 1)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                
                // Time Display
                VStack(spacing: 16) {
                    // Selected Time - Tappable
                    Button(action: {
                        showTimePicker = true
                    }) {
                        Text(formatTime(selectedTime))
                            .font(.system(size: 21, weight: .bold))
                            .foregroundColor(.black)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 16)
                
                // Divider after time
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 1)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
            }
            
            // Drop-off Time and Trip Information (show for one-way trips and pickup leg of round trip)
            if !isRoundTrip || (isRoundTrip && selectedTab == .pickupAt) {
                if let duration = tripDuration, let distance = tripDistance {
                    VStack(spacing: 8) {
                        // Drop-off Time
                        Spacer().frame(height: 10)
                        Text(formatDropOffTime())
                            .font(.system(size: 19, weight: .bold))
                            .foregroundColor(.black)
                            .multilineTextAlignment(.center)
                        
                        // Trip Duration
                        Text("About \(formatDurationText(duration)) trip")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                        
                        // Estimated Distance
                        Text("\(formatDistanceText(distance)) Estimated Distance")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                } else if isLoadingTripData {
                    VStack(spacing: 8) {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle())
                        Text("Calculating trip details...")
                            .font(.system(size: 14, weight: .regular))
                            .foregroundColor(.gray)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                }
            }
            
           
            
            Spacer()
            
            // Disclaimer Text
            disclaimerText
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
            
            // Next Button
            Button(action: {
                // Update the ride data with selected date and time
                print("🕐 TimeSelectionView Next Button - selectedDate: \(selectedDate)")
                print("🕐 TimeSelectionView Next Button - selectedTime: \(selectedTime)")
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let updatedDate = dateFormatter.string(from: selectedDate)
                
                dateFormatter.dateFormat = "HH:mm:ss"
                let updatedTime = dateFormatter.string(from: selectedTime)
                
                print("🕐 TimeSelectionView Next Button - updatedDate string: '\(updatedDate)'")
                print("🕐 TimeSelectionView Next Button - updatedTime string: '\(updatedTime)'")
                
                // For round trips, also format return date and time
                if isRoundTrip {
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    let returnDateString = dateFormatter.string(from: returnDate)
                    
                    dateFormatter.dateFormat = "HH:mm:ss"
                    let returnTimeString = dateFormatter.string(from: returnTime)
                    
                    print("🔄 Round Trip - Return Date: \(returnDateString)")
                    print("🔄 Round Trip - Return Time: \(returnTimeString)")
                }
                
                // Create updated ride data with selected date and time
                updatedRideData = VehicleSelectionView.RideData(
                    serviceType: rideData.serviceType,
                    bookingHour: rideData.bookingHour,
                    pickupType: rideData.pickupType,
                    dropoffType: rideData.dropoffType,
                    pickupDate: updatedDate,
                    pickupTime: updatedTime,
                    pickupLocation: rideData.pickupLocation,
                    destinationLocation: rideData.destinationLocation,
                    selectedPickupAirport: rideData.selectedPickupAirport,
                    selectedDestinationAirport: rideData.selectedDestinationAirport,
                    noOfPassenger: rideData.noOfPassenger,
                    noOfLuggage: rideData.noOfLuggage,
                    noOfVehicles: rideData.noOfVehicles,
                    pickupLat: rideData.pickupLat,
                    pickupLong: rideData.pickupLong,
                    destinationLat: rideData.destinationLat,
                    destinationLong: rideData.destinationLong
                )
                
                // Pass the selected date and time back to parent
                onDataUpdated?(selectedDate, selectedTime)
                
                // Navigate to PaxLuggageVehicleView using path
                path.append(.paxLuggageVehicle(rideData: updatedRideData))
            }) {
                Text("Next")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(AppColors.primaryOrange)
                    .cornerRadius(8)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
        .background(Color.white)
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .overlay(
            showDatePicker ? 
            ZStack {
                // Background overlay
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        showDatePicker = false
                    }
                
                // Date picker dialog
                DatePickerView(selectedDate: $selectedDate, showDatePicker: $showDatePicker, showTimePicker: $showTimePicker)
                    .padding(.horizontal, 20)
            }
            : nil
        )
        .appBottomSheet(
            isPresented: $showTimePicker,
            title: nil,
            showDragIndicator: true,
            dismissOnTapOutside: true
        ) {
            TimePickerView(selectedTime: $selectedTime, showTimePicker: $showTimePicker, selectedDate: $selectedDate)
                .frame(maxWidth: .infinity)
        }
        .overlay(
            showReturnDatePicker ? 
            ZStack {
                // Background overlay
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        showReturnDatePicker = false
                    }
                
                // Return date picker dialog
                DatePickerView(selectedDate: $returnDate, showDatePicker: $showReturnDatePicker, showTimePicker: $showReturnTimePicker)
                    .padding(.horizontal, 20)
            }
            : nil
        )
        .appBottomSheet(
            isPresented: $showReturnTimePicker,
            title: nil,
            showDragIndicator: true,
            dismissOnTapOutside: true
        ) {
            TimePickerView(selectedTime: $returnTime, showTimePicker: $showReturnTimePicker, selectedDate: $returnDate)
                .frame(maxWidth: .infinity)
        }
        // Navigation is now handled via path, so we don't need fullScreenCover here
        .fullScreenCover(isPresented: $showCancellationPolicy) {
            WebViewScreen(
                url: URL(string: "https://1800limo.com/cancellation-policy")!,
                title: "Cancellation Policy"
            )
        }
        .onAppear {
            print("🕐 TimeSelectionView appeared")
            print("🕐 Current selectedDate: \(selectedDate)")
            print("🕐 Current selectedTime: \(selectedTime)")
            print("🕐 Is Round Trip: \(isRoundTrip)")
            calculateTripDetails()
        }
        .onChange(of: selectedTime) { _ in
            calculateTripDetails()
        }
        .onChange(of: selectedDate) { _ in
            calculateTripDetails()
        }
        .onReceive(NotificationCenter.default.publisher(for: .dismissAllSheets)) { _ in
            print("🔚 TimeSelectionView received dismiss notification")
            showPaxLuggageVehicleView = false
        }
        .onReceive(NotificationCenter.default.publisher(for: .forceDismissAllSheets)) { _ in
            print("🔚 TimeSelectionView received force dismiss notification")
            // Dismiss this sheet and all child sheets
            showPaxLuggageVehicleView = false
            dismiss()
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, d MMM"
        return formatter.string(from: date)
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        return formatter.string(from: date)
    }
    
    private func parseDate(from dateString: String) -> Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: dateString)
    }
    
    private func parseTime(from timeString: String) -> Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.date(from: timeString)
    }
    
    // MARK: - Trip Calculation Methods
    
    private func calculateTripDetails() {
        guard let pickupLat = rideData.pickupLat,
              let pickupLong = rideData.pickupLong,
              let destinationLat = rideData.destinationLat,
              let destinationLong = rideData.destinationLong else {
            print("⚠️ TimeSelectionView: Missing coordinates for trip calculation")
            return
        }
        
        isLoadingTripData = true
        
        let pickupCoord = CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong)
        let destinationCoord = CLLocationCoordinate2D(latitude: destinationLat, longitude: destinationLong)
        
        Task {
            let result = await calculateRoadDistance(from: pickupCoord, to: destinationCoord)
            
            await MainActor.run {
                self.tripDistance = result.distance
                self.tripDuration = result.duration
                self.isLoadingTripData = false
                
                print("🗺️ TimeSelectionView Trip Calculation:")
                print("Distance: \(result.distance) meters")
                print("Duration: \(result.duration) seconds")
            }
        }
    }
    
    private func calculateRoadDistance(
        from: CLLocationCoordinate2D,
        to: CLLocationCoordinate2D
    ) async -> (distance: Double, duration: TimeInterval) {
        let apiKey = "AIzaSyDjV38fI9kDAaVJKqEq2sdgLAHXQPC3Up4"
        var components = URLComponents(string: "https://maps.googleapis.com/maps/api/directions/json")!
        
        let queryItems = [
            URLQueryItem(name: "origin", value: "\(from.latitude),\(from.longitude)"),
            URLQueryItem(name: "destination", value: "\(to.latitude),\(to.longitude)"),
            URLQueryItem(name: "key", value: apiKey)
        ]
        
        components.queryItems = queryItems
        
        guard let url = components.url else {
            print("❌ Invalid Google Maps Directions API URL")
            return fallbackToStraightLineDistance(from: from, to: to)
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(GoogleMapsDirectionsResponse.self, from: data)
            
            if response.status == "OK", let route = response.routes.first {
                var totalDistance: Double = 0
                var totalDuration: Double = 0
                
                for leg in route.legs {
                    totalDistance += leg.distance.value
                    totalDuration += leg.duration.value
                }
                
                print("🗺️ Google Maps API - Distance: \(totalDistance)m, Duration: \(totalDuration)s")
                return (totalDistance, totalDuration)
            } else {
                print("❌ Google Maps Directions API error: \(response.status)")
                return fallbackToStraightLineDistance(from: from, to: to)
            }
        } catch {
            print("❌ Google Maps Directions API request failed: \(error)")
            return fallbackToStraightLineDistance(from: from, to: to)
        }
    }
    
    private func fallbackToStraightLineDistance(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> (distance: Double, duration: TimeInterval) {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        
        let distance = fromLocation.distance(from: toLocation)
        // Estimate duration: assume average speed of 60 km/h for city, 100 km/h for highway
        let averageSpeed: Double = distance > 50000 ? 100000.0 : 60000.0 // meters per hour
        let duration = (distance / averageSpeed) * 3600 // convert to seconds
        
        print("⚠️ Using fallback straight-line distance: \(distance) meters")
        return (distance, duration)
    }
    
    // MARK: - Formatting Methods
    
    private func formatDropOffTime() -> String {
        guard let duration = tripDuration else {
            return formatTime(selectedTime)
        }
        
        // Combine selectedDate and selectedTime to get the full pickup datetime
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day], from: selectedDate)
        let timeComponents = calendar.dateComponents([.hour, .minute], from: selectedTime)
        
        var combinedComponents = DateComponents()
        combinedComponents.year = dateComponents.year
        combinedComponents.month = dateComponents.month
        combinedComponents.day = dateComponents.day
        combinedComponents.hour = timeComponents.hour
        combinedComponents.minute = timeComponents.minute
        
        guard let pickupDateTime = calendar.date(from: combinedComponents) else {
            return formatTime(selectedTime)
        }
        
        // Calculate drop-off time: pickup time + trip duration
        let dropOffTime = pickupDateTime.addingTimeInterval(duration)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        let timeString = formatter.string(from: dropOffTime)
        
        // Get timezone abbreviation (e.g., CST, EST, PST)
        formatter.dateFormat = "zzz"
        let timezone = formatter.string(from: dropOffTime)
        
        return "\(timeString) \(timezone) drop-off time"
    }
    
    private func formatDurationText(_ duration: TimeInterval) -> String {
        let totalMinutes = Int(duration) / 60
        let hours = totalMinutes / 60
        let minutes = totalMinutes % 60
        
        if hours > 0 {
            if minutes > 0 {
                return "\(hours) hrs \(minutes) mins"
            } else {
                return "\(hours) hrs"
            }
        } else {
            return "\(minutes) mins"
        }
    }
    
    private func formatDistanceText(_ distance: Double) -> String {
        let distanceKm = distance / 1000.0
        if distanceKm >= 1 {
            // Round to nearest integer for display
            let roundedKm = Int(distanceKm.rounded())
            return "\(roundedKm) km"
        } else {
            let distanceM = Int(distance)
            return "\(distanceM) m"
        }
    }
}

struct DatePickerView: View {
    enum Mode {
        case future
        case past
    }
    
    @Binding var selectedDate: Date
    @Binding var showDatePicker: Bool
    var showTimePicker: Binding<Bool>?
    private let mode: Mode
    
    private let calendar = Calendar.current
    private let dateFormatter: DateFormatter
    
    // Cache months array - only calculate once
    private let monthsToDisplay: [Date]
    private let initialScrollMonth: Date
    private let disablePastDates: Bool
    private let disableFutureDates: Bool
    
    init(selectedDate: Binding<Date>, showDatePicker: Binding<Bool>, showTimePicker: Binding<Bool>? = nil, mode: Mode = .future) {
        self._selectedDate = selectedDate
        self._showDatePicker = showDatePicker
        self.showTimePicker = showTimePicker
        self.mode = mode
        
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        self.dateFormatter = formatter
        
        let calendar = Calendar.current
        
        // Always start from current date (today) to ensure we show current and future months
        let today = Date()
        let currentMonthComponents = calendar.dateComponents([.year, .month], from: today)
        let currentMonthStart = calendar.date(from: currentMonthComponents) ?? today
        
        print("🕐 DatePickerView init - today: \(today)")
        print("🕐 DatePickerView init - selectedDate: \(selectedDate.wrappedValue)")
        
        // Determine which month to scroll to initially
        let selectedMonthComponents = calendar.dateComponents([.year, .month], from: selectedDate.wrappedValue)
        let selectedMonthStart = calendar.date(from: selectedMonthComponents) ?? selectedDate.wrappedValue
        
        let range: (start: Date, end: Date)
        switch mode {
        case .future:
            let monthsForward = 24
            let start = currentMonthStart
            let end = calendar.date(byAdding: .month, value: monthsForward - 1, to: start) ?? start
            range = (start, end)
            disablePastDates = true
            disableFutureDates = false
        case .past:
            let yearsBack = 120
            let end = currentMonthStart
            let start = calendar.date(byAdding: .year, value: -yearsBack, to: end) ?? end
            range = (start, end)
            disablePastDates = false
            disableFutureDates = true
        }
        
        self.monthsToDisplay = DatePickerView.generateMonths(
            from: range.start,
            to: range.end,
            calendar: calendar
        )
        
        if selectedMonthStart < range.start {
            self.initialScrollMonth = range.start
        } else if selectedMonthStart > range.end {
            self.initialScrollMonth = range.end
        } else {
            self.initialScrollMonth = selectedMonthStart
        }
    }
    
    private static func generateMonths(from start: Date, to end: Date, calendar: Calendar) -> [Date] {
        var months: [Date] = []
        var current = start
        while current <= end {
            months.append(current)
            guard let next = calendar.date(byAdding: .month, value: 1, to: current) else { break }
            current = next
        }
        return months
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Calendar content - Use LazyVStack for lazy loading with ScrollViewReader
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 20) {
                        // Generate multiple months lazily
                        ForEach(monthsToDisplay, id: \.self) { month in
                            MonthCalendarView(
                                month: month,
                                selectedDate: $selectedDate,
                                disablePastDates: disablePastDates,
                                disableFutureDates: disableFutureDates
                            )
                            .id(month)
                        }
                    }
//                    .padding(.vertical, 20)
                }
                .onAppear {
                    print("🕐 DatePickerView .onAppear - selectedDate is: \(selectedDate)")
                    print("🕐 DatePickerView - Scrolling to month: \(initialScrollMonth)")
                    // Scroll to the initialScrollMonth (current or selected month, whichever is later)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        proxy.scrollTo(initialScrollMonth, anchor: .top)
                    }
                }
            }
            
            // Bottom buttons - Cancel on left, Next on right
            HStack {
                
                Button("Cancel") {
                    showDatePicker = false
                }
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.red)
                .padding(.vertical, 12)
                
                Spacer()
                
                Button("Next") {
                    showDatePicker = false
                    showTimePicker?.wrappedValue = true
                }
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.green)
                .padding(.vertical, 12)
            }
            .padding(.horizontal, 20)
//            .padding(.top, 20)
//            .padding(.bottom, 24)
        }
        .padding(16)
        .frame(width: 328, height: 675)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
        )
    }
}

struct MonthCalendarView: View {
    let month: Date
    @Binding var selectedDate: Date
    let disablePastDates: Bool
    let disableFutureDates: Bool
    
    private let calendar = Calendar.current
    private let dateFormatter: DateFormatter
    private let days: [Date?]
    
    init(month: Date, selectedDate: Binding<Date>, disablePastDates: Bool, disableFutureDates: Bool) {
        self.month = month
        self._selectedDate = selectedDate
        self.disablePastDates = disablePastDates
        self.disableFutureDates = disableFutureDates
        
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        self.dateFormatter = formatter
        
        // Pre-calculate days array in init for better performance
        let calendar = Calendar.current
        guard let range = calendar.range(of: .day, in: .month, for: month),
              let firstDayOfMonth = calendar.date(from: calendar.dateComponents([.year, .month], from: month)) else {
            self.days = []
            return
        }
        
        let firstWeekday = calendar.component(.weekday, from: firstDayOfMonth)
        let daysInMonth = range.count
        
        var tempDays: [Date?] = []
        
        // Add empty spaces for days before the first day of the month
        for _ in 1..<firstWeekday {
            tempDays.append(nil)
        }
        
        // Add all days in the month
        for day in 1...daysInMonth {
            if let date = calendar.date(byAdding: .day, value: day - 1, to: firstDayOfMonth) {
                tempDays.append(date)
            }
        }
        
        self.days = tempDays
    }
    
    var body: some View {
        VStack(spacing: 10) {
            // Month title
            Text(dateFormatter.string(from: month))
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(.black)
            
            // Weekday headers
            HStack(spacing: 0) {
                ForEach(["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], id: \.self) { day in
                    Text(day)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(day == "Sun" || day == "Sat" ? .red : .black)
                        .frame(maxWidth: .infinity)
                }
            }
            
            // Calendar grid
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7), spacing: 8) {
                ForEach(days.indices, id: \.self) { index in
                    if let date = days[index] {
                        DayView(
                            date: date,
                            selectedDate: $selectedDate,
                            disablePastDates: disablePastDates,
                            disableFutureDates: disableFutureDates
                        )
                    } else {
                        // Empty space for days not in this month
                        Text("")
                            .frame(height: 40)
                    }
                }
            }
        }
        .padding(.horizontal, 20)
    }
}

struct DayView: View {
    let date: Date
    @Binding var selectedDate: Date
    let disablePastDates: Bool
    let disableFutureDates: Bool
    
    private static let calendar = Calendar.current
    private static let dayFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "d"
        return formatter
    }()
    
    private var dayNumber: String {
        Self.dayFormatter.string(from: date)
    }
    
    private var isSelected: Bool {
        Self.calendar.isDate(date, inSameDayAs: selectedDate)
    }
    
    private var isDisabled: Bool {
        let today = Self.calendar.startOfDay(for: Date())
        let dateToCheck = Self.calendar.startOfDay(for: date)
        
        if disablePastDates && dateToCheck < today {
            return true
        }
        
        if disableFutureDates && dateToCheck > today {
            return true
        }
        
        return false
    }
    
    var body: some View {
        Button(action: {
            if !isDisabled {
                selectedDate = date
            }
        }) {
            Text(dayNumber)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(textColor)
                .frame(width: 40, height: 40)
                .background(backgroundColor)
                .cornerRadius(8)
        }
        .buttonStyle(PlainButtonStyle())
        .disabled(isDisabled)
    }
    
    private var backgroundColor: Color {
        if isSelected {
            return .black
        } else {
            return .clear
        }
    }
    
    private var textColor: Color {
        if isDisabled {
            return .gray.opacity(0.3)
        } else if isSelected {
            return .white
        } else {
            return .black
        }
    }
}

struct TimePickerView: View {
    @Binding var selectedTime: Date
    @Binding var showTimePicker: Bool
    @Binding var selectedDate: Date
    @State private var selectedHour: Int = 7
    @State private var selectedMinute: Int = 0
    @State private var isAM: Bool = true
    
    private let calendar = Calendar.current
    
    init(selectedTime: Binding<Date>, showTimePicker: Binding<Bool>, selectedDate: Binding<Date>) {
        self._selectedTime = selectedTime
        self._showTimePicker = showTimePicker
        self._selectedDate = selectedDate
    }
    
    var body: some View {
        ClockTimePickerView(
            selectedHour: $selectedHour,
            selectedMinute: $selectedMinute,
            isAM: $isAM,
            showTimePicker: $showTimePicker,
            onTimeChanged: { hour, minute in
                selectedHour = hour
                selectedMinute = minute
                updateSelectedTime()
            }
        )
        .onAppear {
            initializeTime()
        }
    }
    
    private func initializeTime() {
        print("🕐 TimePickerView initializeTime - selectedTime: \(selectedTime)")
        let components = calendar.dateComponents([.hour, .minute], from: selectedTime)
        selectedHour = components.hour ?? 7
        selectedMinute = components.minute ?? 0
        print("🕐 TimePickerView - extracted hour: \(selectedHour), minute: \(selectedMinute)")
        
        // Convert to 12-hour format
        if selectedHour == 0 {
            selectedHour = 12
            isAM = true
        } else if selectedHour < 12 {
            isAM = true
        } else if selectedHour == 12 {
            isAM = false
        } else {
            selectedHour = selectedHour - 12
            isAM = false
        }
        print("🕐 TimePickerView - converted to 12h format: \(selectedHour):\(selectedMinute) \(isAM ? "AM" : "PM")")
    }
    
    private func updateSelectedTime() {
        var hour24 = selectedHour
        if !isAM && selectedHour != 12 {
            hour24 = selectedHour + 12
        } else if isAM && selectedHour == 12 {
            hour24 = 0
        }
        
        // Use selectedDate as the base date to ensure correct date
        if let newDate = calendar.date(bySettingHour: hour24, minute: selectedMinute, second: 0, of: selectedDate) {
            selectedTime = newDate
            print("🕐 TimePickerView updateSelectedTime - Updated selectedTime to: \(selectedTime)")
        }
    }
}

struct ClockTimePickerView: View {
    @Binding var selectedHour: Int
    @Binding var selectedMinute: Int
    @Binding var isAM: Bool
    @Binding var showTimePicker: Bool
    let onTimeChanged: (Int, Int) -> Void
    
    private let hours = Array(1...12)
    private let minutes = Array(0..<60)
    private let periods = ["AM", "PM"]
    
    private var periodBinding: Binding<String> {
        Binding<String>(
            get: { isAM ? "AM" : "PM" },
            set: {
                isAM = $0 == "AM"
                onTimeChanged(selectedHour, selectedMinute)
            }
        )
    }
    
    var body: some View {
        VStack(spacing: 0) {
            header
                .padding(.bottom, 20)
            
            wheelSection
                .frame(height: 320)
            
            actionBar
                .padding(.top, 24)
        }
        .padding(.top, 8)
        .padding(.bottom, 24)
        .onChange(of: selectedHour) { _ in
            onTimeChanged(selectedHour, selectedMinute)
        }
        .onChange(of: selectedMinute) { _ in
            onTimeChanged(selectedHour, selectedMinute)
        }
        .onChange(of: isAM) { _ in
            onTimeChanged(selectedHour, selectedMinute)
        }
    }
    
    private var header: some View {
        HStack(alignment: .center) {
            Text("Select Time")
                .font(.system(size: 20, weight: .semibold))
                .foregroundColor(AppColors.primaryText)
            
            Spacer()
            
            Text("\(formattedHour):\(String(format: "%02d", selectedMinute)) \(isAM ? "AM" : "PM")")
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(AppColors.primaryOrange)
        }
    }
    
    private var wheelSection: some View {
        HStack(spacing: 6) {
            SpacedPicker(
                selection: $selectedHour,
                items: hours,
                formatter: { "\($0)" },
                fontSize: 32
            )
            .frame(minWidth: 0, maxWidth: .infinity)
            
            Text(":")
                .font(.system(size: 28, weight: .regular))
                .foregroundColor(AppColors.secondaryText)
                .frame(width: 12)
            
            SpacedPicker(
                selection: $selectedMinute,
                items: minutes,
                formatter: { String(format: "%02d", $0) },
                fontSize: 32
            )
            .frame(minWidth: 0, maxWidth: .infinity)
            
            SpacedPicker(
                selection: periodBinding,
                items: periods,
                formatter: { $0 },
                fontSize: 24
            )
            .frame(width: 60)
        }
    }
    
    private var actionBar: some View {
        HStack(spacing: 16) {
            Button(action: {
                showTimePicker = false
            }) {
                Text("Cancel")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(AppColors.secondaryText)
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
            }
            .background(AppColors.backgroundGray.opacity(0.6))
            .cornerRadius(12)
            
            Button(action: {
                onTimeChanged(selectedHour, selectedMinute)
                showTimePicker = false
            }) {
                Text("Done")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(AppColors.white)
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
            }
            .background(AppColors.primaryOrange)
            .cornerRadius(12)
        }
    }
    
    private var formattedHour: Int {
        let hour = selectedHour % 12
        return hour == 0 ? 12 : hour
    }
}

// MARK: - Custom Picker with Increased Spacing
struct SpacedPicker<T: Hashable>: UIViewRepresentable {
    @Binding var selection: T
    let items: [T]
    let formatter: (T) -> String
    let fontSize: CGFloat
    
    func makeUIView(context: Context) -> UIPickerView {
        let picker = UIPickerView()
        picker.delegate = context.coordinator
        picker.dataSource = context.coordinator
        picker.translatesAutoresizingMaskIntoConstraints = false
        picker.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        picker.setContentHuggingPriority(.defaultLow, for: .horizontal)
        return picker
    }
    
    func updateUIView(_ uiView: UIPickerView, context: Context) {
        context.coordinator.parent = self
        if let index = items.firstIndex(of: selection) {
            uiView.selectRow(index, inComponent: 0, animated: false)
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UIPickerViewDelegate, UIPickerViewDataSource {
        var parent: SpacedPicker
        
        init(_ parent: SpacedPicker) {
            self.parent = parent
        }
        
        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return parent.items.count
        }
        
        func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
            let label = UILabel()
            label.text = parent.formatter(parent.items[row])
            label.font = .systemFont(ofSize: parent.fontSize, weight: .regular)
            label.textAlignment = .center
            label.textColor = UIColor.label
            return label
        }
        
        func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
            return 60 // 30-31 points spacing between items (60pt row height = ~30pt spacing)
        }
        
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            parent.selection = parent.items[row]
        }
    }
}


#Preview {
    TimeSelectionView(
        rideData: VehicleSelectionView.RideData(
            serviceType: "one_way",
            bookingHour: "2",
            pickupType: "city",
            dropoffType: "airport",
            pickupDate: "2025-01-15",
            pickupTime: "14:30:00",
            pickupLocation: "Manhattan, New York, NY, USA",
            destinationLocation: "JFK Airport",
            selectedPickupAirport: "",
            selectedDestinationAirport: "JFK-John F Kennedy Intl",
            noOfPassenger: 2,
            noOfLuggage: 1,
            noOfVehicles: 1,
            pickupLat: 40.7589,
            pickupLong: -73.9851,
            destinationLat: 40.6413,
            destinationLong: -73.7781
        ),
        path: .constant([])
    )
}
