//
//  InvoiceCard.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct InvoiceCard: View {
    let invoice: Invoice
    let onViewInvoiceSummary: (() -> Void)?
    
    var body: some View {
        VStack(spacing: 0) {
            // 1. Top Header (Black)
            topHeaderView
            
            // 2. Invoice Summary (Light Grey)
            invoiceSummaryView
            
            // 3. Route Details (White)
            routeDetailsView
            
            // 4. Driver Information (Light Grey)
            driverInfoView
            
            // 5. Action Button (White) - Orange "View Invoice Summary" button
            actionButtonView
        }
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
        )
    }
    
    // MARK: - Top Header View
    private var topHeaderView: some View {
        HStack {
            // Left side - Invoice icon and date
            HStack(spacing: 8) {
                Image(systemName: "doc.text.fill")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.orange)
                
                Text("\(invoice.formattedDate)")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white)
            }
            
            Spacer()
            
            // Right side - Vehicle type button
            Text(invoice.aff_vehicle_type)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.black)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color.white)
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(Color.black, lineWidth: 1)
                )
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.black)
    }
    
    // MARK: - Invoice Summary View
    private var invoiceSummaryView: some View {
        HStack {
            // Invoice Number
            Text("#\(formattedBookingId)")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.black)

            // Separator
            Spacer()

            // Payment Status
            Text(invoice.status.capitalized)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(getStatusColor(invoice.status))

            // Separator
            Spacer()

            // Total Amount
            Text("Total \(formattedTotal)")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.black)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(red: 230/255, green: 230/255, blue: 230/255)) // #E6E6E6
    }
    
    // MARK: - Route Details View
    private var routeDetailsView: some View {
        HStack(alignment: .top, spacing: 12) {
            // Left side - Visual route indicator
            VStack(spacing: 0) {
                // Pickup circle
                Circle()
                    .fill(Color.orange)
                    .frame(width: 12, height: 12)
                
                // Connecting line - conditional height based on text length
                Rectangle()
                    .fill(Color.gray.opacity(0.6))
                    .frame(width: 2, height: shouldUseTallLine ? 40 : 24)
                
                // Dropoff square
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.orange)
                    .frame(width: 12, height: 12)
            }
            .padding(.top, 4)
            
            // Right side - Location text
            VStack(alignment: .leading, spacing: 16) {
                // Pickup location
                Text(invoice.pickup_address)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.black)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                
                // Dropoff location
                Text(invoice.dropoff_address)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.black)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
            }
            
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(Color.white)
    }
    
    // MARK: - Driver Information View
    private var driverInfoView: some View {
        HStack {
            // Driver label
            Text("DRIVER")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.gray)
                .textCase(.uppercase)
            
            // Driver name
            Text(invoice.driver_name)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.black)
            
            // Separator
//            Rectangle()
//                .fill(Color.gray.opacity(0.4))
//                .frame(width: 1, height: 20)
//            
//            // Payment method
//            Text(invoice.paymentMethodDisplay)
//                .font(.system(size: 14, weight: .medium))
//                .foregroundColor(.black)
            
//            Spacer()
            
            // Driver phone - tappable
            Button(action: {
                // Handle driver contact
                let phoneNumber = invoice.driver_phone.replacingOccurrences(of: " ", with: "")
                if let url = URL(string: "tel:\(phoneNumber)") {
                    UIApplication.shared.open(url)
                }
            }) {
                Text(invoice.driver_phone)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.blue)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.gray.opacity(0.1))
    }
    
    // MARK: - Action Button View
    private var actionButtonView: some View {
        HStack(spacing: 12) {
            // View Invoice Summary button - Orange color
            Button(action: {
                onViewInvoiceSummary?()
            }) {
                HStack(spacing: 8) {
                    Image(systemName: "safari")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white)
                    
                    Text("View Invoice Summary")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 40)
                .background(Color.orange)
                .cornerRadius(8)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.white)
    }
    
    // MARK: - Helper computed property for conditional line height
    private var shouldUseTallLine: Bool {
        let pickupLength = invoice.pickup_address.count
        let dropoffLength = invoice.dropoff_address.count
        
        // Use tall line if either address is longer than 30 characters (approximate 1-line limit)
        return pickupLength > 30 || dropoffLength > 30
    }
    
    // MARK: - Formatted Values
    
    private var formattedBookingId: String {
        // Remove commas from booking ID (convert Int to String without grouping separator)
        "\(invoice.booking_id)"
    }
    
    private var formattedTotal: String {
        // Format total to 2 decimal places
        String(format: "%.2f", invoice.booking_total)
    }
    
    // MARK: - Helper Methods
    
    private func getStatusColor(_ status: String) -> Color {
        switch status.lowercased() {
        case "paid":
            return AppColors.greenColor
        case "paid_cash":
            return .blue
        case "pending":
            return .orange
        case "failed":
            return .red
        default:
            return .gray
        }
    }
}

// MARK: - Preview
#Preview {
    InvoiceCard(
        invoice: Invoice.sampleInvoices[0],
        onViewInvoiceSummary: {}
    )
    .padding()
    .background(Color(.systemGroupedBackground))
}
