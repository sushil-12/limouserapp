import SwiftUI
import CoreLocation

struct BookingDetailsView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: [Screen]
    @State private var selectedVehicle: VehicleListingItem?
    @State private var showFilterDialog = false
    @StateObject private var vehicleListingService = VehicleListingService()
    @StateObject private var vehicleService = VehicleService()
    @StateObject private var sheetDismissalManager = SheetDismissalManager.shared
    @StateObject private var filterSelection = FilterSelectionState()
    
    // Hide default back button
    private let shouldHideBackButton = true
    
    // Parameters passed from previous screens
    let rideData: VehicleSelectionView.RideData
    let selectedMasterVehicleId: Int // ID of the selected vehicle from master vehicle API
    let initialFilterSelection: FilterSelectionState? // Initial filter selection from VehicleSelectionView
    
    init(rideData: VehicleSelectionView.RideData, selectedMasterVehicleId: Int, initialFilterSelection: FilterSelectionState? = nil, path: Binding<[Screen]>) {
        self.rideData = rideData
        self.selectedMasterVehicleId = selectedMasterVehicleId
        self.initialFilterSelection = initialFilterSelection
        self._path = path
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                headerView
                filterButtonView
                
                // Vehicle List
                vehicleListContent
            }
            .background(Color.white)
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(shouldHideBackButton)
            .toolbar(.hidden, for: .navigationBar)
            .onAppear {
                // Initialize filter selection with values from VehicleSelectionView
                if let initialFilters = initialFilterSelection {
                    filterSelection.selectedVehicleTypes = initialFilters.selectedVehicleTypes
                    filterSelection.selectedAmenities = initialFilters.selectedAmenities
                    filterSelection.selectedSpecialAmenities = initialFilters.selectedSpecialAmenities
                    filterSelection.selectedInteriors = initialFilters.selectedInteriors
                    filterSelection.selectedMakes = initialFilters.selectedMakes
                    filterSelection.selectedModels = initialFilters.selectedModels
                    filterSelection.selectedYears = initialFilters.selectedYears
                    filterSelection.selectedColors = initialFilters.selectedColors
                    filterSelection.selectedDriverLanguages = initialFilters.selectedDriverLanguages
                    filterSelection.selectedDriverDresses = initialFilters.selectedDriverDresses
                    filterSelection.selectedDriverGenders = initialFilters.selectedDriverGenders
                    filterSelection.selectedDriverBackgrounds = initialFilters.selectedDriverBackgrounds
                    filterSelection.selectedVehicleServiceAreas = initialFilters.selectedVehicleServiceAreas
                    filterSelection.selectedAffiliatePreferences = initialFilters.selectedAffiliatePreferences
                    
                    print("🔍 BOOKING DETAILS - INITIAL FILTERS LOADED:")
                    print("Selected Vehicle Types: \(filterSelection.selectedVehicleTypes)")
                    print("Selected Amenities: \(filterSelection.selectedAmenities)")
                    print("Selected Special Amenities: \(filterSelection.selectedSpecialAmenities)")
                    print("Selected Interiors: \(filterSelection.selectedInteriors)")
                    print("Selected Makes: \(filterSelection.selectedMakes)")
                    print("Selected Models: \(filterSelection.selectedModels)")
                    print("Selected Years: \(filterSelection.selectedYears)")
                    print("Selected Colors: \(filterSelection.selectedColors)")
                    print("Selected Driver Languages: \(filterSelection.selectedDriverLanguages)")
                    print("Selected Driver Dresses: \(filterSelection.selectedDriverDresses)")
                    print("Selected Driver Genders: \(filterSelection.selectedDriverGenders)")
                    print("Selected Driver Backgrounds: \(filterSelection.selectedDriverBackgrounds)")
                    print("Selected Vehicle Service Areas: \(filterSelection.selectedVehicleServiceAreas)")
                    print("Selected Affiliate Preferences: \(filterSelection.selectedAffiliatePreferences)")
                }
                
                Task {
                    await fetchVehicleListing()
                    // Ensure first vehicle is selected after initial fetch
                    await MainActor.run {
                        if !vehicleListingService.vehicles.isEmpty && selectedVehicle == nil {
                            let sorted = vehicleListingService.vehicles.sorted { vehicle1, vehicle2 in
                                let price1 = vehicle1.getPrice(for: rideData.serviceType) ?? Double.greatestFiniteMagnitude
                                let price2 = vehicle2.getPrice(for: rideData.serviceType) ?? Double.greatestFiniteMagnitude
                                return price1 < price2
                            }
                            selectedVehicle = sorted.first
                        }
                    }
                }
            }
            .onChange(of: vehicleListingService.vehicles) { vehicles in
                // Always auto-select first vehicle when vehicles are loaded or updated
                if !vehicles.isEmpty {
                    // Use sorted vehicles to ensure we select the first one by price
                    let sorted = vehicles.sorted { vehicle1, vehicle2 in
                        let price1 = vehicle1.getPrice(for: rideData.serviceType) ?? Double.greatestFiniteMagnitude
                        let price2 = vehicle2.getPrice(for: rideData.serviceType) ?? Double.greatestFiniteMagnitude
                        return price1 < price2
                    }
                    selectedVehicle = sorted.first
                }
            }
            // Navigation to DetailsBookingView is now handled via path
            // Navigation is now handled via path, so we don't need fullScreenCover here
            .sheet(isPresented: $showFilterDialog) {
                FilterDialogView(
                    onApplyFilters: { selectedFilters in
                        // Apply filters and refresh vehicle list
                        filterSelection.selectedVehicleTypes = selectedFilters.selectedVehicleTypes
                        filterSelection.selectedAmenities = selectedFilters.selectedAmenities
                        filterSelection.selectedSpecialAmenities = selectedFilters.selectedSpecialAmenities
                        filterSelection.selectedInteriors = selectedFilters.selectedInteriors
                        filterSelection.selectedMakes = selectedFilters.selectedMakes
                        filterSelection.selectedModels = selectedFilters.selectedModels
                        filterSelection.selectedYears = selectedFilters.selectedYears
                        filterSelection.selectedColors = selectedFilters.selectedColors
                        filterSelection.selectedDriverLanguages = selectedFilters.selectedDriverLanguages
                        filterSelection.selectedDriverDresses = selectedFilters.selectedDriverDresses
                        filterSelection.selectedDriverGenders = selectedFilters.selectedDriverGenders
                        filterSelection.selectedDriverBackgrounds = selectedFilters.selectedDriverBackgrounds
                        filterSelection.selectedVehicleServiceAreas = selectedFilters.selectedVehicleServiceAreas
                        filterSelection.selectedAffiliatePreferences = selectedFilters.selectedAffiliatePreferences
                        
                        // Refresh vehicle list with new filters
                        Task {
                            await fetchVehicleListing()
                        }
                    },
                    initialFilterState: filterSelection
                )
            }
        .onReceive(NotificationCenter.default.publisher(for: .dismissAllSheets)) { _ in
            print("🔚 BookingDetailsView received dismiss notification")
            if !path.isEmpty {
                path.removeLast()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .forceDismissAllSheets)) { _ in
            print("🔚 BookingDetailsView received force dismiss notification")
            // Clear entire path to go back to dashboard
            path.removeAll()
        }
        }
        .navigationBarBackButtonHidden(shouldHideBackButton)
    }
    
    // MARK: - Computed Properties
    
    private var headerView: some View {
        HStack {
            Button(action: {
                dismiss()
            }) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.black)
            }
            
            Spacer()
            
            Text("Select the Vehicle")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.black)
            
            Spacer()
            
            // Invisible button to balance the layout
            Button(action: {}) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.clear)
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 16)
        .padding(.bottom, 24)
    }
    
    private var filterButtonView: some View {
        HStack {
            Spacer()
            
            Button(action: {
                showFilterDialog = true
            }) {
                HStack(spacing: 8) {
                    Text("Filter")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.black)

                    Image("mi_filter")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.black)
                                        
                  
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
            }
            
            Spacer()
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 16)
    }
    
    private var vehicleListContent: some View {
        Group {
            if vehicleListingService.isLoading {
                BookingVehicleListShimmer()
            } else if let errorMessage = vehicleListingService.errorMessage {
                errorView(message: errorMessage)
            } else {
                vehicleListView
            }
        }
    }
    
    private func errorView(message: String) -> some View {
        VStack {
            Image(systemName: "exclamationmark.triangle")
                .font(.system(size: 40))
                .foregroundColor(.red)
            Text("Error loading vehicles")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.black)
                .padding(.top, 8)
            Text(message)
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.top, 4)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    private var vehicleListView: some View {
        ScrollView {
            VStack(spacing: 16) {
                ForEach(sortedVehicles) { vehicle in
                    vehicleCard(for: vehicle)
                }
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
    }
    
    // Computed property to sort vehicles by price (low to high)
    private var sortedVehicles: [VehicleListingItem] {
        vehicleListingService.vehicles.sorted { vehicle1, vehicle2 in
            let price1 = vehicle1.getPrice(for: rideData.serviceType) ?? Double.greatestFiniteMagnitude
            let price2 = vehicle2.getPrice(for: rideData.serviceType) ?? Double.greatestFiniteMagnitude
            return price1 < price2
        }
    }
    
    private func vehicleCard(for vehicle: VehicleListingItem) -> some View {
        BookingVehicleCard(
            vehicle: vehicle,
            rideData: rideData,
            isSelected: selectedVehicle?.id == vehicle.id,
            path: $path,
            onTap: {
                selectedVehicle = vehicle
            },
            onDetailsTap: { tappedVehicle in
                selectedVehicle = tappedVehicle
            }
        )
    }
    
    // MARK: - Private Methods
    
    private func fetchVehicleListing() async {
        // Set loading state immediately so shimmer shows during location info calculation
        await MainActor.run {
            vehicleListingService.isLoading = true
            vehicleListingService.errorMessage = nil
        }
        
        let request = await createVehicleListingRequest()
        await vehicleListingService.fetchVehicleListing(request: request)
    }
    
    private func createVehicleListingRequest() async -> VehicleListingRequest {
        // Get user ID from local storage
        let userId = StorageManager.shared.getUserData()?.id ?? 0
        let bookingHourValue = Int(rideData.bookingHour.trimmingCharacters(in: .whitespaces)) ?? 0
        
        // Determine if this is a round trip or charter tour
        let isRoundTrip = rideData.serviceType == "round_trip"
        let isCharterTour = rideData.serviceType == "charter_tour"
        
        // For round trip and charter tour, we need return trip information
        // Calculate return date based on booking hours (for now, use pickup date)
        let returnPickupDate = rideData.pickupDate // Same as pickup date for now
        let returnPickupTime = "12:00:00" // Default return time
        
        // For all trips, we need to provide return trip fields (API requirement)
        let defaultReturnPickupAirport: Int?
        if rideData.dropoffType == "airport" {
            defaultReturnPickupAirport = getAirportId(from: rideData.selectedDestinationAirport)
        } else {
            defaultReturnPickupAirport = nil
        }
        
        let defaultReturnDropoffAirport: Int?
        if rideData.pickupType == "airport" {
            defaultReturnDropoffAirport = getAirportId(from: rideData.selectedPickupAirport)
        } else {
            defaultReturnDropoffAirport = nil
        }
        
        // Always provide return trip date and time
        let finalReturnPickupDate = returnPickupDate
        let finalReturnPickupTime = returnPickupTime
        
        // Ensure we have proper values for all return trip fields
        let returnPickupAirportName: String? = rideData.dropoffType == "airport" ? rideData.selectedDestinationAirport : nil
        let returnPickupAirportLat: Double? = rideData.dropoffType == "airport" ? rideData.destinationLat : nil
        let returnPickupAirportLong: Double? = rideData.dropoffType == "airport" ? rideData.destinationLong : nil
        let returnPickupAddress: String? = (rideData.dropoffType == "city" || rideData.dropoffType == "cruise") ? rideData.destinationLocation : nil
        let returnPickupAddressLat: Double? = (rideData.dropoffType == "city" || rideData.dropoffType == "cruise") ? rideData.destinationLat : nil
        let returnPickupAddressLong: Double? = (rideData.dropoffType == "city" || rideData.dropoffType == "cruise") ? rideData.destinationLong : nil
        
        let returnDropoffAirportName: String? = rideData.pickupType == "airport" ? rideData.selectedPickupAirport : nil
        let returnDropoffAirportLat: Double? = rideData.pickupType == "airport" ? rideData.pickupLat : nil
        let returnDropoffAirportLong: Double? = rideData.pickupType == "airport" ? rideData.pickupLong : nil
        let returnDropoffAddress: String? = (rideData.pickupType == "city" || rideData.pickupType == "cruise") ? rideData.pickupLocation : nil
        let returnDropoffAddressLat: Double? = (rideData.pickupType == "city" || rideData.pickupType == "cruise") ? rideData.pickupLat : nil
        let returnDropoffAddressLong: Double? = (rideData.pickupType == "city" || rideData.pickupType == "cruise") ? rideData.pickupLong : nil
        
        print("🔄 ROUND TRIP DEBUG:")
        print("Service Type: \(rideData.serviceType)")
        print("Is Round Trip: \(isRoundTrip)")
        print("Is Charter Tour: \(isCharterTour)")
        print("Pickup Date: \(rideData.pickupDate)")
        print("Return Pickup Date: \(finalReturnPickupDate)")
        print("Return Pickup Time: \(finalReturnPickupTime)")
        print("Pickup Airport: \(rideData.selectedPickupAirport)")
        print("Dropoff Airport: \(rideData.selectedDestinationAirport)")
        print("Default Return Pickup Airport ID: \(defaultReturnPickupAirport ?? 0)")
        print("Default Return Dropoff Airport ID: \(defaultReturnDropoffAirport ?? 0)")
        print("Return Pickup Airport Name: \(returnPickupAirportName ?? "nil")")
        print("Return Dropoff Airport Name: \(returnDropoffAirportName ?? "nil")")
        print("Return Pickup Airport Lat: \(returnPickupAirportLat ?? 0.0)")
        print("Return Pickup Airport Long: \(returnPickupAirportLong ?? 0.0)")
        print("Return Dropoff Airport Lat: \(returnDropoffAirportLat ?? 0.0)")
        print("Return Dropoff Airport Long: \(returnDropoffAirportLong ?? 0.0)")
        
        print("🔍 ABOUT TO CREATE VEHICLE LISTING REQUEST...")
        
        // Create location info first (async operation)
        let locationInfo = await createLocationInfoForRequest()
        
        let request = VehicleListingRequest(
            serviceType: rideData.serviceType,
            bookingHour: bookingHourValue,
            pickupType: rideData.pickupType,
            dropoffType: rideData.dropoffType,
            pickupDate: rideData.pickupDate,
            pickupTime: rideData.pickupTime,
            
            // Pickup information
            pickupAirport: rideData.pickupType == "airport" ? getAirportId(from: rideData.selectedPickupAirport) : nil,
            pickupAirportName: rideData.pickupType == "airport" ? rideData.selectedPickupAirport : nil,
            pickupAirportLat: rideData.pickupType == "airport" ? rideData.pickupLat : nil,
            pickupAirportLong: rideData.pickupType == "airport" ? rideData.pickupLong : nil,
            pickupAddress: (rideData.pickupType == "city" || rideData.pickupType == "cruise") ? rideData.pickupLocation : nil,
            pickupAddressLat: (rideData.pickupType == "city" || rideData.pickupType == "cruise") ? rideData.pickupLat : nil,
            pickupAddressLong: (rideData.pickupType == "city" || rideData.pickupType == "cruise") ? rideData.pickupLong : nil,
            
            // Dropoff information
            dropoffAirport: rideData.dropoffType == "airport" ? getAirportId(from: rideData.selectedDestinationAirport) : nil,
            dropoffAirportName: rideData.dropoffType == "airport" ? rideData.selectedDestinationAirport : nil,
            dropoffAirportLat: rideData.dropoffType == "airport" ? rideData.destinationLat : nil,
            dropoffAirportLong: rideData.dropoffType == "airport" ? rideData.destinationLong : nil,
            dropoffAddress: (rideData.dropoffType == "city" || rideData.dropoffType == "cruise") ? rideData.destinationLocation : nil,
            dropoffAddressLat: (rideData.dropoffType == "city" || rideData.dropoffType == "cruise") ? rideData.destinationLat : nil,
            dropoffAddressLong: (rideData.dropoffType == "city" || rideData.dropoffType == "cruise") ? rideData.destinationLong : nil,
            
            // Return pickup information (for round trip and charter tour)
            returnPickupDate: finalReturnPickupDate,
            returnPickupTime: finalReturnPickupTime,
            returnPickupAirport: defaultReturnPickupAirport ?? 0,
            returnPickupAirportName: returnPickupAirportName,
            returnPickupAirportLat: returnPickupAirportLat,
            returnPickupAirportLong: returnPickupAirportLong,
            returnPickupAddress: returnPickupAddress,
            returnPickupAddressLat: returnPickupAddressLat,
            returnPickupAddressLong: returnPickupAddressLong,
            
            // Return dropoff information (for round trip and charter tour)
            returnDropoffAirport: defaultReturnDropoffAirport ?? 0,
            returnDropoffAirportName: returnDropoffAirportName,
            returnDropoffAirportLat: returnDropoffAirportLat,
            returnDropoffAirportLong: returnDropoffAirportLong,
            returnDropoffAddress: returnDropoffAddress,
            returnDropoffAddressLat: returnDropoffAddressLat,
            returnDropoffAddressLong: returnDropoffAddressLong,
            
            // Passenger and luggage information
            noOfPassenger: rideData.noOfPassenger,
            noOfLuggage: rideData.noOfLuggage,
            
            // Location information (already created above)
            locationInfo: locationInfo,
            
            // Other details
            otherDetails: OtherDetails(
                pickupAirportName: rideData.pickupType == "airport" ? rideData.selectedPickupAirport : nil,
                dropoffAirportName: rideData.dropoffType == "airport" ? rideData.selectedDestinationAirport : nil,
                returnPickupAirportName: rideData.dropoffType == "airport" ? rideData.selectedDestinationAirport : nil,
                returnDropoffAirportName: rideData.pickupType == "airport" ? rideData.selectedPickupAirport : nil
            ),
            
            // Filters
            filters: {
                // Always include the selected master vehicle ID in vehicle types
                var currentFilterSelection = filterSelection
                currentFilterSelection.selectedVehicleTypes.insert(selectedMasterVehicleId)
                
                print("🔍 BOOKING DETAILS FILTERS DEBUG:")
                print("Selected Master Vehicle ID: \(selectedMasterVehicleId)")
                print("Filter Selection Vehicle Types: \(currentFilterSelection.selectedVehicleTypes)")
                print("Filter Selection Amenities: \(currentFilterSelection.selectedAmenities)")
                print("Filter Selection Special Amenities: \(currentFilterSelection.selectedSpecialAmenities)")
                print("Filter Selection Interiors: \(currentFilterSelection.selectedInteriors)")
                print("Filter Selection Makes: \(currentFilterSelection.selectedMakes)")
                print("Filter Selection Models: \(currentFilterSelection.selectedModels)")
                print("Filter Selection Years: \(currentFilterSelection.selectedYears)")
                print("Filter Selection Colors: \(currentFilterSelection.selectedColors)")
                print("Filter Selection Driver Languages: \(currentFilterSelection.selectedDriverLanguages)")
                print("Filter Selection Driver Dresses: \(currentFilterSelection.selectedDriverDresses)")
                print("Filter Selection Driver Genders: \(currentFilterSelection.selectedDriverGenders)")
                print("Filter Selection Driver Backgrounds: \(currentFilterSelection.selectedDriverBackgrounds)")
                print("Filter Selection Vehicle Service Areas: \(currentFilterSelection.selectedVehicleServiceAreas)")
                print("Filter Selection Affiliate Preferences: \(currentFilterSelection.selectedAffiliatePreferences)")
                
                return Filters.from(selectionState: currentFilterSelection)
            }(),
            userId: userId
        )
        
        print("✅ VEHICLE LISTING REQUEST CREATED SUCCESSFULLY!")
        
        // Debug: Check if request object is created correctly
        print("🔍 REQUEST OBJECT CREATED:")
        print("Service Type: \(request.serviceType)")
        print("Return Pickup Date: \(request.returnPickupDate)")
        print("Return Pickup Time: \(request.returnPickupTime)")
        print("Return Pickup Airport: \(request.returnPickupAirport ?? 0)")
        print("Return Dropoff Airport: \(request.returnDropoffAirport ?? 0)")
        
        // Manual JSON encoding test to see what's actually being encoded
        print("🔍 ABOUT TO ENCODE REQUEST:")
        print("Request type: \(type(of: request))")
        print("Return Pickup Date in request: \(request.returnPickupDate)")
        print("Return Pickup Time in request: \(request.returnPickupTime)")
        print("Return Pickup Airport in request: \(request.returnPickupAirport ?? 0)")
        print("Return Dropoff Airport in request: \(request.returnDropoffAirport ?? 0)")
        
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let jsonData = try encoder.encode(request)
            let jsonString = String(data: jsonData, encoding: .utf8) ?? "Failed to encode"
            print("🔍 MANUAL JSON ENCODING TEST:")
            print(jsonString)
        } catch {
            print("❌ JSON ENCODING ERROR: \(error)")
        }
        
        print("🔄 FINAL REQUEST DEBUG:")
        print("Pickup Airport ID: \(request.pickupAirport ?? 0)")
        print("Dropoff Airport ID: \(request.dropoffAirport ?? 0)")
        print("Return Pickup Date: \(request.returnPickupDate)")
        print("Return Pickup Time: \(request.returnPickupTime)")
        print("Return Pickup Airport ID: \(request.returnPickupAirport)")
        print("Return Dropoff Airport ID: \(request.returnDropoffAirport)")
        print("Return Pickup Airport Lat: \(request.returnPickupAirportLat ?? 0)")
        print("Return Pickup Airport Long: \(request.returnPickupAirportLong ?? 0)")
        print("Return Dropoff Airport Lat: \(request.returnDropoffAirportLat ?? 0)")
        print("Return Dropoff Airport Long: \(request.returnDropoffAirportLong ?? 0)")
        print("Pickup Airport Name: \(request.otherDetails.pickupAirportName ?? "nil")")
        print("Dropoff Airport Name: \(request.otherDetails.dropoffAirportName ?? "nil")")
        print("Return Pickup Airport Name: \(request.otherDetails.returnPickupAirportName ?? "nil")")
        print("Return Dropoff Airport Name: \(request.otherDetails.returnDropoffAirportName ?? "nil")")
        print("Location Info Count: \(request.locationInfo.count)")
        
        return request
    }
    
    
    private func getAirportId(from airportName: String) -> Int? {
        return AirportMapping.getAirportId(from: airportName)
    }
    
    private func createLocationInfoForRequest() async -> [LocationInfo] {
        let isRoundTrip = rideData.serviceType == "round_trip"
        let isCharterTour = rideData.serviceType == "charter_tour"
        
        let outboundLocationInfo = await vehicleService.createLocationInfo(
            pickupLat: rideData.pickupLat,
            pickupLong: rideData.pickupLong,
            dropoffLat: rideData.destinationLat,
            dropoffLong: rideData.destinationLong
        )
        
        // For round trips, we need two location info entries (outbound and return)
        if isRoundTrip || isCharterTour {
            let returnLocationInfo = await vehicleService.createLocationInfo(
                pickupLat: rideData.destinationLat, // Return pickup is the original dropoff
                pickupLong: rideData.destinationLong,
                dropoffLat: rideData.pickupLat, // Return dropoff is the original pickup
                dropoffLong: rideData.pickupLong
            )
            return outboundLocationInfo + returnLocationInfo
        } else {
            return outboundLocationInfo
        }
    }
}

struct BookingVehicleCard: View {
    let vehicle: VehicleListingItem
    let rideData: VehicleSelectionView.RideData
    let isSelected: Bool
    @Binding var path: [Screen]
    let onTap: () -> Void
    let onDetailsTap: (VehicleListingItem) -> Void
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 0) {
                // Top Section: Image + Details
                HStack(spacing: 0) {
                    // Vehicle Image (1/4 width)
                    VehicleImageView(vehicle: vehicle)
                        .frame(width: UIScreen.main.bounds.width * 0.25)
                    
                    // Vertical Divider
                    Rectangle()
                        .fill(Color.gray.opacity(0.3))
                        .frame(width: 1)
                        .frame(height: 120)
                    
                    // Vehicle Details (3/4 width)
                    VehicleDetailsView(vehicle: vehicle, rideData: rideData)
                        .frame(maxWidth: .infinity)
                        .padding(.leading, 16)
                }
                .frame(height: 120)
                
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(height: 1)
                    .padding(.horizontal, -16)
                
                // Bottom Section: Capacity + Buttons
                VehicleCardBottomSection(vehicle: vehicle, rideData: rideData, path: $path, onDetailsTap: onDetailsTap)
            }
            .background(Color(.white))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isSelected ? Color.black : Color.gray.opacity(0.2), lineWidth: isSelected ? 2 : 1)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}


struct VehicleImageView: View {
    let vehicle: VehicleListingItem
    
    var body: some View {
        AsyncImage(url: URL(string: vehicle.vehicleImages.first ?? "")) { image in
            image
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 70,height:70)
        } placeholder: {
            Rectangle()
                .fill(.white)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .overlay(
                    Image(systemName: "car.fill")
                        .font(.system(size: 40))
                        .foregroundColor(.gray)
                )
        }
    }
}

struct VehicleDetailsView: View {
    let vehicle: VehicleListingItem
    let rideData: VehicleSelectionView.RideData
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            // Vehicle Title
            Text(vehicle.name)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.black)
                .padding(.top, 16)
            
            // Service Type and Price
            BookingTypeAndPriceView(vehicle: vehicle, rideData: rideData)
            
            // Gratuity Text
            Text("All INC Rate include GRATUITY*")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.gray)
                .kerning(-0.23)
            
            // Vehicle Specifications
            VehicleSpecificationsView(vehicle: vehicle)
            
            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.trailing, 16)
    }
}

struct BookingTypeAndPriceView: View {
    let vehicle: VehicleListingItem
    let rideData: VehicleSelectionView.RideData
    
    private var serviceType: String {
        // Show the actual service type selected by the user
        switch rideData.serviceType {
        case "charter_tour":
            return "Charter Tour"
        case "round_trip":
            return "Round Trip"
        case "one_way":
            return "One way"
        default:
            return "N/A"
        }
    }
    
    private var price: Double {
        // Get price based on the user's selected service type
        return vehicle.getPrice(for: rideData.serviceType) ?? 0.0
    }
    
    var body: some View {
        HStack(spacing: 8) {
            // Service Type Pill
            Text(serviceType)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.black)
                .padding(.horizontal, 12)
                .padding(.vertical, 4)
                .background(Color.gray.opacity(0.2))
                .cornerRadius(12)
            
            // Price Pill
            Text("$ \(String(format: "%.2f", price))")
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(.white)
                .padding(.horizontal, 12)
                .padding(.vertical, 4)
                .background(AppColors.primaryOrange)
                .cornerRadius(12)
        }
    }
}

struct VehicleSpecificationsView: View {
    let vehicle: VehicleListingItem
    
    var body: some View {
        HStack(spacing: 6) {
            if let vehicleDetails = vehicle.vehicleDetails {
                Text(vehicleDetails.make)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.black)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
                
                Text(vehicleDetails.model)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.black)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
                
                Text(vehicleDetails.year)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.black)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
            } else {
                // Fallback when vehicle details are not available
                Text("Vehicle Details")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.gray)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
            }
        }
    }
}

struct VehicleCardBottomSection: View {
    let vehicle: VehicleListingItem
    let rideData: VehicleSelectionView.RideData
    @Binding var path: [Screen]
    let onDetailsTap: (VehicleListingItem) -> Void
    
    var body: some View {
        HStack {
            // Capacity Indicators (Left side)
            CapacityIndicatorsView(vehicle: vehicle)
            
            Spacer()
            
            // Action Buttons (Right side)
            ActionButtonsView(vehicle: vehicle, rideData: rideData, path: $path, onDetailsTap: onDetailsTap, onBookNowTap: onDetailsTap)
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 16)
        .frame(height: 50)
    }
}

struct CapacityIndicatorsView: View {
    let vehicle: VehicleListingItem
    
    var body: some View {
        HStack(spacing: 16) {
            CapacityTag(
                icon: "person.fill",
                value: vehicle.passenger
            )
            
            CapacityTag(
                icon: "suitcase.fill",
                value: vehicle.luggage
            )
        }
    }
}

struct CapacityTag: View {
    let icon: String
    let value: Int
    
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: icon)
                .font(.system(size: 12))
                .foregroundColor(AppColors.primaryOrange)
            Text("\(String(format: "%02d", value))")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.black)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(Color.orange.opacity(0.15))
        .cornerRadius(12)
    }
}

struct ActionButtonsView: View {
    let vehicle: VehicleListingItem
    let rideData: VehicleSelectionView.RideData
    @Binding var path: [Screen]
    let onDetailsTap: (VehicleListingItem) -> Void
    let onBookNowTap: (VehicleListingItem) -> Void
    
    var body: some View {
        HStack(spacing: 8) {
            Button(action: {
                onDetailsTap(vehicle)
                // Navigate to DetailsBookingView using path
                path.append(.detailsBooking(rideData: rideData, selectedVehicle: vehicle))
            }) {
                Text("Details")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.black)
                    .cornerRadius(8)
            }
            
            Button(action: {
                onBookNowTap(vehicle)
                // Navigate to ComprehensiveBookingView using path
                path.append(.comprehensiveBooking(
                    rideData: rideData,
                    selectedVehicle: vehicle,
                    isEditMode: false,
                    editBookingId: nil,
                    isRepeatMode: false,
                    repeatBookingId: nil,
                    isReturnFlow: false,
                    isRoundTripFlow: false
                ))
            }) {
                Text("Book Now")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(AppColors.greenColor)
                    .cornerRadius(8)
            }
        }
    }
}

// MARK: - Shimmer Placeholders
struct BookingVehicleListShimmer: View {
    // Show enough placeholders to cover the screen height
    private let placeholderCount = 5
    
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                ForEach(0..<placeholderCount, id: \.self) { _ in
                    BookingVehicleCardShimmer()
                }
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
    }
}

struct BookingVehicleCardShimmer: View {
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                // Image block
                RoundedRectangle(cornerRadius: 0)
                    .fill(Color.gray.opacity(0.15))
                    .overlay(
                        ShimmerView()
                            .clipShape(RoundedRectangle(cornerRadius: 0))
                    )
                    .frame(width: UIScreen.main.bounds.width * 0.25, height: 120)
                
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 1)
                    .frame(height: 120)
                
                VStack(alignment: .leading, spacing: 8) {
                    ShimmerText(width: 160, height: 16)
                    HStack(spacing: 8) {
                        ShimmerPill(width: 90, height: 24, cornerRadius: 12)
                        ShimmerPill(width: 110, height: 26, cornerRadius: 12)
                    }
                    ShimmerText(width: 190, height: 14)
                    HStack(spacing: 6) {
                        ShimmerPill(width: 70, height: 18, cornerRadius: 8)
                        ShimmerPill(width: 70, height: 18, cornerRadius: 8)
                        ShimmerPill(width: 60, height: 18, cornerRadius: 8)
                    }
                    Spacer()
                }
                .padding(.leading, 16)
                .padding(.trailing, 16)
                .frame(maxWidth: .infinity, maxHeight: 120, alignment: .topLeading)
            }
            .frame(height: 120)
            
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(height: 1)
                .padding(.horizontal, -16)
            
            HStack {
                HStack(spacing: 16) {
                    ShimmerPill(width: 60, height: 22, cornerRadius: 12)
                    ShimmerPill(width: 60, height: 22, cornerRadius: 12)
                }
                
                Spacer()
                
                HStack(spacing: 8) {
                    ShimmerButtonPlaceholder(width: 70, height: 32, cornerRadius: 8, baseColor: .gray)
                    ShimmerButtonPlaceholder(width: 90, height: 32, cornerRadius: 8, baseColor: .gray)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 12)
            .padding(.bottom, 16)
            .frame(height: 50)
        }
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
        )
    }
}

struct ShimmerButtonPlaceholder: View {
    let width: CGFloat
    let height: CGFloat
    let cornerRadius: CGFloat
    let baseColor: Color
    
    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius)
            .fill(baseColor.opacity(0.5))
            .frame(width: width, height: height)
            .overlay(
                ShimmerView()
                    .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
            )
    }
}


