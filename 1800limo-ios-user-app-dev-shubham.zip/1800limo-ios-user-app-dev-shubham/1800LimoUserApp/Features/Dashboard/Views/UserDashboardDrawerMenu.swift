//
//  UserDashboardDrawerMenu.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

// MARK: - Shimmer Components
struct ShimmerView: View {
    @State private var isAnimating = false
    
    var body: some View {
        Rectangle()
            .fill(
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.gray.opacity(0.3),
                        Color.gray.opacity(0.1),
                        Color.gray.opacity(0.3)
                    ]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .mask(
                Rectangle()
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.clear,
                                Color.white,
                                Color.clear
                            ]),
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .rotationEffect(.degrees(70))
                    .offset(x: isAnimating ? 200 : -200)
            )
            .drawingGroup() // Optimize rendering performance for multiple shimmer views
            .onAppear {
                withAnimation(
                    Animation.linear(duration: 1.5)
                        .repeatForever(autoreverses: false)
                ) {
                    isAnimating = true
                }
            }
    }
}

struct ShimmerCircle: View {
    let size: CGFloat
    
    var body: some View {
        Circle()
            .fill(Color.gray.opacity(0.3))
            .frame(width: size, height: size)
            .overlay(
                ShimmerView()
                    .clipShape(Circle())
            )
    }
}

struct ShimmerText: View {
    let width: CGFloat
    let height: CGFloat
    
    var body: some View {
        RoundedRectangle(cornerRadius: 4)
            .fill(Color.gray.opacity(0.3))
            .frame(width: width, height: height)
            .overlay(
                ShimmerView()
                    .clipShape(RoundedRectangle(cornerRadius: 4))
            )
    }
}

// MARK: - User Profile Section
struct UserProfileSection: View {
    @Binding var isPresented: Bool
    let userProfileVM: UserProfileViewModel
    
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                // User Profile Image
                if userProfileVM.isLoading {
                    ShimmerCircle(size: 60)
                } else if let imageURL = userProfileVM.userImageURL, !imageURL.isEmpty {
                    AsyncImage(url: URL(string: imageURL)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 60, height: 60)
                            .clipShape(Circle())
                    } placeholder: {
                        Image("personpasskey")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 60, height: 60)
                            .clipShape(Circle())
                    }
                } else {
                    Image("personpasskey")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 60, height: 60)
                        .clipShape(Circle())
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 8) {
                        if userProfileVM.isLoading {
                            ShimmerText(width: 120, height: 16)
                        } else {
                            Text(userProfileVM.userFullName)
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                        }
                        
//                        HStack(spacing: 2) {
//                            Image(systemName: "star.fill")
//                                .font(.system(size: 12))
//                                .foregroundColor(.orange)
//                            
//                            Text(String(format: "%.1f", userProfileVM.userRating))
//                                .font(.system(size: 12, weight: .medium))
//                                .foregroundColor(.orange)
//                        }
                    }
                    
                    if userProfileVM.isLoading {
                        ShimmerText(width: 100, height: 12)
                    } else {
                        Text(userProfileVM.userPhoneNumber)
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(AppColors.secondaryText)
                    }
                }
                
                Spacer()
                
                // Close button
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        isPresented = false
                    }
                }) {
                    Image(systemName: "xmark")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.white)
                        .frame(width: 48, height: 48)
                        .background(Color.red)
                        .clipShape(Circle())
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 60)
        .padding(.bottom, 20)
    }
}

// MARK: - Menu Options Section
struct MenuOptionsSection: View {
    @Binding var navigateToMyBookings: Bool
    @Binding var navigateToCreateBooking: Bool
    @Binding var navigateToMyCards: Bool
    @Binding var navigateToInvoices: Bool
    @Binding var navigateToInbox: Bool
    @Binding var navigateToNotifications: Bool
    @Binding var navigateToAccountSettings: Bool
    @Binding var navigateToHelp: Bool
    @Binding var isPresented: Bool
    @Binding var showLogoutConfirmation: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            UserMenuOption(title: "My Bookings") {
                navigateToMyBookings = true
                isPresented = false
            }
            
            UserMenuOption(title: "Create Booking") {
                navigateToCreateBooking = true
                isPresented = false
            }
            
            UserMenuOption(title: "My Cards") {
                navigateToMyCards = true
                isPresented = false
            }
            
            UserMenuOption(title: "Invoices") {
                navigateToInvoices = true
                isPresented = false
            }
            
//            UserMenuOption(title: "Inbox") {
//                navigateToInbox = true
//                isPresented = false
//            }
            
            UserMenuOption(title: "Notifications", badge: "02") {
                navigateToNotifications = true
                isPresented = false
            }
            
            UserMenuOption(title: "Account Settings") {
                navigateToAccountSettings = true
                isPresented = false
            }
            
            UserMenuOption(title: "Help") {
                navigateToHelp = true
                isPresented = false
            }
            
            Spacer()
            
            // Logout option
            UserLogoutOption(action: {
                showLogoutConfirmation = true
            })
            Spacer().frame(height: 45)
            
        }
        .padding(.horizontal, 20)
    }
}

// MARK: - Main Drawer Menu
struct UserDashboardDrawerMenu: View {
    @Binding var isPresented: Bool
    @Binding var navigateToMyBookings: Bool
    @Binding var navigateToCreateBooking: Bool
    @Binding var navigateToMyCards: Bool
    @Binding var navigateToInvoices: Bool
    @Binding var navigateToInbox: Bool
    @Binding var navigateToNotifications: Bool
    @Binding var navigateToAccountSettings: Bool
    @Binding var navigateToHelp: Bool
    let userProfileVM: UserProfileViewModel
    let onLogout: () -> Void
    @State private var showLogoutConfirmation = false
    
    var body: some View {
        ZStack {
            // Full screen background
            Color.black.opacity(0.3)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        isPresented = false
                    }
                }
            
            // Full screen drawer content
            VStack(spacing: 0) {
                UserProfileSection(isPresented: $isPresented, userProfileVM: userProfileVM)
                
                MenuOptionsSection(
                    navigateToMyBookings: $navigateToMyBookings,
                    navigateToCreateBooking: $navigateToCreateBooking,
                    navigateToMyCards: $navigateToMyCards,
                    navigateToInvoices: $navigateToInvoices,
                    navigateToInbox: $navigateToInbox,
                    navigateToNotifications: $navigateToNotifications,
                    navigateToAccountSettings: $navigateToAccountSettings,
                    navigateToHelp: $navigateToHelp,
                    isPresented: $isPresented,
                    showLogoutConfirmation: $showLogoutConfirmation
                )
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.white)
            .ignoresSafeArea()
        }
        .transition(.move(edge: .leading))
        .alert("Error", isPresented: Binding(
            get: { userProfileVM.showError },
            set: { _ in }
        )) {
            Button("OK") { }
        } message: {
            Text(userProfileVM.errorMessage ?? "An error occurred")
        }
        .alert("Logout", isPresented: $showLogoutConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Logout", role: .destructive) {
                isPresented = false
                onLogout()
            }
        } message: {
            Text("Are you sure you want to logout?")
        }
    }
}

// MARK: - Menu Option Component
struct UserMenuOption: View {
    let title: String
    var badge: String? = nil
    var action: (() -> Void)? = nil
    
    var body: some View {
        Button(action: {
            action?()
        }) {
            HStack {
                Text(title)
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.black)
                
                if let badge = badge {
                    Text(badge)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white)
                        .frame(width: 30, height: 20)
                        .background(Color.orange)
                        .clipShape(Capsule())
                }

                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
            .padding(.vertical, 16)
            .padding(.horizontal, 0)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Logout Option Component
struct UserLogoutOption: View {
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: "rectangle.portrait.and.arrow.right")
                    .font(.system(size: 18))
                    .foregroundColor(.red)
                
                Text("Logout")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.red)
                
                Spacer()
            }
            .padding(.vertical, 16)
            .padding(.horizontal, 0)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Preview
#Preview {
    UserDashboardDrawerMenu(
        isPresented: .constant(true),
        navigateToMyBookings: .constant(false),
        navigateToCreateBooking: .constant(false),
        navigateToMyCards: .constant(false),
        navigateToInvoices: .constant(false),
        navigateToInbox: .constant(false),
        navigateToNotifications: .constant(false),
        navigateToAccountSettings: .constant(false),
        navigateToHelp: .constant(false),
        userProfileVM: UserProfileViewModel(),
        onLogout: {}
    )
}
