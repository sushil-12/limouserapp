import SwiftUI
import MapKit
import CoreLocation

struct ScheduleRideBottomSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: [Screen]
    @StateObject private var pickupAddressViewModel = AddressAutocompleteViewModel()
    @StateObject private var destinationAddressViewModel = AddressAutocompleteViewModel()
    @StateObject private var dashboardViewModel = DashboardViewModel()
    @StateObject private var sheetDismissalManager = SheetDismissalManager.shared
    @State private var selectedRideType: RideType = .oneWay
    @State private var selectedPassenger = "For me"
    @State private var pickupLocation = ""
    @State private var destinationLocation = ""
    @State private var showPassengerPicker = false
    @State private var showPickupSuggestions = false
    @State private var showDestinationSuggestions = false
    @State private var justSelectedPickup = false
    @State private var justSelectedDestination = false
    @State private var showSwitchRiderSheet = false
    @State private var showHoursDropdown = false
    @State private var selectedHours = "2 hours minimum"
    @State private var showTimeSelectionView = false // Keep for backward compatibility but use path instead
    @State private var showCancellationPolicy = false
    @State private var isNavigatingToTimeSelection = false // Prevent multiple navigations
    @State private var openDropdown: String? = nil
    @State private var dropdownFrame: CGRect = .zero
    @State private var dropdownOptions: [String] = []
    @State private var dropdownSelected: Binding<String?>? = nil
    @State private var selectedBookingType = "City (FBO)"
    @State private var selectedDestinationType = "Airport"
    @State private var selectedPickupAirport = ""
    @State private var selectedDestinationAirport = ""
    @State private var pickupAirportSearch = ""
    @State private var destinationAirportSearch = ""
    @State private var isSettingCurrentLocation = false
    @State private var isInitialLoad = true
    @State private var scrollOffset: CGFloat = 0
    @State private var focusedField: String? = nil // Track which field has focus
    @State private var showInvalidLocationDialog = false // Show dialog when pickup and destination are same
    @State private var invalidLocationMessage = "Pickup and destination locations cannot be the same. Please select different locations."
    @State private var isComingBackFromNavigation = false // Track if coming back from navigation to prevent keyboard focus
    @State private var previousFocusedField: String? = nil // Track previous focused field to detect user interaction
    @State private var showRecentLocationsOnReturn = false // Show recent locations when coming back without focus
    
    // Coordinate storage
    @State private var pickupCoordinate: LocationCoordinate?
    @State private var destinationCoordinate: LocationCoordinate?
    @State private var pickupCountry: String?
    @State private var destinationCountry: String?
    
    // Mutable ride data for data flow
    @State private var currentRideData: VehicleSelectionView.RideData?
    
    
    // State preservation for navigation back
    @State private var preservedPickupLocation = ""
    @State private var preservedDestinationLocation = ""
    @State private var preservedPickupAirport = ""
    @State private var preservedDestinationAirport = ""
    @State private var preservedPickupCoordinate: LocationCoordinate?
    @State private var preservedDestinationCoordinate: LocationCoordinate?
    @State private var preservedPickupCountry: String?
    @State private var preservedDestinationCountry: String?
    
    let hoursOptions = ["2 hours minimum", "3 hours", "4 hours", "5 hours", "6 hours", "8 hours", "10 hours", "12 hours"]
    let bookingTypeOptions = ["City (FBO)", "Airport", "Cruise Port"]
    
    @StateObject private var airportService = AirportService()
    @StateObject private var recentLocationService = RecentLocationService.shared
    
    enum RideType: String, CaseIterable {
        case oneWay = "One Way"
        case roundTrip = "Round Trip"
        case hourly = "Hourly"
    }
    
    // Function to determine dropdown position based on dropdown type
    private func getDropdownPosition(for dropdownType: String?) -> CGFloat {
        guard let dropdownType = dropdownType else { return 75 }
        
        switch dropdownType {
        case "hours":
            let rowHeight: CGFloat = 44
            let menuHeight = CGFloat(hoursOptions.count) * rowHeight
            return (menuHeight / 2) + 8
        default:
            return 75
        }
    }
    
    
    
    // Computed property to determine if Recent & Saved section should be hidden
    private var shouldHideRecentAndSaved: Bool {
        let hasPickupSuggestions = showPickupSuggestions && !pickupAddressViewModel.suggestions.isEmpty
        let hasDestinationSuggestions = showDestinationSuggestions && !destinationAddressViewModel.suggestions.isEmpty
        let hasPickupAirportSuggestions = showPickupSuggestions && selectedBookingType == "Airport" && !airportService.suggestions.isEmpty
        let hasDestinationAirportSuggestions = showDestinationSuggestions && selectedDestinationType == "Airport" && !airportService.suggestions.isEmpty
        
        let shouldHide = hasPickupSuggestions || hasDestinationSuggestions || hasPickupAirportSuggestions || hasDestinationAirportSuggestions
        
        print("🔍 shouldHideRecentAndSaved: \(shouldHide)")
        print("   - showPickupSuggestions: \(showPickupSuggestions)")
        print("   - pickupAddressViewModel.suggestions.count: \(pickupAddressViewModel.suggestions.count)")
        print("   - showDestinationSuggestions: \(showDestinationSuggestions)")
        print("   - destinationAddressViewModel.suggestions.count: \(destinationAddressViewModel.suggestions.count)")
        print("   - selectedBookingType: \(selectedBookingType)")
        print("   - airportService.suggestions.count: \(airportService.suggestions.count)")
        
        return shouldHide
    }
    
    // Function to preserve current state before navigation
    private func preserveCurrentState() {
        preservedPickupLocation = pickupLocation
        preservedDestinationLocation = destinationLocation
        preservedPickupAirport = selectedPickupAirport
        preservedDestinationAirport = selectedDestinationAirport
        preservedPickupCoordinate = pickupCoordinate
        preservedDestinationCoordinate = destinationCoordinate
        preservedPickupCountry = pickupCountry
        preservedDestinationCountry = destinationCountry
        print("💾 STATE PRESERVED:")
        print("Pickup: \(preservedPickupLocation) / \(preservedPickupAirport)")
        print("Destination: \(preservedDestinationLocation) / \(preservedDestinationAirport)")
    }
    
    // Function to restore state when navigating back
    private func restoreState() {
        // Only restore if we have preserved state and current state is empty
        if !preservedPickupLocation.isEmpty && pickupLocation.isEmpty {
            pickupLocation = preservedPickupLocation
            selectedPickupAirport = preservedPickupAirport
            pickupCoordinate = preservedPickupCoordinate
            pickupCountry = preservedPickupCountry
            print("🔄 RESTORED PICKUP STATE: \(pickupLocation)")
        }
        
        if !preservedDestinationLocation.isEmpty && destinationLocation.isEmpty {
            destinationLocation = preservedDestinationLocation
            selectedDestinationAirport = preservedDestinationAirport
            destinationCoordinate = preservedDestinationCoordinate
            destinationCountry = preservedDestinationCountry
            print("🔄 RESTORED DESTINATION STATE: \(destinationLocation)")
        }
        
        // Check if both fields are already filled (coming back from navigation)
        let pickupFilled = !pickupLocation.isEmpty || !selectedPickupAirport.isEmpty
        let destinationFilled = !destinationLocation.isEmpty || !selectedDestinationAirport.isEmpty
        
        // Only auto-focus if destination is empty (initial state)
        // If coming back from navigation with fields already filled, show recent locations without keyboard
        if !destinationFilled {
            // Restore focus to destination field and show suggestions only if destination is empty
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                focusedField = "destination"
                showDestinationSuggestions = true
                destinationAddressViewModel.isEditing = true
                destinationAddressViewModel.input = destinationLocation
                
                // Clear pickup suggestions when focusing on destination
                showPickupSuggestions = false
                pickupAddressViewModel.suggestions = []
                airportService.clearSuggestions()
                
                print("🎯 RESTORED FOCUS TO DESTINATION FIELD (destination was empty)")
            }
        } else {
            // Coming back from navigation - clear all focus (no recents or select on map will show)
            previousFocusedField = focusedField // Store current value before changing
            isComingBackFromNavigation = true
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                // Clear all focus - don't set focusedField to anything
                // This ensures no recents or select on map will show (as per user requirement)
                focusedField = nil
                
                // Clear any active editing states to prevent keyboard from showing
                showPickupSuggestions = false
                showDestinationSuggestions = false
                pickupAddressViewModel.suggestions = []
                destinationAddressViewModel.suggestions = []
                destinationAddressViewModel.isEditing = false
                pickupAddressViewModel.isEditing = false
                airportService.clearSuggestions()
                
                print("🔄 COMING BACK FROM NAVIGATION - NO FOCUS, NOTHING WILL SHOW")
            }
        }
    }
    
    // Function to set current location as pickup
    private func setCurrentLocationAsPickup() {
        print("📍 ATTEMPTING TO SET CURRENT LOCATION AS PICKUP...")
        print("📍 LOCATION STATUS: \(dashboardViewModel.getLocationStatus())")
        
        isSettingCurrentLocation = true
        isInitialLoad = true
        
        // Completely disable Google Places suggestions while setting current location
        pickupAddressViewModel.isEditing = false
        pickupAddressViewModel.suggestions = []
        pickupAddressViewModel.input = "" // Clear input to prevent suggestions
        showPickupSuggestions = false
        showDestinationSuggestions = false
        
        // Check if location is already available
        if dashboardViewModel.isLocationAvailable() {
            let currentLocationData = dashboardViewModel.getCurrentLocationForPickup()
            if let address = currentLocationData.address, let coordinate = currentLocationData.coordinate {
                pickupLocation = address
                pickupCoordinate = LocationCoordinate(latitude: coordinate.latitude, longitude: coordinate.longitude)
                pickupCountry = extractCountry(from: address)
                print("📍 CURRENT LOCATION SET AS PICKUP: \(address)")
                print("📍 PICKUP COORDINATE: \(coordinate.latitude), \(coordinate.longitude)")
                isSettingCurrentLocation = false
                return
            }
        }
        
        // If not available, refresh and wait
        dashboardViewModel.refreshCurrentLocation()
        
        // Try multiple times with increasing delays
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.trySetCurrentLocation(attempt: 1)
        }
    }
    
    // Helper function to try setting current location with retries
    private func trySetCurrentLocation(attempt: Int) {
        let currentLocationData = dashboardViewModel.getCurrentLocationForPickup()
        
        if let address = currentLocationData.address, let coordinate = currentLocationData.coordinate {
            pickupLocation = address
            pickupCoordinate = LocationCoordinate(latitude: coordinate.latitude, longitude: coordinate.longitude)
            pickupCountry = extractCountry(from: address)
            print("📍 CURRENT LOCATION SET AS PICKUP (attempt \(attempt)): \(address)")
            print("📍 PICKUP COORDINATE: \(coordinate.latitude), \(coordinate.longitude)")
            isSettingCurrentLocation = false
            
            // Clear any suggestions and keep editing disabled until user manually interacts
            pickupAddressViewModel.suggestions = []
            pickupAddressViewModel.input = ""
            pickupAddressViewModel.isEditing = false
            
            // Mark initial load as complete after a short delay to prevent suggestions
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                self.isInitialLoad = false
            }
        } else if attempt < 3 {
            // Retry with longer delay
            print("📍 LOCATION NOT AVAILABLE, RETRYING (attempt \(attempt + 1))...")
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(attempt + 1)) {
                self.trySetCurrentLocation(attempt: attempt + 1)
            }
        } else {
            // Final fallback
            pickupLocation = "Manhattan, New York, NY, USA"
            pickupCoordinate = LocationCoordinate(latitude: 40.7128, longitude: -74.0060)
            pickupCountry = extractCountry(from: pickupLocation)
            print("📍 FINAL FALLBACK PICKUP LOCATION SET: \(pickupLocation)")
            isSettingCurrentLocation = false
            
            // Clear any suggestions and keep editing disabled until user manually interacts
            pickupAddressViewModel.suggestions = []
            pickupAddressViewModel.input = ""
            pickupAddressViewModel.isEditing = false
            
            // Mark initial load as complete after a short delay to prevent suggestions
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                self.isInitialLoad = false
            }
        }
    }
    
    // Function to refresh current location
    private func refreshCurrentLocation() {
        isSettingCurrentLocation = true
        
        // Completely disable Google Places suggestions while refreshing
        pickupAddressViewModel.isEditing = false
        pickupAddressViewModel.suggestions = []
        pickupAddressViewModel.input = "" // Clear input to prevent suggestions
        showPickupSuggestions = false
        showDestinationSuggestions = false
        
        dashboardViewModel.refreshCurrentLocation()
        
        // Update pickup location with new current location after a short delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            if selectedBookingType != "Airport" {
                setCurrentLocationAsPickup()
            }
        }
    }
    
    // Helper function to check if pickup and destination are the same
    private func normalizedLocationText(_ text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let collapsedWhitespace = trimmed.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
        let removedPunctuation = collapsedWhitespace.replacingOccurrences(of: "[,;]", with: " ", options: .regularExpression)
        return removedPunctuation.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    }
    
    private func areLocationsSame() -> Bool {
        // Check if location text matches
        let pickupText = selectedBookingType == "Airport" ? selectedPickupAirport : pickupLocation
        let destinationText = selectedDestinationType == "Airport" ? selectedDestinationAirport : destinationLocation
        
        // Check if text matches
        let normalizedPickup = normalizedLocationText(pickupText)
        let normalizedDestination = normalizedLocationText(destinationText)
        if !normalizedPickup.isEmpty && !normalizedDestination.isEmpty && normalizedPickup == normalizedDestination {
            return true
        }
        
        // Check if coordinates match (within a small tolerance to account for floating point precision)
        if let pickupCoord = pickupCoordinate, let destCoord = destinationCoordinate {
            let latDiff = abs(pickupCoord.latitude - destCoord.latitude)
            let longDiff = abs(pickupCoord.longitude - destCoord.longitude)
            // Locations are considered same if coordinates are within ~200 meters
            if latDiff < 0.002 && longDiff < 0.002 {
                return true
            }
        }
        
        return false
    }
    
    private func coordinatesApproximatelyEqual(_ lhs: LocationCoordinate, _ rhs: LocationCoordinate, tolerance: Double = 0.002) -> Bool {
        return abs(lhs.latitude - rhs.latitude) < tolerance && abs(lhs.longitude - rhs.longitude) < tolerance
    }

    private static let countrySynonyms: [String: String] = [
        "UNITED STATES OF AMERICA": "US",
        "USA": "US",
        "US": "US",
        "U.S": "US",
        "U.S.A": "US",
        "U.S.A.": "US",
        "UNITED STATES": "US",
        "AMERICA": "US",
        "UNITED KINGDOM": "GB",
        "UK": "GB",
        "U.K": "GB",
        "U.K.": "GB",
        "GREAT BRITAIN": "GB",
        "BRITAIN": "GB",
        "ENGLAND": "GB",
        "SCOTLAND": "GB",
        "WALES": "GB",
        "NORTHERN IRELAND": "GB",
        "UNITED ARAB EMIRATES": "AE",
        "UAE": "AE",
        "U.A.E": "AE",
        "U.A.E.": "AE",
        "EMIRATES": "AE",
        "CANADA": "CA",
        "CA": "CA",
        "C.A": "CA",
        "C.A.": "CA",
        "MEXICO": "MX",
        "AUSTRALIA": "AU",
        "NEW ZEALAND": "NZ",
        "GERMANY": "DE",
        "FRANCE": "FR",
        "SPAIN": "ES",
        "ITALY": "IT",
        "INDIA": "IN",
        "CHINA": "CN",
        "JAPAN": "JP",
        "SINGAPORE": "SG"
    ]
    
    private static let countryNameLookup: [String: String] = {
        var lookup: [String: String] = [:]
        let locale = Locale(identifier: "en_US")
        for code in Locale.isoRegionCodes {
            let uppercaseCode = code.uppercased()
            if let name = locale.localizedString(forRegionCode: uppercaseCode) {
                lookup[name.uppercased()] = uppercaseCode
            }
            lookup[uppercaseCode] = uppercaseCode
        }
        return lookup
    }()
    
    private func normalizeCountry(_ country: String?) -> String? {
        guard var country = country?.trimmingCharacters(in: .whitespacesAndNewlines), !country.isEmpty else {
            return nil
        }
        
        country = country.replacingOccurrences(of: ".", with: "")
        country = country.replacingOccurrences(of: ",", with: "")
        country = country.replacingOccurrences(of: ";", with: "")
        country = country.replacingOccurrences(of: "  ", with: " ")
        
        let uppercased = country.uppercased()
        
        if let synonym = ScheduleRideBottomSheet.countrySynonyms[uppercased] {
            return synonym
        }
        
        if let mapped = ScheduleRideBottomSheet.countryNameLookup[uppercased] {
            return mapped
        }
        
        // If the string is short (<= 3 characters) and not a known ISO region, treat it as ambiguous.
        if uppercased.count <= 3 {
            return nil
        }
        
        return nil
    }
    
    private func extractCountry(from address: String) -> String? {
        let separators = CharacterSet(charactersIn: ",;")
        let components = address
            .components(separatedBy: separators)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        
        for component in components.reversed() {
            // Ignore purely numeric components (likely postal codes)
            let hasLetter = component.rangeOfCharacter(from: .letters) != nil
            if hasLetter {
                return component
            }
        }
        
        return nil
    }
    
    private func resolvePickupCountry(using coordinate: LocationCoordinate? = nil) -> String? {
        let targetCoordinate = coordinate ?? pickupCoordinate
        
        if selectedBookingType == "Airport" {
            if let airport = airportService.airports.first(where: {
                $0.displayName == selectedPickupAirport || $0.fullDisplayName == selectedPickupAirport
            }) {
                return airport.country
            }
            
            if let targetCoordinate = targetCoordinate {
                if let airport = airportService.airports.first(where: {
                    if let lat = $0.lat, let long = $0.long {
                        return coordinatesApproximatelyEqual(LocationCoordinate(latitude: lat, longitude: long), targetCoordinate)
                    }
                    return false
                }) {
                    return airport.country
                }
            }
        }
        
        if let country = pickupAddressViewModel.selectedCountry {
            return country
        }
        
        if !pickupLocation.isEmpty, let country = extractCountry(from: pickupLocation) {
            return country
        }
        
        if let targetCoordinate = targetCoordinate {
            if let recent = recentLocationService.pickupLocations.first(where: {
                coordinatesApproximatelyEqual(LocationCoordinate(latitude: $0.latitude, longitude: $0.longitude), targetCoordinate)
            }) {
                return extractCountry(from: recent.address)
            }
            
            if let recentDrop = recentLocationService.dropoffLocations.first(where: {
                coordinatesApproximatelyEqual(LocationCoordinate(latitude: $0.latitude, longitude: $0.longitude), targetCoordinate)
            }) {
                return extractCountry(from: recentDrop.address)
            }
        }
        
        return nil
    }
    
    private func resolveDestinationCountry(using coordinate: LocationCoordinate? = nil) -> String? {
        let targetCoordinate = coordinate ?? destinationCoordinate
        
        if selectedDestinationType == "Airport" {
            if let airport = airportService.airports.first(where: {
                $0.displayName == selectedDestinationAirport || $0.fullDisplayName == selectedDestinationAirport
            }) {
                return airport.country
            }
            
            if let targetCoordinate = targetCoordinate {
                if let airport = airportService.airports.first(where: {
                    if let lat = $0.lat, let long = $0.long {
                        return coordinatesApproximatelyEqual(LocationCoordinate(latitude: lat, longitude: long), targetCoordinate)
                    }
                    return false
                }) {
                    return airport.country
                }
            }
        }
        
        if let country = destinationAddressViewModel.selectedCountry {
            return country
        }
        
        if !destinationLocation.isEmpty, let country = extractCountry(from: destinationLocation) {
            return country
        }
        
        if let targetCoordinate = targetCoordinate {
            if let recent = recentLocationService.dropoffLocations.first(where: {
                coordinatesApproximatelyEqual(LocationCoordinate(latitude: $0.latitude, longitude: $0.longitude), targetCoordinate)
            }) {
                return extractCountry(from: recent.address)
            }
            
            if let recentPickup = recentLocationService.pickupLocations.first(where: {
                coordinatesApproximatelyEqual(LocationCoordinate(latitude: $0.latitude, longitude: $0.longitude), targetCoordinate)
            }) {
                return extractCountry(from: recentPickup.address)
            }
        }
        
        return nil
    }
    
    private func areCountriesDifferent() -> Bool {
        let pickupValue = pickupCountry ?? resolvePickupCountry()
        let destinationValue = destinationCountry ?? resolveDestinationCountry()
        
        print("🌍 COUNTRY VALIDATION:")
        print("   - pickupValue: '\(pickupValue ?? "nil")'")
        print("   - destinationValue: '\(destinationValue ?? "nil")'")
        
        // If we can't determine countries for both locations, allow the user to proceed
        // Only block if we can clearly determine that countries are different
        guard let normalizedPickup = normalizeCountry(pickupValue),
              let normalizedDestination = normalizeCountry(destinationValue) else {
            print("   - Could not normalize countries, allowing user to proceed (returning false)")
            return false
        }
        
        print("   - normalizedPickup: '\(normalizedPickup)'")
        print("   - normalizedDestination: '\(normalizedDestination)'")
        print("   - Are different: \(normalizedPickup != normalizedDestination)")
        
        return normalizedPickup != normalizedDestination
    }
    
    private func invalidLocationReason() -> String? {
        print("🔍 CHECKING INVALID LOCATION REASON:")
        
        if areLocationsSame() {
            print("   - Locations are the same!")
            return "Pickup and destination locations cannot be the same. Please select different locations."
        }
        
        if areCountriesDifferent() {
            print("   - Countries are different!")
            return "Pickup and destination must be in the same country. Please select valid locations."
        }
        
        print("   - No validation issues found")
        return nil
    }
    
    private func userIsActivelyTyping() -> Bool {
        return (showPickupSuggestions && focusedField == "pickup") ||
               (showDestinationSuggestions && focusedField == "destination")
    }
    
    // Computed property to check if time selection should be shown
    private var shouldShowTimeSelection: Bool {
        // Check if both locations have text
        let pickupSelected = !pickupLocation.isEmpty || !selectedPickupAirport.isEmpty
        let destinationSelected = !destinationLocation.isEmpty || !selectedDestinationAirport.isEmpty
        
        // Check if both have valid coordinates (allow 0,0 for now to be more permissive)
        let pickupHasValidCoordinates = pickupCoordinate != nil
        let destinationHasValidCoordinates = destinationCoordinate != nil
        
        // Check if there is any location conflict (same point or different countries)
        let locationConflictReason = invalidLocationReason()
        
        print("🔍 SHOULD SHOW TIME SELECTION CHECK:")
        print("   - pickupSelected: \(pickupSelected)")
        print("   - destinationSelected: \(destinationSelected)")
        print("   - pickupHasValidCoordinates: \(pickupHasValidCoordinates)")
        print("   - destinationHasValidCoordinates: \(destinationHasValidCoordinates)")
        print("   - userIsActivelyTyping: \(userIsActivelyTyping())")
        print("   - locationConflictReason: \(locationConflictReason ?? "nil")")
        
        // Only navigate if both locations are selected, user is not actively typing, and there are no conflicts
        let shouldShow = pickupSelected && destinationSelected && 
               pickupHasValidCoordinates && destinationHasValidCoordinates &&
               !userIsActivelyTyping() && locationConflictReason == nil
        
        print("   - RESULT: \(shouldShow)")
        return shouldShow
    }
    
    // Helper function to dismiss keyboard
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    // Function to prepare and show time selection
    private func prepareAndShowTimeSelection() {
        let pickupSelected = !pickupLocation.isEmpty || !selectedPickupAirport.isEmpty
        let destinationSelected = !destinationLocation.isEmpty || !selectedDestinationAirport.isEmpty
        let pickupHasValidCoordinates = pickupCoordinate != nil
        let destinationHasValidCoordinates = destinationCoordinate != nil
        let activelyTyping = userIsActivelyTyping()
        
        // Get validation reason with detailed logging
        let locationConflictReason = invalidLocationReason()
        print("🔍 VALIDATION CHECK:")
        print("   - pickupSelected: \(pickupSelected)")
        print("   - destinationSelected: \(destinationSelected)")
        print("   - pickupHasValidCoordinates: \(pickupHasValidCoordinates)")
        print("   - destinationHasValidCoordinates: \(destinationHasValidCoordinates)")
        print("   - activelyTyping: \(activelyTyping)")
        print("   - locationConflictReason: \(locationConflictReason ?? "nil")")
        print("   - pickupCountry: \(pickupCountry ?? "nil")")
        print("   - destinationCountry: \(destinationCountry ?? "nil")")
        print("   - resolvePickupCountry: \(resolvePickupCountry() ?? "nil")")
        print("   - resolveDestinationCountry: \(resolveDestinationCountry() ?? "nil")")
        
        // Check for validation errors FIRST before checking shouldShowTimeSelection
        if let reason = locationConflictReason,
           pickupSelected && destinationSelected &&
           pickupHasValidCoordinates && destinationHasValidCoordinates &&
           !activelyTyping {
            print("⚠️ Location validation failed - showing error dialog. Reason: \(reason)")
            invalidLocationMessage = reason
            showInvalidLocationDialog = true
            return
        }
        
        // Prevent multiple navigations
        guard !isNavigatingToTimeSelection else {
            print("⚠️ prepareAndShowTimeSelection blocked - navigation already in progress")
            return
        }
        
        // Check if already navigated (path contains timeSelection)
        if path.contains(where: { 
            if case .timeSelection = $0 { return true }
            return false
        }) {
            print("⚠️ prepareAndShowTimeSelection blocked - already navigated to TimeSelectionView")
            return
        }
        
        guard shouldShowTimeSelection && !showTimeSelectionView else {
            print("⚠️ prepareAndShowTimeSelection blocked - shouldShowTimeSelection: \(shouldShowTimeSelection), showTimeSelectionView: \(showTimeSelectionView)")
            return 
        }
        
        // Set flag to prevent multiple navigations
        isNavigatingToTimeSelection = true
        
        // Dismiss keyboard before navigating
        hideKeyboard()
        
        print("✅ BOTH LOCATIONS SELECTED WITH VALID COORDINATES - PREPARING TIME SELECTION")
        print("📍 Current state:")
        print("   - pickupLocation: '\(pickupLocation)'")
        print("   - destinationLocation: '\(destinationLocation)'")
        print("   - selectedPickupAirport: '\(selectedPickupAirport)'")
        print("   - selectedDestinationAirport: '\(selectedDestinationAirport)'")
        print("   - pickupCoordinate: \(pickupCoordinate?.latitude ?? 0), \(pickupCoordinate?.longitude ?? 0)")
        print("   - destinationCoordinate: \(destinationCoordinate?.latitude ?? 0), \(destinationCoordinate?.longitude ?? 0)")
        print("   - pickupCountry: '\(pickupCountry ?? resolvePickupCountry() ?? "nil")'")
        print("   - destinationCountry: '\(destinationCountry ?? resolveDestinationCountry() ?? "nil")'")
        
        // Preserve current state before navigation
        preserveCurrentState()
        
        // Create and set ride data SYNCHRONOUSLY (we're already on main thread)
        // This ensures data is ready before view is shown
        let newRideData = createRideData()
        currentRideData = newRideData
        print("🚗 Created ride data: \(newRideData)")
        print("🚗 Pickup: '\(newRideData.pickupLocation)'")
        print("🚗 Destination: '\(newRideData.destinationLocation)'")
        print("🚗 Pickup Coord: \(newRideData.pickupLat ?? 0), \(newRideData.pickupLong ?? 0)")
        print("🚗 Dest Coord: \(newRideData.destinationLat ?? 0), \(newRideData.destinationLong ?? 0)")
        
        // Verify data is not empty before showing (be more permissive with coordinates)
        guard !newRideData.pickupLocation.isEmpty || !newRideData.selectedPickupAirport.isEmpty else {
            print("❌ ERROR: Pickup location is empty!")
            isNavigatingToTimeSelection = false
            return
        }
        guard !newRideData.destinationLocation.isEmpty || !newRideData.selectedDestinationAirport.isEmpty else {
            print("❌ ERROR: Destination location is empty!")
            isNavigatingToTimeSelection = false
            return
        }
        guard newRideData.pickupLat != nil && newRideData.pickupLong != nil else {
            print("❌ ERROR: Pickup coordinates are missing!")
            isNavigatingToTimeSelection = false
            return
        }
        guard newRideData.destinationLat != nil && newRideData.destinationLong != nil else {
            print("❌ ERROR: Destination coordinates are missing!")
            isNavigatingToTimeSelection = false
            return
        }
        
        // Navigate using path instead of fullScreenCover
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            // Verify data is still set
            guard let rideData = self.currentRideData else {
                print("❌ ERROR: currentRideData is nil!")
                self.isNavigatingToTimeSelection = false
                return
            }
            
            // Double-check we haven't already navigated
            if self.path.contains(where: { 
                if case .timeSelection = $0 { return true }
                return false
            }) {
                print("⚠️ Already navigated to TimeSelectionView, skipping")
                self.isNavigatingToTimeSelection = false
                return
            }
            
            // Navigate to time selection using path
            self.path.append(.timeSelection(rideData: rideData))
            print("🚗 Navigating to TimeSelectionView with valid data")
            print("🚗 Verifying currentRideData exists: \(rideData.pickupLocation)")
            
            // Reset flag after a delay to allow navigation to complete
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.isNavigatingToTimeSelection = false
            }
        }
    }
    
    
    // Function to create ride data for API calls
    private func createRideData() -> VehicleSelectionView.RideData {
        // Convert ride type to service type
        let serviceType: String
        switch selectedRideType {
        case .oneWay:
            serviceType = "one_way"
        case .roundTrip:
            serviceType = "round_trip"
        case .hourly:
            serviceType = "charter_tour"
        }
        
        // Convert booking type to pickup/dropoff type
        let pickupType = selectedBookingType.lowercased().replacingOccurrences(of: " (fbo)", with: "").replacingOccurrences(of: " port", with: "")
        let dropoffType = selectedDestinationType.lowercased().replacingOccurrences(of: " (fbo)", with: "").replacingOccurrences(of: " port", with: "")
        
        print("🚢 CRUISE PORT DEBUG:")
        print("Selected Booking Type: '\(selectedBookingType)' -> Pickup Type: '\(pickupType)'")
        print("Selected Destination Type: '\(selectedDestinationType)' -> Dropoff Type: '\(dropoffType)'")
        
        // Extract hours from selected hours string
        let hoursString = selectedHours.replacingOccurrences(of: " hours minimum", with: "").replacingOccurrences(of: " hours", with: "")
        print("🕐 Selected hours: '\(selectedHours)' -> Hours string: '\(hoursString)'")
        
        // Get current date and time for now (this would be updated with actual selection)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let currentDate = dateFormatter.string(from: Date())
        
        dateFormatter.dateFormat = "HH:mm:ss"
        let currentTime = dateFormatter.string(from: Date())
        
        // Extract passenger count from selectedPassenger
        let passengerCount = selectedPassenger == "For me" ? 1 : 2 // Default logic
        
        // Determine pickup and destination location strings
        // For Airport type, use selected airport or airport search field
        // For other types, use the location field
        let finalPickupLocation = selectedBookingType == "Airport" 
            ? (selectedPickupAirport.isEmpty ? pickupAirportSearch : selectedPickupAirport)
            : pickupLocation
        let finalDestinationLocation = selectedDestinationType == "Airport"
            ? (selectedDestinationAirport.isEmpty ? destinationAirportSearch : selectedDestinationAirport)
            : destinationLocation
        
        print("📍 Location selection:")
        print("   - Booking type: \(selectedBookingType), Pickup: '\(finalPickupLocation)'")
        print("   - Destination type: \(selectedDestinationType), Destination: '\(finalDestinationLocation)'")
        
        let request = VehicleSelectionView.RideData(
            serviceType: serviceType,
            bookingHour: hoursString,
            pickupType: pickupType,
            dropoffType: dropoffType,
            pickupDate: currentDate,
            pickupTime: currentTime,
            pickupLocation: finalPickupLocation,
            destinationLocation: finalDestinationLocation,
            selectedPickupAirport: selectedPickupAirport,
            selectedDestinationAirport: selectedDestinationAirport,
            noOfPassenger: passengerCount,
            noOfLuggage: 1, // Default value
            noOfVehicles: 1, // Default value
            pickupLat: pickupCoordinate?.latitude,
            pickupLong: pickupCoordinate?.longitude,
            destinationLat: destinationCoordinate?.latitude,
            destinationLong: destinationCoordinate?.longitude
        )
        
        print("🗺️ RIDE DATA COORDINATES:")
        print("Pickup Coordinate: \(pickupCoordinate?.latitude ?? 0), \(pickupCoordinate?.longitude ?? 0)")
        print("Destination Coordinate: \(destinationCoordinate?.latitude ?? 0), \(destinationCoordinate?.longitude ?? 0)")
        print("Final Request Pickup Lat: \(request.pickupLat ?? 0)")
        print("Final Request Pickup Long: \(request.pickupLong ?? 0)")
        print("Final Request Destination Lat: \(request.destinationLat ?? 0)")
        print("Final Request Destination Long: \(request.destinationLong ?? 0)")
        
        return request
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            ScrollView {
                VStack(spacing: 0) {
                    ScheduleRideHeader(dismiss: dismiss)
                    ScheduleRideContent(
                        selectedRideType: $selectedRideType,
                        selectedPassenger: $selectedPassenger,
                        pickupLocation: $pickupLocation,
                        destinationLocation: $destinationLocation,
                        pickupCountry: $pickupCountry,
                        destinationCountry: $destinationCountry,
                        showSwitchRiderSheet: $showSwitchRiderSheet,
                        showHoursDropdown: $showHoursDropdown,
                        selectedHours: $selectedHours,
                        hoursOptions: hoursOptions,
                        selectedBookingType: $selectedBookingType,
                        selectedDestinationType: $selectedDestinationType,
                        bookingTypeOptions: bookingTypeOptions,
                        selectedPickupAirport: $selectedPickupAirport,
                        selectedDestinationAirport: $selectedDestinationAirport,
                        pickupAirportSearch: $pickupAirportSearch,
                        destinationAirportSearch: $destinationAirportSearch,
                        airportService: airportService,
                        openDropdown: $openDropdown,
                        dropdownFrame: $dropdownFrame,
                        dropdownOptions: $dropdownOptions,
                        dropdownSelected: $dropdownSelected,
                        pickupAddressViewModel: pickupAddressViewModel,
                        destinationAddressViewModel: destinationAddressViewModel,
                        showPickupSuggestions: $showPickupSuggestions,
                        showDestinationSuggestions: $showDestinationSuggestions,
                        justSelectedPickup: $justSelectedPickup,
                        justSelectedDestination: $justSelectedDestination,
                        pickupCoordinate: $pickupCoordinate,
                        destinationCoordinate: $destinationCoordinate,
                        prepareAndShowTimeSelection: { prepareAndShowTimeSelection() },
                        refreshCurrentLocation: { refreshCurrentLocation() },
                        setCurrentLocationAsPickup: { setCurrentLocationAsPickup() },
                        isSettingCurrentLocation: $isSettingCurrentLocation,
                        isInitialLoad: $isInitialLoad,
                        shouldHideRecentAndSaved: shouldHideRecentAndSaved,
                        focusedField: $focusedField,
                        recentLocationService: recentLocationService,
                        showInvalidLocationDialog: $showInvalidLocationDialog,
                        invalidLocationMessage: invalidLocationMessage,
                        countryExtractor: { extractCountry(from: $0) },
                        path: $path,
                        isComingBackFromNavigation: $isComingBackFromNavigation,
                        previousFocusedField: $previousFocusedField,
                        showRecentLocationsOnReturn: $showRecentLocationsOnReturn
                    )
                }
                .offset(y: scrollOffset)
            }
            .background(Color.white)
            .cornerRadius(20, corners: [.topLeft, .topRight])
            .coordinateSpace(name: "dropdownArea")
            
            // Dropdown overlay at root level
            if openDropdown != nil {
                Color.black.opacity(0.001)
                    .ignoresSafeArea()
                    .onTapGesture {
                        openDropdown = nil
                    }
                    .zIndex(100)
                
                // Regular dropdown options
                if openDropdown == "hours" {
                    HoursDropdownMenu(
                        options: hoursOptions,
                        selectedHours: $selectedHours,
                        openDropdown: $openDropdown
                    )
                    .padding(.leading, 0)
                    .padding(.trailing, 0)
                    .frame(width: min(max(dropdownFrame.width - 8, 110), UIScreen.main.bounds.width - 30))
                    .position(
                        x: dropdownFrame.midX,
                        y: dropdownFrame.maxY + getDropdownPosition(for: openDropdown)
                    )
                    .zIndex(102)
                } else if let dropdownSelected = dropdownSelected,
                          openDropdown != "pickupAirport",
                          openDropdown != "destinationAirport" {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(dropdownOptions, id: \.self) { option in
                            Button(action: {
                                dropdownSelected.wrappedValue = option
                                openDropdown = nil
                            }) {
                                HStack {
                                    Text(option)
                                        .foregroundColor(.black)
                                        .padding(.vertical, 8)
                                        .padding(.horizontal, 12)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }
                                .padding(.trailing, 16)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(dropdownSelected.wrappedValue == option ? AppColors.primaryOrange.opacity(0.1) : Color.white)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.leading, 0)
                    .padding(.trailing, 0)
                    .frame(width: min(max(dropdownFrame.width - 8, 110), UIScreen.main.bounds.width - 30))
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(color: Color.black.opacity(0.12), radius: 12, x: 0, y: 4)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.gray.opacity(0.08), lineWidth: 0.5)
                    )
                    .position(
                        x: dropdownFrame.midX,
                        y: dropdownFrame.maxY + getDropdownPosition(for: openDropdown)
                    )
                    .zIndex(101)
                }
                
            }
            
        }
        .navigationBarBackButtonHidden(true)
        .fullScreenCover(isPresented: $showSwitchRiderSheet) {
            SwitchRiderBottomSheet(selectedPassenger: $selectedPassenger)
        }
        // Navigation is now handled via path, so we don't need fullScreenCover here
        .fullScreenCover(isPresented: $showCancellationPolicy) {
            WebViewScreen(
                url: URL(string: "https://1800limo.com/cancellation-policy")!,
                title: "Cancellation Policy"
            )
        }
        .onTapGesture {
            // Dismiss keyboard when tapping anywhere
            hideKeyboard()
            // Hide suggestions when tapping outside
            showPickupSuggestions = false
            showDestinationSuggestions = false
            // Clear focus when tapping outside
            focusedField = nil
        }
        .onChange(of: selectedPickupAirport) { newValue in
            if showInvalidLocationDialog && invalidLocationReason() == nil {
                showInvalidLocationDialog = false
            }
            // Sync the search field with the selected airport
            if !newValue.isEmpty && pickupAirportSearch != newValue {
                pickupAirportSearch = newValue
                print("🔄 SYNCED pickupAirportSearch to: \(newValue)")
            }
            
            // Only update pickup location if it's different and not empty
            if !newValue.isEmpty && pickupLocation != newValue {
                pickupLocation = newValue
            }
            
            if newValue.isEmpty {
                pickupCountry = nil
                pickupCoordinate = nil
            } else {
                pickupCountry = resolvePickupCountry()
                
                // Ensure coordinate is set for airport selection
                if let airport = airportService.airports.first(where: { 
                    $0.displayName == newValue || $0.fullDisplayName == newValue 
                }) {
                    pickupCoordinate = LocationCoordinate(
                        latitude: airport.lat ?? 0,
                        longitude: airport.long ?? 0
                    )
                    print("📍 PICKUP AIRPORT COORDINATE SET: \(airport.lat ?? 0), \(airport.long ?? 0)")
                }
            }
            
            // Auto-show time selection when both locations are selected
            // Add delay to ensure coordinates are set
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                prepareAndShowTimeSelection()
            }
        }
        .onChange(of: selectedDestinationAirport) { newValue in
            if showInvalidLocationDialog && invalidLocationReason() == nil {
                showInvalidLocationDialog = false
            }
            // Sync the search field with the selected airport
            if !newValue.isEmpty && destinationAirportSearch != newValue {
                destinationAirportSearch = newValue
                print("🔄 SYNCED destinationAirportSearch to: \(newValue)")
            }
            
            // Only update destination location if it's different and not empty
            if !newValue.isEmpty && destinationLocation != newValue {
                destinationLocation = newValue
            }
            
            if newValue.isEmpty {
                destinationCountry = nil
                destinationCoordinate = nil
            } else {
                destinationCountry = resolveDestinationCountry()
                
                // Ensure coordinate is set for airport selection
                if let airport = airportService.airports.first(where: { 
                    $0.displayName == newValue || $0.fullDisplayName == newValue 
                }) {
                    destinationCoordinate = LocationCoordinate(
                        latitude: airport.lat ?? 0,
                        longitude: airport.long ?? 0
                    )
                    print("📍 DESTINATION AIRPORT COORDINATE SET: \(airport.lat ?? 0), \(airport.long ?? 0)")
                }
            }
            
            // Auto-show time selection when both locations are selected
            // Add delay to ensure coordinates are set
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                prepareAndShowTimeSelection()
            }
        }
        .onChange(of: pickupLocation) { newValue in
            if showInvalidLocationDialog && invalidLocationReason() == nil {
                showInvalidLocationDialog = false
            }
            // Clear coordinate if location is cleared
            if newValue.isEmpty {
                pickupCoordinate = nil
                pickupCountry = nil
                return
            }
            
            // Navigate when location is set and coordinate exists
            // The shouldShowTimeSelection check will prevent navigation if user is typing
            if pickupCoordinate != nil {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    self.prepareAndShowTimeSelection()
                }
            }
        }
        .onChange(of: destinationLocation) { newValue in
            if showInvalidLocationDialog && invalidLocationReason() == nil {
                showInvalidLocationDialog = false
            }
            // Clear coordinate if location is cleared
            if newValue.isEmpty {
                destinationCoordinate = nil
                destinationCountry = nil
                return
            }
            
            // Navigate when location is set and coordinate exists
            // The shouldShowTimeSelection check will prevent navigation if user is typing
            if destinationCoordinate != nil {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    self.prepareAndShowTimeSelection()
                }
            }
        }
        .onChange(of: pickupCoordinate) { newValue in
            if showInvalidLocationDialog && invalidLocationReason() == nil {
                showInvalidLocationDialog = false
            }
            // Navigate when coordinate is set
            // The shouldShowTimeSelection check will prevent navigation if user is typing
            if let coordinate = newValue {
                pickupCountry = resolvePickupCountry(using: coordinate)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    self.prepareAndShowTimeSelection()
                }
            } else {
                pickupCountry = nil
            }
        }
        .onChange(of: destinationCoordinate) { newValue in
            if showInvalidLocationDialog && invalidLocationReason() == nil {
                showInvalidLocationDialog = false
            }
            // Navigate when coordinate is set
            // The shouldShowTimeSelection check will prevent navigation if user is typing
            if let coordinate = newValue {
                destinationCountry = resolveDestinationCountry(using: coordinate)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    self.prepareAndShowTimeSelection()
                }
            } else {
                destinationCountry = nil
            }
        }
        .onAppear {
            // Set initial load flag to prevent suggestions during setup
            isInitialLoad = true
            
            // Load all airports for validation purposes
            Task {
                if airportService.airports.isEmpty {
                    await airportService.fetchAllAirports()
                    print("✈️ Loaded \(airportService.airports.count) airports for validation")
                }
            }
            
            // Listen for map location selection
            NotificationCenter.default.addObserver(
                forName: NSNotification.Name("MapLocationSelected"),
                object: nil,
                queue: .main
            ) { notification in
                if let userInfo = notification.userInfo,
                   let locationType = userInfo["locationType"] as? String,
                   let address = userInfo["address"] as? String,
                   let coordinate = userInfo["coordinate"] as? LocationCoordinate {
                    // Handle map location selection
                    if locationType == "pickup" {
                        justSelectedPickup = true
                        if selectedBookingType == "Airport" {
                            selectedPickupAirport = address
                            pickupAirportSearch = address
                        } else {
                            pickupLocation = address
                        }
                        pickupCoordinate = coordinate
                        pickupCountry = extractCountry(from: address)
                        showPickupSuggestions = false
                        pickupAddressViewModel.suggestions = []
                        pickupAddressViewModel.isEditing = false
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            self.justSelectedPickup = false
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                self.focusedField = "destination"
                                self.showDestinationSuggestions = true
                                self.destinationAddressViewModel.isEditing = true
                            }
                        }
                    } else if locationType == "destination" {
                        justSelectedDestination = true
                        if selectedDestinationType == "Airport" {
                            selectedDestinationAirport = address
                            destinationAirportSearch = address
                        } else {
                            destinationLocation = address
                        }
                        destinationCoordinate = coordinate
                        destinationCountry = extractCountry(from: address)
                        showDestinationSuggestions = false
                        focusedField = nil
                        destinationAddressViewModel.suggestions = []
                        destinationAddressViewModel.isEditing = false
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            self.justSelectedDestination = false
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                self.prepareAndShowTimeSelection()
                            }
                        }
                    }
                }
            }
            
            // Set current location as pickup location if empty (first time)
            if pickupLocation.isEmpty && selectedBookingType != "Airport" {
                // Clear any existing suggestions immediately
                pickupAddressViewModel.suggestions = []
                pickupAddressViewModel.input = "" // Clear input to prevent suggestions
                pickupAddressViewModel.isEditing = false
                showPickupSuggestions = false
                showDestinationSuggestions = false
                
                // Force refresh current location immediately
                dashboardViewModel.refreshCurrentLocation()
                
                // Add a small delay to ensure location manager is ready
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    setCurrentLocationAsPickup()
                }
            } else {
                // If pickup location is already set, mark initial load as complete
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    self.isInitialLoad = false
                }
            }
            
            // Restore state when view appears (e.g., when navigating back)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                restoreState()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .dismissAllSheets)) { _ in
            print("🔚 ScheduleRideBottomSheet received dismiss notification")
            showTimeSelectionView = false
        }
        .onReceive(NotificationCenter.default.publisher(for: .forceDismissAllSheets)) { _ in
            print("🔚 ScheduleRideBottomSheet received force dismiss notification")
            // Dismiss this sheet and all child sheets
            showTimeSelectionView = false
            dismiss()
        }
    }
}

// MARK: - Header Component
struct ScheduleRideHeader: View {
    let dismiss: DismissAction
    
    var body: some View {
        VStack(spacing: 0) {
            // Drag Handle
            RoundedRectangle(cornerRadius: 2.5)
                .fill(Color.gray.opacity(0.3))
                .frame(width: 36, height: 5)
                .padding(.top, 8)
                .padding(.bottom, 16)
            
            // Header with back button and title
            HStack {
                Button(action: {
                    dismiss()
                }) {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Text("Schedule Ride")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
                
                Spacer()
                
                // Invisible spacer to center the title
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.clear)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 8)
            
            // Subtitle
            Text("Free Prearranged Quotes in Over 40 Countries.")
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(.gray)
                .padding(.horizontal, 24)
                .padding(.bottom, 20)
            
            // Divider after subtitle
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(height: 1)
                .padding(.horizontal, 24)
                .padding(.bottom, 20)
        }
    }
}

// MARK: - Main Content Component
struct ScheduleRideContent: View {
    @Binding var selectedRideType: ScheduleRideBottomSheet.RideType
    @Binding var selectedPassenger: String
    @Binding var pickupLocation: String
    @Binding var destinationLocation: String
    @Binding var pickupCountry: String?
    @Binding var destinationCountry: String?
    @Binding var showSwitchRiderSheet: Bool
    @Binding var showHoursDropdown: Bool
    @Binding var selectedHours: String
    let hoursOptions: [String]
    @Binding var selectedBookingType: String
    @Binding var selectedDestinationType: String
    let bookingTypeOptions: [String]
    @Binding var selectedPickupAirport: String
    @Binding var selectedDestinationAirport: String
    @Binding var pickupAirportSearch: String
    @Binding var destinationAirportSearch: String
    let airportService: AirportService
    @Binding var openDropdown: String?
    @Binding var dropdownFrame: CGRect
    @Binding var dropdownOptions: [String]
    @Binding var dropdownSelected: Binding<String?>?
    let pickupAddressViewModel: AddressAutocompleteViewModel
    let destinationAddressViewModel: AddressAutocompleteViewModel
    @Binding var showPickupSuggestions: Bool
    @Binding var showDestinationSuggestions: Bool
    @Binding var justSelectedPickup: Bool
    @Binding var justSelectedDestination: Bool
    @Binding var pickupCoordinate: LocationCoordinate?
    @Binding var destinationCoordinate: LocationCoordinate?
    let prepareAndShowTimeSelection: () -> Void
    let refreshCurrentLocation: () -> Void
    let setCurrentLocationAsPickup: () -> Void
    @Binding var isSettingCurrentLocation: Bool
    @Binding var isInitialLoad: Bool
    let shouldHideRecentAndSaved: Bool
    @Binding var focusedField: String?
    let recentLocationService: RecentLocationService
    @Binding var showInvalidLocationDialog: Bool
    let invalidLocationMessage: String
    let countryExtractor: (String) -> String?
    @Binding var path: [Screen]
    @Binding var isComingBackFromNavigation: Bool
    @Binding var previousFocusedField: String?
    @Binding var showRecentLocationsOnReturn: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            RideTypeSelection(selectedRideType: $selectedRideType)
            // PassengerSelection(selectedPassenger: $selectedPassenger, showSwitchRiderSheet: $showSwitchRiderSheet)
            HoursSelection(
                selectedRideType: selectedRideType,
                showHoursDropdown: $showHoursDropdown,
                selectedHours: $selectedHours,
                hoursOptions: hoursOptions,
                openDropdown: $openDropdown,
                dropdownFrame: $dropdownFrame,
                dropdownOptions: $dropdownOptions,
                dropdownSelected: $dropdownSelected
            )
            BookingTypeSelection(
                selectedBookingType: $selectedBookingType,
                selectedDestinationType: $selectedDestinationType,
                bookingTypeOptions: bookingTypeOptions,
                selectedPickupAirport: $selectedPickupAirport,
                selectedDestinationAirport: $selectedDestinationAirport,
                pickupLocation: $pickupLocation,
                destinationLocation: $destinationLocation,
                openDropdown: $openDropdown,
                dropdownFrame: $dropdownFrame,
                dropdownOptions: $dropdownOptions,
                dropdownSelected: $dropdownSelected,
                setCurrentLocationAsPickup: { setCurrentLocationAsPickup() },
                pickupAddressViewModel: pickupAddressViewModel,
                showPickupSuggestions: $showPickupSuggestions
            )
            LocationInputSection(
                pickupLocation: $pickupLocation,
                destinationLocation: $destinationLocation,
                selectedBookingType: selectedBookingType,
                selectedDestinationType: selectedDestinationType,
                selectedPickupAirport: $selectedPickupAirport,
                selectedDestinationAirport: $selectedDestinationAirport,
                pickupAirportSearch: $pickupAirportSearch,
                destinationAirportSearch: $destinationAirportSearch,
                airportService: airportService,
                pickupAddressViewModel: pickupAddressViewModel,
                destinationAddressViewModel: destinationAddressViewModel,
                showPickupSuggestions: $showPickupSuggestions,
                showDestinationSuggestions: $showDestinationSuggestions,
                justSelectedPickup: $justSelectedPickup,
                justSelectedDestination: $justSelectedDestination,
                pickupCoordinate: $pickupCoordinate,
                destinationCoordinate: $destinationCoordinate,
                pickupCountry: $pickupCountry,
                destinationCountry: $destinationCountry,
                prepareAndShowTimeSelection: { prepareAndShowTimeSelection() },
                refreshCurrentLocation: { refreshCurrentLocation() },
                isSettingCurrentLocation: $isSettingCurrentLocation,
                isInitialLoad: $isInitialLoad,
                focusedField: $focusedField,
                showInvalidLocationDialog: $showInvalidLocationDialog,
                invalidLocationMessage: invalidLocationMessage,
                isComingBackFromNavigation: $isComingBackFromNavigation,
                previousFocusedField: $previousFocusedField,
                recentLocationService: recentLocationService
            )
            LocationSuggestions(
                shouldHide: shouldHideRecentAndSaved,
                focusedField: $focusedField,
                selectedBookingType: $selectedBookingType,
                selectedDestinationType: $selectedDestinationType,
                pickupLocation: $pickupLocation,
                destinationLocation: $destinationLocation,
                selectedPickupAirport: $selectedPickupAirport,
                selectedDestinationAirport: $selectedDestinationAirport,
                pickupAirportSearch: $pickupAirportSearch,
                destinationAirportSearch: $destinationAirportSearch,
                pickupCoordinate: $pickupCoordinate,
                destinationCoordinate: $destinationCoordinate,
                pickupCountry: $pickupCountry,
                destinationCountry: $destinationCountry,
                justSelectedPickup: $justSelectedPickup,
                justSelectedDestination: $justSelectedDestination,
                showPickupSuggestions: $showPickupSuggestions,
                showDestinationSuggestions: $showDestinationSuggestions,
                airportService: airportService,
                pickupAddressViewModel: pickupAddressViewModel,
                destinationAddressViewModel: destinationAddressViewModel,
                prepareAndShowTimeSelection: { prepareAndShowTimeSelection() },
                recentLocationService: recentLocationService,
                isInitialLoad: isInitialLoad,
                isSettingCurrentLocation: isSettingCurrentLocation,
                countryExtractor: countryExtractor,
                path: $path,
                showRecentLocationsOnReturn: $showRecentLocationsOnReturn
            )
        }
    }
}

// MARK: - Ride Type Selection Component
struct RideTypeSelection: View {
    @Binding var selectedRideType: ScheduleRideBottomSheet.RideType
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                ForEach(ScheduleRideBottomSheet.RideType.allCases, id: \.self) { rideType in
                    Button(action: {
                        selectedRideType = rideType
                    }) {
                        Text(rideType.rawValue)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(selectedRideType == rideType ? .white : .black)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 4)
                            .frame(width: 105, height: 30)
                            .background(selectedRideType == rideType ? AppColors.primaryOrange : Color.white)
                            .cornerRadius(4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(selectedRideType == rideType ? Color.clear : Color.black, lineWidth: 1)
                            )
                    }
                }
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 16)
            
            // Divider after ride type selection
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(height: 1)
                .padding(.horizontal, 24)
                .padding(.bottom, 20)
        }
    }
}

// MARK: - Passenger Selection Component
struct PassengerSelection: View {
    @Binding var selectedPassenger: String
    @Binding var showSwitchRiderSheet: Bool
    
    var body: some View {
            HStack {
                Spacer()
                Button(action: {
                    showSwitchRiderSheet = true
                }) {
                    HStack(spacing: 4) {
                        Image(systemName: "person.fill")
                            .foregroundColor(.black)
                        Text(selectedPassenger)
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                         Image("arrowIcon")

                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                .background(Color.orange.opacity(0.1))
                    .cornerRadius(44)
                }
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 20)
    }
}

// MARK: - Booking Type Selection Component
struct BookingTypeSelection: View {
    @Binding var selectedBookingType: String
    @Binding var selectedDestinationType: String
    let bookingTypeOptions: [String]
    @Binding var selectedPickupAirport: String
    @Binding var selectedDestinationAirport: String
    @Binding var pickupLocation: String
    @Binding var destinationLocation: String
    @Binding var openDropdown: String?
    @Binding var dropdownFrame: CGRect
    @Binding var dropdownOptions: [String]
    @Binding var dropdownSelected: Binding<String?>?
    let setCurrentLocationAsPickup: () -> Void
    let pickupAddressViewModel: AddressAutocompleteViewModel
    @Binding var showPickupSuggestions: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                // City Add. FBO Dropdown
                Button(action: {
                    openDropdown = openDropdown == "bookingType" ? nil : "bookingType"
                    dropdownOptions = bookingTypeOptions
                    dropdownSelected = Binding(
                        get: { selectedBookingType },
                        set: { selectedBookingType = $0 ?? "" }
                    )
                }) {
                    HStack {
                        Text(selectedBookingType)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                        Spacer()
                        Image( "arrowIcon")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                            .rotationEffect(.degrees(openDropdown == "bookingType" ? 180 : 0))
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 4)
                    .frame(height: 30)
                    .background(Color.white)
                    .cornerRadius(4)
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                            .stroke(Color.black, lineWidth: 1)
                    )
                }
                .frame(maxWidth: .infinity)
                .background(
                    GeometryReader { geo in
                        Color.clear
                            .onChange(of: openDropdown) { open in
                                if open == "bookingType" {
                                    let frame = geo.frame(in: .named("dropdownArea"))
                                    dropdownFrame = frame
                                }
                            }
                    }
                )
                
                // Arrow
                Image(systemName: "arrow.right")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.black)
                
                // Airport Dropdown
                Button(action: {
                    openDropdown = openDropdown == "destinationType" ? nil : "destinationType"
                    dropdownOptions = bookingTypeOptions
                    dropdownSelected = Binding(
                        get: { selectedDestinationType },
                        set: { selectedDestinationType = $0 ?? "" }
                    )
                }) {
                    HStack {
                        Text(selectedDestinationType)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                        Spacer()
                        Image("arrowIcon")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                            .rotationEffect(.degrees(openDropdown == "destinationType" ? 180 : 0))
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 4)
                    .frame(height: 30)
                    .background(Color.white)
                    .cornerRadius(4)
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                            .stroke(Color.black, lineWidth: 1)
                    )
                }
                .frame(maxWidth: .infinity)
                .background(
                    GeometryReader { geo in
                        Color.clear
                            .onChange(of: openDropdown) { open in
                                if open == "destinationType" {
                                    let frame = geo.frame(in: .named("dropdownArea"))
                                    dropdownFrame = frame
                                }
                            }
                    }
                )
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 20)
        }
        .onChange(of: selectedBookingType) { newValue in
            // Only clear pickup airport if changing from Airport to something else
            // Don't clear destination airport - preserve it
            if newValue != "Airport" {
                selectedPickupAirport = ""
                pickupLocation = ""
                // Clear any existing suggestions when switching to City mode
                pickupAddressViewModel.suggestions = []
                pickupAddressViewModel.input = ""
                pickupAddressViewModel.isEditing = false
                showPickupSuggestions = false
                // Set current location when switching to City mode
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    setCurrentLocationAsPickup()
                }
            }
        }
        .onChange(of: selectedDestinationType) { newValue in
            // Only clear destination airport if changing from Airport to something else
            // Don't clear pickup airport - preserve it
            if newValue != "Airport" {
                selectedDestinationAirport = ""
                destinationLocation = ""
            }
        }
    }
}

// MARK: - Hours Selection Component
struct HoursSelection: View {
    let selectedRideType: ScheduleRideBottomSheet.RideType
    @Binding var showHoursDropdown: Bool
    @Binding var selectedHours: String
    let hoursOptions: [String]
    @Binding var openDropdown: String?
    @Binding var dropdownFrame: CGRect
    @Binding var dropdownOptions: [String]
    @Binding var dropdownSelected: Binding<String?>?
    
    var body: some View {
        Group {
            if selectedRideType == .hourly {
                VStack(alignment: .leading, spacing: 0) {
                    HStack(spacing: 8) {
                        Button(action: {
                            openDropdown = openDropdown == "hours" ? nil : "hours"
                            dropdownOptions = hoursOptions
                            dropdownSelected = Binding(
                                get: { selectedHours },
                                set: { selectedHours = $0 ?? "" }
                            )
                        }) {
                            HStack {
                                Text(selectedHours)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(.black)
                                Spacer()
                                Image("arrowIcon")
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                                    .rotationEffect(.degrees(openDropdown == "hours" ? 180 : 0))
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 4)
                            .frame(height: 30)
                            .background(Color.white)
                            .cornerRadius(4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 4)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        }
                        .frame(maxWidth: .infinity)
                        .background(
                            GeometryReader { geo in
                                Color.clear
                                    .onChange(of: openDropdown) { open in
                                        if open == "hours" {
                                            let frame = geo.frame(in: .named("dropdownArea"))
                                            dropdownFrame = frame
                                        }
                                    }
                            }
                        )
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 20)
                }
            }
        }
    }
}

struct HoursDropdownMenu: View {
    let options: [String]
    @Binding var selectedHours: String
    @Binding var openDropdown: String?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(options, id: \.self) { option in
                Button(action: {
                    selectedHours = option
                    openDropdown = nil
                }) {
                    HStack {
                        Text(option)
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                        Spacer()
                        if selectedHours == option {
                            Image(systemName: "checkmark")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(AppColors.primaryOrange)
                        }
                    }
                    .padding(.vertical, 10)
                    .padding(.horizontal, 16)
                    .background(selectedHours == option ? AppColors.primaryOrange.opacity(0.12) : Color.white)
                }
                .buttonStyle(PlainButtonStyle())
                
                if option != options.last {
                    Divider()
                        .padding(.leading, 16)
                }
            }
        }
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.12), radius: 12, x: 0, y: 4)
        )
    }
}

// MARK: - Location Input Section Component
struct LocationInputSection: View {
    @Binding var pickupLocation: String
    @Binding var destinationLocation: String
    let selectedBookingType: String
    let selectedDestinationType: String
    @Binding var selectedPickupAirport: String
    @Binding var selectedDestinationAirport: String
    @Binding var pickupAirportSearch: String
    @Binding var destinationAirportSearch: String
    let airportService: AirportService
    let pickupAddressViewModel: AddressAutocompleteViewModel
    let destinationAddressViewModel: AddressAutocompleteViewModel
    @Binding var showPickupSuggestions: Bool
    @Binding var showDestinationSuggestions: Bool
    @Binding var justSelectedPickup: Bool
    @Binding var justSelectedDestination: Bool
    @Binding var pickupCoordinate: LocationCoordinate?
    @Binding var destinationCoordinate: LocationCoordinate?
    @Binding var pickupCountry: String?
    @Binding var destinationCountry: String?
    let prepareAndShowTimeSelection: () -> Void
    let refreshCurrentLocation: () -> Void
    @Binding var isSettingCurrentLocation: Bool
    @Binding var isInitialLoad: Bool
    @Binding var focusedField: String?
    @Binding var showInvalidLocationDialog: Bool
    let invalidLocationMessage: String
    @Binding var isComingBackFromNavigation: Bool
    @Binding var previousFocusedField: String?
    let recentLocationService: RecentLocationService
    
    // FocusState for TextField focus
    enum Field {
        case pickup
        case destination
    }
    @FocusState private var focusedTextField: Field?
    

    
    var body: some View {
        VStack(spacing: 0) {
            // Full width pickup/dropoff container
            LocationInputFields(
                selectedBookingType: selectedBookingType,
                selectedDestinationType: selectedDestinationType,
                selectedPickupAirport: $selectedPickupAirport,
                selectedDestinationAirport: $selectedDestinationAirport,
                pickupLocation: $pickupLocation,
                destinationLocation: $destinationLocation,
                pickupAirportSearch: $pickupAirportSearch,
                destinationAirportSearch: $destinationAirportSearch,
                airportService: airportService,
                pickupAddressViewModel: pickupAddressViewModel,
                destinationAddressViewModel: destinationAddressViewModel,
                showPickupSuggestions: $showPickupSuggestions,
                showDestinationSuggestions: $showDestinationSuggestions,
                justSelectedPickup: $justSelectedPickup,
                justSelectedDestination: $justSelectedDestination,
                pickupCoordinate: $pickupCoordinate,
                destinationCoordinate: $destinationCoordinate,
                prepareAndShowTimeSelection: prepareAndShowTimeSelection,
                isSettingCurrentLocation: $isSettingCurrentLocation,
                isInitialLoad: $isInitialLoad,
                focusedField: $focusedField,
                focusedTextField: $focusedTextField,
                recentLocationService: recentLocationService
            )
            .padding(.top, 12)
            .padding(.bottom, 20)
            .onChange(of: focusedTextField) { newFocus in
                // When TextField focus changes, sync to focusedField and fetch recent locations
                if let focus = newFocus {
                    if focus == .pickup && focusedField != "pickup" {
                        focusedField = "pickup"
                        // Fetch pickup recent locations
                        Task {
                            await recentLocationService.fetchRecentLocations(type: "pickup")
                            print("📍 FETCHED PICKUP RECENT LOCATIONS ON FOCUS")
                        }
                    } else if focus == .destination && focusedField != "destination" {
                        focusedField = "destination"
                        // Fetch destination recent locations
                        Task {
                            await recentLocationService.fetchRecentLocations(type: "dropoff")
                            print("📍 FETCHED DESTINATION RECENT LOCATIONS ON FOCUS")
                        }
                    }
                } else {
                    // Focus lost
                    if focusedField != nil {
                        focusedField = nil
                    }
                }
            }
            .onChange(of: focusedField) { newValue in
                // Only sync FocusState with focusedField if not coming back from navigation
                // This prevents keyboard from showing when just showing recent locations
                if isComingBackFromNavigation {
                    // If coming back and user changes focus (indicates interaction), reset flag and allow focus
                    if previousFocusedField != newValue && newValue != nil {
                        isComingBackFromNavigation = false
                        // Now allow the focus to be set
                        if newValue == "destination" {
                            focusedTextField = .destination
                        } else if newValue == "pickup" {
                            focusedTextField = .pickup
                        }
                    }
                    // Update previous value
                    previousFocusedField = newValue
                    // If just setting to destination when coming back, don't set TextField focus
                    return
                }
                
                // Normal behavior: sync FocusState with focusedField
                if newValue == "destination" {
                    focusedTextField = .destination
                } else if newValue == "pickup" {
                    focusedTextField = .pickup
                } else {
                    focusedTextField = nil
                }
                
                // Update previous value
                previousFocusedField = newValue
            }
            
            if showInvalidLocationDialog {
                LocationErrorBannerView(message: invalidLocationMessage)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 12)
            }
            
            // Show suggestions in full width below the input fields
            if showPickupSuggestions && !isSettingCurrentLocation {
                if selectedBookingType == "Airport" {
                    AirportSuggestionsDropdown(
                        airportService: airportService,
                        selectedAirport: $selectedPickupAirport,
                        airportSearch: $pickupAirportSearch,
                        justSelectedPickup: Binding<Bool?>(
                            get: { justSelectedPickup },
                            set: { justSelectedPickup = $0 ?? false }
                        ),
                        justSelectedDestination: .constant(nil),
                        showPickupSuggestions: Binding<Bool?>(
                            get: { showPickupSuggestions },
                            set: { showPickupSuggestions = $0 ?? false }
                        ),
                        showDestinationSuggestions: Binding<Bool?>(
                            get: { showDestinationSuggestions },
                            set: { showDestinationSuggestions = $0 ?? false }
                        ),
                        pickupCoordinate: $pickupCoordinate,
                        destinationCoordinate: .constant(nil),
                        prepareAndShowTimeSelection: { prepareAndShowTimeSelection() },
                        focusedField: $focusedField,
                        destinationAddressViewModel: destinationAddressViewModel
                    )
                } else {
                    PickupSuggestionsDropdown(
                        pickupAddressViewModel: pickupAddressViewModel,
                        pickupLocation: $pickupLocation,
                        justSelectedPickup: $justSelectedPickup,
                        showPickupSuggestions: $showPickupSuggestions,
                        pickupCoordinate: $pickupCoordinate,
                        prepareAndShowTimeSelection: prepareAndShowTimeSelection,
                        focusedField: $focusedField,
                        showDestinationSuggestions: $showDestinationSuggestions,
                        destinationAddressViewModel: destinationAddressViewModel,
                        recentLocationService: RecentLocationService.shared
                    )
                }
            }
            
            if showDestinationSuggestions {
                if selectedDestinationType == "Airport" {
                    AirportSuggestionsDropdown(
                        airportService: airportService,
                        selectedAirport: $selectedDestinationAirport,
                        airportSearch: $destinationAirportSearch,
                        justSelectedPickup: .constant(nil),
                        justSelectedDestination: Binding<Bool?>(
                            get: { justSelectedDestination },
                            set: { justSelectedDestination = $0 ?? false }
                        ),
                        showPickupSuggestions: .constant(nil),
                        showDestinationSuggestions: Binding<Bool?>(
                            get: { showDestinationSuggestions },
                            set: { showDestinationSuggestions = $0 ?? false }
                        ),
                        pickupCoordinate: .constant(nil),
                        destinationCoordinate: $destinationCoordinate,
                        prepareAndShowTimeSelection: { prepareAndShowTimeSelection() },
                        focusedField: $focusedField,
                        destinationAddressViewModel: destinationAddressViewModel
                    )
                } else {
                    DestinationSuggestionsDropdown(
                        destinationAddressViewModel: destinationAddressViewModel,
                        destinationLocation: $destinationLocation,
                        justSelectedDestination: $justSelectedDestination,
                        showDestinationSuggestions: $showDestinationSuggestions,
                        destinationCoordinate: $destinationCoordinate,
                        prepareAndShowTimeSelection: prepareAndShowTimeSelection
                    )
                }
            }
            
            // Only show dividers when there are actual suggestions to display
            let hasPickupSuggestions = showPickupSuggestions && (
                (selectedBookingType == "Airport" && !airportService.suggestions.isEmpty) ||
                (!pickupAddressViewModel.suggestions.isEmpty)
            )
            let hasDestinationSuggestions = showDestinationSuggestions && (
                (selectedDestinationType == "Airport" && !airportService.suggestions.isEmpty) ||
                (!destinationAddressViewModel.suggestions.isEmpty)
            )
            
            // Helper to check if locations are the same
            let locationsAreSame: Bool = {
                // Check if location text matches
                let pickupText = selectedBookingType == "Airport" ? selectedPickupAirport : pickupLocation
                let destinationText = selectedDestinationType == "Airport" ? selectedDestinationAirport : destinationLocation
                
                // Check if text matches
                if !pickupText.isEmpty && !destinationText.isEmpty && pickupText == destinationText {
                    return true
                }
                
                // Check if coordinates match (within a small tolerance)
                if let pickupCoord = pickupCoordinate, let destCoord = destinationCoordinate {
                    let latDiff = abs(pickupCoord.latitude - destCoord.latitude)
                    let longDiff = abs(pickupCoord.longitude - destCoord.longitude)
                    // Locations are considered same if coordinates are within 0.0001 degrees (~11 meters)
                    if latDiff < 0.0001 && longDiff < 0.0001 {
                        return true
                    }
                }
                
                return false
            }()
            
            // Show Next button when both locations are filled and no suggestions are showing
            let bothLocationsFilled = (!pickupLocation.isEmpty || !selectedPickupAirport.isEmpty) && 
                                     (!destinationLocation.isEmpty || !selectedDestinationAirport.isEmpty)
            let noSuggestionsShowing = !showPickupSuggestions && !showDestinationSuggestions
            let hasValidCoordinates = pickupCoordinate != nil && destinationCoordinate != nil &&
                                     pickupCoordinate?.latitude != 0 && pickupCoordinate?.longitude != 0 &&
                                     destinationCoordinate?.latitude != 0 && destinationCoordinate?.longitude != 0
            
            // Only show Next button if locations are different
            if bothLocationsFilled && noSuggestionsShowing && hasValidCoordinates && !locationsAreSame {
                HStack {
                    Spacer()
                    Button(action: {
                        prepareAndShowTimeSelection()
                    }) {
                        Text("Next")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundColor(.black)
                    }
                }
                .padding(.bottom, 8)
                .padding(.horizontal, 24)
                .transition(.opacity)
                .animation(.easeInOut(duration: 0.2), value: bothLocationsFilled && noSuggestionsShowing && hasValidCoordinates)
            }
            
            // Removed divider lines for cleaner UI
        }
    }
}

// MARK: - Location Input Fields Component
struct LocationInputFields: View {
    let selectedBookingType: String
    let selectedDestinationType: String
    @Binding var selectedPickupAirport: String
    @Binding var selectedDestinationAirport: String
    @Binding var pickupLocation: String
    @Binding var destinationLocation: String
    @Binding var pickupAirportSearch: String
    @Binding var destinationAirportSearch: String
    let airportService: AirportService
    let pickupAddressViewModel: AddressAutocompleteViewModel
    let destinationAddressViewModel: AddressAutocompleteViewModel
    @Binding var showPickupSuggestions: Bool
    @Binding var showDestinationSuggestions: Bool
    @Binding var justSelectedPickup: Bool
    @Binding var justSelectedDestination: Bool
    @Binding var pickupCoordinate: LocationCoordinate?
    @Binding var destinationCoordinate: LocationCoordinate?
    let prepareAndShowTimeSelection: () -> Void
    @Binding var isSettingCurrentLocation: Bool
    @Binding var isInitialLoad: Bool
    @Binding var focusedField: String?
    @FocusState.Binding var focusedTextField: LocationInputSection.Field?
    let recentLocationService: RecentLocationService
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 16) {
                VStack(spacing: 0) {
                    Circle()
                        .fill(AppColors.primaryOrange)
                        .frame(width: 12, height: 12)
                        .overlay(
                            Circle()
                                .fill(.white)
                                .frame(width: 6, height: 6)
                        )
                    
                    Rectangle()
                        .fill(Color.black)
                        .frame(width: 2, height: 40)
                    
                    RoundedRectangle(cornerRadius: 2)
                        .stroke(AppColors.primaryOrange, lineWidth: 2)
                        .frame(width: 12, height: 12)
                }
                
                VStack(spacing: 0) {
                    // Pickup input
                    PickupInputField(
                        selectedBookingType: selectedBookingType,
                        selectedPickupAirport: $selectedPickupAirport,
                        pickupLocation: $pickupLocation,
                        pickupAirportSearch: $pickupAirportSearch,
                        airportService: airportService,
                        pickupAddressViewModel: pickupAddressViewModel,
                        showPickupSuggestions: $showPickupSuggestions,
                        justSelectedPickup: $justSelectedPickup,
                        pickupCoordinate: $pickupCoordinate,
                        prepareAndShowTimeSelection: { prepareAndShowTimeSelection() },
                        isSettingCurrentLocation: $isSettingCurrentLocation,
                        isInitialLoad: $isInitialLoad,
                        showDestinationSuggestions: $showDestinationSuggestions,
                        destinationAddressViewModel: destinationAddressViewModel,
                        focusedField: $focusedField,
                        focusedTextField: $focusedTextField,
                        recentLocationService: recentLocationService
                    )
                    
                    Rectangle()
                        .fill(Color.gray.opacity(0.3))
                        .frame(height: 1)
                    
                    // Destination input
                    DestinationInputField(
                        selectedDestinationType: selectedDestinationType,
                        selectedDestinationAirport: $selectedDestinationAirport,
                        destinationLocation: $destinationLocation,
                        destinationAirportSearch: $destinationAirportSearch,
                        airportService: airportService,
                        destinationAddressViewModel: destinationAddressViewModel,
                        showDestinationSuggestions: $showDestinationSuggestions,
                        justSelectedDestination: $justSelectedDestination,
                        destinationCoordinate: $destinationCoordinate,
                        prepareAndShowTimeSelection: { prepareAndShowTimeSelection() },
                        showPickupSuggestions: $showPickupSuggestions,
                        pickupAddressViewModel: pickupAddressViewModel,
                        focusedField: $focusedField,
                        focusedTextField: $focusedTextField,
                        recentLocationService: recentLocationService
                    )
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 20)
            .frame(height: 90)
            .background(Color.white)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.black, lineWidth: 1)
            )
            .padding(.horizontal, 24)
            
        }
    }
}

// MARK: - Pickup Input Field Component
struct PickupInputField: View {
    let selectedBookingType: String
    @Binding var selectedPickupAirport: String
    @Binding var pickupLocation: String
    @Binding var pickupAirportSearch: String
    let airportService: AirportService
    let pickupAddressViewModel: AddressAutocompleteViewModel
    @Binding var showPickupSuggestions: Bool
    @Binding var justSelectedPickup: Bool
    @Binding var pickupCoordinate: LocationCoordinate?
    let prepareAndShowTimeSelection: () -> Void
    @Binding var isSettingCurrentLocation: Bool
    @Binding var isInitialLoad: Bool
    // Destination-related parameters for clearing suggestions
    @Binding var showDestinationSuggestions: Bool
    let destinationAddressViewModel: AddressAutocompleteViewModel
    // Focus tracking
    @Binding var focusedField: String?
    @FocusState.Binding var focusedTextField: LocationInputSection.Field?
    // Recent locations service
    let recentLocationService: RecentLocationService
    
    var body: some View {
        if selectedBookingType == "Airport" {
            // Airport input field with inline suggestions and clear button
            HStack {
                TextField("Search airports...", text: $pickupAirportSearch)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.black)
                    .focused($focusedTextField, equals: LocationInputSection.Field.pickup)
                
                if !pickupAirportSearch.isEmpty {
                    Button(action: {
                        pickupAirportSearch = ""
                        selectedPickupAirport = ""
                        pickupCoordinate = nil
                        airportService.clearSuggestions()
                        showPickupSuggestions = false
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding(.vertical, 12)
            .background(Color.clear)
                .onTapGesture {
                    if !isSettingCurrentLocation {
                        print("🎯 PICKUP FIELD TAPPED (airport)")
                        // Set TextField focus - this will trigger onChange handler
                        focusedTextField = .pickup
                        // Also set focusedField for immediate update
                        focusedField = "pickup"
                        print("🎯 FOCUS SET TO: pickup")
                        
                        // Clear destination suggestions when focusing on pickup
                        showDestinationSuggestions = false
                        destinationAddressViewModel.suggestions = []
                        airportService.clearSuggestions()
                        
                        // Don't show pickup suggestions on tap - only show recent locations
                        // Suggestions will show when user starts typing
                        showPickupSuggestions = false
                        isInitialLoad = false
                        justSelectedPickup = false
                        
                        // Fetch recent locations immediately on tap
                        Task {
                            await recentLocationService.fetchRecentLocations(type: "pickup")
                            print("📍 FETCHED PICKUP RECENT LOCATIONS ON TAP")
                        }
                        
                        // Only search airports if there's already text in the field
                        if !pickupAirportSearch.isEmpty && pickupAirportSearch.count >= 2 {
                            showPickupSuggestions = true
                            airportService.searchAirports(query: pickupAirportSearch)
                        }
                    }
                }
                .onChange(of: pickupAirportSearch) { newValue in
                    if !justSelectedPickup && !isSettingCurrentLocation {
                        // Set focus to pickup field
                        focusedField = "pickup"
                        
                        // Clear destination suggestions when typing in pickup
                        showDestinationSuggestions = false
                        destinationAddressViewModel.suggestions = []
                        airportService.clearSuggestions()
                        
                        if isInitialLoad {
                            isInitialLoad = false
                        }
                        
                        // Always show suggestions when field has focus
                        showPickupSuggestions = true
                        
                        if !newValue.isEmpty && newValue.count >= 2 {
                            airportService.searchAirports(query: newValue)
                        } else {
                            // Keep suggestions visible even when empty if field has focus
                            if focusedField == "pickup" {
                                airportService.suggestions = []
                            }
                        }
                    } else {
                        justSelectedPickup = false
                    }
                }
        } else {
            // Regular pickup field with clear button
            HStack {
                TextField("Pickup location", text: $pickupLocation)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.black)
                    .focused($focusedTextField, equals: LocationInputSection.Field.pickup)
                
                if !pickupLocation.isEmpty {
                    Button(action: {
                        pickupLocation = ""
                        pickupCoordinate = nil
                        pickupAddressViewModel.suggestions = []
                        showPickupSuggestions = false
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding(.vertical, 12)
            .background(Color.clear)
                .onTapGesture {
                    if !isSettingCurrentLocation {
                        print("🎯 PICKUP FIELD TAPPED (regular)")
                        // Set TextField focus - this will trigger onChange handler
                        focusedTextField = .pickup
                        // Also set focusedField for immediate update
                        focusedField = "pickup"
                        print("🎯 FOCUS SET TO: pickup")
                        
                        // Clear destination suggestions when focusing on pickup
                        showDestinationSuggestions = false
                        destinationAddressViewModel.suggestions = []
                        airportService.clearSuggestions()
                        
                        // Don't show pickup suggestions on tap - only show recent locations
                        // Suggestions will show when user starts typing
                        showPickupSuggestions = false
                        isInitialLoad = false
                        pickupAddressViewModel.isEditing = true
                        pickupAddressViewModel.input = pickupLocation
                        justSelectedPickup = false
                        
                        // Fetch recent locations immediately on tap
                        Task {
                            await recentLocationService.fetchRecentLocations(type: "pickup")
                            print("📍 FETCHED PICKUP RECENT LOCATIONS ON TAP")
                        }
                    }
                }
                .onChange(of: pickupLocation) { newValue in
                    if !justSelectedPickup && !isSettingCurrentLocation {
                        // Set focus to pickup field
                        focusedField = "pickup"
                        
                        // Clear destination suggestions when typing in pickup
                        showDestinationSuggestions = false
                        destinationAddressViewModel.suggestions = []
                        airportService.clearSuggestions()
                        
                        if isInitialLoad {
                            isInitialLoad = false
                        }
                        
                        // Always show suggestions when field has focus
                        pickupAddressViewModel.input = newValue
                        pickupAddressViewModel.isEditing = true
                        showPickupSuggestions = true
                    } else {
                        justSelectedPickup = false
                    }
                }
        }
    }
}

// MARK: - Destination Input Field Component
struct DestinationInputField: View {
    let selectedDestinationType: String
    @Binding var selectedDestinationAirport: String
    @Binding var destinationLocation: String
    @Binding var destinationAirportSearch: String
    let airportService: AirportService
    let destinationAddressViewModel: AddressAutocompleteViewModel
    @Binding var showDestinationSuggestions: Bool
    @Binding var justSelectedDestination: Bool
    @Binding var destinationCoordinate: LocationCoordinate?
    let prepareAndShowTimeSelection: () -> Void
    // Pickup-related parameters for clearing suggestions
    @Binding var showPickupSuggestions: Bool
    let pickupAddressViewModel: AddressAutocompleteViewModel
    // Focus tracking
    @Binding var focusedField: String?
    @FocusState.Binding var focusedTextField: LocationInputSection.Field?
    // Recent locations service
    let recentLocationService: RecentLocationService
    
    var body: some View {
        if selectedDestinationType == "Airport" {
            // Airport input field with inline suggestions and clear button
            HStack {
                TextField("Search airports...", text: $destinationAirportSearch)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.black)
                    .focused($focusedTextField, equals: LocationInputSection.Field.destination)
                    .focused($focusedTextField, equals: LocationInputSection.Field.destination)
                
                if !destinationAirportSearch.isEmpty {
                    Button(action: {
                        destinationAirportSearch = ""
                        selectedDestinationAirport = ""
                        destinationCoordinate = nil
                        airportService.clearSuggestions()
                        showDestinationSuggestions = false
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding(.vertical, 12)
            .background(Color.clear)
                .onTapGesture {
                    print("🎯 DESTINATION FIELD TAPPED (airport)")
                    // Set TextField focus - this will trigger onChange handler
                    focusedTextField = .destination
                    // Also set focusedField for immediate update
                    focusedField = "destination"
                    print("🎯 FOCUS SET TO: destination")
                    
                    // Clear pickup suggestions when focusing on destination
                    showPickupSuggestions = false
                    pickupAddressViewModel.suggestions = []
                    airportService.clearSuggestions()
                    
                    // Don't show destination suggestions on tap - only show recent locations
                    // Suggestions will show when user starts typing
                    showDestinationSuggestions = false
                    justSelectedDestination = false
                    
                    // Fetch recent locations immediately on tap
                    Task {
                        await recentLocationService.fetchRecentLocations(type: "dropoff")
                        print("📍 FETCHED DESTINATION RECENT LOCATIONS ON TAP")
                    }
                    
                    // Only search airports if there's already text in the field
                    if !destinationAirportSearch.isEmpty && destinationAirportSearch.count >= 2 {
                        showDestinationSuggestions = true
                        airportService.searchAirports(query: destinationAirportSearch)
                    }
                }
                .onChange(of: destinationAirportSearch) { newValue in
                    if !justSelectedDestination {
                        // Set focus to destination field
                        focusedField = "destination"
                        
                        // Clear pickup suggestions when typing in destination
                        showPickupSuggestions = false
                        pickupAddressViewModel.suggestions = []
                        airportService.clearSuggestions()
                        
                        // Always show suggestions when field has focus
                        showDestinationSuggestions = true
                        
                        if !newValue.isEmpty && newValue.count >= 2 {
                            airportService.searchAirports(query: newValue)
                        } else {
                            // Keep suggestions visible even when empty if field has focus
                            if focusedField == "destination" {
                                airportService.suggestions = []
                            }
                        }
                    } else {
                        justSelectedDestination = false
                    }
                }
        } else {
            // Regular destination field with clear button
            HStack {
                TextField("Where to?", text: $destinationLocation)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.black)
                    .focused($focusedTextField, equals: LocationInputSection.Field.destination)
                
                if !destinationLocation.isEmpty {
                    Button(action: {
                        destinationLocation = ""
                        destinationCoordinate = nil
                        destinationAddressViewModel.suggestions = []
                        showDestinationSuggestions = false
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding(.vertical, 12)
            .background(Color.clear)
                .onTapGesture {
                    print("🎯 DESTINATION FIELD TAPPED (regular)")
                    // Set TextField focus - this will trigger onChange handler
                    focusedTextField = .destination
                    // Also set focusedField for immediate update
                    focusedField = "destination"
                    print("🎯 FOCUS SET TO: destination")
                    
                    // Clear pickup suggestions when focusing on destination
                    showPickupSuggestions = false
                    pickupAddressViewModel.suggestions = []
                    airportService.clearSuggestions()
                    
                    // Don't show destination suggestions on tap - only show recent locations
                    // Suggestions will show when user starts typing
                    showDestinationSuggestions = false
                    destinationAddressViewModel.isEditing = true
                    destinationAddressViewModel.input = destinationLocation
                    justSelectedDestination = false
                    
                    // Fetch recent locations immediately on tap
                    Task {
                        await recentLocationService.fetchRecentLocations(type: "dropoff")
                        print("📍 FETCHED DESTINATION RECENT LOCATIONS ON TAP")
                    }
                }
                .onChange(of: destinationLocation) { newValue in
                    if !justSelectedDestination {
                        // Set focus to destination field
                        focusedField = "destination"
                        
                        // Clear pickup suggestions when typing in destination
                        showPickupSuggestions = false
                        pickupAddressViewModel.suggestions = []
                        airportService.clearSuggestions()
                        
                        destinationAddressViewModel.input = newValue
                        destinationAddressViewModel.isEditing = true
                        showDestinationSuggestions = true
                    } else {
                        justSelectedDestination = false
                    }
                }
        }
    }
}


// MARK: - Pickup Suggestions Dropdown Component
struct PickupSuggestionsDropdown: View {
    let pickupAddressViewModel: AddressAutocompleteViewModel
    @Binding var pickupLocation: String
    @Binding var justSelectedPickup: Bool
    @Binding var showPickupSuggestions: Bool
    @Binding var pickupCoordinate: LocationCoordinate?
    let prepareAndShowTimeSelection: () -> Void
    @Binding var focusedField: String?
    @Binding var showDestinationSuggestions: Bool
    let destinationAddressViewModel: AddressAutocompleteViewModel
    let recentLocationService: RecentLocationService
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Show loading indicator when fetching suggestions
            if pickupAddressViewModel.isLoading {
                HStack {
                    ProgressView()
                        .scaleEffect(0.8)
                    Text("Searching locations...")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .transition(.opacity)
            } else if pickupAddressViewModel.suggestions.isEmpty && !pickupLocation.isEmpty {
                // No results state
                HStack {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Text("No locations found")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .transition(.opacity)
            } else {
                ForEach(Array(pickupAddressViewModel.suggestions.enumerated()), id: \.element) { index, suggestion in
                Button(action: {
                    pickupLocation = suggestion
                    pickupAddressViewModel.selectSuggestion(suggestion)
                    justSelectedPickup = true
                    showPickupSuggestions = false
                    
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        // Set pickup coordinate with validation
                        if let coordinate = pickupAddressViewModel.selectedCoordinate {
                            pickupCoordinate = coordinate
                            print("📍 PICKUP COORDINATE SET FROM SUGGESTION: \(coordinate.latitude), \(coordinate.longitude)")
                        } else {
                            print("❌ WARNING: No coordinate available from pickupAddressViewModel")
                            // Try to get coordinate from the suggestion text using geocoding
                            // For now, we'll set a default coordinate or show an error
                        }
                        
                        // Reset selection flag
                        justSelectedPickup = false
                        
                        // Auto-focus on destination field and show dropoff recent locations
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                            focusedField = "destination"
                            showDestinationSuggestions = true
                            destinationAddressViewModel.isEditing = true
                            print("🎯 AUTO-FOCUSED ON DESTINATION FIELD AFTER PICKUP SELECTION FROM SUGGESTIONS")
                            
                            // Fetch dropoff recent locations
                            Task {
                                await recentLocationService.fetchRecentLocations(type: "dropoff")
                                print("📍 FETCHED DROPOFF RECENT LOCATIONS")
                            }
                        }
                    }
                }) {
                    HStack(spacing: 16) {
                        // Location details
                        VStack(alignment: .leading, spacing: 2) {
                            Text(suggestion)
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                                .lineLimit(1)
                            
                            Text(suggestion) // Using same text for subtitle, in real app this would be formatted address
                                .font(.system(size: 14, weight: .regular))
                                .foregroundColor(.gray)
                                .lineLimit(1)
                        }
                        
                        Spacer()
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .background(Color.white)
                }
                .buttonStyle(PlainButtonStyle())
                
                if index < pickupAddressViewModel.suggestions.count - 1 {
                    Divider()
                        .padding(.leading, 24) // Align with text content
                }
            }
            }
        }
        .background(Color.white)
        .frame(maxWidth: .infinity)
        .padding(.top, 8)
    }
}

// MARK: - Destination Suggestions Dropdown Component
struct DestinationSuggestionsDropdown: View {
    let destinationAddressViewModel: AddressAutocompleteViewModel
    @Binding var destinationLocation: String
    @Binding var justSelectedDestination: Bool
    @Binding var showDestinationSuggestions: Bool
    @Binding var destinationCoordinate: LocationCoordinate?
    let prepareAndShowTimeSelection: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Show loading indicator when fetching suggestions
            if destinationAddressViewModel.isLoading {
                HStack {
                    ProgressView()
                        .scaleEffect(0.8)
                    Text("Searching locations...")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .transition(.opacity)
            } else if destinationAddressViewModel.suggestions.isEmpty && !destinationLocation.isEmpty {
                // No results state
                HStack {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Text("No locations found")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .transition(.opacity)
            } else {
                ForEach(Array(destinationAddressViewModel.suggestions.enumerated()), id: \.element) { index, suggestion in
                Button(action: {
                    destinationLocation = suggestion
                    destinationAddressViewModel.selectSuggestion(suggestion)
                    justSelectedDestination = true
                    showDestinationSuggestions = false
                    
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        destinationCoordinate = destinationAddressViewModel.selectedCoordinate
                        prepareAndShowTimeSelection()
                    }
                }) {
                    HStack(spacing: 16) {
                        // Location details
                        VStack(alignment: .leading, spacing: 2) {
                            Text(suggestion)
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                                .lineLimit(1)
                            
                            Text(suggestion) // Using same text for subtitle, in real app this would be formatted address
                                .font(.system(size: 14, weight: .regular))
                                .foregroundColor(.gray)
                                .lineLimit(1)
                        }
                        
                        Spacer()
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .background(Color.white)
                }
                .buttonStyle(PlainButtonStyle())
                
                if index < destinationAddressViewModel.suggestions.count - 1 {
                    Divider()
                        .padding(.leading, 24) // Align with text content
                }
            }
            }
        }
        .background(Color.white)
        .frame(maxWidth: .infinity)
        .padding(.top, 8)
    }
}

// MARK: - Airport Suggestions Dropdown Component
struct AirportSuggestionsDropdown: View {
    let airportService: AirportService
    @Binding var selectedAirport: String
    @Binding var airportSearch: String
    @Binding var justSelectedPickup: Bool?
    @Binding var justSelectedDestination: Bool?
    @Binding var showPickupSuggestions: Bool?
    @Binding var showDestinationSuggestions: Bool?
    @Binding var pickupCoordinate: LocationCoordinate?
    @Binding var destinationCoordinate: LocationCoordinate?
    let prepareAndShowTimeSelection: () -> Void
    @Binding var focusedField: String?
    let destinationAddressViewModel: AddressAutocompleteViewModel?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Show loading state when searching OR when pending (debouncing)
            if (airportService.isLoading || airportService.isSearchPending) && airportSearch.count >= 2 {
                HStack {
                    ProgressView()
                        .scaleEffect(0.8)
                    Text("Searching airports...")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .background(Color.white)
            } else if airportService.suggestions.isEmpty && !airportSearch.isEmpty && airportSearch.count >= 2 && !airportService.isLoading && !airportService.isSearchPending {
                // No results state - only show after search is complete AND not pending
                HStack {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Text("No airports found")
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.vertical, 16)
                .background(Color.white)
            } else if !airportService.suggestions.isEmpty {
                // Show suggestions
                ForEach(Array(airportService.suggestions.enumerated()), id: \.element) { index, suggestion in
                Button(action: {
                    print("✈️ AIRPORT SELECTED: \(suggestion)")
                    
                    // Set the appropriate selection flag FIRST to prevent onChange interference
                    let isPickupSelection = justSelectedPickup != nil
                    let isDestinationSelection = justSelectedDestination != nil
                    
                    if isPickupSelection {
                        justSelectedPickup = true
                        showPickupSuggestions = false
                    } else if isDestinationSelection {
                        justSelectedDestination = true
                        showDestinationSuggestions = false
                        focusedField = nil // Clear focus after selection
                    }
                    
                    // Get the selected airport data and set coordinates
                    if let selectedAirportData = airportService.selectAirportSuggestion(suggestion) {
                        print("🔍 SELECTED AIRPORT DATA: \(selectedAirportData.code) - \(selectedAirportData.name)")
                        print("🔍 RAW COORDINATES: lat=\(selectedAirportData.lat ?? -999), long=\(selectedAirportData.long ?? -999)")
                        
                        let coordinate = LocationCoordinate(
                            latitude: selectedAirportData.lat ?? 0,
                            longitude: selectedAirportData.long ?? 0
                        )
                        
                        // Validate that we have real coordinates (not 0,0)
                        if coordinate.latitude == 0 && coordinate.longitude == 0 {
                            print("⚠️ WARNING: Airport \(suggestion) has invalid coordinates (0,0)")
                        }
                        
                        // Determine if this is pickup or destination based on which binding is not nil
                        if isPickupSelection {
                            pickupCoordinate = coordinate
                            print("📍 PICKUP AIRPORT COORDINATE STORED: \(coordinate.latitude), \(coordinate.longitude)")
                        } else if isDestinationSelection {
                            destinationCoordinate = coordinate
                            print("📍 DESTINATION AIRPORT COORDINATE STORED: \(coordinate.latitude), \(coordinate.longitude)")
                        }
                    } else {
                        print("❌ NO AIRPORT DATA FOUND FOR SUGGESTION: \(suggestion)")
                    }
                    
                    // Now update the UI fields AFTER setting the flag and coordinates
                    selectedAirport = suggestion
                    airportSearch = suggestion
                    print("✅ AIRPORT FIELDS UPDATED: selectedAirport=\(suggestion), airportSearch=\(suggestion)")
                    
                    // Clear airport suggestions immediately after selection
                    airportService.clearSuggestions()
                    print("🧹 CLEARED AIRPORT SUGGESTIONS")
                    
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    
                    if isPickupSelection {
                        // Auto-focus on destination field after pickup selection
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                            justSelectedPickup = false
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                focusedField = "destination"
                                showDestinationSuggestions = true
                                destinationAddressViewModel?.isEditing = true
                                print("🎯 AUTO-FOCUSED ON DESTINATION FIELD AFTER PICKUP AIRPORT SELECTION")
                                
                                // Fetch dropoff recent locations
                                Task {
                                    await RecentLocationService.shared.fetchRecentLocations(type: "dropoff")
                                    print("📍 FETCHED DROPOFF RECENT LOCATIONS")
                                }
                            }
                        }
                    } else {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            prepareAndShowTimeSelection()
                        }
                    }
                }) {
                    HStack(spacing: 16) {
                       
                        
                        // Airport details
                        VStack(alignment: .leading, spacing: 2) {
                            Text(suggestion)
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                                .lineLimit(1)
                            
                            // Find the airport data for subtitle
                            if let airportData = airportService.airports.first(where: { $0.displayName == suggestion }) {
                                Text("\(airportData.city), \(airportData.country)")
                                    .font(.system(size: 14, weight: .regular))
                                    .foregroundColor(.gray)
                                    .lineLimit(1)
                            }
                        }
                        
                        Spacer()
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .background(Color.white)
                }
                .buttonStyle(PlainButtonStyle())
                
                if index < airportService.suggestions.count - 1 {
                    Divider()
                        .padding(.leading, 64) // Align with text content (20 + 24 + 20)
                }
                }
            }
        }
        .background(Color.white)
        .frame(maxWidth: .infinity)
        .padding(.top, 8)
    }
}

// MARK: - Location Suggestions Component
struct LocationSuggestions: View {
    let shouldHide: Bool
    @Binding var focusedField: String?
    @Binding var selectedBookingType: String
    @Binding var selectedDestinationType: String
    @Binding var pickupLocation: String
    @Binding var destinationLocation: String
    @Binding var selectedPickupAirport: String
    @Binding var selectedDestinationAirport: String
    @Binding var pickupAirportSearch: String
    @Binding var destinationAirportSearch: String
    @Binding var pickupCoordinate: LocationCoordinate?
    @Binding var destinationCoordinate: LocationCoordinate?
    @Binding var pickupCountry: String?
    @Binding var destinationCountry: String?
    @Binding var justSelectedPickup: Bool
    @Binding var justSelectedDestination: Bool
    @Binding var showPickupSuggestions: Bool
    @Binding var showDestinationSuggestions: Bool
    let airportService: AirportService
    let pickupAddressViewModel: AddressAutocompleteViewModel
    let destinationAddressViewModel: AddressAutocompleteViewModel
    let prepareAndShowTimeSelection: () -> Void
    @ObservedObject var recentLocationService: RecentLocationService
    let isInitialLoad: Bool
    let isSettingCurrentLocation: Bool
    let countryExtractor: (String) -> String?
    @Binding var path: [Screen]
    @Binding var showRecentLocationsOnReturn: Bool
    
    @State private var currentLocations: [RecentLocation] = []
    
    // Determine which locations to show based on focused field
    private var displayLocations: [RecentLocation] {
        print("🔍 DISPLAY LOCATIONS CHECK:")
        print("   - focusedField: \(focusedField ?? "nil")")
        print("   - pickupLocation: '\(pickupLocation)'")
        print("   - selectedPickupAirport: '\(selectedPickupAirport)'")
        print("   - destinationLocation: '\(destinationLocation)'")
        print("   - selectedDestinationAirport: '\(selectedDestinationAirport)'")
        print("   - selectedBookingType: '\(selectedBookingType)'")
        print("   - selectedDestinationType: '\(selectedDestinationType)'")
        
        if focusedField == "pickup" {
            // Check the correct field based on booking type
            let fieldValue: String
            if selectedBookingType == "Airport" {
                fieldValue = selectedPickupAirport
            } else {
                fieldValue = pickupLocation
            }
            
            // Show recent locations if field is empty or has minimal text (1-2 characters)
            let shouldShowRecent = fieldValue.isEmpty || fieldValue.count <= 2
            
            print("   - Pickup field value: '\(fieldValue)'")
            print("   - Should show recent: \(shouldShowRecent)")
            print("   - Pickup locations count: \(recentLocationService.pickupLocations.count)")
            
            if shouldShowRecent {
                var locations = recentLocationService.pickupLocations
                
                // Filter logic for pickup recent:
                // If booking type is Airport, show only airport addresses
                // Otherwise, filter out airport addresses (show only non-airport addresses)
                if selectedBookingType == "Airport" {
                    // Airport pickup: show only airport addresses
                    locations = locations.filter { $0.isAirport }
                    print("   - Pickup: Showing only airports. Showing \(locations.count) airport locations")
                } else {
                    // City pickup: filter out airport addresses (show only non-airport addresses)
                    locations = locations.filter { !$0.isAirport }
                    print("   - Pickup: Filtered out airports (city pickup). Showing \(locations.count) non-airport locations")
                }
                
                return locations
            }
        } else if focusedField == "destination" {
            // Check the correct field based on destination type
            let fieldValue: String
            if selectedDestinationType == "Airport" {
                fieldValue = selectedDestinationAirport
            } else {
                fieldValue = destinationLocation
            }
            
            // Show recent locations if field is empty or has minimal text (1-2 characters)
            let shouldShowRecent = fieldValue.isEmpty || fieldValue.count <= 2
            
            print("   - Destination field value: '\(fieldValue)'")
            print("   - Should show recent: \(shouldShowRecent)")
            print("   - Dropoff locations count: \(recentLocationService.dropoffLocations.count)")
            
            if shouldShowRecent {
                var locations = recentLocationService.dropoffLocations
                
                // Filter logic for dropoff recent:
                // If pickup is Airport AND destination is NOT Airport (airport to city), filter out airport addresses (show only city addresses)
                // If destination is Airport (something to airport or airport to airport), show only airport addresses
                // Otherwise, show all locations
                if selectedBookingType == "Airport" && selectedDestinationType != "Airport" {
                    // Airport to city: filter out airport addresses (show only non-airport addresses)
                    locations = locations.filter { !$0.isAirport }
                    print("   - Dropoff: Filtered out airports (airport to city). Showing \(locations.count) non-airport locations")
                } else if selectedDestinationType == "Airport" {
                    // Something to airport or airport to airport: show only airport addresses
                    locations = locations.filter { $0.isAirport }
                    print("   - Dropoff: Showing only airports (destination is airport). Showing \(locations.count) airport locations")
                } else {
                    // City to city: show all locations
                    print("   - Dropoff: Showing \(locations.count) locations (city to city - all locations)")
                }
                
                return locations
            }
        }
        
        print("   - Returning empty array")
        return []
    }
    
    var body: some View {
        let _ = print("🎨 LocationSuggestions BODY RENDER:")
        let _ = print("   - shouldHide: \(shouldHide)")
        let _ = print("   - focusedField: \(focusedField ?? "nil")")
        let _ = print("   - displayLocations count: \(displayLocations.count)")
        let _ = print("   - isInitialLoad: \(isInitialLoad)")
        let _ = print("   - isSettingCurrentLocation: \(isSettingCurrentLocation)")
        let _ = print("   - recentLocationService.isLoading: \(recentLocationService.isLoading)")
        
        // Show content ONLY when a field is focused (pickup or destination)
        if !shouldHide && focusedField != nil {
            VStack(alignment: .leading, spacing: 0) {
                // Check if we have locations available from service
                let hasLocationsInService = (focusedField == "pickup" && !recentLocationService.pickupLocations.isEmpty) || 
                                          (focusedField == "destination" && !recentLocationService.dropoffLocations.isEmpty)
                
                // Determine if "Select on map" button should be shown
                // Only show if: field is focused AND it's not an airport
                let shouldShowSelectOnMap: Bool = {
                    guard let focused = focusedField else { return false }
                    
                    if focused == "pickup" {
                        // Show for pickup only if pickup is not an airport
                        return selectedBookingType != "Airport"
                    } else if focused == "destination" {
                        // Show for destination only if destination is not an airport
                        return selectedDestinationType != "Airport"
                    }
                    return false
                }()
                
                // Show loading indicator only if actively loading AND no data available
                if recentLocationService.isLoading && !hasLocationsInService {
                    HStack {
                        ProgressView()
                            .scaleEffect(0.8)
                        Text("Loading locations...")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.gray)
                        Spacer()
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                    .transition(.opacity)
                } else {
                    // Show "Select on map" button if conditions are met AND not during initial location setup
                    if shouldShowSelectOnMap && !isSettingCurrentLocation && !isInitialLoad {
                        HStack {
                            Button(action: {
                                // Use the focused field to determine location type
                                guard let focused = focusedField else { return }
                                let locationType = focused == "pickup" ? "pickup" : "destination"
                                path.append(.mapLocationSelection(
                                    locationType: locationType,
                                    selectedBookingType: selectedBookingType,
                                    selectedDestinationType: selectedDestinationType
                                ))
                            }) {
                                HStack(spacing: 12) {
                                    Image(systemName: "location.fill")
                                        .font(.system(size: 16, weight: .medium))
                                        .foregroundColor(.black)
                                    Text("Select on map")
                                        .font(.system(size: 16, weight: .medium))
                                        .foregroundColor(.black)
                                }
                                .padding(.horizontal, 24)
                                .padding(.vertical, 16)
                                .background(Color.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.black, lineWidth: 1)
                                )
                                .cornerRadius(8)
                            }
                            .buttonStyle(PlainButtonStyle())
                            Spacer()
                        }
                        .padding(.horizontal, 20)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    
                    if !displayLocations.isEmpty {
                        // Show "Recent & Saved" only when we have data
                        Spacer().frame(height: 16)
                        Text("Recent & Saved")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.black)
                            .padding(.horizontal, 24)
                            .padding(.top, shouldShowSelectOnMap ? 0 : 0)
                            .padding(.bottom, 16)
                            .transition(.opacity)
                    
                        ScrollView {
                            VStack(spacing: 0) {
                                ForEach(displayLocations) { location in
                                    Button(action: {
                                        handleLocationSelection(location)
                                    }) {
                                        LocationSuggestionRow(
                                            icon: location.isAirport ? "airplane" : "mappin.circle.fill",
                                            title: formatLocationTitle(location),
                                            subtitle: location.address,
                                            iconColor: .gray
                                        )
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                }
                            }.padding(.horizontal, 24)
                        }
                        .transition(.opacity)
                    }
                }
                // If displayLocations is empty and not loading, show nothing
            }
                .onAppear {
                    // Fetch locations immediately when field is focused
                    Task {
                        if focusedField == "pickup" {
                            print("🔍 Fetching pickup locations on appear")
                            await recentLocationService.fetchRecentLocations(type: "pickup")
                        } else if focusedField == "destination" {
                            print("🔍 Fetching destination locations on appear")
                            await recentLocationService.fetchRecentLocations(type: "dropoff")
                        }
                    }
                }
                .onChange(of: focusedField) { newField in
                    print("🔍 FOCUS CHANGED: \(newField ?? "nil")")
                    // Fetch locations immediately when focus changes
                    Task {
                        if newField == "pickup" {
                            print("🔍 Fetching pickup locations")
                            await recentLocationService.fetchRecentLocations(type: "pickup")
                        } else if newField == "destination" {
                            print("🔍 Fetching destination locations")
                            await recentLocationService.fetchRecentLocations(type: "dropoff")
                        }
                    }
                }
        }
    }
    
    private func formatLocationTitle(_ location: RecentLocation) -> String {
        if location.isAirport {
            if let code = location.airportCode, let name = location.airportName {
                return "\(code) - \(name)"
            } else {
                // Fallback to address if airport code/name not available
                return location.address.components(separatedBy: ",").first ?? location.address
            }
        }
        return location.address.components(separatedBy: ",").first ?? location.address
    }
    
    private func handleLocationSelection(_ location: RecentLocation) {
        print("📍 SELECTED RECENT LOCATION: \(location.address)")
        print("📍 IS AIRPORT: \(location.isAirport)")
        print("📍 FOCUSED FIELD: \(focusedField ?? "none")")
        print("📍 SELECTED BOOKING TYPE: \(selectedBookingType)")
        print("📍 SELECTED DESTINATION TYPE: \(selectedDestinationType)")
        print("📍 AIRPORT CODE: \(location.airportCode ?? "nil")")
        print("📍 AIRPORT NAME: \(location.airportName ?? "nil")")
        
        // Use focused field to determine which location to set
        guard let focused = focusedField else {
            print("📍 No field focused, ignoring selection")
            return
        }
        
        if focused == "pickup" {
            print("📍 SETTING PICKUP LOCATION")
            
            // Set selection flag to prevent onChange handlers from interfering
            justSelectedPickup = true
            
            if location.isAirport && selectedBookingType != "Airport" {
                selectedBookingType = "Airport"
            }
            
            // Always set the pickup location based on booking type
            if selectedBookingType == "Airport" {
                // Airport mode - format the airport display name properly
                let airportDisplayName: String
                if let code = location.airportCode, let name = location.airportName {
                    airportDisplayName = "\(code) - \(name)"
                } else {
                    airportDisplayName = location.address
                }
                
                selectedPickupAirport = airportDisplayName
                pickupAirportSearch = airportDisplayName
                pickupLocation = location.address
                
                // For airports, try to get country from airport service first
                if let airportCode = location.airportCode {
                    // Try to find airport in loaded airports
                    if let airport = airportService.airports.first(where: { $0.code == airportCode }) {
                        pickupCountry = airport.country
                        print("📍 SET PICKUP COUNTRY FROM AIRPORT SERVICE: \(airport.country)")
                    } else {
                        // Airport not in list, try to extract from address
                        pickupCountry = countryExtractor(location.address)
                        print("📍 AIRPORT NOT IN SERVICE, SET PICKUP COUNTRY FROM ADDRESS: \(pickupCountry ?? "nil")")
                        
                        // Fetch all airports if not already loaded to ensure validation works
                        if airportService.airports.isEmpty {
                            Task {
                                await airportService.fetchAllAirports()
                                // Re-check country after loading
                                if let airport = airportService.airports.first(where: { $0.code == airportCode }) {
                                    pickupCountry = airport.country
                                    print("📍 UPDATED PICKUP COUNTRY AFTER FETCH: \(airport.country)")
                                }
                            }
                        }
                    }
                } else {
                    pickupCountry = countryExtractor(location.address)
                    print("📍 NO AIRPORT CODE, SET PICKUP COUNTRY FROM ADDRESS: \(pickupCountry ?? "nil")")
                }
                print("📍 SET PICKUP AIRPORT: \(airportDisplayName)")
            } else {
                // City/Cruise mode - use regular location field
                pickupLocation = location.address
                pickupCountry = countryExtractor(location.address)
                print("📍 SET PICKUP CITY: \(location.address)")
                print("📍 SET PICKUP COUNTRY: \(pickupCountry ?? "nil")")
            }
            
            // Always set the coordinate
            pickupCoordinate = LocationCoordinate(latitude: location.latitude, longitude: location.longitude)
            print("📍 PICKUP COORDINATE SET: \(location.latitude), \(location.longitude)")
            print("📍 FINAL PICKUP LOCATION: '\(pickupLocation)'")
            print("📍 FINAL PICKUP AIRPORT: '\(selectedPickupAirport)'")
            
            // Dismiss keyboard first
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
            
            // Hide pickup suggestions
            showPickupSuggestions = false
            airportService.clearSuggestions()
            pickupAddressViewModel.suggestions = []
            pickupAddressViewModel.isEditing = false
            
            // Reset selection flag after a delay and then focus on destination field
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.justSelectedPickup = false
                
                // Auto-focus on destination field and show dropoff recent locations
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    self.focusedField = "destination"
                    self.showDestinationSuggestions = true
                    self.destinationAddressViewModel.isEditing = true
                    print("🎯 AUTO-FOCUSED ON DESTINATION FIELD AFTER PICKUP SELECTION")
                    
                    // Fetch dropoff recent locations
                    Task {
                        await self.recentLocationService.fetchRecentLocations(type: "dropoff")
                        print("📍 FETCHED DROPOFF RECENT LOCATIONS")
                    }
                }
            }
            
        } else if focused == "destination" {
            print("📍 SETTING DESTINATION LOCATION")
            
            // Set selection flag to prevent onChange handlers from interfering
            justSelectedDestination = true
            
            if location.isAirport && selectedDestinationType != "Airport" {
                selectedDestinationType = "Airport"
            }
            
            // Always set the destination location based on booking type
            if selectedDestinationType == "Airport" {
                // Airport mode - format the airport display name properly
                let airportDisplayName: String
                if let code = location.airportCode, let name = location.airportName {
                    airportDisplayName = "\(code) - \(name)"
                } else {
                    airportDisplayName = location.address
                }
                
                selectedDestinationAirport = airportDisplayName
                destinationAirportSearch = airportDisplayName
                destinationLocation = location.address
                
                // For airports, try to get country from airport service first
                if let airportCode = location.airportCode {
                    // Try to find airport in loaded airports
                    if let airport = airportService.airports.first(where: { $0.code == airportCode }) {
                        destinationCountry = airport.country
                        print("📍 SET DESTINATION COUNTRY FROM AIRPORT SERVICE: \(airport.country)")
                    } else {
                        // Airport not in list, try to extract from address
                        destinationCountry = countryExtractor(location.address)
                        print("📍 AIRPORT NOT IN SERVICE, SET DESTINATION COUNTRY FROM ADDRESS: \(destinationCountry ?? "nil")")
                        
                        // Fetch all airports if not already loaded to ensure validation works
                        if airportService.airports.isEmpty {
                            Task {
                                await airportService.fetchAllAirports()
                                // Re-check country after loading
                                if let airport = airportService.airports.first(where: { $0.code == airportCode }) {
                                    destinationCountry = airport.country
                                    print("📍 UPDATED DESTINATION COUNTRY AFTER FETCH: \(airport.country)")
                                }
                            }
                        }
                    }
                } else {
                    destinationCountry = countryExtractor(location.address)
                    print("📍 NO AIRPORT CODE, SET DESTINATION COUNTRY FROM ADDRESS: \(destinationCountry ?? "nil")")
                }
                print("📍 SET DESTINATION AIRPORT: \(airportDisplayName)")
            } else {
                // City/Cruise mode - use regular location field
                destinationLocation = location.address
                destinationCountry = countryExtractor(location.address)
                print("📍 SET DESTINATION CITY: \(location.address)")
                print("📍 SET DESTINATION COUNTRY: \(destinationCountry ?? "nil")")
            }
            
            // Always set the coordinate
            destinationCoordinate = LocationCoordinate(latitude: location.latitude, longitude: location.longitude)
            print("📍 DESTINATION COORDINATE SET: \(location.latitude), \(location.longitude)")
            print("📍 FINAL DESTINATION LOCATION: '\(destinationLocation)'")
            print("📍 FINAL DESTINATION AIRPORT: '\(selectedDestinationAirport)'")
            
            // Dismiss keyboard first
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
            
            // Hide suggestions and clear focus
            showDestinationSuggestions = false
            focusedField = nil
            airportService.clearSuggestions()
            destinationAddressViewModel.suggestions = []
            destinationAddressViewModel.isEditing = false
            
            // Reset selection flag after a delay and trigger navigation
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.justSelectedDestination = false
                // Trigger navigation check after coordinates are set
                // Add extra delay to ensure country extraction completes
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.prepareAndShowTimeSelection()
                }
            }
        }
    }
    
}

struct LocationErrorBannerView: View {
    let message: String
    
    private var labels: (title: String, subtitle: String) {
        let trimmed = message.trimmingCharacters(in: .whitespacesAndNewlines)
        let lowercased = trimmed.lowercased()
        
        if lowercased.contains("country") {
            return (
                "Pickup and drop countries must match",
                "Please select pickup and drop-off within the same country."
            )
        }
        
        if lowercased.contains("cannot be the same") || lowercased.contains("same location") || lowercased.contains("pickup and drop") {
            return (
                "Pickup and drop locations are same",
                "Please change your pickup or drop location."
            )
        }
        
        if let periodIndex = trimmed.firstIndex(of: ".") {
            let title = String(trimmed[..<periodIndex]).trimmingCharacters(in: .whitespaces)
            let remainder = trimmed[trimmed.index(after: periodIndex)...].trimmingCharacters(in: .whitespaces)
            if !title.isEmpty && !remainder.isEmpty {
                return (title, remainder)
            }
        }
        
        return ("Invalid location selected", trimmed)
    }
    
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color(red: 1.0, green: 0.94, blue: 0.94))
                    .frame(width: 36, height: 36)
                Circle()
                    .stroke(Color(red: 0.93, green: 0.46, blue: 0.46), lineWidth: 1)
                    .frame(width: 36, height: 36)
                Image(systemName: "info.circle.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(Color(red: 0.78, green: 0.12, blue: 0.12))
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(labels.title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(Color(red: 0.78, green: 0.12, blue: 0.12))
                Text(labels.subtitle)
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(Color(red: 0.58, green: 0.16, blue: 0.16))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color(red: 1.0, green: 0.95, blue: 0.95))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(Color(red: 0.94, green: 0.47, blue: 0.47), lineWidth: 1)
        )
    }
}

struct SwitchRiderBottomSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var selectedPassenger: String
    
    var body: some View {
        ZStack {
            // Blurred background
            Color.black.opacity(0.3)
                .ignoresSafeArea()
            
            VStack {
                Spacer()
                
                VStack(spacing: 0) {
                    // Drag Handle
                    RoundedRectangle(cornerRadius: 2.5)
                        .fill(Color.gray.opacity(0.3))
                        .frame(width: 36, height: 5)
                        .padding(.top, 8)
                        .padding(.bottom, 16)
                    
                    // Header
                    Text("Switch rider")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                        .padding(.bottom, 20)
                    
                    // Contact List
                    VStack(spacing: 0) {
                        // First Contact - Georgia
                        Button(action: {
                            selectedPassenger = "Georgia"
                            dismiss()
                        }) {
                            HStack(spacing: 16) {
                                Circle()
                                    .fill(AppColors.primaryOrange)
                                    .frame(width: 40, height: 40)
                                    .overlay(
                                        Text("G")
                                            .font(.system(size: 16, weight: .semibold))
                                            .foregroundColor(.white)
                                    )
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Georgia")
                                        .font(.system(size: 16, weight: .medium))
                                        .foregroundColor(.black)
                                    Text("+198754668735")
                                        .font(.system(size: 14, weight: .regular))
                                        .foregroundColor(.gray)
                                }
                                
                                Spacer()
                            }
                            .padding(.horizontal, 24)
                            .padding(.vertical, 16)
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        Divider()
                            .padding(.horizontal, 24)
                        
                        // Second Contact - Even Lewis
                        Button(action: {
                            selectedPassenger = "Even Lewis"
                            dismiss()
                        }) {
                            HStack(spacing: 16) {
                                Circle()
                                    .fill(AppColors.primaryOrange)
                                    .frame(width: 40, height: 40)
                                    .overlay(
                                        Text("E")
                                            .font(.system(size: 16, weight: .semibold))
                                            .foregroundColor(.white)
                                    )
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Even Lewis")
                                        .font(.system(size: 16, weight: .medium))
                                        .foregroundColor(.black)
                                    Text("+198754668735")
                                        .font(.system(size: 14, weight: .regular))
                                        .foregroundColor(.gray)
                                }
                                
                                Spacer()
                            }
                            .padding(.horizontal, 24)
                            .padding(.vertical, 16)
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        Divider()
                            .padding(.horizontal, 24)
                        
                        // Add New Contact
                        Button(action: {
                            // Handle add new contact
                        }) {
                            HStack(spacing: 16) {
                                Image(systemName: "person")
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundColor(.black)
                                    .frame(width: 40, height: 40)
                                
                                Text("Add new Contact")
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundColor(.black)
                                
                                Spacer()
                            }
                            .padding(.horizontal, 24)
                            .padding(.vertical, 16)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    
                    // Done Button
                    Button(action: {
                        dismiss()
                    }) {
                        Text("Done")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(AppColors.primaryOrange)
                            .cornerRadius(25)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 20)
                    .padding(.bottom, 40)
                }
                .background(Color.white)
                .cornerRadius(20, corners: [.topLeft, .topRight])
            }
        }
    }
}

struct LocationSuggestionRow: View {
    let icon: String
    let title: String
    let subtitle: String
    let iconColor: Color
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.white)
                .frame(width: 32, height: 32)
                .background(iconColor)
                .clipShape(Circle())
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.black)
                
                Text(subtitle)
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(.gray)
                    .lineLimit(1)
            }
            
            Spacer()
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 16)
        .background(Color.white)
    }
}

struct PassengerPickerView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var selectedPassenger: String
    
    let passengers = ["For me", "For someone else", "For business"]
    
    var body: some View {
        NavigationView {
            List(passengers, id: \.self) { passenger in
                Button(action: {
                    selectedPassenger = passenger
                    dismiss()
                }) {
                    HStack {
                        Text(passenger)
                            .foregroundColor(.black)
                        Spacer()
                        if selectedPassenger == passenger {
                            Image(systemName: "checkmark")
                                .foregroundColor(AppColors.primaryOrange)
                        }
                    }
                }
            }
            .navigationTitle("Select Passenger")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Map Location Selection View
struct MapLocationSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: [Screen]
    
    let locationType: String // "pickup" or "destination"
    let selectedBookingType: String
    let selectedDestinationType: String
    
    @StateObject private var addressViewModel = AddressAutocompleteViewModel()
    private let placesService = GooglePlacesService()
    @State private var locationManager = CLLocationManager()
    @State private var locationDelegate: LocationManagerDelegate?
    
    @State private var searchText = ""
    @State private var selectedAddress = ""
    @State private var selectedCoordinate: LocationCoordinate?
    @State private var mapRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 40.7128, longitude: -74.0060),
        span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
    )
    @State private var reverseGeocodeWorkItem: DispatchWorkItem?
    @State private var lastReverseGeocodeAt: Date = .distantPast
    @State private var showSearchSuggestions = false
    @State private var isSearching = false
    @State private var searchSuggestions: [String] = []
    @State private var isSelectingSuggestion = false
    @FocusState private var isSearchFieldFocused: Bool
    
    var screenTitle: String {
        locationType == "pickup" ? "Select Pickup" : "Select Drop"
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Navigation Bar
            HStack {
                Text(screenTitle)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.black)
                
                Spacer()
                
                Button("Cancel") {
                    dismiss()
                }
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.blue)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
            
            // Search Bar
            HStack(spacing: 12) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.gray)
                
                TextField("Search address", text: $searchText)
                    .font(.system(size: 16, weight: .regular))
                    .foregroundColor(.black)
                    .focused($isSearchFieldFocused)
                    .onChange(of: searchText) { newValue in
                        if isSelectingSuggestion {
                            isSelectingSuggestion = false
                            return
                        }
                        if !newValue.isEmpty {
                            searchAddress(query: newValue)
                        } else {
                            searchSuggestions = []
                            showSearchSuggestions = false
                        }
                    }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
            .cornerRadius(8)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.black, lineWidth: 1)
            )
            .padding(.horizontal, 20)
            .padding(.bottom, 12)
            
            // Map View
            ZStack {
                Map(coordinateRegion: $mapRegion, annotationItems: selectedCoordinate != nil ? [MapPin(coordinate: selectedCoordinate!)] : []) { pin in
                    MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: pin.coordinate.latitude, longitude: pin.coordinate.longitude)) {
                        VStack(spacing: 0) {
                            Image(systemName: "mappin.circle.fill")
                                .font(.system(size: 40))
                                .foregroundColor(.red)
                                .background(
                                    Circle()
                                        .fill(.white)
                                        .frame(width: 20, height: 20)
                                )
                                .offset(y: -20)
                        }
                    }
                }
                .onChange(of: mapRegion.center.latitude) { _ in
                    scheduleReverseGeocode(
                        for: LocationCoordinate(latitude: mapRegion.center.latitude, longitude: mapRegion.center.longitude)
                    )
                }
                .onChange(of: mapRegion.center.longitude) { _ in
                    scheduleReverseGeocode(
                        for: LocationCoordinate(latitude: mapRegion.center.latitude, longitude: mapRegion.center.longitude)
                    )
                }
                .gesture(
                    DragGesture()
                        .onEnded { _ in
                            // Update address when map drag ends
                            scheduleReverseGeocode(
                                for: LocationCoordinate(latitude: mapRegion.center.latitude, longitude: mapRegion.center.longitude)
                            )
                        }
                )
                
                // Current Location Button
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button(action: {
                            centerOnCurrentLocation()
                        }) {
                            Image(systemName: "location.fill")
                                .font(.system(size: 20, weight: .medium))
                                .foregroundColor(.white)
                                .frame(width: 44, height: 44)
                                .background(Color.orange)
                                .clipShape(Circle())
                                .shadow(color: Color.black.opacity(0.2), radius: 4, x: 0, y: 2)
                        }
                        .padding(.trailing, 16)
                        .padding(.bottom, 16)
                    }
                }

                // Full-screen suggestions overlay when typing
                if showSearchSuggestions && !searchSuggestions.isEmpty {
                    Color.white.opacity(0.95)
                        .edgesIgnoringSafeArea(.bottom)
                    ScrollView {
                        VStack(spacing: 0) {
                            ForEach(searchSuggestions, id: \.self) { suggestion in
                                Button(action: {
                                    selectSuggestion(suggestion)
                                }) {
                                    HStack(spacing: 12) {
                                        Image(systemName: "mappin.circle.fill")
                                            .font(.system(size: 16, weight: .medium))
                                            .foregroundColor(.gray)
                                        
                                        Text(suggestion)
                                            .font(.system(size: 16, weight: .regular))
                                            .foregroundColor(.black)
                                            .multilineTextAlignment(.leading)
                                        
                                        Spacer()
                                    }
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 14)
                                }
                                .buttonStyle(PlainButtonStyle())
                                
                                Divider()
                                    .padding(.leading, 48)
                            }
                        }
                        .padding(.top, 8)
                    }
                }
            }
            
            // Address Display
            if !selectedAddress.isEmpty {
                VStack(spacing: 0) {
                    Divider()
                    
                    HStack {
                        Text(selectedAddress)
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(.black)
                            .multilineTextAlignment(.leading)
                            .lineLimit(3)
                        
                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 16)
                }
                .background(Color.white)
            }
            
            // Set Address Button
            Button(action: {
                if let coordinate = selectedCoordinate {
                    // Post notification with selected location
                    NotificationCenter.default.post(
                        name: NSNotification.Name("MapLocationSelected"),
                        object: nil,
                        userInfo: [
                            "locationType": locationType,
                            "address": selectedAddress,
                            "coordinate": coordinate
                        ]
                    )
                    dismiss()
                }
            }) {
                Text("Set Address")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(selectedCoordinate != nil ? Color.orange : Color.gray)
                    .cornerRadius(8)
            }
            .disabled(selectedCoordinate == nil)
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .background(Color.white)
        .onAppear {
            setupLocationManager()
            centerOnCurrentLocation()
        }
        .navigationBarBackButtonHidden(true)
    }
    
    private func setupLocationManager() {
        let delegate = LocationManagerDelegate { location in
            if self.selectedCoordinate == nil {
                self.centerOnLocation(location)
            }
        }
        locationDelegate = delegate
        locationManager.delegate = delegate
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    private func centerOnCurrentLocation() {
        if let location = locationManager.location {
            centerOnLocation(location.coordinate)
        } else {
            locationManager.requestLocation()
        }
    }
    
    private func centerOnLocation(_ coordinate: CLLocationCoordinate2D) {
        withAnimation {
            mapRegion = MKCoordinateRegion(
                center: coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            )
        }
        scheduleReverseGeocode(
            for: LocationCoordinate(latitude: coordinate.latitude, longitude: coordinate.longitude)
        )
    }

    // Debounced reverse geocode to avoid throttling
    private func scheduleReverseGeocode(for coordinate: LocationCoordinate) {
        reverseGeocodeWorkItem?.cancel()

        let task = DispatchWorkItem {
            let now = Date()
            if now.timeIntervalSince(self.lastReverseGeocodeAt) < 0.8 {
                let delay = 0.8 - now.timeIntervalSince(self.lastReverseGeocodeAt)
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    self.updateAddressFromCoordinate(coordinate)
                }
            } else {
                self.updateAddressFromCoordinate(coordinate)
            }
            self.lastReverseGeocodeAt = Date()
        }

        reverseGeocodeWorkItem = task
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: task)
    }
    
    private func searchAddress(query: String) {
        isSearching = true
        placesService.fetchSuggestions(for: query) { (suggestions: [String]) in
            DispatchQueue.main.async {
                self.searchSuggestions = suggestions
                self.showSearchSuggestions = !suggestions.isEmpty
                self.isSearching = false
            }
        }
    }
    
    private func selectSuggestion(_ suggestion: String) {
        isSelectingSuggestion = true
        searchText = suggestion
        showSearchSuggestions = false
        searchSuggestions = []
        
        // Dismiss keyboard when suggestion is selected
        isSearchFieldFocused = false
        
        placesService.fetchCoordinates(for: suggestion) { (coordinate: LocationCoordinate?) in
            DispatchQueue.main.async {
                if let coordinate = coordinate {
                    self.selectedCoordinate = coordinate
                    self.selectedAddress = suggestion
                    centerOnLocation(CLLocationCoordinate2D(latitude: coordinate.latitude, longitude: coordinate.longitude))
                }
            }
        }
    }
    
    private func updateAddressFromCoordinate(_ coordinate: LocationCoordinate) {
        selectedCoordinate = coordinate
        
        let geocoder = CLGeocoder()
        let location = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        
        geocoder.reverseGeocodeLocation(location) { placemarks, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Geocoding error: \(error.localizedDescription)")
                    return
                }
                
                if let placemark = placemarks?.first {
                    var addressComponents: [String] = []
                    
                    if let streetNumber = placemark.subThoroughfare {
                        addressComponents.append(streetNumber)
                    }
                    if let streetName = placemark.thoroughfare {
                        addressComponents.append(streetName)
                    }
                    if let locality = placemark.locality {
                        addressComponents.append(locality)
                    }
                    if let subLocality = placemark.subLocality {
                        addressComponents.append(subLocality)
                    }
                    if let administrativeArea = placemark.administrativeArea {
                        addressComponents.append(administrativeArea)
                    }
                    if let postalCode = placemark.postalCode {
                        addressComponents.append(postalCode)
                    }
                    if let country = placemark.country {
                        addressComponents.append(country)
                    }
                    
                    self.selectedAddress = addressComponents.joined(separator: ", ")
                }
            }
        }
    }
    
}

// Helper class for location manager delegate
class LocationManagerDelegate: NSObject, CLLocationManagerDelegate {
    let onLocationUpdate: (CLLocationCoordinate2D) -> Void
    
    init(onLocationUpdate: @escaping (CLLocationCoordinate2D) -> Void) {
        self.onLocationUpdate = onLocationUpdate
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            onLocationUpdate(location.coordinate)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("❌ Location error: \(error.localizedDescription)")
    }
}

struct MapPin: Identifiable {
    let id = UUID()
    let coordinate: LocationCoordinate
}

#Preview {
    ScheduleRideBottomSheet(path: .constant([]))
}
