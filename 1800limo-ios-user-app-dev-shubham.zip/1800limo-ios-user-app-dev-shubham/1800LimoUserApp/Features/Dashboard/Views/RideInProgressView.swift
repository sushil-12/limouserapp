import SwiftUI
import MapKit
import CoreLocation
import Foundation
import UIKit

// Note: Both ViewModels can now handle driver location updates independently

// MARK: - MKCoordinateRegion Extension
extension MKCoordinateRegion {
    init(coordinates: [CLLocationCoordinate2D]) {
        guard !coordinates.isEmpty else {
            self = MKCoordinateRegion()
            return
        }
        
        var minLat = coordinates[0].latitude
        var maxLat = coordinates[0].latitude
        var minLng = coordinates[0].longitude
        var maxLng = coordinates[0].longitude
        
        for coord in coordinates {
            minLat = min(minLat, coord.latitude)
            maxLat = max(maxLat, coord.latitude)
            minLng = min(minLng, coord.longitude)
            maxLng = max(maxLng, coord.longitude)
        }
        
        let center = CLLocationCoordinate2D(
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2
        )
        
        let span = MKCoordinateSpan(
            latitudeDelta: (maxLat - minLat) * 1.3,
            longitudeDelta: (maxLng - minLng) * 1.3
        )
        
        self = MKCoordinateRegion(center: center, span: span)
    }
}

// MARK: - Car Annotation
class CarAnnotation: NSObject, MKAnnotation {
    @objc dynamic var coordinate: CLLocationCoordinate2D
    var heading: CLLocationDirection
    
    init(coordinate: CLLocationCoordinate2D, heading: CLLocationDirection = 0) {
        self.coordinate = coordinate
        self.heading = heading
        super.init()
    }
}

@MainActor
class RideInProgressViewModel: NSObject, ObservableObject {
    @Published var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 30.6942, longitude: 76.7933), // Chandigarh
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    @Published var currentLocation: CLLocationCoordinate2D?
    @Published var carHeading: CLLocationDirection = 0
    @Published var route: MKRoute?
    @Published var previewRoute: MKRoute? // Light grey route showing pickup to dropoff (matching driver app)
    @Published var customRoutePolyline: MKPolyline?
    @Published var carPathPolyline: MKPolyline? // Path line showing car's movement trail
    @Published var estimatedTime: String = "16 Min"
    @Published var distance: String = "2.3km"
    @Published var rideStatus: String = "en_route_pu" // Driver is on the way to pickup
    @Published var statusMessage: String = "Driver is on the way" // Status message for UI
    @Published var rideOTP: String = "1234" // OTP for ride verification
    @Published var isDriverOnLocation: Bool = false // Track if driver has arrived
    @Published var hasArrivedAtPickup: Bool = false // Track if driver has arrived at pickup (matching driver app)
    @Published var isRideStarted: Bool = false // Track if ride has started (matching driver app)
    
    // Map interaction tracking
    @Published var userHasInteractedWithMap: Bool = false
    
    // Car path tracking for trail line
    private var carPathCoordinates: [CLLocationCoordinate2D] = []
    private var lastCarLocation: CLLocationCoordinate2D?
    
    // Route calculation tracking
    private var isCalculatingRoute: Bool = false
    
    // Flag to control if this ViewModel should handle driver location updates
    @Published var shouldHandleDriverLocationUpdates: Bool = true
    
    // Flag to track if we've manually updated status (prevents timer override)
    private var manuallyUpdatedStatus: Bool = false
    
    private let locationManager = CLLocationManager()
    let socketService = SimpleSocketIOService.shared
    private var locationUpdateTimer: Timer?
    private var statusUpdateTimer: Timer?
    private var socketConnectionTimer: Timer?
    private var driverLocationRequestTimer: Timer?
    var carAnnotation: CarAnnotation?
    
    let pickupLocation: CLLocationCoordinate2D
    let dropoffLocation: CLLocationCoordinate2D
    let bookingData: BookingNotificationData
    
    private let vehicleService = VehicleService()
    private var hasCalculatedBookingMetrics = false
    private let prefersGoogleBookingMetrics = true
    
    init(bookingData: BookingNotificationData) {
        self.bookingData = bookingData
//        print("RideDrive---RideInProgressViewModel:init")
//        socketService.showSuccessToast("RideInProgressViewModel:init")
        // Use actual coordinates from notification data
        if let pickupCoords = bookingData.getPickupCoordinates() {
            self.pickupLocation = pickupCoords
             
        } else {
            // Fallback to default coordinates if not provided
            self.pickupLocation = CLLocationCoordinate2D(latitude: 30.6735, longitude: 76.7884)
             
        }
        
        if let dropoffCoords = bookingData.getDropoffCoordinates() {
            self.dropoffLocation = dropoffCoords
             
        } else {
            // Fallback to default coordinates if not provided
            self.dropoffLocation = CLLocationCoordinate2D(latitude: 30.6942, longitude: 76.7933)
             
        }
        
        super.init()
        
        // Set initial status from booking data if available
        if let initialStatus = bookingData.status {
            self.rideStatus = initialStatus
             
        }
        
        // Initialize based on ride status (matching driver app pattern)
        initializeStateFromBookingStatus()
        
        // Set initial status message
        updateStatusMessage()
        
        updateBookingDistanceAndTime(force: true)
        
        setupLocationManager()
        setupDriverLocationListener()
        setupDirectSocketListener()
        setupStatusListener()
        setupActiveRideDataObserver()
        startSocketConnectionMonitoring()
        startDriverLocationRequesting()
        startSocketEventDebugging()
         
        socketService.ensureConnectionForViewTransition()
    }
    
    // Initialize state based on booking status from active ride (matching driver app)
    private func initializeStateFromBookingStatus() {
        guard let status = bookingData.status else {
            print("🚗 No status found in booking data, using default state")
            initializeRideState()
            return
        }
        
        print("🚗 Initializing state based on booking status: \(status)")
        
        // Update ride status
        self.rideStatus = status
        
        switch status {
        case "on_location":
            // Driver has already arrived at pickup location
            print("🚗 Status 'on_location' - Driver has arrived at pickup")
            isDriverOnLocation = true
            hasArrivedAtPickup = true
            
            // Set initial location to pickup
            self.currentLocation = self.pickupLocation
            self.lastCarLocation = self.pickupLocation
            self.carPathCoordinates.append(self.pickupLocation)
            
            // Set initial region to focus on pickup location
            self.region = MKCoordinateRegion(
                center: self.pickupLocation,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            )
            
            // Calculate preview route (pickup to dropoff) to show full journey
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.calculatePreviewRoute()
            }
            break
            
        case "en_route_do":
            // Driver has already started the ride (verification completed)
            print("🚗 Status 'en_route_do' - Ride already started, showing 'Ride In Progress' UI")
            isDriverOnLocation = false
            hasArrivedAtPickup = true
            isRideStarted = true
            
            // Reset user interaction flags to ensure map region updates work
            userHasInteractedWithMap = false
            
            // Set initial location - use pickup as fallback until driver location updates
            self.currentLocation = self.pickupLocation
            self.lastCarLocation = self.pickupLocation
            self.carPathCoordinates.append(self.pickupLocation)
            
            // Set initial region to focus on pickup location
            self.region = MKCoordinateRegion(
                center: self.pickupLocation,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            )
            print("🚗 Status 'en_route_do' - Initial region set to pickup location")
            
            // Calculate route from pickup to dropoff (driver should be at pickup)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                print("🚗 Status 'en_route_do' - Calculating route from pickup to dropoff")
                self.calculateDropoffRoute()
            }
            break
            
        case "en_route_pu":
            // Driver is en route to pickup (normal state)
            print("🚗 Status 'en_route_pu' - Driver en route to pickup, showing normal UI")
            isDriverOnLocation = false
            
            // Reset user interaction flags to ensure map region updates work
            userHasInteractedWithMap = false
            
            // Set initial location to pickup (will be updated when driver location arrives)
            self.currentLocation = self.pickupLocation
            self.lastCarLocation = self.pickupLocation
            self.carPathCoordinates.append(self.pickupLocation)
            
            // Set initial region to focus on pickup location
            self.region = MKCoordinateRegion(
                center: self.pickupLocation,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            )
            print("🚗 Status 'en_route_pu' - Initial region set to pickup location")
            
            // Calculate preview route (pickup to dropoff) to show full journey
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                print("🚗 Status 'en_route_pu' - Calculating preview route (pickup to dropoff)")
                self.calculatePreviewRoute()
            }
            break
            
        default:
            print("🚗 Unknown status '\(status)', using default state")
            initializeRideState()
            break
        }
        
        // Ensure annotations are properly displayed after a delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.refreshMapAnnotations()
        }
    }
    
    // Fallback initialization method (original logic)
    private func initializeRideState() {
        // Set initial driver location status based on ride status
        switch rideStatus {
        case "on_location", "at_pickup":
            self.isDriverOnLocation = true
        case "en_route_pu":
            self.isDriverOnLocation = false
        case "en_route_do":
            self.isDriverOnLocation = false
        default:
            self.isDriverOnLocation = false
        }
        
        // Set initial location based on ride status
        switch rideStatus {
        case "en_route_pu", "at_pickup", "on_location":
            self.currentLocation = self.pickupLocation
            self.lastCarLocation = self.pickupLocation
            self.carPathCoordinates.append(self.pickupLocation)
        case "en_route_do":
            self.currentLocation = self.pickupLocation
            self.lastCarLocation = self.pickupLocation
            self.carPathCoordinates.append(self.pickupLocation)
        default:
            self.currentLocation = self.pickupLocation
            self.lastCarLocation = self.pickupLocation
            self.carPathCoordinates.append(self.pickupLocation)
        }
        
        // Set initial region to show all points
        updateRegionToShowAllPoints()
        
        DispatchQueue.main.async {
            self.updateRegionToShowAllPoints()
        }
        
        // Calculate initial route based on ride status
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.calculateRoute()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.calculateRoute()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.forcePickupToDropoffRoute()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.refreshMapAnnotations()
        }
    }
    
    private func updateBookingDistanceAndTime(force: Bool = false) {
        guard force || !hasCalculatedBookingMetrics else { return }
        
        Task { [weak self] in
            guard let self = self else { return }
            let (distanceMeters, durationSeconds) = await self.vehicleService.calculateDistance(
                from: self.pickupLocation,
                to: self.dropoffLocation
            )
            
            await MainActor.run {
                self.hasCalculatedBookingMetrics = true
                self.distance = self.formatDistanceText(distanceMeters)
                self.estimatedTime = self.formatDurationText(durationSeconds)
            }
        }
    }
    
    private func formatDistanceText(_ meters: CLLocationDistance) -> String {
        if meters >= 1000 {
            return String(format: "%.1fkm", meters / 1000)
        }
        return "\(Int(meters))m"
    }
    
    private func formatDurationText(_ seconds: TimeInterval) -> String {
        let totalMinutes = Int(round(seconds / 60))
        if totalMinutes >= 60 {
            let hours = totalMinutes / 60
            let remainingMinutes = totalMinutes % 60
            if remainingMinutes > 0 {
                return "\(hours) hour \(remainingMinutes) min"
            } else {
                return "\(hours) hour"
            }
        } else {
            return "\(totalMinutes) min"
        }
    }
    
    private func updateMetricsFromRoute(_ route: MKRoute) {
        guard !prefersGoogleBookingMetrics else { return }
        self.distance = formatDistanceText(route.distance)
        self.estimatedTime = formatDurationText(route.expectedTravelTime)
    }
    
    private func updateMetricsFromFallback(distanceMeters: Double, durationSeconds: Double) {
        guard !prefersGoogleBookingMetrics else { return }
        self.distance = formatDistanceText(distanceMeters)
        self.estimatedTime = formatDurationText(durationSeconds)
    }
    
    // MARK: - Map Annotation Management
    
    /// Refresh map annotations to ensure they're properly displayed
    private func refreshMapAnnotations() {
         
        
        // Force region update to show all points
        updateRegionToShowAllPoints()
        
        // Trigger map view update by posting a notification
        NotificationCenter.default.post(name: NSNotification.Name("RefreshMapAnnotations"), object: nil)
        
         
    }
    
    /// Force route calculation and display between pickup and dropoff
    private func forcePickupToDropoffRoute() {
         
        
        // Calculate route from pickup to dropoff
        calculatePickupToDropoffRoute()
        
        // Also ensure we have a route even if the above fails
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            if self.route == nil {
                 
                self.createDirectLineRoute(from: self.pickupLocation, to: self.dropoffLocation)
            }
        }
    }
    
    private func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone // Get all updates
        
        // Request permissions first
        let status = locationManager.authorizationStatus
        if status == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        }
        
        // Only start location updates if we have permission
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            locationManager.startUpdatingLocation()
             
        }
    }
    
    // MARK: - Driver Location Socket Listener
    
    /// Continuously listen to driver location updates from socket
    private func setupDriverLocationListener() {
         
        
        // Remove any existing observer first to avoid duplicates
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("DriverLocationUpdate"), object: nil)
        
        // Listen directly to the driver.location.update socket event
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("DriverLocationUpdate"),
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self = self else { 
                 
                return 
            }
            
       
             
            
            // Check if this ViewModel should handle driver location updates
            guard self.shouldHandleDriverLocationUpdates else {
                 
                return
            }
            
            // Extract location update from notification
            guard let userInfo = notification.userInfo,
                  let locationUpdate = userInfo["locationUpdate"] as? DriverLocationUpdate else { 
                 
                return 
            }
            
            // Check if this is for our booking
            if let bookingId = locationUpdate.bookingId, 
               String(bookingId) == String(self.bookingData.bookingId) {
                 
            } else {
                 
                return
            }
            
            let newCoordinate = CLLocationCoordinate2D(
                latitude: locationUpdate.latitude,
                longitude: locationUpdate.longitude
            )
            
            // Check if this update is for our booking (if bookingId is provided)
            if let bookingIdString = locationUpdate.bookingId,
               let bookingIdInt = Int(bookingIdString),
               bookingIdInt != self.bookingData.bookingId {
                // This update is for a different booking, ignore it
                 
                 
                 
                // TEMPORARILY DISABLED FOR TESTING - Remove this comment and uncomment return when booking ID is fixed
                // return
            }
            
            // Check if location actually changed (to avoid unnecessary updates)
            // Use a smaller threshold to catch smaller movements
            if let currentLoc = self.currentLocation,
               abs(currentLoc.latitude - newCoordinate.latitude) < 0.0000001,
               abs(currentLoc.longitude - newCoordinate.longitude) < 0.0000001 {
                // Location hasn't changed significantly
                 
                return
            }
                
             
             
             
             
             
             
             
            
            // Calculate distance moved for better debugging
            if let currentLoc = self.currentLocation {
                let distance = CLLocation(latitude: currentLoc.latitude, longitude: currentLoc.longitude)
                    .distance(from: CLLocation(latitude: newCoordinate.latitude, longitude: newCoordinate.longitude))
                 
            }
             
            
            // Snap to route for smoother movement
            let snappedLocation = self.snapToRoute(location: newCoordinate)
            
            // Calculate heading from movement direction if not provided
            var calculatedHeading: CLLocationDirection = 0
            if let heading = locationUpdate.heading {
                calculatedHeading = heading
            } else if let lastLoc = self.lastCarLocation {
                // Calculate heading from previous location to current location
                calculatedHeading = self.calculateHeading(from: lastLoc, to: snappedLocation)
            } else if let currentLoc = self.currentLocation {
                // Use current location if lastCarLocation is not set
                calculatedHeading = self.calculateHeading(from: currentLoc, to: snappedLocation)
            }
            
            // Update heading
            self.carHeading = calculatedHeading
            
            // Update current location
            self.currentLocation = snappedLocation
            self.lastCarLocation = snappedLocation
            
            // Update car path trail
            self.updateCarPath(newLocation: snappedLocation)
            
            // Animate car movement
            if let car = self.carAnnotation {
                UIView.animate(withDuration: 0.5, delay: 0, options: [.curveLinear]) {
                    car.coordinate = snappedLocation
                    car.heading = calculatedHeading
                }
                 
            } else {
                // Create car annotation if it doesn't exist
                let carAnnotation = CarAnnotation(coordinate: snappedLocation, heading: calculatedHeading)
                self.carAnnotation = carAnnotation
                 
            }
            
            // Force map refresh to show car movement
            DispatchQueue.main.async {
                // Always focus on car if user hasn't interacted with map
                if !self.userHasInteractedWithMap {
                    self.updateRegionToFocusOnCar()
                }
                
                // Calculate route if needed
                if self.route == nil {
                    self.calculateRoute()
                } else {
                    self.updateETAFromCurrentLocation()
                }
            }
        }
        
         
    }
    
    // MARK: - Direct Socket Event Listener
    
    /// Listen directly to driver.location.update socket events
    private func setupDirectSocketListener() {
         
        
        // Listen to all socket events for debugging
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("SocketEventReceived"),
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self = self else { return }
            
            if let userInfo = notification.userInfo,
               let eventName = userInfo["eventName"] as? String,
               let data = userInfo["data"] as? [Any] {
                
                 
                
                // Check if it's a driver location update
                if eventName == "driver.location.update" {
                     
                     
                    
                    if let locationData = data.first as? [String: Any] {
                        self.handleDirectDriverLocationUpdate(locationData)
                    } else {
                         
                    }
                }
            }
        }
        
         
    }
    
    /// Handle direct driver location update from socket
    private func handleDirectDriverLocationUpdate(_ locationData: [String: Any]) {
         
        
        // Extract latitude and longitude (required)
        guard let latitude = locationData["latitude"] as? Double,
              let longitude = locationData["longitude"] as? Double else {
             
            return
        }
        
        // Extract optional fields
        let bookingId = locationData["bookingId"] as? String
        let customerId = locationData["customerId"] as? String
        let accuracy = locationData["accuracy"] as? Double
        let heading = locationData["heading"] as? Double
        let speed = locationData["speed"] as? Double
        let timestamp = Date().timeIntervalSince1970
        
         
         
         
         
         
         
         
         
         
        
        // Check if this update is for our booking (if bookingId is provided)
        if let bookingIdString = bookingId,
           let bookingIdInt = Int(bookingIdString),
           bookingIdInt != self.bookingData.bookingId {
             
             
             
            // TEMPORARILY DISABLED FOR TESTING - Remove this comment and uncomment return when booking ID is fixed
            // return
        }
        
        let newCoordinate = CLLocationCoordinate2D(
            latitude: latitude,
            longitude: longitude
        )
        
        // Check if location actually changed (to avoid unnecessary updates)
        // Use a smaller threshold to catch smaller movements
        if let currentLoc = self.currentLocation,
           abs(currentLoc.latitude - newCoordinate.latitude) < 0.0000001,
           abs(currentLoc.longitude - newCoordinate.longitude) < 0.0000001 {
             
            return
        }
        
         
         
         
         
         
        
        // Calculate distance moved for better debugging
        if let currentLoc = self.currentLocation {
            let distance = CLLocation(latitude: currentLoc.latitude, longitude: currentLoc.longitude)
                .distance(from: CLLocation(latitude: newCoordinate.latitude, longitude: newCoordinate.longitude))
             
        }
         
        
        // Snap to route for smoother movement
        let snappedLocation = self.snapToRoute(location: newCoordinate)
        
        // Calculate heading from movement direction if not provided
        var calculatedHeading: CLLocationDirection = 0
        if let providedHeading = heading {
            calculatedHeading = providedHeading
        } else if let lastLoc = self.lastCarLocation {
            // Calculate heading from previous location to current location
            calculatedHeading = self.calculateHeading(from: lastLoc, to: snappedLocation)
        } else if let currentLoc = self.currentLocation {
            // Use current location if lastCarLocation is not set
            calculatedHeading = self.calculateHeading(from: currentLoc, to: snappedLocation)
        }
        
        // Update heading
        self.carHeading = calculatedHeading
        
        // Update current location
        self.currentLocation = snappedLocation
        self.lastCarLocation = snappedLocation
        
        // Update car path trail
        self.updateCarPath(newLocation: snappedLocation)
        
        // Animate car movement
        if let car = self.carAnnotation {
            UIView.animate(withDuration: 0.5, delay: 0, options: [.curveLinear]) {
                car.coordinate = snappedLocation
                car.heading = calculatedHeading
            }
             
        } else {
            // Create car annotation if it doesn't exist
            let carAnnotation = CarAnnotation(coordinate: snappedLocation, heading: calculatedHeading)
            self.carAnnotation = carAnnotation
             
        }
        
        // Always focus on car if user hasn't interacted
        if !self.userHasInteractedWithMap {
            DispatchQueue.main.async {
                self.updateRegionToFocusOnCar()
            }
        }
        
        // Calculate route if needed
        if self.route == nil {
            self.calculateRoute()
        } else {
            self.updateETAFromCurrentLocation()
        }
        
         
         
    }
    
    // MARK: - Status Update Listener
    
    /// Listen for status updates (like driver on location)
    private func setupStatusListener() {
         
        
        // Listen to Socket.IO notifications for status changes
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("RideStatusUpdate"),
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self = self,
                  let userInfo = notification.userInfo,
                  let status = userInfo["status"] as? String else { return }
            
             
             
             
            
            DispatchQueue.main.async {
                let previousStatus = self.rideStatus
                self.rideStatus = status
                
                 
                
                // Handle different status changes comprehensively
                switch status {
                case "on_location":
                    self.isDriverOnLocation = true
                     
                    
                case "en_route_do":
                    self.isDriverOnLocation = false
                     
                    
                case "ended", "completed":
                    print("default case")
                    // The ride completion will be handled by the completion listener
                    
                default:
                    print("default case")
                     
                }
                
                // Handle route transitions based on status changes
                self.handleRouteTransition(from: previousStatus, to: status)
                
                // Update status message based on new status
                self.updateStatusMessage()
                
                // Set manual update flag to prevent timer override
                self.manuallyUpdatedStatus = true
                
                // Force UI update to reflect status changes
                self.objectWillChange.send()
                 
            }
        }
        
         
    }
    
    /// Monitor active ride data changes from socket service
    private func setupActiveRideDataObserver() {
         
        
        // This will be called every second when new data arrives
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            // Check if socket is connected
            if !self.socketService.isConnected {
                 
                self.socketService.ensureConnectionForViewTransition()
                return
            }
            
            if let newData = self.socketService.activeRideData,
               newData.bookingId == self.bookingData.bookingId {
                
                // Check if status has changed
                let statusChanged = newData.status != self.rideStatus
                
                // Check if driver location has changed (if available in active ride data)
                // Note: ActiveRideData might not have driver location, so we'll focus on status changes
                
                 
                 
                
                // Update status if it has changed
                if statusChanged {
                    DispatchQueue.main.async {
                        let previousStatus = self.rideStatus
                        self.rideStatus = newData.status
                        
                         
                        
                        // Handle different status changes
                        switch newData.status {
                        case "on_location":
                            self.isDriverOnLocation = true
                             
                            
                        case "en_route_do":
                            self.isDriverOnLocation = false
                             
                            
                        case "ended", "completed":
                            print("default case")
                            
                        default:
                            print("default case")
                        }
                        
                        // Update status message
                        self.updateStatusMessage()
                        
                        // Handle route transitions
                        self.handleRouteTransition(from: previousStatus, to: newData.status)
                        
                        // Set manual update flag to prevent timer override
                        self.manuallyUpdatedStatus = true
                        
                        // Force UI update
                        self.objectWillChange.send()
                         
                    }
                }
            }
        }
        
         
        
        // Reset manual update flag periodically to allow automatic updates
        Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { [weak self] _ in
            self?.manuallyUpdatedStatus = false
        }
    }
    
    /// Update status message based on current ride status
    private func updateStatusMessage() {
        switch rideStatus {
        case "en_route_pu":
            statusMessage = "Driver is on the way to pickup"
             
            
        case "at_pickup", "on_location":
            statusMessage = "Driver is on Location"
             
            
        case "en_route_do":
            statusMessage = "Heading to destination"
             
            
        case "ended", "completed":
            statusMessage = "Ride completed"
             
            
        default:
            statusMessage = "Status: \(rideStatus)"
             
        }
    }
    
    /// Handle route transitions when ride status changes (matching driver app pattern)
    private func handleRouteTransition(from previousStatus: String, to newStatus: String) {
        print("🔄 Handling route transition from '\(previousStatus)' to '\(newStatus)'")
        
        switch newStatus {
        case "en_route_do":
            if previousStatus != "en_route_do" {
                print("🔄 Transitioning to en_route_do - calculating route to dropoff")
                
                // Mark ride as started
                isRideStarted = true
                
                // Only update car position if driver is not already near pickup location
                if let currentLoc = self.currentLocation {
                    let distanceToPickup = CLLocation(latitude: currentLoc.latitude, longitude: currentLoc.longitude)
                        .distance(from: CLLocation(latitude: self.pickupLocation.latitude, longitude: self.pickupLocation.longitude))
                    
                    // Only move car to pickup if driver is more than 100 meters away
                    if distanceToPickup > 100 {
                        print("🔄 Driver is far from pickup, moving car to pickup location")
                        self.currentLocation = self.pickupLocation
                        
                        // Update car annotation position
                        if let car = self.carAnnotation {
                            UIView.animate(withDuration: 1.0, delay: 0, options: [.curveEaseInOut]) {
                                car.coordinate = self.pickupLocation
                            }
                        }
                    } else {
                        print("🔄 Driver is near pickup, keeping current location")
                    }
                } else {
                    // If no current location, set to pickup
                    self.currentLocation = self.pickupLocation
                }
                
                // Reset user interaction flag to allow proper route display
                self.userHasInteractedWithMap = false
                
                // Calculate route from current location to dropoff
                // Try immediately, then retry after location updates
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    if let currentLoc = self.currentLocation {
                        print("🔄 Current location available, calculating route to dropoff")
                        self.calculateRouteToDropoff()
                    } else {
                        print("🔄 Current location not yet available, using pickup to dropoff route")
                        self.calculateDropoffRoute()
                    }
                }
                
                // Fallback: Calculate route from pickup to dropoff if current location never becomes available
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    if self.route == nil {
                        print("🔄 No route calculated yet, using pickup to dropoff as fallback")
                        self.calculateDropoffRoute()
                    }
                }
                
                // Force map region update after a short delay to ensure route is calculated
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.forceUpdateMapRegion()
                }
            }
            
        case "on_location", "at_pickup":
            print("🔄 Status changed to on_location - no route change needed, just show OTP")
            isDriverOnLocation = true
            hasArrivedAtPickup = true
            // Calculate preview route to show full journey
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.calculatePreviewRoute()
            }
            
        case "en_route_pu":
            print("🔄 Status changed to en_route_pu - calculating route to pickup")
            isDriverOnLocation = false
            
            // Reset user interaction flag to allow proper route display
            self.userHasInteractedWithMap = false
            
            // Calculate route from driver to pickup if needed
            if self.route == nil {
                self.calculateRoute()
            }
            
            // Calculate preview route (pickup to dropoff) to show full journey
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.calculatePreviewRoute()
            }
            
        case "live_ride", "live_ride_do":
            print("🔄 Status changed to live_ride - forcing route calculation")
            
            // Reset user interaction flag to allow proper route display
            self.userHasInteractedWithMap = false
            
            // Force route calculation and region update
            self.calculateRoute()
            
            // Force map region update after route calculation
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.forceUpdateMapRegion()
            }
            
        default:
            print("🔄 Unknown status '\(newStatus)', no route transition")
        }
    }
    
    // MARK: - Socket Connection Monitoring
    
    /// Continuously monitor socket connection and reconnect if needed
    private func startSocketConnectionMonitoring() {
         
        
        // Check connection every 0.5 seconds for more aggressive monitoring
        socketConnectionTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            if !self.socketService.isConnected {
                 
                self.socketService.ensureConnectionForViewTransition()
                
                // Wait 1 second and check again
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    if self.socketService.isConnected {
                         
                    } else {
                         
                    }
                }
            } else {
                 
            }
        }
        
         
    }
    
    /// Start requesting driver location updates from server
    private func startDriverLocationRequesting() {
         
        
        // Request driver location updates every 3 seconds
        driverLocationRequestTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            if self.socketService.isConnected {
                 
                self.requestDriverLocationUpdates()
            } else {
                 
            }
        }
        
         
    }
    
    /// Stop requesting driver location updates
    private func stopDriverLocationRequesting() {
         
        driverLocationRequestTimer?.invalidate()
        driverLocationRequestTimer = nil
    }
    
    /// Stop socket connection monitoring
    private func stopSocketConnectionMonitoring() {
         
//        socketConnectionTimer?.invalidate()
//        socketConnectionTimer = nil
    }
    
    // Snap location to nearest point on route
    private func snapToRoute(location: CLLocationCoordinate2D) -> CLLocationCoordinate2D {
        guard let route = route else { return location }
        
        let points = route.polyline.points()
        let pointCount = route.polyline.pointCount
        let currentPoint = MKMapPoint(location)
        
        var closestPoint: MKMapPoint?
        var minDistance: Double = Double.infinity
        
        // Find closest point on route
        for i in 0..<pointCount {
            let routePoint = points[i]
            let distance = routePoint.distance(to: currentPoint)
            
            if distance < minDistance {
                minDistance = distance
                closestPoint = routePoint
            }
        }
        
        // Snap if within 100m, otherwise use actual location
        if let closest = closestPoint, minDistance < 100 {
            return closest.coordinate
        }
        
        return location
    }
    
    // Calculate heading/bearing from previous location to current location
    private func calculateHeading(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDirection {
        let fromLocation = CLLocation(latitude: from.latitude, longitude: from.longitude)
        let toLocation = CLLocation(latitude: to.latitude, longitude: to.longitude)
        
        let lat1 = from.latitude * .pi / 180.0
        let lat2 = to.latitude * .pi / 180.0
        let deltaLon = (to.longitude - from.longitude) * .pi / 180.0
        
        let y = sin(deltaLon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(deltaLon)
        
        let bearing = atan2(y, x) * 180.0 / .pi
        let normalizedBearing = (bearing + 360.0).truncatingRemainder(dividingBy: 360.0)
        
        return normalizedBearing
    }
    
    // Update car path trail line
    private func updateCarPath(newLocation: CLLocationCoordinate2D) {
        // Add new location to path
        carPathCoordinates.append(newLocation)
        
        // Limit path to last 100 points to avoid performance issues
        if carPathCoordinates.count > 100 {
            carPathCoordinates.removeFirst()
        }
        
        // Create polyline from path coordinates
        if carPathCoordinates.count >= 2 {
            carPathPolyline = MKPolyline(coordinates: carPathCoordinates, count: carPathCoordinates.count)
        }
    }
    
    func calculateRoute() {
         
        
        // Reset user interaction flag to ensure route is properly displayed
        self.userHasInteractedWithMap = false
        
        // Ensure we have valid coordinates before calculating route
        guard CLLocationCoordinate2DIsValid(pickupLocation) && CLLocationCoordinate2DIsValid(dropoffLocation) else {
             
            return
        }
        
        // Determine route based on ride status
        let routeType = getRouteType()
        
        switch routeType {
        case .driverToPickup:
            if let currentLoc = currentLocation, CLLocationCoordinate2DIsValid(currentLoc) {
                calculateDriverToPickupRoute(from: currentLoc)
            } else {
                 
                // Set current location to pickup and calculate route
                self.currentLocation = self.pickupLocation
                calculateDriverToPickupRoute(from: self.pickupLocation)
            }
        case .pickupToDropoff:
            // For pickup to dropoff, always start from pickup location
            calculatePickupToDropoffRoute()
        case .completeRoute:
            if let currentLoc = currentLocation, CLLocationCoordinate2DIsValid(currentLoc) {
                calculateCompleteRoute(from: currentLoc)
            } else {
                 
                // Set current location to pickup and calculate route
                self.currentLocation = self.pickupLocation
                calculateCompleteRoute(from: self.pickupLocation)
            }
        }
        
        // Don't immediately focus on car - let the route calculation handle region updates
        // This ensures the full route is visible
    }
    
    enum RouteType {
        case driverToPickup
        case pickupToDropoff
        case completeRoute
    }
    
    func getRouteType() -> RouteType {
        // Check ride status to determine route type
        switch rideStatus {
        case "en_route_pu":
            return .driverToPickup
        case "at_pickup", "on_location", "en_route_do":
            return .pickupToDropoff
        default:
            // For any other status, show complete route from current location to dropoff
            return .completeRoute
        }
    }
    
    private func calculateDriverToPickupRoute(from currentLoc: CLLocationCoordinate2D) {
         
         
         
        
        let sourcePlacemark = MKPlacemark(coordinate: currentLoc)
        let pickupPlacemark = MKPlacemark(coordinate: pickupLocation)
        
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let pickupMapItem = MKMapItem(placemark: pickupPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceMapItem
        directionRequest.destination = pickupMapItem
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = false
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] response, error in
            guard let self = self else { return }
            
            if let error = error {
                 
                // Fallback to straight line
                self.createDirectLineRoute(from: currentLoc, to: self.pickupLocation)
                return
            }
            
            if let route = response?.routes.first {
                DispatchQueue.main.async {
                    self.route = route
                    
                    self.updateMetricsFromRoute(route)
                    
                    // Update region to show entire route with reasonable padding
                    let routeRegion = MKCoordinateRegion(route.polyline.boundingMapRect)
                    // Add reasonable padding to ensure the route is fully visible
                    let paddedRegion = MKCoordinateRegion(
                        center: routeRegion.center,
                        span: MKCoordinateSpan(
                            latitudeDelta: max(routeRegion.span.latitudeDelta * 1.2, 0.01), // Ensure minimum zoom level
                            longitudeDelta: max(routeRegion.span.longitudeDelta * 1.2, 0.01)
                        )
                    )
                    self.region = paddedRegion
                    
                    // Force map view update to show the route
                    DispatchQueue.main.async {
                        // Post notification to update map view
                        NotificationCenter.default.post(name: NSNotification.Name("RouteUpdated"), object: nil)
                    }
                    
                     
                }
            } else {
                 
                // Fallback to straight line
                self.createDirectLineRoute(from: currentLoc, to: self.pickupLocation)
            }
        }
    }
    
    private func calculatePickupToDropoffRoute() {
        // For pickup→dropoff route, always start from pickup location
        let startLocation = pickupLocation
        
         
         
         
        
        let startPlacemark = MKPlacemark(coordinate: startLocation)
        let dropoffPlacemark = MKPlacemark(coordinate: dropoffLocation)
        
        let startMapItem = MKMapItem(placemark: startPlacemark)
        let dropoffMapItem = MKMapItem(placemark: dropoffPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = startMapItem
        directionRequest.destination = dropoffMapItem
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = false
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] response, error in
            guard let self = self else { return }
            
            if let error = error {
                 
                 
                
                // Try to retry with different transport type if the first attempt fails
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                     
                    self.retryRouteCalculation(from: startLocation, to: self.dropoffLocation)
                }
                return
            }
            
            if let route = response?.routes.first {
                DispatchQueue.main.async {
                    self.route = route
                    
                    self.updateMetricsFromRoute(route)
                    
                    // Update region to show entire route with reasonable padding
                    let routeRegion = MKCoordinateRegion(route.polyline.boundingMapRect)
                    // Add reasonable padding to ensure the route is fully visible
                    let paddedRegion = MKCoordinateRegion(
                        center: routeRegion.center,
                        span: MKCoordinateSpan(
                            latitudeDelta: max(routeRegion.span.latitudeDelta * 1.2, 0.01), // Ensure minimum zoom level
                            longitudeDelta: max(routeRegion.span.longitudeDelta * 1.2, 0.01)
                        )
                    )
                    self.region = paddedRegion
                    
                    // Force map view update to show the route
                    DispatchQueue.main.async {
                        // Trigger a map view update by updating the region
                        self.objectWillChange.send()
                        
                        // Post notification to update map view
                        NotificationCenter.default.post(name: NSNotification.Name("RouteUpdated"), object: nil)
                    }
                    
                     
                }
            } else {
                 
                // Fallback to straight line
                self.createDirectLineRoute(from: startLocation, to: self.dropoffLocation)
            }
        }
    }
    
    private func calculateCompleteRoute(from currentLoc: CLLocationCoordinate2D) {
         
        
        // Create a route that goes through all three points
        let coordinates = [currentLoc, pickupLocation, dropoffLocation]
        let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
        
        DispatchQueue.main.async {
            self.route = MKRoute()
            // We'll use a custom polyline for the complete route
            self.createCustomRoutePolyline(polyline)
            
            // Calculate total distance
            let totalDistance = self.calculateTotalDistance()
            // Estimate time (assuming 40 km/h average speed)
            let estimatedSeconds = (totalDistance / 1000) / 40 * 3600
            self.updateMetricsFromFallback(distanceMeters: totalDistance, durationSeconds: estimatedSeconds)
            
            // Update region to show all three points
            self.updateRegionToShowAllPoints()
            
             
             
        }
    }
    
    private func createCustomRoutePolyline(_ polyline: MKPolyline) {
        // Store the custom polyline for rendering
        // We'll use this in the map view renderer
        self.customRoutePolyline = polyline
    }
    
    private func retryRouteCalculation(from start: CLLocationCoordinate2D, to end: CLLocationCoordinate2D) {
         
        
        let startPlacemark = MKPlacemark(coordinate: start)
        let endPlacemark = MKPlacemark(coordinate: end)
        
        let startMapItem = MKMapItem(placemark: startPlacemark)
        let endMapItem = MKMapItem(placemark: endPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = startMapItem
        directionRequest.destination = endMapItem
        directionRequest.transportType = .any // Try with any transport type
        directionRequest.requestsAlternateRoutes = true // Allow alternate routes
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] response, error in
            guard let self = self else { return }
            
            if let error = error {
                 
                 
                self.createDirectLineRoute(from: start, to: end)
                return
            }
            
            if let route = response?.routes.first {
                DispatchQueue.main.async {
                    self.route = route
                    
                    self.updateMetricsFromRoute(route)
                    
                    // Update region to show entire route with reasonable padding
                    let routeRegion = MKCoordinateRegion(route.polyline.boundingMapRect)
                    let paddedRegion = MKCoordinateRegion(
                        center: routeRegion.center,
                        span: MKCoordinateSpan(
                            latitudeDelta: max(routeRegion.span.latitudeDelta * 1.2, 0.01),
                            longitudeDelta: max(routeRegion.span.longitudeDelta * 1.2, 0.01)
                        )
                    )
                    self.region = paddedRegion
                    
                     
                }
            } else {
                 
                self.createDirectLineRoute(from: start, to: end)
            }
        }
    }
    
    private func createDirectLineRoute(from start: CLLocationCoordinate2D, to end: CLLocationCoordinate2D) {
         
        
        let coordinates = [start, end]
        let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
        
        DispatchQueue.main.async {
            self.route = MKRoute()
            self.customRoutePolyline = polyline
            
            // Calculate straight line distance
            let distance = CLLocation(latitude: start.latitude, longitude: start.longitude)
                .distance(from: CLLocation(latitude: end.latitude, longitude: end.longitude))
            
            // Estimate time (assuming 40 km/h average speed)
            let estimatedSeconds = (distance / 1000) / 40 * 3600
            self.updateMetricsFromFallback(distanceMeters: distance, durationSeconds: estimatedSeconds)
            
            // Update region
            let region = MKCoordinateRegion(coordinates: coordinates)
            self.region = region
            
             
        }
    }
    
    private func calculateTotalDistance() -> Double {
        guard let currentLoc = currentLocation else { return 0 }
        
        // Calculate distance from driver to pickup
        let driverToPickup = CLLocation(latitude: currentLoc.latitude, longitude: currentLoc.longitude)
            .distance(from: CLLocation(latitude: pickupLocation.latitude, longitude: pickupLocation.longitude))
        
        // Calculate distance from pickup to dropoff
        let pickupToDropoff = CLLocation(latitude: pickupLocation.latitude, longitude: pickupLocation.longitude)
            .distance(from: CLLocation(latitude: dropoffLocation.latitude, longitude: dropoffLocation.longitude))
        
        return driverToPickup + pickupToDropoff
    }
    
    // MARK: - Route Calculation Methods (matching driver app)
    
    /// Calculate route from current location to dropoff (for ride in progress)
    func calculateRouteToDropoff() {
        guard let currentLoc = currentLocation else {
            print("❌ Current location not available for route calculation to dropoff")
            // Fallback to pickup to dropoff route
            calculateDropoffRoute()
            return
        }
        
        print("🗺️ Calculating route from current location to dropoff location")
        print("   From: (\(String(format: "%.6f", currentLoc.latitude)), \(String(format: "%.6f", currentLoc.longitude)))")
        print("   To Dropoff: (\(String(format: "%.6f", dropoffLocation.latitude)), \(String(format: "%.6f", dropoffLocation.longitude)))")
        
        // Validate coordinates
        guard CLLocationCoordinate2DIsValid(currentLoc) && CLLocationCoordinate2DIsValid(dropoffLocation) else {
            print("❌ Invalid coordinates for dropoff route")
            calculateDropoffRoute()
            return
        }
        
        guard currentLoc.latitude != 0.0 && currentLoc.longitude != 0.0,
              dropoffLocation.latitude != 0.0 && dropoffLocation.longitude != 0.0 else {
            print("❌ Zero coordinates for dropoff route")
            calculateDropoffRoute()
            return
        }
        
        let sourcePlacemark = MKPlacemark(coordinate: currentLoc)
        let dropoffPlacemark = MKPlacemark(coordinate: dropoffLocation)
        
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let dropoffMapItem = MKMapItem(placemark: dropoffPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = sourceMapItem
        directionRequest.destination = dropoffMapItem
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = false
        
        print("🗺️ Requesting directions from Apple Maps (current location to dropoff)...")
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] response, error in
            guard let self = self else { return }
            
            if let error = error {
                print("❌ Error calculating route to dropoff: \(error.localizedDescription)")
                // Fallback to pickup to dropoff route
                self.calculateDropoffRoute()
                return
            }
            
            guard let response = response else {
                print("❌ No response from directions service")
                self.calculateDropoffRoute()
                return
            }
            
            print("🗺️ Directions response received with \(response.routes.count) routes")
            
            if let route = response.routes.first {
                DispatchQueue.main.async {
                    print("🗺️ Setting dropoff route: \(route.polyline.pointCount) points")
                    self.route = route
                    
                    // Update estimates
                    let minutes = Int(route.expectedTravelTime / 60)
                    self.estimatedTime = "\(minutes) Min"
                    
                    let kilometers = route.distance / 1000
                    self.distance = String(format: "%.1fkm", kilometers)
                    
                    // Update region to show entire route with proper padding
                    let routeRegion = MKCoordinateRegion(route.polyline.boundingMapRect)
                    let paddedRegion = MKCoordinateRegion(
                        center: routeRegion.center,
                        span: MKCoordinateSpan(
                            latitudeDelta: routeRegion.span.latitudeDelta * 1.2,
                            longitudeDelta: routeRegion.span.longitudeDelta * 1.2
                        )
                    )
                    self.region = paddedRegion
                    
                    // Reset user interaction flag to allow proper route display
                    self.userHasInteractedWithMap = false
                    
                    // Post notification to update map view
                    NotificationCenter.default.post(name: NSNotification.Name("RouteUpdated"), object: nil)
                    
                    print("✅ Dropoff route calculated: \(minutes) minutes, \(kilometers)km")
                }
            } else {
                print("❌ No routes found in response")
                self.calculateDropoffRoute()
            }
        }
    }
    
    /// Calculate route from pickup to dropoff (fallback method)
    func calculateDropoffRoute() {
        print("🗺️ Calculating route from pickup to dropoff location")
        print("   From Pickup: (\(String(format: "%.6f", pickupLocation.latitude)), \(String(format: "%.6f", pickupLocation.longitude)))")
        print("   To Dropoff: (\(String(format: "%.6f", dropoffLocation.latitude)), \(String(format: "%.6f", dropoffLocation.longitude)))")
        
        // Validate coordinates
        guard CLLocationCoordinate2DIsValid(pickupLocation) && CLLocationCoordinate2DIsValid(dropoffLocation) else {
            print("❌ Invalid coordinates for dropoff route")
            return
        }
        
        guard pickupLocation.latitude != 0.0 && pickupLocation.longitude != 0.0,
              dropoffLocation.latitude != 0.0 && dropoffLocation.longitude != 0.0 else {
            print("❌ Zero coordinates for dropoff route")
            return
        }
        
        let pickupPlacemark = MKPlacemark(coordinate: pickupLocation)
        let dropoffPlacemark = MKPlacemark(coordinate: dropoffLocation)
        
        let pickupMapItem = MKMapItem(placemark: pickupPlacemark)
        let dropoffMapItem = MKMapItem(placemark: dropoffPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = pickupMapItem
        directionRequest.destination = dropoffMapItem
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = false
        
        print("🗺️ Requesting directions from Apple Maps...")
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] response, error in
            guard let self = self else { return }
            
            if let error = error {
                print("❌ Error calculating dropoff route: \(error.localizedDescription)")
                return
            }
            
            guard let response = response else {
                print("❌ No response from directions service")
                return
            }
            
            print("🗺️ Directions response received with \(response.routes.count) routes")
            
            if let route = response.routes.first {
                DispatchQueue.main.async {
                    print("🗺️ Setting dropoff route: \(route.polyline.pointCount) points")
                    self.route = route
                    
                    // Update estimates
                    let minutes = Int(route.expectedTravelTime / 60)
                    self.estimatedTime = "\(minutes) Min"
                    
                    let kilometers = route.distance / 1000
                    self.distance = String(format: "%.1fkm", kilometers)
                    
                    // Update region to show entire route with proper padding
                    let routeRegion = MKCoordinateRegion(route.polyline.boundingMapRect)
                    let paddedRegion = MKCoordinateRegion(
                        center: routeRegion.center,
                        span: MKCoordinateSpan(
                            latitudeDelta: routeRegion.span.latitudeDelta * 1.2,
                            longitudeDelta: routeRegion.span.longitudeDelta * 1.2
                        )
                    )
                    self.region = paddedRegion
                    
                    // Reset user interaction flag to allow proper route display
                    self.userHasInteractedWithMap = false
                    
                    // Post notification to update map view
                    NotificationCenter.default.post(name: NSNotification.Name("RouteUpdated"), object: nil)
                    
                    print("✅ Dropoff route calculated: \(minutes) minutes, \(kilometers)km")
                }
            } else {
                print("❌ No routes found in response")
            }
        }
    }
    
    /// Calculate preview route (pickup to dropoff) - shown as light grey line (matching driver app)
    func calculatePreviewRoute() {
        print("🗺️ ===== CALCULATING PREVIEW ROUTE =====")
        print("🗺️ Calculating preview route from pickup to dropoff")
        print("   From Pickup: (\(String(format: "%.6f", pickupLocation.latitude)), \(String(format: "%.6f", pickupLocation.longitude)))")
        print("   To Dropoff: (\(String(format: "%.6f", dropoffLocation.latitude)), \(String(format: "%.6f", dropoffLocation.longitude)))")
        
        // Validate coordinates
        guard CLLocationCoordinate2DIsValid(pickupLocation) && CLLocationCoordinate2DIsValid(dropoffLocation) else {
            print("❌ Invalid coordinates for preview route")
            return
        }
        
        guard pickupLocation.latitude != 0.0 && pickupLocation.longitude != 0.0,
              dropoffLocation.latitude != 0.0 && dropoffLocation.longitude != 0.0 else {
            print("❌ Zero coordinates for preview route")
            return
        }
        
        print("✅ All coordinate validations passed for preview route")
        
        let pickupPlacemark = MKPlacemark(coordinate: pickupLocation)
        let dropoffPlacemark = MKPlacemark(coordinate: dropoffLocation)
        
        let pickupMapItem = MKMapItem(placemark: pickupPlacemark)
        let dropoffMapItem = MKMapItem(placemark: dropoffPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = pickupMapItem
        directionRequest.destination = dropoffMapItem
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = false
        
        print("🗺️ Requesting preview route directions from Apple Maps...")
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] response, error in
            guard let self = self else { return }
            
            if let error = error {
                print("❌ Error calculating preview route: \(error.localizedDescription)")
                return
            }
            
            guard let response = response else {
                print("❌ No response from directions service for preview route")
                return
            }
            
            print("🗺️ Preview route directions response received with \(response.routes.count) routes")
            
            if let route = response.routes.first {
                DispatchQueue.main.async {
                    print("🗺️ Setting preview route: \(route.polyline.pointCount) points")
                    // Store preview route separately (matching driver app pattern)
                    self.previewRoute = route
                    
                    // Only use as main route if no active route exists
                    if self.route == nil {
                        self.route = route
                    }
                    
                    // Update map region to show the preview route
                    let routeRegion = MKCoordinateRegion(route.polyline.boundingMapRect)
                    let paddedRegion = MKCoordinateRegion(
                        center: routeRegion.center,
                        span: MKCoordinateSpan(
                            latitudeDelta: routeRegion.span.latitudeDelta * 1.3,
                            longitudeDelta: routeRegion.span.longitudeDelta * 1.3
                        )
                    )
                    self.region = paddedRegion
                    
                    // Post notification to update map view
                    NotificationCenter.default.post(name: NSNotification.Name("RouteUpdated"), object: nil)
                    
                    print("✅ Preview route calculated: \(Int(route.expectedTravelTime / 60)) minutes, \(String(format: "%.1f", route.distance / 1000))km")
                }
            } else {
                print("❌ No routes found in preview route response")
            }
        }
    }
    
    private func updateRegionToShowAllPoints() {
        // Use currentLocation if available, otherwise use pickupLocation as fallback
        let currentLoc = currentLocation ?? pickupLocation
        
        let coordinates = [currentLoc, pickupLocation, dropoffLocation]
        let region = MKCoordinateRegion(coordinates: coordinates)
        
        // Add reasonable padding to ensure all points are clearly visible
        let paddedRegion = MKCoordinateRegion(
            center: region.center,
            span: MKCoordinateSpan(
                latitudeDelta: max(region.span.latitudeDelta * 1.2, 0.01), // Ensure minimum zoom level
                longitudeDelta: max(region.span.longitudeDelta * 1.2, 0.01)
            )
        )
        self.region = paddedRegion
        
         
         
         
    }
    
    private func updateRegionToFocusOnCar() {
        guard let currentLoc = currentLocation else { 
             
            return 
        }
        
        // Focus on car location with good zoom level for clear visibility
        // Using smaller span for closer zoom to clearly see car and surrounding area
        let region = MKCoordinateRegion(
            center: currentLoc,
            span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005) // Closer zoom for better car visibility
        )
        self.region = region
        
        // Force immediate region update
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: NSNotification.Name("MapRegionUpdate"), object: nil)
        }
    }
    
    /// Force update map region to show route (useful for debugging)
    func forceUpdateMapRegion() {
         
        
        // Reset user interaction flag to ensure region update is applied
        self.userHasInteractedWithMap = false
        
        if let route = route {
            let routeRegion = MKCoordinateRegion(route.polyline.boundingMapRect)
            let paddedRegion = MKCoordinateRegion(
                center: routeRegion.center,
                span: MKCoordinateSpan(
                    latitudeDelta: max(routeRegion.span.latitudeDelta * 1.2, 0.01), // Reasonable padding with minimum zoom
                    longitudeDelta: max(routeRegion.span.longitudeDelta * 1.2, 0.01)
                )
            )
            self.region = paddedRegion
             
        } else {
            // If no route, show all important points
            updateRegionToShowAllPoints()
        }
    }
    
    func stopTracking() {
        locationManager.stopUpdatingLocation()
        locationUpdateTimer?.invalidate()
        locationUpdateTimer = nil
        
        // Stop socket connection monitoring
        stopSocketConnectionMonitoring()
        
        // Stop driver location requesting
        stopDriverLocationRequesting()
        
        // Remove notification observers
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("DriverLocationUpdate"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("RideStatusUpdate"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("SocketEventReceived"), object: nil)
        
         
         
         
         
    }
    
    /// Reset map interaction flag to allow auto-following again
    func resetMapInteraction() {
        userHasInteractedWithMap = false
         
    }
    
    /// Force reset map interaction and update region to show route properly
    func forceResetMapAndShowRoute() {
        userHasInteractedWithMap = false
         
        
        // Force update the map region to show the route properly
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.forceUpdateMapRegion()
        }
    }
    
    
    // MARK: - Test Methods for Car Movement
    
    /// Test method to simulate driver location updates (for debugging)
    func simulateDriverLocationUpdates() {
         
        
        // Simulate driver moving from pickup to dropoff
        let pickupLat = pickupLocation.latitude
        let pickupLng = pickupLocation.longitude
        let dropoffLat = dropoffLocation.latitude
        let dropoffLng = dropoffLocation.longitude
        
        // Create a path with intermediate points
        let steps = 10
        let latStep = (dropoffLat - pickupLat) / Double(steps)
        let lngStep = (dropoffLng - pickupLng) / Double(steps)
        
        for i in 0...steps {
            let testLat = pickupLat + (latStep * Double(i))
            let testLng = pickupLng + (lngStep * Double(i))
            
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 2.0) {
                // Create a simulated DriverLocationUpdate
                let locationUpdate = DriverLocationUpdate(
                    latitude: testLat,
                    longitude: testLng,
                    bookingId: String(self.bookingData.bookingId),
                    customerId: nil, // BookingNotificationData doesn't have customerId
                    accuracy: 10.0,
                    heading: Double(i * 36), // Rotate 36 degrees each step
                    speed: 25.0,
                    timestamp: Date().timeIntervalSince1970
                )
                
                // Post the notification
                NotificationCenter.default.post(
                    name: NSNotification.Name("DriverLocationUpdate"),
                    object: nil,
                    userInfo: ["locationUpdate": locationUpdate]
                )
                
                 
            }
        }
        
         
    }
    
    /// Force socket reconnection and ensure driver location listening is active
//    func forceSocketReconnection() {
//         
//        
//        // Disconnect and reconnect socket
////        socketService.disconnect()
//        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
//            self.socketService.connect()
//            
//            // Wait for connection and re-setup listeners
//            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
//                if self.socketService.isConnected {
//                     
//                    
//                    // Re-setup driver location listener
//                    self.setupDriverLocationListener()
//                     
//                } else {
//                     
//                }
//            }
//        }
//    }
    
    /// Test if socket is receiving events by emitting a test event
    func testSocketConnection() {
         
    
        // Also test with a simulated driver location update
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            let testLocationUpdate = DriverLocationUpdate(
                latitude: self.pickupLocation.latitude + 0.001,
                longitude: self.pickupLocation.longitude + 0.001,
                bookingId: String(self.bookingData.bookingId),
                customerId: "1146",
                accuracy: 10.0,
                heading: 45.0,
                speed: 25.0,
                timestamp: Date().timeIntervalSince1970
            )
            
            NotificationCenter.default.post(
                name: NSNotification.Name("DriverLocationUpdate"),
                object: nil,
                userInfo: ["locationUpdate": testLocationUpdate]
            )
            
             
        }
    }
    
    /// Request driver location updates from server
    func requestDriverLocationUpdates() {
         
        
        // Emit a request for driver location updates
        let requestData: [String: Any] = [
            "bookingId": String(bookingData.bookingId),
            "customerId": "1146", // Use the user ID from the logs
            "requestType": "driver_location_updates",
            "timestamp": Date().timeIntervalSince1970
        ]
        
        // Use the socket service to emit the request
        socketService.emitEvent(eventName: "request_driver_location", data: requestData)
         
    }
    
    /// Listen to all socket events for debugging
    func startSocketEventDebugging() {
         
        
        // Listen to all socket events
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("SocketEventReceived"),
            object: nil,
            queue: .main
        ) { notification in
            if let userInfo = notification.userInfo,
               let eventName = userInfo["eventName"] as? String,
               let data = userInfo["data"] as? [Any] {
                 
                 
                
                // Check if it's a driver location update
                if eventName == "driver.location.update" {
                     
                     
                }
            }
        }
        
         
    }
    
    /// Test direct socket listener with simulated driver location update
    func testDirectSocketListener() {
         
        
        // Create a simulated driver location update
        let testLocationData: [String: Any] = [
            "latitude": pickupLocation.latitude + 0.001,
            "longitude": pickupLocation.longitude + 0.001,
            "bookingId": String(bookingData.bookingId),
            "customerId": "1146",
            "accuracy": 10.0,
            "heading": 45.0,
            "speed": 25.0
        ]
        
        // Simulate receiving the event
        let testData = [testLocationData]
        
        // Post the socket event notification
        NotificationCenter.default.post(
            name: NSNotification.Name("SocketEventReceived"),
            object: nil,
            userInfo: [
                "eventName": "driver.location.update",
                "data": testData
            ]
        )
        
         
    }
    
}

// MARK: - Location Manager Delegate
extension RideInProgressViewModel: CLLocationManagerDelegate {
    private func updateETAFromCurrentLocation() {
        guard !prefersGoogleBookingMetrics else { return }
        guard let currentLoc = currentLocation else { return }
        
        // Calculate remaining distance to pickup location
        let currentLocation = CLLocation(latitude: currentLoc.latitude, longitude: currentLoc.longitude)
        let pickupLocation = CLLocation(latitude: self.pickupLocation.latitude, longitude: self.pickupLocation.longitude)
        let remainingDistance = currentLocation.distance(from: pickupLocation)
        
        // Update distance display
        let kilometers = remainingDistance / 1000
        self.distance = String(format: "%.1fkm", kilometers)
        
        // Estimate time based on average speed (assuming 40 km/h in city)
        let estimatedSeconds = (remainingDistance / 1000) / 40 * 3600
        let totalMinutes = Int(estimatedSeconds / 60)
        
        // Format time as hours and minutes
        if totalMinutes >= 60 {
            let hours = totalMinutes / 60
            let remainingMinutes = totalMinutes % 60
            if remainingMinutes > 0 {
                self.estimatedTime = "\(hours) hour \(remainingMinutes) min"
            } else {
                self.estimatedTime = "\(hours) hour"
            }
        } else {
            self.estimatedTime = "\(totalMinutes) min"
        }
        
         
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
         
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
         
        
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
             
            manager.startUpdatingLocation()
        case .denied, .restricted:
            print("default case")
        case .notDetermined:
            print("default case")
        @unknown default:
            print("default case")
        }
    }
}

// MARK: - Map View with Route
struct RideMapView: UIViewRepresentable {
    @ObservedObject var viewModel: RideInProgressViewModel
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = false // Hide default blue dot - we'll show custom car
        mapView.isRotateEnabled = true
        mapView.isPitchEnabled = true
        mapView.showsCompass = true
        mapView.showsScale = true
        
         
         
         
        
        // Set initial region immediately
        mapView.setRegion(viewModel.region, animated: false)
         
        
        // Add car annotation if we have a location
        if let location = viewModel.currentLocation {
            let carAnnotation = CarAnnotation(coordinate: location)
            viewModel.carAnnotation = carAnnotation
            mapView.addAnnotation(carAnnotation)
             
        }
        
        // Listen for annotation refresh notifications
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("RefreshMapAnnotations"),
            object: nil,
            queue: .main
        ) { _ in
             
            // Force map view to refresh
            mapView.setNeedsDisplay()
        }
        
        // Listen for route update notifications
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("RouteUpdated"),
            object: nil,
            queue: .main
        ) { _ in
             
            // Force map view to refresh overlays
            mapView.setNeedsDisplay()
        }
        
        // Listen for map region update notifications
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("MapRegionUpdate"),
            object: nil,
            queue: .main
        ) { _ in
            // Update map region to focus on car
            if !self.viewModel.userHasInteractedWithMap, let currentLoc = self.viewModel.currentLocation {
                let carRegion = MKCoordinateRegion(
                    center: currentLoc,
                    span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
                )
                mapView.setRegion(carRegion, animated: true)
            }
        }
        
        return mapView
    }
    
    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Update car annotation position and rotation to match heading
        if let location = viewModel.currentLocation {
            if let carAnnotation = viewModel.carAnnotation {
                // Track whether we need to refresh the annotation view
                let locationChanged = abs(carAnnotation.coordinate.latitude - location.latitude) > 0.00001 ||
                                      abs(carAnnotation.coordinate.longitude - location.longitude) > 0.00001
                let headingChanged = abs(carAnnotation.heading - viewModel.carHeading) > 1.0
                
                if locationChanged || headingChanged {
                    carAnnotation.coordinate = location
                    carAnnotation.heading = viewModel.carHeading
                    
                    // Rotate the visible annotation view so the car faces travel direction
                    if let annotationView = mapView.view(for: carAnnotation) {
                        let rotation = CGFloat(viewModel.carHeading * .pi / 180)
                        annotationView.transform = CGAffineTransform(rotationAngle: rotation)
                    }
                }
            } else {
                // Create car annotation if it doesn't exist
                let carAnnotation = CarAnnotation(coordinate: location, heading: viewModel.carHeading)
                viewModel.carAnnotation = carAnnotation
                mapView.addAnnotation(carAnnotation)
            }
        }
        
        // Update route overlays - show both preview and active routes (matching driver app)
        print("🗺️ ===== UPDATING MAP OVERLAYS =====")
        print("🗺️ MapView: Preview route available: \(viewModel.previewRoute != nil)")
        print("🗺️ MapView: Active route available: \(viewModel.route != nil)")
        print("🗺️ MapView: Ride started: \(viewModel.isRideStarted)")
        
        // Remove all existing overlays first
        mapView.removeOverlays(mapView.overlays)
        print("🗺️ MapView: Removed existing overlays")
        
        var hasOverlays = false
        
        // Add preview route (light grey) if available and ride not started (matching driver app)
        if let previewRoute = viewModel.previewRoute, !viewModel.isRideStarted {
            mapView.addOverlay(previewRoute.polyline, level: .aboveRoads)
            print("🗺️ MapView: ✅ Added preview route overlay (light grey) - pickup to dropoff")
            print("🗺️ MapView: Preview route has \(previewRoute.polyline.pointCount) points")
            hasOverlays = true
        } else {
            print("🗺️ MapView: ❌ Not adding preview route - previewRoute: \(viewModel.previewRoute != nil), rideStarted: \(viewModel.isRideStarted)")
        }
        
        // Add active route (dark) if available
        if let route = viewModel.route {
            mapView.addOverlay(route.polyline, level: .aboveRoads)
            print("🗺️ MapView: ✅ Added active route overlay (dark) with \(route.polyline.pointCount) points")
            hasOverlays = true
        } else {
            print("🗺️ MapView: ❌ No active route to add")
        }
        
        // Add custom polyline if no regular route
        if let customPolyline = viewModel.customRoutePolyline, viewModel.route == nil {
            mapView.addOverlay(customPolyline, level: .aboveRoads)
            hasOverlays = true
        }
        
        // Add car path trail line only when NOT on pickup-to-dropoff route
        // This prevents overlap with the route line
        let routeType = viewModel.getRouteType()
        if routeType != .pickupToDropoff, let carPath = viewModel.carPathPolyline {
            // Only show car path when driver is heading to pickup (en_route_pu)
            // Don't show when on pickup-to-dropoff route to avoid overlap
            // Remove old car path if exists
            mapView.removeOverlay(carPath)
            // Add car path with higher level to be on top
            mapView.addOverlay(carPath, level: .aboveLabels)
            hasOverlays = true
        } else if routeType == .pickupToDropoff, let carPath = viewModel.carPathPolyline {
            // Remove car path when on pickup-to-dropoff route to avoid overlap
            mapView.removeOverlay(carPath)
        }
        
        // Remove all overlays if no route and no car path
        if !hasOverlays {
            mapView.removeOverlays(mapView.overlays)
        }
        
        // Add pickup location annotation once
        let hasPickup = mapView.annotations.contains { annotation in
            if let point = annotation as? MKPointAnnotation {
                return point.title == "Pickup Location"
            }
            return false
        }
        
        if !hasPickup {
            let pickupAnnotation = MKPointAnnotation()
            pickupAnnotation.coordinate = viewModel.pickupLocation
            pickupAnnotation.title = "Pickup Location"
            // Ensure we have a proper address to display
            let pickupAddress = viewModel.bookingData.pickupAddress.isEmpty ? "Pickup Location" : viewModel.bookingData.pickupAddress
            pickupAnnotation.subtitle = pickupAddress
            mapView.addAnnotation(pickupAnnotation)
             
        }
        
        // Add dropoff location annotation once
        let hasDropoff = mapView.annotations.contains { annotation in
            if let point = annotation as? MKPointAnnotation {
                return point.title == "Drop-off Location"
            }
            return false
        }
        
        if !hasDropoff {
            let dropoffAnnotation = MKPointAnnotation()
            dropoffAnnotation.coordinate = viewModel.dropoffLocation
            dropoffAnnotation.title = "Drop-off Location"
            // Ensure we have a proper address to display
            let dropoffAddress = viewModel.bookingData.dropoffAddress.isEmpty ? "Drop-off Location" : viewModel.bookingData.dropoffAddress
            dropoffAnnotation.subtitle = dropoffAddress
            mapView.addAnnotation(dropoffAnnotation)
             
        }
        
        // Always focus on car if user hasn't interacted with map
        if !viewModel.userHasInteractedWithMap, let currentLoc = viewModel.currentLocation {
            // Calculate distance between current map center and car location
            let currentCenter = CLLocation(
                latitude: mapView.region.center.latitude,
                longitude: mapView.region.center.longitude
            )
            let carLocation = CLLocation(
                latitude: currentLoc.latitude,
                longitude: currentLoc.longitude
            )
            let distanceFromCar = currentCenter.distance(from: carLocation)
            
            // Always focus on car directly with close zoom for clear visibility
            // Update if map is not focused on car (more than 50 meters away)
            if distanceFromCar > 50 {
                let carRegion = MKCoordinateRegion(
                    center: currentLoc,
                    span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005) // Close zoom for car visibility
                )
                mapView.setRegion(carRegion, animated: true)
                viewModel.region = carRegion
            }
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: RideMapView
        
        init(_ parent: RideMapView) {
            self.parent = parent
        }
        
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let polyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: polyline)
                
                // Check if this is the car path trail
                if overlay === parent.viewModel.carPathPolyline {
                    // Light black/gray trail line showing car's movement path
                    renderer.strokeColor = UIColor.black.withAlphaComponent(0.4)
                    renderer.lineWidth = 3
                    renderer.alpha = 0.6
                    renderer.lineCap = .round
                    renderer.lineJoin = .round
                    return renderer
                }
                
                // Check if this is the preview route (matching driver app pattern)
                if let previewRoute = parent.viewModel.previewRoute,
                   overlay === previewRoute.polyline as? MKPolyline {
                    // Light grey line for preview route (pickup to dropoff)
                    renderer.strokeColor = UIColor.lightGray
                    renderer.lineWidth = 4
                    renderer.alpha = 0.5
                    renderer.lineCap = .round
                    renderer.lineJoin = .round
                    print("🗺️ Rendering preview route with light grey color")
                    return renderer
                }
                
                // Determine route type and styling for active route lines
                let routeType = parent.viewModel.getRouteType()
                
                switch routeType {
                case .driverToPickup:
                    // Solid blue line for driver to pickup
                    renderer.strokeColor = UIColor.systemBlue
                    renderer.lineWidth = 6
                    renderer.alpha = 1.0
                     
                    
                case .pickupToDropoff:
                    // Dark line for pickup to dropoff (active route)
                    renderer.strokeColor = UIColor.black
                    renderer.lineWidth = 5
                    renderer.alpha = 1.0
                     
                    
                case .completeRoute:
                    // Solid black line for complete route
                    renderer.strokeColor = UIColor.black
                    renderer.lineWidth = 5
                    renderer.alpha = 1.0
                     
                }
                
                renderer.lineCap = .round
                renderer.lineJoin = .round
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
        
        func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
            // This gets called when user location updates on the map
            let coord = userLocation.coordinate
             
             
             
            
            // Update parent's view model
            parent.viewModel.currentLocation = coord
        }
        
        func mapView(_ mapView: MKMapView, didChange mode: MKUserTrackingMode, animated: Bool) {
             
            switch mode {
            case .none:
                print("default case")
            case .follow:
                print("default case")
            case .followWithHeading:
                print("default case")
            @unknown default:
                print("default case")
            }
        }
        
        func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
            // Detect if user manually changed the map region (zoom/pan)
            if animated {
                // This was likely a programmatic change, not user interaction
                return
            }
            
            // Mark that user has interacted with the map
            DispatchQueue.main.async {
                self.parent.viewModel.userHasInteractedWithMap = true
                 
            }
        }
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            // Handle car annotation
            if let carAnnotation = annotation as? CarAnnotation {
                let identifier = "Car"
                var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
                
                if annotationView == nil {
                    annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                    annotationView?.canShowCallout = false
                    
                    // Use car image from assets
                    if let carImage = UIImage(named: "car") {
                        let size = CGSize(width: 50, height: 50)
                        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
                        carImage.draw(in: CGRect(origin: .zero, size: size))
                        let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
                        UIGraphicsEndImageContext()
                        
                        annotationView?.image = resizedImage
                    } else {
                        // Fallback
                        let config = UIImage.SymbolConfiguration(pointSize: 40, weight: .bold)
                        annotationView?.image = UIImage(systemName: "car.fill", withConfiguration: config)?.withTintColor(.systemBlue, renderingMode: .alwaysOriginal)
                    }
                    
                    annotationView?.centerOffset = CGPoint(x: 0, y: 0)
                } else {
                    annotationView?.annotation = annotation
                }
                
                // Rotate based on heading
                let rotation = CGFloat(carAnnotation.heading * .pi / 180)
                annotationView?.transform = CGAffineTransform(rotationAngle: rotation)
                
                return annotationView
            }
            
            // Handle pickup and dropoff location annotations
            if let pointAnnotation = annotation as? MKPointAnnotation {
                let isPickup = pointAnnotation.title == "Pickup Location"
                let identifier = isPickup ? "Pickup" : "Dropoff"
                var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
                
                if annotationView == nil {
                    annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                    annotationView?.canShowCallout = true
                } else {
                    annotationView?.annotation = annotation
                }
                
                // Ensure callout is enabled and properly configured
                annotationView?.canShowCallout = true
                
                // Custom pin for pickup (green) and dropoff (red) locations with better visibility
                let color: UIColor = isPickup ? .systemGreen : .systemRed
                let config = UIImage.SymbolConfiguration(pointSize: 30, weight: .bold)
                annotationView?.image = UIImage(systemName: "mappin.circle.fill", withConfiguration: config)?.withTintColor(color, renderingMode: .alwaysOriginal)
                
                // Add a small offset to make the pin point to the exact location
                annotationView?.centerOffset = CGPoint(x: 0, y: -15)
                
                return annotationView
            }
            
            return nil
        }
    }
}

// MARK: - Live Ride In Progress View Model
@MainActor
class LiveRideViewModel: ObservableObject {
    @Published var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 30.6942, longitude: 76.7933),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    @Published var driverLocation: CLLocationCoordinate2D
    @Published var driverHeading: CLLocationDirection = 0
    @Published var pickupLocation: CLLocationCoordinate2D
    @Published var dropoffLocation: CLLocationCoordinate2D
    @Published var route: MKRoute?
    @Published var completeRoute: MKPolyline?
    @Published var carPathPolyline: MKPolyline? // Path line showing car's movement trail
    @Published var estimatedTime: String = "Calculating..."
    @Published var distance: String = "..."
    @Published var statusMessage: String = "Driver is on the way"
    @Published var rideOTP: String = "1234" // OTP for ride verification
    @Published var isDriverOnLocation: Bool = false // Track if driver has arrived
    @Published var countdownTime: String = "05:00" // Countdown timer (5 minutes)
    @Published var isCountdownActive: Bool = false // Track if countdown is running
    
    // Map interaction tracking
    @Published var userHasInteractedWithMap: Bool = false
    
    // Car path tracking for trail line
    private var carPathCoordinates: [CLLocationCoordinate2D] = []
    private var lastCarLocationForPath: CLLocationCoordinate2D?
    
    // Flag to control if this ViewModel should handle driver location updates
    @Published var shouldHandleDriverLocationUpdates: Bool = true
    
    // Flag to track if we're receiving real-time socket updates
    @Published var isReceivingSocketUpdates: Bool = false
    
    // Flag to force initial focus on car (important for active_ride)
    @Published var needsInitialFocus: Bool = true
    
    // Debouncing mechanism to prevent excessive view updates
    private var lastViewUpdateTime: Date = Date()
    private let viewUpdateThrottleInterval: TimeInterval = 0.5 // 500ms throttle
    
    // Track last car location to prevent unnecessary map updates
    private var lastCarLocation: CLLocation?
    
    // MARK: - View Update Throttling
    
    /// Throttled view update to prevent excessive refreshes
    private func throttledViewUpdate() {
        let now = Date()
        if now.timeIntervalSince(lastViewUpdateTime) >= viewUpdateThrottleInterval {
            lastViewUpdateTime = now
            
            DispatchQueue.main.async {
                self.objectWillChange.send()
                NotificationCenter.default.post(name: NSNotification.Name("LiveRideDataUpdated"), object: nil)
            }
        }
    }
    
    // Route calculation tracking
    private var isCalculatingRoute: Bool = false
    
    var carAnnotation: CarAnnotation?
    var liveRideData: LiveRideData
    private var manuallyUpdatedStatus: Bool = false // Flag to prevent timer override
    private var countdownTimer: Timer? // Timer for countdown
    private var countdownSeconds: Int = 300 // 5 minutes in seconds (5 * 60)
    
    lazy var socketService = SimpleSocketIOService.shared
    private let vehicleService = VehicleService()
    private var hasCalculatedLiveBookingMetrics = false
    private let prefersGoogleLiveMetrics = true
    
    var driverDisplayName: String {
        if let name = liveRideData.driverName?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty {
            return name
        }
        return "Driver"
    }
    
    var canCallDriver: Bool {
        return sanitizedDriverPhone != nil
    }
    
    private var sanitizedDriverPhone: String? {
        guard let rawPhone = liveRideData.driverPhone?.trimmingCharacters(in: .whitespacesAndNewlines), !rawPhone.isEmpty else {
            return nil
        }
        let allowedCharacters = CharacterSet(charactersIn: "+0123456789")
        let filteredScalars = rawPhone.unicodeScalars.filter { allowedCharacters.contains($0) }
        var filtered = String(filteredScalars)
        let digits = filtered.filter { $0.isNumber }
        guard !digits.isEmpty else { return nil }
        if filtered.hasPrefix("+") {
            return "+" + digits
        } else {
            return digits
        }
    }
    
    func callDriver() {
        guard let phoneNumber = sanitizedDriverPhone,
              let url = URL(string: "tel://\(phoneNumber)") else {
            return
        }
        if UIApplication.shared.canOpenURL(url) {
            DispatchQueue.main.async {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
    }
    
    init(liveRideData: LiveRideData) {
//        print("RideDrive---LiveRideViewModel:init")
      
        self.liveRideData = liveRideData
        self.driverLocation = CLLocationCoordinate2D(
            latitude: liveRideData.driverLatitude,
            longitude: liveRideData.driverLongitude
        )
        self.pickupLocation = CLLocationCoordinate2D(
            latitude: liveRideData.pickupLatitude,
            longitude: liveRideData.pickupLongitude
        )
        self.dropoffLocation = CLLocationCoordinate2D(
            latitude: liveRideData.dropoffLatitude,
            longitude: liveRideData.dropoffLongitude
        )
        
        // Initialize car path with first location
        self.lastCarLocationForPath = self.driverLocation
        self.carPathCoordinates.append(self.driverLocation)
        
        // CRITICAL: Set region to focus on car IMMEDIATELY in initializer
        // This must happen BEFORE any async calls to ensure map shows car on first render
        // Set region synchronously to driver location with close zoom
        self.region = MKCoordinateRegion(
            center: self.driverLocation,
            span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005) // Closer zoom for better visibility
        )
        // Ensure needsInitialFocus is true so map view will focus on first render
        self.needsInitialFocus = true
        
        // Set initial status message based on ride status
        updateStatusMessage()
        
        // Force immediate region update to ensure it's set before map appears
        // Do this synchronously on main thread to ensure it happens before view renders
        self.updateRegionToFocusOnCar()
        
        updateLiveBookingDistanceAndTime(force: true)
        
        // Calculate initial route with a slight delay to ensure map is ready
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
             
             
            self.calculateRoute()
        }
        
        // Also ensure route calculation happens after a longer delay to handle any initialization issues
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            if self.route == nil {
                 
                self.calculateRoute()
            }
        }
        
        // Observe live ride data changes
        setupLiveDataObserver()
        
        // Listen for status updates from on_location notifications
        setupStatusUpdateListener()
        
        // Listen for driver location updates from socket
        setupDriverLocationListener()
        
        socketService.connect()
        
        socketService.ensureConnectionForViewTransition()
        
        // LiveRideViewModel is now active and ready to handle events
         
    
    }
    
    
    private func updateStatusMessage() {
        switch liveRideData.status {
        case "en_route_pu":
            statusMessage = "Driver is on the way to pickup"
            isDriverOnLocation = false
        case "at_pickup", "on_location":
            statusMessage = "Driver is on Location"
            isDriverOnLocation = true
        case "en_route_do":
            statusMessage = "Heading to destination"
            isDriverOnLocation = false
        case "at_dropoff":
            statusMessage = "Arrived at destination"
            isDriverOnLocation = false
        default:
            statusMessage = liveRideData.message
            // Check if status indicates driver is on location
            isDriverOnLocation = liveRideData.status.contains("location") || liveRideData.status.contains("pickup")
        }
    }
    
    private func setupLiveDataObserver() {
         
        
        // This will be called every second when new data arrives
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            // Check if socket is connected
            if !self.socketService.isConnected {
                 
                self.socketService.ensureConnectionForViewTransition()
                return
            }
            
            if let newData = self.socketService.liveRideData,
               newData.bookingId == self.liveRideData.bookingId {
                
                // Check if status has changed
                let statusChanged = newData.status != self.liveRideData.status
                
                // Check if driver location has changed
                let newDriverLocation = CLLocationCoordinate2D(
                    latitude: newData.driverLatitude,
                    longitude: newData.driverLongitude
                )
                
                let locationChanged = newDriverLocation.latitude != self.driverLocation.latitude ||
                                   newDriverLocation.longitude != self.driverLocation.longitude
                
                // Only update if there are real changes and we haven't manually updated status
                if (statusChanged || locationChanged) && !self.manuallyUpdatedStatus {
                     
                    if statusChanged {
                         
                    }
                    if locationChanged {
                         
                    }
                    
                    // Update data
                    DispatchQueue.main.async {
                        // Store previous status for comparison
                        let previousStatus = self.liveRideData.status
                        
                        let pickupChanged = newData.pickupLatitude != self.liveRideData.pickupLatitude ||
                            newData.pickupLongitude != self.liveRideData.pickupLongitude
                        let dropoffChanged = newData.dropoffLatitude != self.liveRideData.dropoffLatitude ||
                            newData.dropoffLongitude != self.liveRideData.dropoffLongitude
                        
                        // Update liveRideData
                        self.liveRideData = newData
                        if pickupChanged || dropoffChanged {
                            self.hasCalculatedLiveBookingMetrics = false
                            self.updateLiveBookingDistanceAndTime(force: true)
                        }
                        
                        if locationChanged {
                            // Don't update driver location from liveRideData when receiving real-time socket updates
                            // This prevents reverting the driver location back to the original position
                            if self.isReceivingSocketUpdates {
                                 
                            } else {
                                 
                                self.driverLocation = newDriverLocation
                            }
                        }
                        
                        // Update car annotation
                        if let car = self.carAnnotation {
                            UIView.animate(withDuration: 1.0, delay: 0, options: [.curveLinear]) {
                                car.coordinate = self.driverLocation // Use current driver location, not newDriverLocation
                            }
                        }
                        
                        // Always update status message when data changes
                        self.updateStatusMessage()
                        
                        // Recalculate route and ETA with current driver location
                        self.calculateRoute()
                        
                        // CRITICAL: Always focus on car when location changes (especially when app is reopened)
                        // This ensures focus when real driver location arrives from socket
                        if !self.userHasInteractedWithMap {
                            self.updateRegionToFocusOnCar()
                            NotificationCenter.default.post(name: NSNotification.Name("MapRegionUpdate"), object: nil)
                        }
                        
                        // If status changed to en_route_do, recalculate route from pickup to dropoff
                        if newData.status == "en_route_do" && previousStatus != "en_route_do" {
                             
                            
                            // Don't override driver location if we're receiving real-time updates
                            // Let the real-time location updates handle the driver position
                             
                            
                            // Calculate new route from pickup to dropoff
                            self.calculateRoute() // This will now calculate pickup→dropoff route
                            
                            // Update region specifically for en_route_do
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                self.updateRegionForEnRouteDo()
                            }
                            
                            // Send specific notification for status change
                            NotificationCenter.default.post(
                                name: NSNotification.Name("RideStatusChanged"),
                                object: nil,
                                userInfo: [
                                    "previousStatus": previousStatus,
                                    "newStatus": newData.status
                                ]
                            )
                        }
                        
                        // Use throttled view update to prevent excessive refreshes
                        self.throttledViewUpdate()
                    }
                } else if self.manuallyUpdatedStatus {
                     
                    // Reset the flag after a delay to allow future updates
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                        self.manuallyUpdatedStatus = false
                         
                    }
                }
            }
        }
    }
    
    // MARK: - Status Update Listener
    
    /// Listen for status updates from on_location notifications
    private func setupStatusUpdateListener() {
//        print("RideDrive---Here")

        
        // Listen to NotificationCenter for status updates
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("RideStatusUpdate"),
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self = self,
                  let userInfo = notification.userInfo,
                  let status = userInfo["status"] as? String else { return }
            
             
            
            // Update the liveRideData status and trigger UI update
            if status == "on_location" {
                DispatchQueue.main.async {
                    // Create a new LiveRideData with updated status
                    let updatedLiveRideData = LiveRideData(
                        bookingId: self.liveRideData.bookingId,
                        driverId: self.liveRideData.driverId,
                        customerId: self.liveRideData.customerId,
                        status: status,
                        driverLatitude: self.liveRideData.driverLatitude,
                        driverLongitude: self.liveRideData.driverLongitude,
                        pickupLatitude: self.liveRideData.pickupLatitude,
                        pickupLongitude: self.liveRideData.pickupLongitude,
                        dropoffLatitude: self.liveRideData.dropoffLatitude,
                        dropoffLongitude: self.liveRideData.dropoffLongitude,
                        pickupAddress: self.liveRideData.pickupAddress,
                        dropoffAddress: self.liveRideData.dropoffAddress,
                        timestamp: self.liveRideData.timestamp,
                        title: self.liveRideData.title,
                        message: self.liveRideData.message,
                        driverName: self.liveRideData.driverName,
                        driverPhone: self.liveRideData.driverPhone
                    )
                    
                    // Update both local data and socket service data
                    self.liveRideData = updatedLiveRideData
                    self.socketService.liveRideData = updatedLiveRideData  // ✅ Also update socket service
                    self.manuallyUpdatedStatus = true  // ✅ Flag to prevent timer override
                    self.updateStatusMessage()
                    
                    // Start countdown timer when driver is on location
                    if !self.isCountdownActive {
                        self.startCountdownTimer()
                    }
                    
                     
                     
                     
                     
                     
                }
            }
        }
        
         
    }
    
    // MARK: - Driver Location Socket Listener for LiveRideViewModel
    
    /// Listen for driver location updates from socket
    private func setupDriverLocationListener() {
    
//        print("RideDrive---DriverLocationListener")
        
        // Listen directly to the driver.location.update socket event
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("DriverLocationUpdate"),
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self = self else { 
                 
                return 
            }
            
            // Handle driver location update for LiveRideViewModel
             
            
            // Check if this ViewModel should handle driver location updates
            guard self.shouldHandleDriverLocationUpdates else {
                 
                return
            }
            
            // Extract location update from notification
            guard let userInfo = notification.userInfo,
                  let locationUpdate = userInfo["locationUpdate"] as? DriverLocationUpdate else { 
                 
                return 
            }
            
            // Check if this is for our booking
            if let bookingId = locationUpdate.bookingId, 
               bookingId == self.liveRideData.bookingId {
                 
            } else {
                 
                return
            }
            
            let newCoordinate = CLLocationCoordinate2D(
                latitude: locationUpdate.latitude,
                longitude: locationUpdate.longitude
            )
            
            // Check if this update is for our booking (if bookingId is provided)
            if let bookingIdString = locationUpdate.bookingId,
               bookingIdString != self.liveRideData.bookingId {
                // This update is for a different booking, ignore it
                 
                 
                 
                // TEMPORARILY DISABLED FOR TESTING - Remove this comment and uncomment return when booking ID is fixed
                // return
            }
            
            // Check if location actually changed (to avoid unnecessary updates)
            // Use a smaller threshold to catch smaller movements
            
             
            
            if abs(self.driverLocation.latitude - newCoordinate.latitude) < 0.0000001,
               abs(self.driverLocation.longitude - newCoordinate.longitude) < 0.0000001 {
                // Location hasn't changed significantly
                 
                return
            }
            
             
             
             
             
             
             
            
            // Calculate distance moved for better debugging
            let distance = CLLocation(latitude: self.driverLocation.latitude, longitude: self.driverLocation.longitude)
                .distance(from: CLLocation(latitude: newCoordinate.latitude, longitude: newCoordinate.longitude))
             
             
            
            // Check if this is a significant location change (like from pickup offset to real driver location)
            // This happens when first real location arrives from active_ride
            let isSignificantLocationChange = distance > 100 // More than 100 meters
            
            // Calculate heading from movement direction if not provided
            var calculatedHeading: CLLocationDirection = 0
            if let providedHeading = locationUpdate.heading {
                calculatedHeading = providedHeading
            } else if let lastLoc = self.lastCarLocationForPath {
                // Calculate heading from previous location to current location
                calculatedHeading = self.calculateHeading(from: lastLoc, to: newCoordinate)
            } else {
                // Use current driver location if lastCarLocationForPath is not set
                calculatedHeading = self.calculateHeading(from: self.driverLocation, to: newCoordinate)
            }
        self.driverHeading = calculatedHeading

            // Immediately focus map on this coordinate (even if user interacted)
            self.forceFocusOnCar(at: newCoordinate)
            
            // Update driver location
            self.driverLocation = newCoordinate
            self.lastCarLocationForPath = newCoordinate
            
            // Update car path trail
            self.updateCarPath(newLocation: newCoordinate)
            
            // Set flag to indicate we're receiving real-time socket updates
            self.isReceivingSocketUpdates = true
            
            // CRITICAL: Force focus on car IMMEDIATELY when location updates
            // This is especially important when first real location arrives from active_ride
            // The car was at pickup location, now it moves to driver location - focus must follow
        if !self.userHasInteractedWithMap {
                // Update region immediately - this will trigger SwiftUI to update the map
                let carRegion = MKCoordinateRegion(
                    center: newCoordinate,
                    span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
                )
                self.region = carRegion
            // Initial focus satisfied
            self.needsInitialFocus = false
                
                // Post notification for immediate map view update
                // This ensures the map view updates even if SwiftUI hasn't refreshed yet
                DispatchQueue.main.async {
                    NotificationCenter.default.post(
                        name: NSNotification.Name("MapRegionUpdate"),
                        object: nil,
                        userInfo: ["coordinate": newCoordinate, "isSignificantChange": isSignificantLocationChange]
                    )
                    
                    // If this is a significant location change (like from active_ride offset to real location)
                    // Force additional updates to ensure map focuses properly
                    if isSignificantLocationChange {
                        // Post additional notifications to ensure map updates
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                            NotificationCenter.default.post(
                                name: NSNotification.Name("MapRegionUpdate"),
                                object: nil,
                                userInfo: ["coordinate": newCoordinate]
                            )
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                            NotificationCenter.default.post(
                                name: NSNotification.Name("MapRegionUpdate"),
                                object: nil,
                                userInfo: ["coordinate": newCoordinate]
                            )
                        }
                    }
                }
            }
            
            // Update car annotation position with heading
            if let car = self.carAnnotation {
                UIView.animate(withDuration: 0.5, delay: 0, options: [.curveLinear]) {
                    car.coordinate = newCoordinate
                    car.heading = calculatedHeading
                }
                 
            } else {
                // Create car annotation if it doesn't exist
                let carAnnotation = CarAnnotation(coordinate: newCoordinate, heading: calculatedHeading)
                self.carAnnotation = carAnnotation
                 
            }
            
        // Recalculate route and ETA
        self.updateETAFromCurrentLocation()
        
        // CRITICAL: Also ensure focus is maintained after a brief delay
        // This handles cases where the first update might not trigger properly
        if !self.userHasInteractedWithMap {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.updateRegionToFocusOnCar()
                NotificationCenter.default.post(name: NSNotification.Name("MapRegionUpdate"), object: nil)
            }
        }
        
        // Use throttled view update to prevent excessive refreshes
        self.throttledViewUpdate()
        }
        
         
    }
    
    private func updateRegionToShowCarAndRoute() {
        // Only update region on first load or when car moves significantly
        let currentCarLocation = CLLocation(latitude: driverLocation.latitude, longitude: driverLocation.longitude)
        
        // Check if we have a previous car location to compare
        if let lastCarLocation = self.lastCarLocation {
            let distance = currentCarLocation.distance(from: lastCarLocation)
            
            // Only update region if car moved more than 200 meters or this is first load
            if distance < 200 {
                 
                return
            }
        }
        
        // Update last car location
        self.lastCarLocation = currentCarLocation
        
        // ALWAYS show the car - prioritize car visibility
         
        
        // Focus primarily on the car location
        let driverLoc = CLLocation(latitude: driverLocation.latitude, longitude: driverLocation.longitude)
        let pickupLoc = CLLocation(latitude: pickupLocation.latitude, longitude: pickupLocation.longitude)
        
        // Calculate distance between driver and pickup
        let distance = driverLoc.distance(from: pickupLoc)
         
        
        // If driver and pickup are close, focus on car with small span
        if distance < 2000 { // Less than 2km
            let carRegion = MKCoordinateRegion(
                center: driverLocation,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01) // Small span focused on car
            )
            
            DispatchQueue.main.async {
                self.region = carRegion
                 
            }
        } else {
            // If far apart, show both but center on car
            let minLat = min(driverLoc.coordinate.latitude, pickupLoc.coordinate.latitude)
            let maxLat = max(driverLoc.coordinate.latitude, pickupLoc.coordinate.latitude)
            let minLng = min(driverLoc.coordinate.longitude, pickupLoc.coordinate.longitude)
            let maxLng = max(driverLoc.coordinate.longitude, pickupLoc.coordinate.longitude)
            
            // Center on driver (car) but include pickup
            let centerLat = driverLoc.coordinate.latitude + (pickupLoc.coordinate.latitude - driverLoc.coordinate.latitude) * 0.3
            let centerLng = driverLoc.coordinate.longitude + (pickupLoc.coordinate.longitude - driverLoc.coordinate.longitude) * 0.3
            
            let latSpan = max(maxLat - minLat, 0.01) + 0.005
            let lngSpan = max(maxLng - minLng, 0.01) + 0.005
            
            let newRegion = MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: centerLat, longitude: centerLng),
                span: MKCoordinateSpan(latitudeDelta: latSpan, longitudeDelta: lngSpan)
            )
            
            DispatchQueue.main.async {
                self.region = newRegion
                 
            }
        }
    }
    
    private func followCarLocation() {
        // Only follow car if user hasn't interacted with map
        if userHasInteractedWithMap {
             
            return
        }
        
        // For en_route_do, follow the car (like en_route_pu) but only if user hasn't interacted
        if liveRideData.status == "en_route_do" {
            // Follow the car location for en_route_do only if user hasn't interacted
             
            
            // Create a focused region around the car with good visibility
            let carRegion = MKCoordinateRegion(
                center: driverLocation,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01) // Good visibility around car
            )
            
            DispatchQueue.main.async {
                self.region = carRegion
                 
            }
            return
        }
        
        // For other statuses, only update if car has moved significantly (more than 100 meters)
        let currentCarLocation = CLLocation(latitude: driverLocation.latitude, longitude: driverLocation.longitude)
        
        // Check if we have a previous car location to compare
        if let lastCarLocation = self.lastCarLocation {
            let distance = currentCarLocation.distance(from: lastCarLocation)
             
            
            // Only update region if car moved more than 100 meters
            if distance < 100 {
                 
                return
            }
        }
        
        // Update last car location
        self.lastCarLocation = currentCarLocation
        
        // Force map to follow the car location - ALWAYS show the car
         
        
        // Create a focused region around the car with good visibility
        let carRegion = MKCoordinateRegion(
            center: driverLocation,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01) // Good visibility around car
        )
        
        DispatchQueue.main.async {
            self.region = carRegion
             
        }
    }
    
    private func updateRegionForEnRouteDo() {
        // Only update region if user hasn't interacted with map
        if userHasInteractedWithMap {
             
            return
        }
        
        // For en_route_do, follow the car first (like en_route_pu) but only if user hasn't interacted
         
        
        let driverLoc = CLLocation(latitude: driverLocation.latitude, longitude: driverLocation.longitude)
        let dropoffLoc = CLLocation(latitude: dropoffLocation.latitude, longitude: dropoffLocation.longitude)
        
        // Calculate distance between driver and dropoff
        let distance = driverLoc.distance(from: dropoffLoc)
         
        
        // Focus on the car first - just like en_route_pu, but only if user hasn't interacted
        let carRegion = MKCoordinateRegion(
            center: driverLocation,
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01) // Small span focused on car
        )
        
        DispatchQueue.main.async {
            self.region = carRegion
             
        }
    }
    
    private func updateETAFromCurrentLocation() {
        guard !prefersGoogleLiveMetrics else { return }
        // Calculate remaining distance to dropoff location (since we're in pickup→dropoff phase)
        let currentLocation = CLLocation(latitude: driverLocation.latitude, longitude: driverLocation.longitude)
        let dropoffLocation = CLLocation(latitude: self.dropoffLocation.latitude, longitude: self.dropoffLocation.longitude)
        let remainingDistance = currentLocation.distance(from: dropoffLocation)
        
        // Update distance display
        let kilometers = remainingDistance / 1000
        self.distance = String(format: "%.1fkm", kilometers)
        
        // Estimate time based on average speed (assuming 40 km/h in city)
        let estimatedSeconds = (remainingDistance / 1000) / 40 * 3600
        let totalMinutes = Int(estimatedSeconds / 60)
        
        // Format time as hours and minutes
        if totalMinutes >= 60 {
            let hours = totalMinutes / 60
            let remainingMinutes = totalMinutes % 60
            if remainingMinutes > 0 {
                self.estimatedTime = "\(hours) hour \(remainingMinutes) min"
            } else {
                self.estimatedTime = "\(hours) hour"
            }
        } else {
            self.estimatedTime = "\(totalMinutes) min"
        }
        
         
    }
    
    // MARK: - Countdown Timer Methods
    
    /// Start the 5-minute countdown timer when driver arrives
    private func startCountdownTimer() {
         
        
        // Reset countdown to 5 minutes
        countdownSeconds = 300 // 5 minutes
        countdownTime = "05:00"
        isCountdownActive = true
        
        // Start timer that updates every second
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            self.countdownSeconds -= 1
            
            // Format time as MM:SS
            let minutes = self.countdownSeconds / 60
            let seconds = self.countdownSeconds % 60
            self.countdownTime = String(format: "%02d:%02d", minutes, seconds)
            
             
            
            // Stop timer when it reaches 00:00
            if self.countdownSeconds <= 0 {
                self.stopCountdownTimer()
                 
            }
        }
        
         
    }
    
    /// Stop the countdown timer
    private func stopCountdownTimer() {
         
        
        countdownTimer?.invalidate()
        countdownTimer = nil
        isCountdownActive = false
        countdownTime = "05:00"
        countdownSeconds = 300
        
         
    }
    
    deinit {
        // Clean up timers when view model is deallocated
        countdownTimer?.invalidate()
         
        countdownTimer = nil
        
        // Remove notification observers
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("DriverLocationUpdate"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("RideStatusUpdate"), object: nil)
        
         
    }
    
    /// Reset map interaction flag to allow auto-following again
    func resetMapInteraction() {
        userHasInteractedWithMap = false
         
    }
    
    /// Force reset map interaction and update region to show route properly
    func forceResetMapAndShowRoute() {
        userHasInteractedWithMap = false
         
        
        // Force update the map region to show the route properly
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.forceUpdateMapRegion()
        }
    }
    
    /// Force update map region to show route (useful for debugging)
    func forceUpdateMapRegion() {
         
        
        // Only update if user hasn't interacted - keep focus on car
        guard !userHasInteractedWithMap else { return }
        
        // Always focus on car, not the full route
        updateRegionToFocusOnCar()
    }
    
    func updateRegionToFocusOnCar() {
        // Only update if user hasn't interacted with map
        guard !userHasInteractedWithMap else {
            print("🗺️ LiveRideViewModel: updateRegionToFocusOnCar - Skipped (user has interacted)")
            return
        }
        
        // Focus on the car location with closer zoom for clear visibility
        let carRegion = MKCoordinateRegion(
            center: driverLocation,
            span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005) // Closer zoom for better car visibility
        )
        self.region = carRegion
        self.needsInitialFocus = false
        
        print("🗺️ LiveRideViewModel: updateRegionToFocusOnCar - Setting region to driver location: (\(driverLocation.latitude), \(driverLocation.longitude))")
        
        // Force immediate region update with driver location
        DispatchQueue.main.async {
            NotificationCenter.default.post(
                name: NSNotification.Name("MapRegionUpdate"),
                object: nil,
                userInfo: ["coordinate": self.driverLocation]
            )
        }
    }

    /// Force focus on car even if user interacted (used when driver.location.update arrives)
    func forceFocusOnCar(at coordinate: CLLocationCoordinate2D? = nil) {
        let target = coordinate ?? driverLocation
        let carRegion = MKCoordinateRegion(
            center: target,
            span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
        )
        self.region = carRegion
        self.needsInitialFocus = false
        
        DispatchQueue.main.async {
            NotificationCenter.default.post(
                name: NSNotification.Name("MapRegionUpdate"),
                object: nil,
                userInfo: ["coordinate": target, "force": true]
            )
        }
    }
    
    private func updateRegionToShowAllPoints() {
        let coordinates = [driverLocation, pickupLocation, dropoffLocation]
        let region = MKCoordinateRegion(coordinates: coordinates)
        
        // Add reasonable padding to ensure all points are clearly visible
        let paddedRegion = MKCoordinateRegion(
            center: region.center,
            span: MKCoordinateSpan(
                latitudeDelta: max(region.span.latitudeDelta * 1.2, 0.01), // Ensure minimum zoom level
                longitudeDelta: max(region.span.longitudeDelta * 1.2, 0.01)
            )
        )
        self.region = paddedRegion
        
         
         
         
    }
    
    private func updateLiveBookingDistanceAndTime(force: Bool = false) {
        guard force || !hasCalculatedLiveBookingMetrics else { return }
        
        let origin = pickupLocation
        let destination = dropoffLocation
        
        Task { [weak self] in
            guard let self = self else { return }
            let (distanceMeters, durationSeconds) = await self.vehicleService.calculateDistance(
                from: origin,
                to: destination
            )
            
            await MainActor.run {
                self.hasCalculatedLiveBookingMetrics = true
                self.distance = self.formatLiveDistanceText(distanceMeters)
                self.estimatedTime = self.formatLiveDurationText(durationSeconds)
            }
        }
    }
    
    private func formatLiveDistanceText(_ meters: CLLocationDistance) -> String {
        if meters >= 1000 {
            return String(format: "%.1fkm", meters / 1000)
        }
        return "\(Int(meters))m"
    }
    
    private func formatLiveDurationText(_ seconds: TimeInterval) -> String {
        let totalMinutes = Int(round(seconds / 60))
        if totalMinutes >= 60 {
            let hours = totalMinutes / 60
            let remainingMinutes = totalMinutes % 60
            if remainingMinutes > 0 {
                return "\(hours) hour \(remainingMinutes) min"
            } else {
                return "\(hours) hour"
            }
        } else {
            return "\(totalMinutes) min"
        }
    }
    
    private func updateLiveMetricsFromRoute(_ route: MKRoute) {
        guard !prefersGoogleLiveMetrics else { return }
        self.distance = formatLiveDistanceText(route.distance)
        self.estimatedTime = formatLiveDurationText(route.expectedTravelTime)
    }
    
    private func updateLiveMetricsFromFallback(distanceMeters: Double, durationSeconds: Double) {
        guard !prefersGoogleLiveMetrics else { return }
        self.distance = formatLiveDistanceText(distanceMeters)
        self.estimatedTime = formatLiveDurationText(durationSeconds)
    }
    
    func calculateRoute() {
        // Prevent multiple simultaneous route calculations
        guard !isCalculatingRoute else {
             
            return
        }
        
        isCalculatingRoute = true
        
        // Determine route based on ride status
        let routeType = getLiveRouteType()
        
        switch routeType {
        case .driverToPickup:
            calculateDriverToPickupRoute()
        case .pickupToDropoff:
            // For pickup to dropoff, calculate from current driver location to dropoff
            calculatePickupToDropoffRoute()
        case .completeRoute:
            calculateCompleteRoute()
        }
        
        // Update region to show full route instead of just car location
        // The route calculation will handle the proper region update
        
        // Reset flag after a delay to allow for route calculation completion
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.isCalculatingRoute = false
        }
    }
    
    enum LiveRouteType {
        case driverToPickup
        case pickupToDropoff
        case completeRoute
    }
    
    func getLiveRouteType() -> LiveRouteType {
        // Check ride status to determine route type
        switch liveRideData.status {
        case "en_route_pu":
            return .driverToPickup
        case "at_pickup", "on_location", "en_route_do":
            return .pickupToDropoff
        default:
            return .completeRoute
        }
    }
    
    private func calculateDriverToPickupRoute() {
         
        
        let driverPlacemark = MKPlacemark(coordinate: driverLocation)
        let pickupPlacemark = MKPlacemark(coordinate: pickupLocation)
        
        let driverMapItem = MKMapItem(placemark: driverPlacemark)
        let pickupMapItem = MKMapItem(placemark: pickupPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = driverMapItem
        directionRequest.destination = pickupMapItem
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = false
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] response, error in
            guard let self = self else { return }
            
            if let error = error {
                 
                self.createDirectLineRoute(from: self.driverLocation, to: self.pickupLocation)
                return
            }
            
            if let route = response?.routes.first {
                DispatchQueue.main.async {
                    self.route = route
                    self.completeRoute = route.polyline
                    
                    self.updateLiveMetricsFromRoute(route)
                    
                    // Only update region if user hasn't interacted - keep focus on car
                    if !self.userHasInteractedWithMap {
                        // Focus on car, not the full route
                        self.updateRegionToFocusOnCar()
                    }
                    
                    // Force map view update to show the route
                    DispatchQueue.main.async {
                        // Trigger a map view update by updating the region
                        self.objectWillChange.send()
                    }
                    
                     
                }
            } else {
                 
                self.createDirectLineRoute(from: self.driverLocation, to: self.pickupLocation)
            }
        }
    }
    
    private func calculatePickupToDropoffRoute() {
    
        
        let driverPlacemark = MKPlacemark(coordinate: driverLocation)
        let dropoffPlacemark = MKPlacemark(coordinate: dropoffLocation)
        
        let driverMapItem = MKMapItem(placemark: driverPlacemark)
        let dropoffMapItem = MKMapItem(placemark: dropoffPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = driverMapItem
        directionRequest.destination = dropoffMapItem
        directionRequest.transportType = .automobile
        directionRequest.requestsAlternateRoutes = false
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate { [weak self] response, error in
            guard let self = self else { return }
            
            if let error = error {
        
                self.createDirectLineRoute(from: self.driverLocation, to: self.dropoffLocation)
                return
            }
            
            if let route = response?.routes.first {
                DispatchQueue.main.async {
                    self.route = route
                    self.completeRoute = route.polyline
                    
                    self.updateLiveMetricsFromRoute(route)
                    
                    // Only update region if user hasn't interacted - keep focus on car
                    if !self.userHasInteractedWithMap {
                        // Focus on car, not the full route
                        self.updateRegionToFocusOnCar()
                    }
                
                }
            } else {
            
                self.createDirectLineRoute(from: self.driverLocation, to: self.dropoffLocation)
            }
        }
    }
    
    private func calculateCompleteRoute() {
       
        
        // Create a single polyline that goes through all three points
        let coordinates = [driverLocation, pickupLocation, dropoffLocation]
        let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
        
        DispatchQueue.main.async {
            self.completeRoute = polyline
            
            // Calculate distance for ETA
            let totalDistance = self.calculateTotalDistance()
            // Estimate time (assuming 40 km/h average speed)
            let estimatedSeconds = (totalDistance / 1000) / 40 * 3600
            self.updateLiveMetricsFromFallback(distanceMeters: totalDistance, durationSeconds: estimatedSeconds)
            
            // Only update region if user hasn't interacted - keep focus on car
            if !self.userHasInteractedWithMap {
                // Focus on car, not all points
                self.updateRegionToFocusOnCar()
            }
    
        }
    }
    
    private func createDirectLineRoute(from start: CLLocationCoordinate2D, to end: CLLocationCoordinate2D) {
    
        
        let coordinates = [start, end]
        let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
        
        DispatchQueue.main.async {
            self.completeRoute = polyline
            
            // Calculate straight line distance
            let distance = CLLocation(latitude: start.latitude, longitude: start.longitude)
                .distance(from: CLLocation(latitude: end.latitude, longitude: end.longitude))
            
            // Estimate time (assuming 40 km/h average speed)
            let estimatedSeconds = (distance / 1000) / 40 * 3600
            self.updateLiveMetricsFromFallback(distanceMeters: distance, durationSeconds: estimatedSeconds)
            
            // Only update region if user hasn't interacted - keep focus on car
            if !self.userHasInteractedWithMap {
                // Focus on car, not the full route
                self.updateRegionToFocusOnCar()
            }
        
        }
    }
    
    private func calculateTotalDistance() -> Double {
        // Calculate distance from driver to pickup
        let driverToPickup = CLLocation(latitude: driverLocation.latitude, longitude: driverLocation.longitude)
            .distance(from: CLLocation(latitude: pickupLocation.latitude, longitude: pickupLocation.longitude))
        
        // Calculate distance from pickup to dropoff
        let pickupToDropoff = CLLocation(latitude: pickupLocation.latitude, longitude: pickupLocation.longitude)
            .distance(from: CLLocation(latitude: dropoffLocation.latitude, longitude: dropoffLocation.longitude))
        
        return driverToPickup + pickupToDropoff
    }
    
    // Calculate heading/bearing from previous location to current location
    private func calculateHeading(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) -> CLLocationDirection {
        let lat1 = from.latitude * .pi / 180.0
        let lat2 = to.latitude * .pi / 180.0
        let deltaLon = (to.longitude - from.longitude) * .pi / 180.0
        
        let y = sin(deltaLon) * cos(lat2)
        let x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(deltaLon)
        
        let bearing = atan2(y, x) * 180.0 / .pi
        let normalizedBearing = (bearing + 360.0).truncatingRemainder(dividingBy: 360.0)
        
        return normalizedBearing
    }
    
    // Update car path trail line
    private func updateCarPath(newLocation: CLLocationCoordinate2D) {
        // Add new location to path
        carPathCoordinates.append(newLocation)
        
        // Limit path to last 100 points to avoid performance issues
        if carPathCoordinates.count > 100 {
            carPathCoordinates.removeFirst()
        }
        
        // Create polyline from path coordinates
        if carPathCoordinates.count >= 2 {
            carPathPolyline = MKPolyline(coordinates: carPathCoordinates, count: carPathCoordinates.count)
        }
    }
    
}

// MARK: - Live Ride Map View
struct LiveRideMapView: UIViewRepresentable {
    @ObservedObject var viewModel: LiveRideViewModel
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = false
        mapView.isRotateEnabled = true
        mapView.isPitchEnabled = true
        mapView.showsCompass = true
        mapView.showsScale = true
        
        // Enable user interactions for zoom and pan
        mapView.isZoomEnabled = true
        mapView.isScrollEnabled = true
        
        // Add car annotation
        let carAnnotation = CarAnnotation(coordinate: viewModel.driverLocation, heading: viewModel.driverHeading)
        viewModel.carAnnotation = carAnnotation
        mapView.addAnnotation(carAnnotation)
        
        // CRITICAL: Set initial region to focus on car IMMEDIATELY with close zoom
        // This ensures car is visible when coming from active_ride event after app kill
        let carRegion = MKCoordinateRegion(
            center: viewModel.driverLocation,
            span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005) // Closer zoom for better visibility
        )
        // Force immediate region update - use non-animated for instant focus
        mapView.setRegion(carRegion, animated: false)
        // Also update viewModel's region to keep it in sync
        viewModel.region = carRegion
        viewModel.needsInitialFocus = false // Mark that initial focus is set
        
        // Listen for annotation refresh notifications
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("RefreshMapAnnotations"),
            object: nil,
            queue: .main
        ) { _ in
           
            // Force map view to refresh
            mapView.setNeedsDisplay()
        }
        
        // Listen for route update notifications
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("RouteUpdated"),
            object: nil,
            queue: .main
        ) { _ in
            // Force map view to refresh overlays
            mapView.setNeedsDisplay()
        }
        
        // Listen for map region update notifications
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("MapRegionUpdate"),
            object: nil,
            queue: .main
        ) { notification in
            // Update map region to focus on car
            let isForce = (notification.userInfo?["force"] as? Bool) == true
            if isForce || !self.viewModel.userHasInteractedWithMap {
                // Get coordinate from notification if available, otherwise use driverLocation
                let targetCoordinate: CLLocationCoordinate2D
                if let userInfo = notification.userInfo,
                   let coord = userInfo["coordinate"] as? CLLocationCoordinate2D {
                    targetCoordinate = coord
                } else {
                    targetCoordinate = self.viewModel.driverLocation
                }
                
                let carRegion = MKCoordinateRegion(
                    center: targetCoordinate,
                    span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
                )
                
                // Check if current map center is far from target location
                let currentCenter = CLLocation(
                    latitude: mapView.region.center.latitude,
                    longitude: mapView.region.center.longitude
                )
                let targetLoc = CLLocation(
                    latitude: targetCoordinate.latitude,
                    longitude: targetCoordinate.longitude
                )
                let distanceFromCar = currentCenter.distance(from: targetLoc)
                
                // If far from car (like when first real location arrives), use non-animated for immediate update
                // Otherwise use animated for smooth following
                let shouldAnimate = distanceFromCar < 500 // Less than 500 meters
                
                // Update region directly on map view
                mapView.setRegion(carRegion, animated: shouldAnimate)
                
                // Update viewModel region to keep in sync
                self.viewModel.region = carRegion
                self.viewModel.needsInitialFocus = false
            }
        }
        
        return mapView
    }
    
    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Force SwiftUI to observe these properties so updateUIView gets called when they change
        _ = viewModel.driverLocation
        _ = viewModel.region
        _ = viewModel.needsInitialFocus
        _ = viewModel.userHasInteractedWithMap
        _ = viewModel.driverHeading
        
        // CRITICAL: Always focus on car if user hasn't interacted
        // This ensures car is always visible when coming from active_ride
        if !viewModel.userHasInteractedWithMap {
            // Always check distance from driver location to current map center
            let driverLoc = CLLocation(
                latitude: viewModel.driverLocation.latitude,
                longitude: viewModel.driverLocation.longitude
            )
            let currentMapCenter = CLLocation(
                latitude: mapView.region.center.latitude,
                longitude: mapView.region.center.longitude
            )
            let distanceFromDriver = currentMapCenter.distance(from: driverLoc)
            
            // Force focus if map is far from car OR we need initial focus
            // Use a more aggressive threshold (50 meters) to ensure car is always visible
            // ALWAYS focus if needsInitialFocus is true (first render or after active_ride)
            if distanceFromDriver > 50 || viewModel.needsInitialFocus {
                // Always create region centered on driver location for consistency
                let carRegion = MKCoordinateRegion(
                    center: viewModel.driverLocation,
                    span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
                )
                
                // Use non-animated if initial focus needed or far from car
                // This ensures instant focus when view first appears or driver.location.update arrives
                let shouldAnimate = distanceFromDriver < 25 && !viewModel.needsInitialFocus
                
                // Update map view directly - this forces immediate focus
                mapView.setRegion(carRegion, animated: shouldAnimate)
                
                // Also update viewModel region to keep in sync
                viewModel.region = carRegion
                viewModel.needsInitialFocus = false
                
                print("🗺️ LiveRideMapView: Focused on car at (\(viewModel.driverLocation.latitude), \(viewModel.driverLocation.longitude)), distance: \(Int(distanceFromDriver))m, animated: \(shouldAnimate)")
            }
        }
        
        // Update car position continuously
        if let car = viewModel.carAnnotation {
            // Update existing car annotation position smoothly
            UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseInOut]) {
                car.coordinate = viewModel.driverLocation
                car.heading = viewModel.driverHeading
            }
            
            // Apply rotation so the car always faces direction of travel
            if let annotationView = mapView.view(for: car) {
                let rotation = CGFloat(viewModel.driverHeading * .pi / 180)
                annotationView.transform = CGAffineTransform(rotationAngle: rotation)
            }
     
        } else {
            // Create car annotation if it doesn't exist
            let carAnnotation = CarAnnotation(coordinate: viewModel.driverLocation, heading: viewModel.driverHeading)
            viewModel.carAnnotation = carAnnotation
            mapView.addAnnotation(carAnnotation)

        }
        
        // Update route overlay
        var hasOverlays = false
        
        if let route = viewModel.route {
            // Remove existing route overlays but keep car path
            let existingOverlays = mapView.overlays.filter { overlay in
                !(overlay is MKPolyline && overlay !== viewModel.carPathPolyline)
            }
            mapView.removeOverlays(existingOverlays)
            
            // Add the route polyline
            mapView.addOverlay(route.polyline, level: .aboveRoads)
            hasOverlays = true
            
            // DON'T override region - let the ViewModel handle region updates
            // The ViewModel's updateRegionToFocusOnCar() method will handle the region updates properly
          
        } else if let completeRoute = viewModel.completeRoute {
            // Remove existing route overlays but keep car path
            let existingOverlays = mapView.overlays.filter { overlay in
                !(overlay is MKPolyline && overlay !== viewModel.carPathPolyline)
            }
            mapView.removeOverlays(existingOverlays)
            
            // Fallback to complete route if no specific route
            mapView.addOverlay(completeRoute, level: .aboveRoads)
            hasOverlays = true
            
            // DON'T override region - let the ViewModel handle region updates
        }
        
        // Add car path trail line only when NOT on pickup-to-dropoff route
        // This prevents overlap with the route line
        let routeType = viewModel.getLiveRouteType()
        if routeType != .pickupToDropoff, let carPath = viewModel.carPathPolyline {
            // Only show car path when driver is heading to pickup (en_route_pu)
            // Don't show when on pickup-to-dropoff route to avoid overlap
            // Remove old car path if exists
            mapView.removeOverlay(carPath)
            // Add car path with higher level to be on top
            mapView.addOverlay(carPath, level: .aboveLabels)
            hasOverlays = true
        } else if routeType == .pickupToDropoff, let carPath = viewModel.carPathPolyline {
            // Remove car path when on pickup-to-dropoff route to avoid overlap
            mapView.removeOverlay(carPath)
        }
        
        // Remove all overlays if no route and no car path
        if !hasOverlays {
            mapView.removeOverlays(mapView.overlays)
        }
        
        // Add pickup annotation
        let hasPickup = mapView.annotations.contains { annotation in
            if let point = annotation as? MKPointAnnotation {
                return point.title == "Pickup Location"
            }
            return false
        }
        
        if !hasPickup {
            let pickupAnnotation = MKPointAnnotation()
            pickupAnnotation.coordinate = viewModel.pickupLocation
            pickupAnnotation.title = "Pickup Location"
            // Use liveRideData for address information
            let pickupAddress = viewModel.liveRideData.pickupAddress.isEmpty ? "Pickup Location" : viewModel.liveRideData.pickupAddress
            pickupAnnotation.subtitle = pickupAddress
            mapView.addAnnotation(pickupAnnotation)
        }
        
        // Add dropoff annotation
        let hasDropoff = mapView.annotations.contains { annotation in
            if let point = annotation as? MKPointAnnotation {
                return point.title == "Dropoff Location"
            }
            return false
        }
        
        if !hasDropoff {
            let dropoffAnnotation = MKPointAnnotation()
            dropoffAnnotation.coordinate = viewModel.dropoffLocation
            dropoffAnnotation.title = "Dropoff Location"
            // Use liveRideData for address information
            let dropoffAddress = viewModel.liveRideData.dropoffAddress.isEmpty ? "Dropoff Location" : viewModel.liveRideData.dropoffAddress
            dropoffAnnotation.subtitle = dropoffAddress
            mapView.addAnnotation(dropoffAnnotation)
        }
        
        // Only follow car if no route is available and user hasn't interacted
        if !viewModel.userHasInteractedWithMap && viewModel.route == nil && viewModel.completeRoute == nil {
            let region = MKCoordinateRegion(
                center: viewModel.driverLocation,
                span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            )
            
            // Use a more noticeable animation for car following
            UIView.animate(withDuration: 0.8, delay: 0, options: [.curveEaseInOut], animations: {
                mapView.setRegion(region, animated: true)
            })
        
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: LiveRideMapView
        
        init(_ parent: LiveRideMapView) {
            self.parent = parent
        }
        
        func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
            // Track user interaction with map
            if !parent.viewModel.userHasInteractedWithMap {
                parent.viewModel.userHasInteractedWithMap = true
        
            }
        }
        
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let polyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: polyline)
                
                // Check if this is the car path trail
                if overlay === parent.viewModel.carPathPolyline {
                    // Light black/gray trail line showing car's movement path
                    renderer.strokeColor = UIColor.black.withAlphaComponent(0.4)
                    renderer.lineWidth = 3
                    renderer.alpha = 0.6
                    renderer.lineCap = .round
                    renderer.lineJoin = .round
                    return renderer
                }
                
                // Determine route type and styling for route lines
                let routeType = parent.viewModel.getLiveRouteType()
                
                switch routeType {
                case .driverToPickup:
                    // Solid blue line for driver to pickup
                    renderer.strokeColor = UIColor.systemBlue
                    renderer.lineWidth = 6
                    renderer.alpha = 1.0
                    
                case .pickupToDropoff:
                    // Faded black line for pickup to dropoff
                    renderer.strokeColor = UIColor.black
                    renderer.lineWidth = 5
                    renderer.alpha = 0.6 // Fade effect
                    
                case .completeRoute:
                    // Solid black line for complete route
                    renderer.strokeColor = UIColor.black
                    renderer.lineWidth = 5
                    renderer.alpha = 1.0
                }
                
                renderer.lineCap = .round
                renderer.lineJoin = .round
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            // Handle car annotation
            if let carAnnotation = annotation as? CarAnnotation {
                let identifier = "Car"
                var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
                
                if annotationView == nil {
                    annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                    annotationView?.canShowCallout = false
                    
                    // Use car image
                    if let carImage = UIImage(named: "car") {
                        let size = CGSize(width: 50, height: 50)
                        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
                        carImage.draw(in: CGRect(origin: .zero, size: size))
                        let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
                        UIGraphicsEndImageContext()
                        annotationView?.image = resizedImage
                    } else {
                        let config = UIImage.SymbolConfiguration(pointSize: 40, weight: .bold)
                        annotationView?.image = UIImage(systemName: "car.fill", withConfiguration: config)?.withTintColor(.systemBlue, renderingMode: .alwaysOriginal)
                    }
                    
                    annotationView?.centerOffset = CGPoint(x: 0, y: 0)
                } else {
                    annotationView?.annotation = annotation
                }
                
                // Rotate based on heading
                let rotation = CGFloat(carAnnotation.heading * .pi / 180)
                annotationView?.transform = CGAffineTransform(rotationAngle: rotation)
                
                return annotationView
            }
            
            // Handle pickup and dropoff annotations
            if let pointAnnotation = annotation as? MKPointAnnotation {
                let isPickup = pointAnnotation.title == "Pickup Location"
                let identifier = isPickup ? "Pickup" : "Dropoff"
                var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
                
                if annotationView == nil {
                    annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                    annotationView?.canShowCallout = true
                } else {
                    annotationView?.annotation = annotation
                }
                
                // Ensure callout is enabled and properly configured
                annotationView?.canShowCallout = true
                
                // Custom pin for pickup (green) and dropoff (red) locations with better visibility
                let color: UIColor = isPickup ? .systemGreen : .systemRed
                let config = UIImage.SymbolConfiguration(pointSize: 30, weight: .bold)
                annotationView?.image = UIImage(systemName: "mappin.circle.fill", withConfiguration: config)?.withTintColor(color, renderingMode: .alwaysOriginal)
                
                // Add a small offset to make the pin point to the exact location
                annotationView?.centerOffset = CGPoint(x: 0, y: -15)
                
                return annotationView
            }
            
            return nil
        }
    }
}

// MARK: - Live Ride In Progress View
struct LiveRideInProgressView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel: LiveRideViewModel
    @State private var showCancelAlert = false
    @State private var showRideCompletionDialog = false
    @State private var showTextField = false
    @State private var showChatView = false
    @State private var chatNotificationData: ChatNotificationData?
    @State private var isShareSheetPresented = false
    @State private var shareItems: [Any] = []
    
    // Store observer tokens to properly remove them
    @State private var chatMessageObserver: NSObjectProtocol?
    @State private var chatToastObserver: NSObjectProtocol?
    @State private var chatMessageForViewObserver: NSObjectProtocol?
    @State private var chatToastForViewObserver: NSObjectProtocol?
    @State private var liveRideDataObserver: NSObjectProtocol?
    @State private var rideStatusObserver: NSObjectProtocol?
    @State private var appActiveObserver: NSObjectProtocol?
    @State private var appForegroundObserver: NSObjectProtocol?
    
    init(liveRideData: LiveRideData) {
        //print("RideDrive---LiveRideInProgressView:init")
        _viewModel = StateObject(wrappedValue: LiveRideViewModel(liveRideData: liveRideData))
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        // Map - 80% of screen
                        LiveRideMapView(viewModel: viewModel)
                            .frame(height: geometry.size.height * 0.8)
                        
                        // Bottom Card - Ride details
                        LiveRideBottomCard(
                            viewModel: viewModel,
                            showChatView: $showChatView,
                            onShareTripStatus: shareTripStatus,
                            showCancelAlert: $showCancelAlert
                        )
                    }
                }
                .edgesIgnoringSafeArea(.top)
                
                
            }
        }
        .navigationBarHidden(true)
        .alert("Cancel Ride", isPresented: $showCancelAlert) {
            Button("No", role: .cancel) { }
            Button("Yes, Cancel", role: .destructive) {
                cancelRide()
            }
        } message: {
            Text("Are you sure you want to cancel this ride?")
        }
        .onAppear {
            // CRITICAL: Ensure socket connection is established when ride in progress view appears
            print("🔌 LiveRideInProgressView: onAppear - Ensuring socket connection")
            
            // CRITICAL: Force map to focus on car immediately when view appears
            // This is especially important when coming from active_ride event after app kill
            // Reset user interaction flag to allow auto-focus
            viewModel.userHasInteractedWithMap = false
            viewModel.needsInitialFocus = true
            
            // Force focus immediately with driver location in notification
            DispatchQueue.main.async {
                viewModel.updateRegionToFocusOnCar()
                // Post notification with driver location to force map view update
                NotificationCenter.default.post(
                    name: NSNotification.Name("MapRegionUpdate"),
                    object: nil,
                    userInfo: ["coordinate": viewModel.driverLocation]
                )
                print("🗺️ LiveRideInProgressView: onAppear - Posted MapRegionUpdate with driver location")
            }
            
            // Also ensure focus after multiple delays to handle timing issues
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                viewModel.updateRegionToFocusOnCar()
                NotificationCenter.default.post(name: NSNotification.Name("MapRegionUpdate"), object: nil)
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                viewModel.updateRegionToFocusOnCar()
                NotificationCenter.default.post(name: NSNotification.Name("MapRegionUpdate"), object: nil)
            }
            
            // Also focus when driver location updates arrive (for when app is reopened)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                viewModel.updateRegionToFocusOnCar()
                NotificationCenter.default.post(name: NSNotification.Name("MapRegionUpdate"), object: nil)
            }
            
            // Check if socket is connected
            if !viewModel.socketService.isConnected {
                print("⚠️ LiveRideInProgressView: Socket not connected, attempting to connect...")
                viewModel.socketService.ensureConnectionForViewTransition()
            } else {
                print("✅ LiveRideInProgressView: Socket already connected, ensuring room membership...")
                viewModel.socketService.ensureConnectionForViewTransition()
            }
            
            // Start connection monitoring if not already active
            if !viewModel.socketService.isConnectionMonitoringActive {
                viewModel.socketService.startConnectionMonitoring()
            }
            
            // Force view refresh to ensure it's properly bound to the data
            viewModel.objectWillChange.send()
            
            // Setup app lifecycle listeners
            setupAppLifecycleListeners()
            
            // Listen for ride completion notifications
            setupRideCompletionListener()
            
            // Setup chat notification listener
            setupChatNotificationListener()
            
            // Remove existing internal view observers if they exist
            if let observer = chatMessageForViewObserver {
                NotificationCenter.default.removeObserver(observer)
                chatMessageForViewObserver = nil
            }
            if let observer = chatToastForViewObserver {
                NotificationCenter.default.removeObserver(observer)
                chatToastForViewObserver = nil
            }
            
            // Listen for chat message notifications (posted by observer)
            chatMessageForViewObserver = NotificationCenter.default.addObserver(
                forName: NSNotification.Name("ChatMessageReceivedForView"),
                object: nil,
                queue: .main
            ) { notification in
                guard let userInfo = notification.userInfo,
                      let bookingId = userInfo["bookingId"] as? Int,
                      let driverId = userInfo["driverId"] as? String,
                      let driverName = userInfo["driverName"] as? String else {
                    return
                }
                
                DispatchQueue.main.async {
                    guard !showChatView else { return }
                    
                    chatNotificationData = ChatNotificationData(
                        bookingId: bookingId,
                        driverId: driverId,
                        driverName: driverName
                    )
                    
                    // Removed orange toast banner - we now show proper notifications from SimpleSocketIOService
                    // The notification is handled in SimpleSocketIOService.handleNotificationEvent
                    // and will show only when user is not on chat screen
                    print("💬 RideInProgressView: Chat message received, but toast banner is disabled - using proper notifications instead")
                }
            }
            
            // Listen for chat toast tap notifications (posted by observer)
            chatToastForViewObserver = NotificationCenter.default.addObserver(
                forName: NSNotification.Name("ChatToastTappedForView"),
                object: nil,
                queue: .main
            ) { notification in
                guard let userInfo = notification.userInfo,
                      let tappedBookingId = userInfo["bookingId"] as? Int,
                      let tappedDriverId = userInfo["driverId"] as? String,
                      let tappedDriverName = userInfo["driverName"] as? String else {
                    return
                }
                
                DispatchQueue.main.async {
                    chatNotificationData = ChatNotificationData(
                        bookingId: tappedBookingId,
                        driverId: tappedDriverId,
                        driverName: tappedDriverName
                    )
                    
                    withAnimation(.easeInOut(duration: 0.25)) {
                        showChatView = true
                    }
                }
            }
            
            // Listen for live ride data updates to force view refresh and focus
            liveRideDataObserver = NotificationCenter.default.addObserver(
                forName: NSNotification.Name("LiveRideDataUpdated"),
                object: nil,
                queue: .main
            ) { [weak viewModel] _ in
                guard let viewModel = viewModel else { return }
                // Force view refresh by updating a dummy state
                viewModel.objectWillChange.send()
                
                // CRITICAL: Force focus on car when data updates (especially when real location arrives)
                // This is important when app is reopened and real driver location comes from socket
                if !viewModel.userHasInteractedWithMap {
                    viewModel.updateRegionToFocusOnCar()
                    NotificationCenter.default.post(name: NSNotification.Name("MapRegionUpdate"), object: nil)
                }
            }
            
            // Listen for status changes to force view refresh
            rideStatusObserver = NotificationCenter.default.addObserver(
                forName: NSNotification.Name("RideStatusChanged"),
                object: nil,
                queue: .main
            ) { [weak viewModel] notification in
                guard let viewModel = viewModel else { return }
                if let userInfo = notification.userInfo,
                   let previousStatus = userInfo["previousStatus"] as? String,
                   let newStatus = userInfo["newStatus"] as? String {
              
                    // Force view refresh by updating a dummy state
                    viewModel.objectWillChange.send()
                }
            }
        }
        .onDisappear {
            // Clean up chat notification observers using stored tokens
            if let observer = chatMessageObserver {
                NotificationCenter.default.removeObserver(observer)
                chatMessageObserver = nil
            }
            if let observer = chatToastObserver {
                NotificationCenter.default.removeObserver(observer)
                chatToastObserver = nil
            }
            if let observer = chatMessageForViewObserver {
                NotificationCenter.default.removeObserver(observer)
                chatMessageForViewObserver = nil
            }
            if let observer = chatToastForViewObserver {
                NotificationCenter.default.removeObserver(observer)
                chatToastForViewObserver = nil
            }
            
            // Clean up other notification observers using stored tokens
            if let observer = liveRideDataObserver {
                NotificationCenter.default.removeObserver(observer)
                liveRideDataObserver = nil
            }
            if let observer = rideStatusObserver {
                NotificationCenter.default.removeObserver(observer)
                rideStatusObserver = nil
            }
            if let observer = appActiveObserver {
                NotificationCenter.default.removeObserver(observer)
                appActiveObserver = nil
            }
            if let observer = appForegroundObserver {
                NotificationCenter.default.removeObserver(observer)
                appForegroundObserver = nil
            }
        }
        .sheet(isPresented: $showRideCompletionDialog) {
            RideCompletionBottomSheet(
                isPresented: $showRideCompletionDialog,
                showTextField: $showTextField,
                onRatingSubmitted: { rating, feedback in
                    handleRatingSubmitted(rating: rating, feedback: feedback)
                },
                onClose: {
                    // Navigate back to dashboard when close is tapped
                    dismiss()
                }
            )
            .presentationDetents([.height(showTextField ? 550 : 450)])
            .presentationDragIndicator(.visible)
            .presentationBackground {
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color.white)
                    .ignoresSafeArea(edges: .bottom)
            }
        }
        .fullScreenCover(isPresented: $showChatView) {
            if let chatData = chatNotificationData {
                ChatView(
                    bookingId: chatData.bookingId,
                    driverId: chatData.driverId,
                    driverName: chatData.driverName
                )
                .interactiveDismissDisabled()
                .onDisappear {
                    chatNotificationData = nil
                }
            } else {
                ChatView(
                    bookingId: Int(viewModel.liveRideData.bookingId) ?? 0,
                    driverId: viewModel.liveRideData.driverId,
                    driverName: "Driver"
                )
                .interactiveDismissDisabled()
            }
        }
        .sheet(isPresented: $isShareSheetPresented) {
            ShareSheet(activityItems: shareItems)
        }
        .toastOverlay()
    }
    
    // MARK: - Helper Functions
    
    private func cancelRide() {
        dismiss()
     
    }
    
    private func shareTripStatus() {
        let liveData = viewModel.liveRideData
        
        func formattedCoordinate(_ coordinate: CLLocationCoordinate2D) -> String {
            String(format: "%.5f, %.5f", coordinate.latitude, coordinate.longitude)
        }
        
        var infoLines: [String] = [
            "1800Limo Ride Details",
            "Booking ID: \(liveData.bookingId)",
            "Status: \(viewModel.statusMessage)",
            "Driver: \(viewModel.driverDisplayName)"
        ]
        
        infoLines.append("Pickup: \(liveData.pickupAddress) (\(formattedCoordinate(viewModel.pickupLocation)))")
        infoLines.append("Drop-off: \(liveData.dropoffAddress) (\(formattedCoordinate(viewModel.dropoffLocation)))")
        infoLines.append("Driver Location: \(formattedCoordinate(viewModel.driverLocation))")
        infoLines.append("ETA • Distance: \(viewModel.estimatedTime) • \(viewModel.distance)")
        
        let shareMessage = infoLines.joined(separator: "\n")
        
        var items: [Any] = [shareMessage]
        
        let driverLink = String(
            format: "https://maps.apple.com/?ll=%.6f,%.6f",
            viewModel.driverLocation.latitude,
            viewModel.driverLocation.longitude
        )
        
        if let url = URL(string: driverLink) {
            items.append(url)
        }
        
        shareItems = items
        isShareSheetPresented = !items.isEmpty
    }
    
    // MARK: - Ride Completion Handling
    
    private func setupRideCompletionListener() {
        
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name("RideStatusUpdate"),
            object: nil,
            queue: .main
        ) { notification in
            guard let userInfo = notification.userInfo,
                  let status = userInfo["status"] as? String else { 
                return
            }
            
            
            // Check if ride is completed
            if status == "ended" || status == "completed" {
                 
                 
                 
                DispatchQueue.main.async {
                    self.showRideCompletionDialog = true
                     
                }
            }
        }
        
         
    }
    
    private func setupChatNotificationListener() {
        // Remove existing observers if they exist
        if let observer = chatMessageObserver {
            NotificationCenter.default.removeObserver(observer)
            chatMessageObserver = nil
        }
        if let observer = chatToastObserver {
            NotificationCenter.default.removeObserver(observer)
            chatToastObserver = nil
        }
        
        let bookingId = viewModel.liveRideData.bookingId
        
        // Add new observer and store the token
        chatMessageObserver = NotificationCenter.default.addObserver(
            forName: .chatMessageReceived,
            object: nil,
            queue: .main
        ) { [weak viewModel] notification in
            guard let viewModel = viewModel else { return }
            guard let userInfo = notification.userInfo,
                  let notificationBookingId = userInfo["bookingId"] as? Int,
                  let driverId = userInfo["driverId"] as? String,
                  let driverName = userInfo["driverName"] as? String else {
                return
            }
            
            let currentBookingId = Int(bookingId) ?? 0
            guard notificationBookingId == currentBookingId else { return }
            
            // Post a notification that the view can observe to update state
            NotificationCenter.default.post(
                name: NSNotification.Name("ChatMessageReceivedForView"),
                object: nil,
                userInfo: [
                    "bookingId": notificationBookingId,
                    "driverId": driverId,
                    "driverName": driverName
                ]
            )
        }
        
        // Add new observer and store the token
        chatToastObserver = NotificationCenter.default.addObserver(
            forName: .chatToastTapped,
            object: nil,
            queue: .main
        ) { [weak viewModel] notification in
            guard let viewModel = viewModel else { return }
            guard let userInfo = notification.userInfo,
                  let tappedBookingId = userInfo["bookingId"] as? Int else {
                return
            }
            
            let currentBookingId = Int(bookingId) ?? 0
            guard tappedBookingId == currentBookingId else { return }
            
            let tappedDriverId = userInfo["driverId"] as? String ?? viewModel.liveRideData.driverId
            let tappedDriverName = (userInfo["driverName"] as? String).flatMap { name in
                name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : name
            } ?? "Driver"
            
            // Post a notification that the view can observe to update state
            NotificationCenter.default.post(
                name: NSNotification.Name("ChatToastTappedForView"),
                object: nil,
                userInfo: [
                    "bookingId": tappedBookingId,
                    "driverId": tappedDriverId,
                    "driverName": tappedDriverName
                ]
            )
        }
    }
    
    // MARK: - App Lifecycle Listeners
    private func setupAppLifecycleListeners() {
        // Remove existing observers if they exist
        if let observer = appActiveObserver {
            NotificationCenter.default.removeObserver(observer)
            appActiveObserver = nil
        }
        if let observer = appForegroundObserver {
            NotificationCenter.default.removeObserver(observer)
            appForegroundObserver = nil
        }
        
        // Listen for app becoming active (when app comes back from background)
        appActiveObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { _ in
            self.reconnectSocketAndListeners()
        }
        
        // Listen for app entering foreground (when app is launched or comes back from background)
        appForegroundObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.willEnterForegroundNotification,
            object: nil,
            queue: .main
        ) { _ in
            self.reconnectSocketAndListeners()
        }
    }
    
    // MARK: - Socket Reconnection
    private func reconnectSocketAndListeners() {
         
        
        // Use the consistent connection method
        viewModel.socketService.ensureConnectionForViewTransition()
        
        // Wait a bit for connection to establish
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            if self.viewModel.socketService.isConnected {
                 
                
                // Re-setup all listeners
                self.setupRideCompletionListener()
                self.setupChatNotificationListener()
                
                // Force view refresh
                self.viewModel.objectWillChange.send()
            } else {
                 
                self.viewModel.socketService.ensureConnectionForViewTransition()
            }
        }
    }
    
    private func handleRatingSubmitted(rating: Int, feedback: String?) {
        // Here you would typically send the rating to your backend API
        submitRatingToAPI(rating: rating, feedback: feedback)
        
        // Close sheet and navigate back to dashboard
        withAnimation(.easeInOut(duration: 0.3)) {
            showRideCompletionDialog = false
        }
        
        // Navigate back to dashboard after a brief delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            dismiss()
        }
    }
    
    private func submitRatingToAPI(rating: Int, feedback: String?) {
        // TODO: Implement API call to submit rating
        // This would typically involve:
        // 1. Creating a rating request with bookingId, rating (1-5 stars), feedback
        // 2. Making an API call to your backend
        // 3. Handling success/error responses
        
        // Simulate API call
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            print("Rating submitted: \(rating) stars, Feedback: \(feedback ?? "none")")
        }
    }
}

// MARK: - Live Ride Bottom Card
struct LiveRideBottomCard: View {
    @ObservedObject var viewModel: LiveRideViewModel
    @Binding var showChatView: Bool
    let onShareTripStatus: () -> Void
    @Binding var showCancelAlert: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            // Handle bar (centered) with Booking ID (top right)
            ZStack {
                // Centered handle bar
                RoundedRectangle(cornerRadius: 2.5)
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 40, height: 5)
                    .padding(.top, 8)
                
                // Booking ID Display (top right of card)
                HStack {
                    Spacer()
                    Text("Booking ID: \(viewModel.liveRideData.bookingId)")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.black)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(6)
                        .padding(.trailing, 20)
                        .padding(.top, 8)
                }
            }
            
            if viewModel.liveRideData.status == "on_location" {
                // DRIVER ON LOCATION UI (matching driver app)
                // Driver On Location Badge
                Text("Driver is on Location")
                    .font(.system(size: 16, weight: .semibold, design: .default))
                    .foregroundColor(Color(red: 0.2, green: 0.6, blue: 0.2))
                    .padding(.horizontal, 20)
                    .padding(.vertical, 8)
                    .background(Color(red: 0.9, green: 1.0, blue: 0.9))
                    .cornerRadius(20)
                    .padding(.top, 12)
                
                // Countdown Timer (5 minutes) - Black pill shape
                if viewModel.isCountdownActive {
                    Text(viewModel.countdownTime)
                        .font(.system(size: 18, weight: .bold, design: .monospaced))
                        .foregroundColor(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 8)
                        .background(Color.black)
                        .clipShape(Capsule())
                        .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 2)
                        .padding(.top, 16)
                }
                
                // OTP Section (matching driver app)
                VStack(spacing: 8) {
                    Text("Start ride with PIN")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    // Individual PIN boxes (like driver app)
                    HStack(spacing: 8) {
                        ForEach(Array(viewModel.rideOTP.enumerated()), id: \.offset) { index, digit in
                            Text(String(digit))
                                .font(.title2)
                                .fontWeight(.medium)
                                .foregroundColor(.black)
                                .frame(width: 40, height: 40)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(8)
                        }
                    }
                }
                .padding(.top, 16)
                
                // Driver Name with Contact Options
                HStack {
                    // Call Button - Left side
                    Button(action: {
                        viewModel.callDriver()
                    }) {
                        Image(systemName: "phone.fill")
                            .font(.system(size: 20))
                            .foregroundColor(viewModel.canCallDriver ? .black : .gray)
                            .frame(width: 50, height: 50)
                            .background(Color.gray.opacity(viewModel.canCallDriver ? 0.2 : 0.1))
                            .clipShape(Circle())
                    }
                    .disabled(!viewModel.canCallDriver)
                    .accessibilityLabel("Call driver")
                    
                    Spacer()
                    
                    // Driver's Name in center
                    Text(viewModel.driverDisplayName)
                        .font(.system(size: 20, weight: .bold, design: .default))
                        .foregroundColor(.black)
                    
                    Spacer()
                    
                    // Message Button - Right side
                    Button(action: {
                        showChatView = true
                    }) {
                        Image(systemName: "message.fill")
                            .font(.system(size: 20))
                            .foregroundColor(.black)
                            .frame(width: 50, height: 50)
                            .background(Color.gray.opacity(0.2))
                            .clipShape(Circle())
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                
                // Ride Details Section
                VStack(alignment: .leading, spacing: 16) {
                    Text("Ride Details")
                        .font(.title3)
                        .fontWeight(.bold)
                    
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "circle.fill")
                            .foregroundColor(.orange)
                            .font(.system(size: 12))
                            .padding(.top, 4)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Drop-off at \(viewModel.liveRideData.dropoffAddress)")
                                .font(.body)
                                .fontWeight(.medium)
                            
                            Text("Pickup: \(viewModel.liveRideData.pickupAddress)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        
                        Spacer()
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 24)
                
                // Share Trip Status Button
                Button(action: {
                    onShareTripStatus()
                }) {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 16))
                        Text("Share Trip Status")
                            .font(.body)
                            .fontWeight(.medium)
                    }
                    .foregroundColor(.black)
                    .padding(.vertical, 14)
                    .padding(.horizontal, 24)
                    .background(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 25)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
                    .cornerRadius(25)
                }
                .padding(.top, 20)
                
                // Cancel Ride Button
                Button(action: {
                    showCancelAlert = true
                }) {
                    Text("Cancel Ride")
                        .font(.body)
                        .fontWeight(.semibold)
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color.red, lineWidth: 2)
                        )
                        .cornerRadius(25)
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 24)
                
            } else if viewModel.liveRideData.status == "en_route_do" {
                // RIDE IN PROGRESS UI (matching driver app)
                // Ride In Progress Badge
                Text("Ride In Progress")
                    .font(.system(size: 16, weight: .semibold, design: .default))
                    .foregroundColor(Color(red: 0.2, green: 0.6, blue: 0.2))
                    .padding(.horizontal, 20)
                    .padding(.vertical, 8)
                    .background(Color(red: 0.9, green: 1.0, blue: 0.9))
                    .cornerRadius(20)
                    .padding(.top, 12)
                
                // Time and Distance (matching driver app font)
                Text("\(viewModel.estimatedTime) • \(viewModel.distance)")
                    .font(.system(size: 24, weight: .bold, design: .default))
                    .foregroundColor(.black)
                    .padding(.top, 16)
                
//                // Current Action (matching driver app)
//                Text("Dropping Off Passenger")
//                    .font(.system(size: 16, weight: .medium, design: .default))
//                    .foregroundColor(.gray)
//                    .padding(.top, 4)
                
                // Ride Details Section (matching driver app)
                VStack(alignment: .leading, spacing: 16) {
                    Text("Ride Details")
                        .font(.title3)
                        .fontWeight(.bold)
                    
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "circle.fill")
                            .foregroundColor(.orange)
                            .font(.system(size: 12))
                            .padding(.top, 4)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Drop-off at \(viewModel.liveRideData.dropoffAddress)")
                                .font(.body)
                                .fontWeight(.medium)
                            
                            Text("Pickup: \(viewModel.liveRideData.pickupAddress)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        
                        Spacer()
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 24)
                
                // Share Trip Status Button
                Button(action: {
                    onShareTripStatus()
                }) {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 16))
                        Text("Share Trip Status")
                            .font(.body)
                            .fontWeight(.medium)
                    }
                    .foregroundColor(.black)
                    .padding(.vertical, 14)
                    .padding(.horizontal, 24)
                    .background(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 25)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
                    .cornerRadius(25)
                }
                .padding(.top, 20)
                
                // Cancel Ride Button
                Button(action: {
                    showCancelAlert = true
                }) {
                    Text("Cancel Ride")
                        .font(.body)
                        .fontWeight(.semibold)
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color.red, lineWidth: 2)
                        )
                        .cornerRadius(25)
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 24)
                
            } else {
                // EN ROUTE TO PICKUP UI (matching driver app)
                // Status Text - Waiting For The Driver
                Text("Waiting For The Driver")
                    .font(.system(size: 16, weight: .semibold, design: .default))
                    .foregroundColor(.gray)
                    .padding(.top, 12)
                
                // Driver Name with Contact Options on sides
                HStack {
                    // Call Button - Left side
                    Button(action: {
                        viewModel.callDriver()
                    }) {
                        Image(systemName: "phone.fill")
                            .font(.system(size: 20))
                            .foregroundColor(viewModel.canCallDriver ? .black : .gray)
                            .frame(width: 50, height: 50)
                            .background(Color.gray.opacity(viewModel.canCallDriver ? 0.2 : 0.1))
                            .clipShape(Circle())
                    }
                    .disabled(!viewModel.canCallDriver)
                    .accessibilityLabel("Call driver")
                    
                    Spacer()
                    
                    // Driver's Name in center
                    Text(viewModel.driverDisplayName)
                        .font(.system(size: 20, weight: .bold, design: .default))
                        .foregroundColor(.black)
                    
                    Spacer()
                    
                    // Message Button - Right side
                    Button(action: {
                        showChatView = true
                    }) {
                        Image(systemName: "message.fill")
                            .font(.system(size: 20))
                            .foregroundColor(.black)
                            .frame(width: 50, height: 50)
                            .background(Color.gray.opacity(0.2))
                            .clipShape(Circle())
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                
                // Ride Details Section
                VStack(alignment: .leading, spacing: 16) {
                    Text("Ride Details")
                        .font(.title3)
                        .fontWeight(.bold)
                    
                    HStack(alignment: .top, spacing: 12) {
                        Image(systemName: "circle.fill")
                            .foregroundColor(.orange)
                            .font(.system(size: 12))
                            .padding(.top, 4)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Drop-off at \(viewModel.liveRideData.dropoffAddress)")
                                .font(.body)
                                .fontWeight(.medium)
                            
                            Text("Pickup: \(viewModel.liveRideData.pickupAddress)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        
                        Spacer()
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 24)
                
                // Share Trip Status Button
                Button(action: {
                    onShareTripStatus()
                }) {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 16))
                        Text("Share Trip Status")
                            .font(.body)
                            .fontWeight(.medium)
                    }
                    .foregroundColor(.black)
                    .padding(.vertical, 14)
                    .padding(.horizontal, 24)
                    .background(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 25)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
                    .cornerRadius(25)
                }
                .padding(.top, 20)
                
                // Cancel Ride Button
                Button(action: {
                    showCancelAlert = true
                }) {
                    Text("Cancel Ride")
                        .font(.body)
                        .fontWeight(.semibold)
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color.red, lineWidth: 2)
                        )
                        .cornerRadius(25)
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 24)
            }
        }
        .background(Color.white)
        .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: -2)
    }
}

// MARK: - Share Sheet Helper
struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    var applicationActivities: [UIActivity]? = nil
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: applicationActivities)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}


