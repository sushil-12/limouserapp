import SwiftUI
import MessageUI

struct DriverActionsBottomSheet: View {
    let booking: UserBooking
    @Binding var isPresented: Bool
    @State private var showMailComposer = false
    @State private var showReportMailComposer = false
    @State private var mailData = ComposeMailData(subject: "", recipients: [], body: "")
    @State private var reportMailData = ComposeMailData(subject: "", recipients: [], body: "")
    
    // Admin contact info
    private let adminEmail = "info@1800limo.com"
    private let adminPhoneNumber = "7087761685"
    
    var body: some View {
        VStack(spacing: 0) {
            // Handle bar at the top
            RoundedRectangle(cornerRadius: 2.5)
                .fill(Color.gray.opacity(0.4))
                .frame(width: 36, height: 4)
                .padding(.top, 12)
                .padding(.bottom, 8)
            
            VStack(spacing: 20) {
                // Booking ID
                Spacer().frame(height: 24)
                Text("Booking #\(booking.booking_id)")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.orange)
                    .padding(.top, 16)
                
                // Driver Info Card
                VStack(spacing: 12) {
                    // Profile Image and Name
                    VStack(spacing: 8) {
                        // Profile Image (placeholder)
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 60, height: 60)
                            .foregroundColor(.gray.opacity(0.3))
                        
                        // Driver Name
                        Text(booking.computed_driver_name ?? "1800limo Chauffeurs")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.black)
                        
                        Text("Driver")
                            .font(.system(size: 14, weight: .regular))
                            .foregroundColor(.gray)
                    }
                }
                .padding(.horizontal, 20)
                
                // Action Buttons Grid
                VStack(spacing: 16) {
                    // First row - Driver actions
                    HStack(spacing: 20) {
                        ActionButton(
                            icon: "phone.fill",
                            title: "Call\nDriver",
                            color: .orange
                        ) {
                            callDriver()
                        }
                        
                        ActionButton(
                            icon: "message.fill",
                            title: "Text\nDriver",
                            color: .orange
                        ) {
                            textDriver()
                        }
                        
                        ActionButton(
                            icon: "envelope.fill",
                            title: "Email Admin",
                            color: .orange
                        ) {
                            emailAdmin()
                        }
                    }
                    
                    // Second row - Admin and Report actions
                    HStack(spacing: 20) {
                        ActionButton(
                            icon: "phone.fill",
                            title: "Call Admin",
                            color: .orange
                        ) {
                            callAdmin()
                        }
                        
                        ActionButton(
                            icon: "message.fill",
                            title: "Text Admin",
                            color: .orange
                        ) {
                            textAdmin()
                        }
                        
                        ActionButton(
                            icon: "exclamationmark.triangle.fill",
                            title: "Report Issue",
                            color: .red
                        ) {
                            reportIssue()
                        }
                    }
                }
                .padding(.horizontal, 20)
                
                // Bottom message
                Text("Need help? Contact your driver or admin...")
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(.gray)
                    .padding(.bottom, 20)
                Spacer().frame(height: 18)
            }
        }
        .background(Color.white)
        .sheet(isPresented: $showMailComposer) {
            MailComposeView(data: $mailData) { result in
                showMailComposer = false
            }
        }
        .sheet(isPresented: $showReportMailComposer) {
            MailComposeView(data: $reportMailData) { result in
                showReportMailComposer = false
            }
        }
    }
    
    // MARK: - Action Methods
    
    private func callDriver() {
        if let isd = booking.driver_cell_isd, let number = booking.driver_cell_number,
           !isd.isEmpty && !number.isEmpty {
            let driverNumber = "\(isd)\(number)".replacingOccurrences(of: " ", with: "")
            if let url = URL(string: "tel:\(driverNumber)") {
                UIApplication.shared.open(url)
            }
        } else if let driverPhone = booking.driver_phone {
            let phoneNumber = driverPhone.replacingOccurrences(of: " ", with: "")
            if let url = URL(string: "tel:\(phoneNumber)") {
                UIApplication.shared.open(url)
            }
        }
        isPresented = false
    }
    
    private func textDriver() {
        if let isd = booking.driver_cell_isd, let number = booking.driver_cell_number,
           !isd.isEmpty && !number.isEmpty {
            let driverNumber = "\(isd)\(number)".replacingOccurrences(of: " ", with: "")
            if let url = URL(string: "sms:\(driverNumber)") {
                UIApplication.shared.open(url)
            }
        } else if let driverPhone = booking.driver_phone {
            let phoneNumber = driverPhone.replacingOccurrences(of: " ", with: "")
            if let url = URL(string: "sms:\(phoneNumber)") {
                UIApplication.shared.open(url)
            }
        }
        isPresented = false
    }
    
    private func emailAdmin() {
        guard MFMailComposeViewController.canSendMail() else {
            // Show alert or fallback action if mail is not available
            print("Mail services are not available")
            return
        }
        
        mailData = ComposeMailData(
            subject: "Booking #\(booking.booking_id) - User Communication",
            recipients: [adminEmail],
            body: "Dear Admin,\n\nRegarding booking #\(booking.booking_id).\n\nBest regards,\nUser"
        )
        showMailComposer = true
    }
    
    private func callAdmin() {
        if let url = URL(string: "tel:\(adminPhoneNumber)") {
            UIApplication.shared.open(url)
        }
        isPresented = false
    }
    
    private func textAdmin() {
        if let url = URL(string: "sms:\(adminPhoneNumber)") {
            UIApplication.shared.open(url)
        }
        isPresented = false
    }
    
    private func reportIssue() {
        guard MFMailComposeViewController.canSendMail() else {
            // Show alert or fallback action if mail is not available
            print("Mail services are not available")
            return
        }
        
        reportMailData = ComposeMailData(
            subject: "User Issue - Booking number #\(booking.booking_id)",
            recipients: [adminEmail],
            body: "Dear Admin,\n\nI am reporting an issue with booking #\(booking.booking_id).\n\nIssue Description:\n[Please describe the issue here]\n\nBest regards,\nUser"
        )
        showReportMailComposer = true
    }
}

// MARK: - Action Button Component
struct ActionButton: View {
    let icon: String
    let title: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 24, weight: .medium))
                    .foregroundColor(color)
                
                Text(title)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            .frame(width: 80, height: 80)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(12)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Mail Composer
struct ComposeMailData {
    let subject: String
    let recipients: [String]
    let body: String
}

struct MailComposeView: UIViewControllerRepresentable {
    @Binding var data: ComposeMailData
    let completion: (MFMailComposeResult) -> Void
    
    func makeUIViewController(context: Context) -> MFMailComposeViewController {
        let controller = MFMailComposeViewController()
        controller.mailComposeDelegate = context.coordinator
        
        // Safely set mail content
        if !data.subject.isEmpty {
            controller.setSubject(data.subject)
        }
        if !data.recipients.isEmpty {
            controller.setToRecipients(data.recipients)
        }
        if !data.body.isEmpty {
            controller.setMessageBody(data.body, isHTML: false)
        }
        
        return controller
    }
    
    func updateUIViewController(_ uiViewController: MFMailComposeViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, MFMailComposeViewControllerDelegate {
        let parent: MailComposeView
        
        init(_ parent: MailComposeView) {
            self.parent = parent
        }
        
        func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
            controller.dismiss(animated: true)
            parent.completion(result)
        }
    }
}























