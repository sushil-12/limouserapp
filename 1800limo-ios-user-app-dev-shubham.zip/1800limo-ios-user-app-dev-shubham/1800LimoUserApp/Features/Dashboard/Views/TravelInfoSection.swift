import SwiftUI

// MARK: - Travel Info Section Component
struct TravelInfoSection: View {
    let travelInfo: String
    let showDivider: Bool
    
    init(travelInfo: String, showDivider: Bool = true) {
        self.travelInfo = travelInfo
        self.showDivider = showDivider
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if showDivider {
                Divider()
                    .background(Color.gray.opacity(0.3))
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Total Travel Time")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.black)
                
                Text(travelInfo)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(AppColors.primaryOrange)
            }
        }
    }
}

// MARK: - Preview
struct TravelInfoSection_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 20) {
            TravelInfoSection(
                travelInfo: "45 minutes / 25.3 miles"
            )
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 2)
            
            TravelInfoSection(
                travelInfo: "1 hours, 30 minutes / 52.7 miles"
            )
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 2)
            
            TravelInfoSection(
                travelInfo: "4 hours (Charter Tour)"
            )
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 2)
        }
        .padding()
        .background(Color.gray.opacity(0.1))
    }
}
