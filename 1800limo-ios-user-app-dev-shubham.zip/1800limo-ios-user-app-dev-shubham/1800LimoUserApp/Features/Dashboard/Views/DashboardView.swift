import SwiftUI
import MapKit
import UserNotifications
import UIKit

struct MapAnnotationData: Identifiable {
    let id = UUID()
    let coordinate: CLLocationCoordinate2D
}

// MARK: - Navigation Screen Enum
enum Screen: Hashable {
    case scheduleRide
    case timeSelection(rideData: VehicleSelectionView.RideData)
    case paxLuggageVehicle(rideData: VehicleSelectionView.RideData)
    case vehicleSelection(rideData: VehicleSelectionView.RideData)
    case bookingDetails(rideData: VehicleSelectionView.RideData, selectedMasterVehicleId: Int, initialFilterSelection: FilterSelectionState?)
    case detailsBooking(rideData: VehicleSelectionView.RideData, selectedVehicle: VehicleListingItem?)
    case comprehensiveBooking(
        rideData: VehicleSelectionView.RideData?,
        selectedVehicle: VehicleListingItem?,
        isEditMode: Bool,
        editBookingId: Int?,
        isRepeatMode: Bool,
        repeatBookingId: Int?,
        isReturnFlow: Bool,
        isRoundTripFlow: Bool
    )
    case mapLocationSelection(
        locationType: String, // "pickup" or "destination"
        selectedBookingType: String,
        selectedDestinationType: String
    )
}

enum PermissionPromptType: Identifiable {
    case locationRequest
    case locationSettings
    case notificationRequest
    case notificationSettings
    
    var id: String {
        switch self {
        case .locationRequest:
            return "location_request"
        case .locationSettings:
            return "location_settings"
        case .notificationRequest:
            return "notification_request"
        case .notificationSettings:
            return "notification_settings"
        }
    }
}

final class NotificationPermissionManager: ObservableObject {
    @Published var authorizationStatus: UNAuthorizationStatus = .notDetermined
    
    init() {
        refreshAuthorizationStatus()
    }
    
    func refreshAuthorizationStatus(completion: ((UNAuthorizationStatus) -> Void)? = nil) {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                self.authorizationStatus = settings.authorizationStatus
                completion?(settings.authorizationStatus)
            }
        }
    }
    
    func requestPermission(completion: (() -> Void)? = nil) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            DispatchQueue.main.async {
                self.authorizationStatus = granted ? .authorized : .denied
                completion?()
            }
            self.refreshAuthorizationStatus()
        }
    }
}

struct DashboardView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var viewModel = DashboardViewModel()
    @StateObject private var userProfileVM = UserProfileViewModel()
    @StateObject private var userProfileService = UserProfileService()
    @StateObject private var bookingsViewModel = UserBookingsViewModel()
    @State private var searchText = ""
    @State private var showScheduleRideSheet = false
    @State private var showDrawerMenu = false
    @State private var shouldNavigateToLogin = false
    
    // Navigation path for NavigationStack
    @State private var navigationPath: [Screen] = []
    
    // Firebase and Socket.IO Services
    // Note: Use @ObservedObject for singleton services to avoid creating new instances
    @ObservedObject private var firebaseService = FirebasePushNotificationService.shared
    @ObservedObject private var socketService = SimpleSocketIOService.shared
    
    // Notification data manager for deep link handling
    @StateObject private var notificationDataManager = NotificationDataManager.shared
    
    // Navigation bindings for drawer menu
    @State private var navigateToMyBookings = false
    @State private var navigateToCreateBooking = false
    @State private var navigateToMyCards = false
    @State private var navigateToInvoices = false
    @State private var navigateToInbox = false
    @State private var navigateToNotifications = false
    @State private var navigateToAccountSettings = false
    @State private var navigateToHelp = false
    @State private var showRideInProgress = false
    
    // Track if navigation came from drawer menu to reopen drawer on back
    @State private var navigatedFromDrawerMenu = false
    @State private var drawerMenuClosedTimestamp: Date?
    @State private var permissionSheetType: PermissionPromptType?
    
    // Active ride booking data for RideInProgressView
    @State private var activeRideBookingData: BookingNotificationData?
    
    // Chat notification data
    @State private var chatNotificationData: ChatNotificationData?
    
    // Connection monitoring timer
    @State private var connectionCheckTimer: Timer?
    @StateObject private var notificationPermissionManager = NotificationPermissionManager()
    @State private var appBecameActiveObserver: NSObjectProtocol?
    @State private var permissionStatusObserver: NSObjectProtocol?
    
    
    var body: some View {
        NavigationStack(path: $navigationPath) {
            ZStack {
                // Map View
                Map(coordinateRegion: .constant(viewModel.mapRegion), annotationItems: [MapAnnotationData(coordinate: viewModel.mapRegion.center)]) { annotation in
                    MapAnnotation(coordinate: annotation.coordinate) {
                        Image("car")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 80, height: 80)
                    }
                }
                .ignoresSafeArea()
                
                VStack {
                    HStack {
                    // Hamburger Menu Button
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            showDrawerMenu = true
                        }
                    }) {
                        Image(systemName: "line.horizontal.3")
                            .font(.title2)
                            .foregroundColor(.black)
                            .frame(width: 44, height: 44)
                            .background(Color.white)
                            .clipShape(Circle())
                            .shadow(radius: 2)
                    }
                    .padding(.leading, 20)
                    .padding(.top, 20)
                    
                    Spacer()
                }
                
                Spacer()
                
                HStack {
                    Spacer()
                    
                    // Location Target Button
                    Button(action: {
                        viewModel.centerOnUserLocation()
                    }) {
                        Image("currentlocation")
                            
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, viewModel.isBottomSheetExpanded ? 430 : 190)
                    .animation(.easeInOut(duration: 0.3), value: viewModel.isBottomSheetExpanded)
                    }
                }
                
                // Bottom Sheet
                VStack {
                    Spacer()
                
                BottomSheetView(
                    isExpanded: $viewModel.isBottomSheetExpanded,
                    searchText: $searchText,
                    bookingsViewModel: bookingsViewModel,
                    showScheduleRideSheet: $showScheduleRideSheet,
                    onRefresh: {
                        fetchUpcomingBookings()
                    }
                    )
                }
                .ignoresSafeArea(.container, edges: .bottom)
                
                // Drawer Menu Overlay
                if showDrawerMenu {
                    UserDashboardDrawerMenu(
                    isPresented: $showDrawerMenu,
                    navigateToMyBookings: $navigateToMyBookings,
                    navigateToCreateBooking: $navigateToCreateBooking,
                    navigateToMyCards: $navigateToMyCards,
                    navigateToInvoices: $navigateToInvoices,
                    navigateToInbox: $navigateToInbox,
                    navigateToNotifications: $navigateToNotifications,
                    navigateToAccountSettings: $navigateToAccountSettings,
                    navigateToHelp: $navigateToHelp,
                    userProfileVM: userProfileVM,
                    onLogout: {
                        // Handle logout
                        handleLogout()
                    }
                    )
                    .zIndex(1)
                }
            }
            .navigationDestination(for: Screen.self) { screen in
                switch screen {
                case .scheduleRide:
                    ScheduleRideBottomSheet(path: $navigationPath)
                case .timeSelection(let rideData):
                    TimeSelectionView(rideData: rideData, path: $navigationPath)
                case .paxLuggageVehicle(let rideData):
                    PaxLuggageVehicleView(rideData: rideData, path: $navigationPath)
                case .vehicleSelection(let rideData):
                    VehicleSelectionView(rideData: rideData, path: $navigationPath)
                case .bookingDetails(let rideData, let selectedMasterVehicleId, let initialFilterSelection):
                    BookingDetailsView(
                        rideData: rideData,
                        selectedMasterVehicleId: selectedMasterVehicleId,
                        initialFilterSelection: initialFilterSelection,
                        path: $navigationPath
                    )
                case .detailsBooking(let rideData, let selectedVehicle):
                    DetailsBookingView(
                        rideData: rideData,
                        selectedVehicle: selectedVehicle,
                        path: $navigationPath
                    )
                case .comprehensiveBooking(let rideData, let selectedVehicle, let isEditMode, let editBookingId, let isRepeatMode, let repeatBookingId, let isReturnFlow, let isRoundTripFlow):
                    ComprehensiveBookingView(
                        rideData: rideData,
                        selectedVehicle: selectedVehicle as? VehicleListingItem,
                        isEditMode: isEditMode,
                        editBookingId: editBookingId,
                        isRepeatMode: isRepeatMode,
                        repeatBookingId: repeatBookingId,
                        isReturnFlow: isReturnFlow,
                        isRoundTripFlow: isRoundTripFlow,
                        path: $navigationPath
                    )
                case .mapLocationSelection(let locationType, let selectedBookingType, let selectedDestinationType):
                    MapLocationSelectionView(
                        path: $navigationPath,
                        locationType: locationType,
                        selectedBookingType: selectedBookingType,
                        selectedDestinationType: selectedDestinationType
                    )
                }
            }
        }
        .toastOverlay()
        .refreshable {
            // Pull to refresh functionality
            await refreshDashboard()
            
        }
        .onAppear {
            // CRITICAL: Ensure socket connection is established when Dashboard appears
            // This is the ONLY place where we explicitly connect the socket
            // The socket will remain connected across all navigation
            print("🔌 DashboardView: onAppear - Ensuring socket connection")
            
            // Ensure socket connection - this will connect if not already connected
            // Connection is managed at app lifecycle level, not view lifecycle
            socketService.ensureConnection()
            
            // Fetch user profile data when dashboard appears
            Task {
                await fetchUserProfile()
            }
            
            // Initialize Firebase when dashboard appears
            setupNotifications()
            
            // Check for deep link navigation when dashboard appears
            checkDeepLinkNavigation()
            
            // Fetch bookings for today and future dates
            fetchUpcomingBookings()
            
            // Update user location in socket service
            if let userLocation = viewModel.userLocation {
                socketService.updateCurrentUserLocation(userLocation)
            }
            
            // Setup chat notification listener
            setupChatNotificationListener()
            
            notificationPermissionManager.refreshAuthorizationStatus()
            updatePermissionSheet(for: viewModel.locationPermissionStatus)
            
            // Setup app lifecycle observer for immediate permission checking
            setupAppLifecycleObserver()
            
            // Listen for permission status changes from observer
            setupPermissionStatusListener()
        }
        .onDisappear {
            // Remove app lifecycle observer
            removeAppLifecycleObserver()
            
            // NOTE: Socket connection is NOT disconnected here
            // Socket remains connected across all navigation
            // Only disconnects on explicit logout via disconnectForLogout()
        }
        // Removed onChange observers for socket connection
        // Socket reconnection is handled automatically by SimpleSocketIOService
        // Views should not manage socket lifecycle
        .onChange(of: scenePhase) { newPhase in
            handleScenePhaseChange(newPhase)
        }
        .onChange(of: viewModel.locationPermissionStatus) { status in
            updatePermissionSheet(for: status)
        }
        .onChange(of: notificationPermissionManager.authorizationStatus) { status in
            updateNotificationPermissionPrompt(for: status)
        }
        .onChange(of: permissionSheetType) { newSheetType in
            // When location sheet is dismissed, immediately check and show notification sheet if needed
            if newSheetType == nil {
                // Sheet was dismissed, check if we need to show notification sheet
                checkAndShowNextPermissionSheet()
            }
        }
        // Track navigation from drawer menu - use timestamp to detect navigation right after drawer closes
        .onChange(of: showDrawerMenu) { newValue in
            if !newValue {
                // Drawer just closed - record timestamp
                drawerMenuClosedTimestamp = Date()
            } else {
                // Drawer opened - clear navigation flag and timestamp
                navigatedFromDrawerMenu = false
                drawerMenuClosedTimestamp = nil
            }
        }
        // Track navigation from drawer menu - check if navigation happens within 0.5 seconds of drawer closing
        .onChange(of: navigateToMyBookings) { isNavigating in
            if isNavigating {
                checkIfNavigationFromDrawerMenu()
            } else if navigatedFromDrawerMenu {
                // Screen was dismissed - immediately open drawer menu to avoid DashboardView flash
                showDrawerMenu = true
                navigatedFromDrawerMenu = false
            }
        }
        .onChange(of: navigateToCreateBooking) { isNavigating in
            if isNavigating {
                checkIfNavigationFromDrawerMenu()
            } else if navigatedFromDrawerMenu {
                // Screen was dismissed - immediately open drawer menu to avoid DashboardView flash
                showDrawerMenu = true
                navigatedFromDrawerMenu = false
            }
        }
        .onChange(of: navigateToMyCards) { isNavigating in
            if isNavigating {
                checkIfNavigationFromDrawerMenu()
            } else if navigatedFromDrawerMenu {
                // Screen was dismissed - immediately open drawer menu to avoid DashboardView flash
                showDrawerMenu = true
                navigatedFromDrawerMenu = false
            }
        }
        .onChange(of: navigateToInvoices) { isNavigating in
            if isNavigating {
                checkIfNavigationFromDrawerMenu()
            } else if navigatedFromDrawerMenu {
                // Screen was dismissed - immediately open drawer menu to avoid DashboardView flash
                showDrawerMenu = true
                navigatedFromDrawerMenu = false
            }
        }
        .onChange(of: navigateToInbox) { isNavigating in
            if isNavigating {
                checkIfNavigationFromDrawerMenu()
            } else if navigatedFromDrawerMenu {
                // Screen was dismissed - immediately open drawer menu to avoid DashboardView flash
                showDrawerMenu = true
                navigatedFromDrawerMenu = false
            }
        }
        .onChange(of: navigateToNotifications) { isNavigating in
            if isNavigating {
                checkIfNavigationFromDrawerMenu()
            } else if navigatedFromDrawerMenu {
                // Screen was dismissed - immediately open drawer menu to avoid DashboardView flash
                showDrawerMenu = true
                navigatedFromDrawerMenu = false
            }
        }
        .onChange(of: navigateToAccountSettings) { isNavigating in
            if isNavigating {
                checkIfNavigationFromDrawerMenu()
            } else if navigatedFromDrawerMenu {
                // Screen was dismissed - immediately open drawer menu to avoid DashboardView flash
                showDrawerMenu = true
                navigatedFromDrawerMenu = false
            }
        }
        .onChange(of: navigateToHelp) { isNavigating in
            if isNavigating {
                checkIfNavigationFromDrawerMenu()
            } else if navigatedFromDrawerMenu {
                // Screen was dismissed - immediately open drawer menu to avoid DashboardView flash
                showDrawerMenu = true
                navigatedFromDrawerMenu = false
            }
        }
        .withInAppNotifications()
        .onChange(of: showScheduleRideSheet) { newValue in
            if newValue {
                navigationPath.append(.scheduleRide)
                showScheduleRideSheet = false
            }
        }
        .fullScreenCover(isPresented: $navigateToMyBookings) {
            NavigationView {
                MyBookingsView()
            }
            .onDisappear {
                reopenDrawerMenuIfNeeded()
            }
        }
        .onChange(of: navigateToCreateBooking) { newValue in
            if newValue {
                navigationPath.append(.scheduleRide)
                navigateToCreateBooking = false
            }
        }
        .fullScreenCover(isPresented: $navigateToInvoices) {
            NavigationView {
                InvoicesView()
            }
            .onDisappear {
                reopenDrawerMenuIfNeeded()
            }
        }
        .fullScreenCover(isPresented: $navigateToMyCards) {
            NavigationView {
                MyCardsView()
            }
            .onDisappear {
                reopenDrawerMenuIfNeeded()
            }
        }
        .fullScreenCover(isPresented: $navigateToAccountSettings) {
            NavigationView {
                AccountSettingsView()
            }
            .onDisappear {
                reopenDrawerMenuIfNeeded()
            }
        }
        .fullScreenCover(isPresented: $shouldNavigateToLogin) {
            NavigationView {
                LoginScreen()
            }
        }
        .fullScreenCover(isPresented: $navigateToInbox) {
            if let chatData = chatNotificationData {
                ChatView(
                    bookingId: chatData.bookingId,
                    driverId: chatData.driverId,
                    driverName: chatData.driverName
                )
                .interactiveDismissDisabled()
                .onDisappear {
                    chatNotificationData = nil
                    reopenDrawerMenuIfNeeded()
                }
            } else {
                // For testing purposes - in real implementation, these should come from actual booking data
                ChatView(
                    bookingId: 123,
                    driverId: "2",
                    driverName: "Driver"
                )
                .interactiveDismissDisabled()
                .onDisappear {
                    reopenDrawerMenuIfNeeded()
                }
            }
        }
        .fullScreenCover(isPresented: $navigateToNotifications) {
            BookingAuditRecordsView()
                .onDisappear {
                    reopenDrawerMenuIfNeeded()
                }
        }
        .fullScreenCover(isPresented: $showRideInProgress) {
            if let liveRideData = socketService.liveRideData {
                // Always use LiveRideInProgressView for both live_ride and active_ride events
                LiveRideInProgressView(liveRideData: liveRideData)
                    .onAppear {
                        // Use consistent connection method
                        socketService.ensureConnectionForViewTransition()
                    }
            } else {
                // Fallback to test data with LiveRideData format
                let fallbackLiveRideData = LiveRideData(
                    bookingId: "1497",
                    driverId: "1",
                    customerId: "1",
                    status: "en_route_pu",
                    driverLatitude: 30.6735,
                    driverLongitude: 76.7884,
                    pickupLatitude: 30.6735,
                    pickupLongitude: 76.7884,
                    dropoffLatitude: 30.6942,
                    dropoffLongitude: 76.7933,
                    pickupAddress: "Sector 17, Chandigarh",
                    dropoffAddress: "Chandigarh Airport, Mohali",
                    timestamp: "2025-01-15T14:00:00Z",
                    title: "Test Ride",
                    message: "Driver is on the way to pickup",
                    driverName: "Sample Driver",
                    driverPhone: "+18571423652"
                )
                
                LiveRideInProgressView(liveRideData: fallbackLiveRideData)
                    .onAppear {
                    }
            }
        }
        .onChange(of: socketService.shouldShowRideInProgress) { shouldShow in
            if shouldShow {
                showRideInProgress = true
                // Reset the flag
                socketService.shouldShowRideInProgress = false
            }
        }
        .onChange(of: socketService.shouldNavigateToActiveRide) { shouldNavigate in
            if shouldNavigate {
                // Ensure socket connection is stable before navigation
                socketService.ensureConnectionForViewTransition()
                
                // Wait a moment for connection to stabilize
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.handleActiveRideNavigation()
                }
            }
        }
        .onChange(of: showRideInProgress) { isShowing in
            if !isShowing {
                // User has returned from RideInProgressView - ensure socket connection is maintained
                ensureSocketConnection()
                
                // Clear the active ride booking data
                activeRideBookingData = nil
                
                // Clear ride data from socket service to stop driver location updates
                socketService.clearRideData()
            }
        }
        .sheet(
            isPresented: Binding(
                get: { permissionSheetType != nil },
                set: { isPresented in
                    if !isPresented {
                        permissionSheetType = nil
                    }
                }
            )
        ) {
            if let sheetType = permissionSheetType {
                PermissionPromptSheet(
                    type: sheetType,
                    onLocationRequest: {
                        viewModel.refreshCurrentLocation()
                    },
                    onNotificationRequest: {
                            notificationPermissionManager.requestPermission {
                                updateNotificationPermissionPrompt(for: notificationPermissionManager.authorizationStatus)
                            }
                    },
                    onOpenSettings: {
                        openAppSettings()
                    }
                )
                .interactiveDismissDisabled(true)
            }
        }
    }
    
    // MARK: - Active Ride Navigation Helper
    
    /// Handle active ride navigation with proper socket connection
    private func handleActiveRideNavigation() {
        // Convert ActiveRideData to LiveRideData for LiveRideInProgressView
        if let activeRideData = socketService.activeRideData {
            // Convert ActiveRideData to LiveRideData format
            let liveRideData = convertActiveRideToLiveRideData(activeRideData)
            
            // Store the converted data in socket service for LiveRideInProgressView
            socketService.liveRideData = liveRideData
            
            // Clear any existing active ride booking data
            activeRideBookingData = nil
            
            showRideInProgress = true
        }
        
        // Reset the flag
        socketService.shouldNavigateToActiveRide = false
    }
    
    // MARK: - Active Ride Data Conversion
    
    /// Convert ActiveRideData to BookingNotificationData for RideInProgressView
    private func convertActiveRideToBookingData(_ activeRideData: ActiveRideData) -> BookingNotificationData {
        // Convert string coordinates to doubles
        let pickupLat = Double(activeRideData.locations.pickup.latitude) ?? 0.0
        let pickupLong = Double(activeRideData.locations.pickup.longitude) ?? 0.0
        let dropoffLat = Double(activeRideData.locations.dropoff.latitude) ?? 0.0
        let dropoffLong = Double(activeRideData.locations.dropoff.longitude) ?? 0.0
        
        
        return BookingNotificationData(
            bookingId: activeRideData.bookingId,
            pickupDate: activeRideData.locations.pickup.datetime,
            pickupTime: "00:00:00", // Will be extracted from datetime if needed
            pickupAddress: activeRideData.locations.pickup.address,
            dropoffAddress: activeRideData.locations.dropoff.address,
            reminderType: "none",
            formattedDatetime: activeRideData.locations.pickup.datetime,
            pickupAddressLat: pickupLat,
            pickupAddressLong: pickupLong,
            dropoffAddressLat: dropoffLat,
            dropoffAddressLong: dropoffLong,
            status: activeRideData.status
        )
    }
    
    /// Convert ActiveRideData to LiveRideData for socket service
    private func convertActiveRideToLiveRideData(_ activeRideData: ActiveRideData) -> LiveRideData {
        // Convert string coordinates to doubles
        let pickupLat = Double(activeRideData.locations.pickup.latitude) ?? 0.0
        let pickupLong = Double(activeRideData.locations.pickup.longitude) ?? 0.0
        let dropoffLat = Double(activeRideData.locations.dropoff.latitude) ?? 0.0
        let dropoffLong = Double(activeRideData.locations.dropoff.longitude) ?? 0.0
        
        // Set driver location away from pickup to show route
        // Offset driver location by ~1km to show a proper route
        let driverLat = pickupLat + 0.01 // ~1km north of pickup
        let driverLong = pickupLong + 0.01 // ~1km east of pickup
        
        
        return LiveRideData(
            bookingId: String(activeRideData.bookingId),
            driverId: String(activeRideData.driver.id),
            customerId: String(activeRideData.customer.id),
            status: activeRideData.status,
            driverLatitude: driverLat, // Set driver away from pickup to show route
            driverLongitude: driverLong,
            pickupLatitude: pickupLat,
            pickupLongitude: pickupLong,
            dropoffLatitude: dropoffLat,
            dropoffLongitude: dropoffLong,
            pickupAddress: activeRideData.locations.pickup.address,
            dropoffAddress: activeRideData.locations.dropoff.address,
            timestamp: activeRideData.timestamps.updatedAt,
            title: "Active Ride",
            message: "Driver is \(activeRideData.statusDisplay.lowercased())",
            driverName: activeRideData.driver.name,
            driverPhone: activeRideData.driver.phone
        )
    }
    
    // MARK: - Deep Link Navigation
    
    /// Check if dashboard was opened from notification and handle navigation
    private func checkDeepLinkNavigation() {
        notificationDataManager.printCurrentState()
        
        // Check if we should navigate to RideInProgressView
        if notificationDataManager.shouldOpenToRideInProgress {
            // Get the pending ride data
            if let rideData = notificationDataManager.retrievePendingRideData() {
                // Store the data in socket service for the view
                socketService.liveRideData = rideData
                
                // Open RideInProgressView
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    showRideInProgress = true
                    notificationDataManager.clearNavigationFlags()
                }
            } else {
                notificationDataManager.clearNavigationFlags()
            }
            return
        }
        
        // Check if we should navigate to MyBookingsView
        if notificationDataManager.shouldOpenToMyBookings {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                navigateToMyBookings = true
                notificationDataManager.clearNavigationFlags()
            }
            return
        }
    }
    
    // MARK: - Firebase & Socket.IO Setup
    private func setupNotifications() {
        // Get user ID
        guard let userId = StorageManager.shared.getUserIdString() else {
            return
        }
        
        // Subscribe to Firebase topic
        firebaseService.subscribeToUserTopic()
        
        // Connect Socket.IO
        if !socketService.isConnected {
            socketService.reconnectWithNewUserId()
        }
        
        // Ensure connection is established for active ride events
        socketService.ensureConnectionForViewTransition()
        
        // Active ride listener is already set up in SimpleSocketIOService
    }
    
    /// Ensure socket connection is maintained when returning from RideInProgressView or when dashboard appears
    private func ensureSocketConnection() {
        print("🔌 DashboardView: ensureSocketConnection - Checking socket status")
        
        // Get current user ID to verify we can connect
        let userId = StorageManager.shared.getUserIdString() ?? "unknown"
        if userId == "unknown" {
            print("⚠️ DashboardView: Cannot connect - User ID is unknown")
            return
        }
        
        // Always call ensureConnectionForViewTransition to ensure connection
        // This method handles both connecting and reconnecting scenarios
        socketService.ensureConnectionForViewTransition()
        
        // Check if socket is connected
        if !socketService.isConnected {
            print("⚠️ DashboardView: Socket not connected, attempting immediate connection...")
            // If not connected, try connecting directly
            socketService.connect()
            
            // Also ensure room membership once connected
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                if self.socketService.isConnected {
                    self.socketService.joinRoomManually()
                } else {
                    // Retry connection
                    self.socketService.connect()
                }
            }
        } else {
            print("✅ DashboardView: Socket already connected, ensuring room membership...")
            // If already connected, ensure room membership is active
            socketService.joinRoomManually()
        }
        
        // Start connection monitoring if not already active
        if !socketService.isConnectionMonitoringActive {
            socketService.startConnectionMonitoring()
        }
    }
    
    /// Start enhanced socket connection monitoring
    private func startEnhancedSocketConnectionMonitoring() {
        // Start the socket service's built-in monitoring
        socketService.startConnectionMonitoring()
        
        // Also ensure connection is active
        ensureSocketConnection()
    }
    
    /// Start periodic connection check to ensure socket stays connected
    private func startPeriodicConnectionCheck() {
        // Stop any existing timer
        stopPeriodicConnectionCheck()
        
        // Capture socketService to avoid potential retain cycles
        let service = socketService
        
        // Check connection every 10 seconds
        connectionCheckTimer = Timer.scheduledTimer(withTimeInterval: 10.0, repeats: true) { _ in
            // Only check if we're not already reconnecting
            if !service.isReconnecting {
                if !service.isConnected {
                    print("⚠️ Periodic check: Socket disconnected, reconnecting...")
                    service.ensureConnectionForViewTransition()
                } else {
                    // Connection is good, ensure monitoring is active
                    if !service.isConnectionMonitoringActive {
                        service.startConnectionMonitoring()
                    }
                }
            }
        }
    }
    
    /// Stop periodic connection check
    private func stopPeriodicConnectionCheck() {
        connectionCheckTimer?.invalidate()
        connectionCheckTimer = nil
    }
    
    // MARK: - Scene Phase Handling
    
    private func handleScenePhaseChange(_ newPhase: ScenePhase) {
        switch newPhase {
        case .active:
            resumeForegroundRideUpdates()
        case .inactive, .background:
            pauseBackgroundActivities()
        @unknown default:
            break
        }
    }
    
    private func resumeForegroundRideUpdates() {
        // Socket connection is managed by SimpleSocketIOService at app lifecycle level
        // App lifecycle observers in SimpleSocketIOService will handle reconnection
        print("🔌 DashboardView: App became active - Socket connection managed by SimpleSocketIOService")
        
        // Check permissions immediately when app becomes active
        checkPermissionsImmediately()
    }
    
    private func pauseBackgroundActivities() {
        stopPeriodicConnectionCheck()
    }

    private func refreshNotificationPermissionState() {
        // Check notification permission immediately
        notificationPermissionManager.refreshAuthorizationStatus { status in
            DispatchQueue.main.async {
                self.updateNotificationPermissionPrompt(for: status)
            }
        }
        
        // Refresh location permission status immediately
        let currentLocationStatus = viewModel.locationPermissionStatus
        viewModel.refreshLocationPermissionStatus()
        
        // Update sheet based on current status
        DispatchQueue.main.async {
            self.updatePermissionSheet(for: currentLocationStatus)
        }
    }
    
    // MARK: - App Lifecycle Observer
    
    private func setupAppLifecycleObserver() {
        // Remove existing observer if any
        removeAppLifecycleObserver()
        
        // Store references to the objects we need
        let notificationManager = notificationPermissionManager
        let locationViewModel = viewModel
        
        // Add observer for app becoming active to check permissions immediately
        appBecameActiveObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didBecomeActiveNotification,
            object: nil,
            queue: .main
        ) { _ in
            // Check permissions immediately when app becomes active (e.g., returning from Settings)
            // Small delay to ensure system has updated permission status
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                // Refresh location permission status
                locationViewModel.refreshLocationPermissionStatus()
                let locationStatus = locationViewModel.locationPermissionStatus
                
                // Check notification permission
                notificationManager.refreshAuthorizationStatus { status in
                    DispatchQueue.main.async {
                        // Update permission sheets based on current status
                        // If location was just granted, show notification sheet immediately
                        if locationStatus == .authorizedAlways || locationStatus == .authorizedWhenInUse {
                            // Location is granted, check if notification sheet should be shown
                            let prompt = self.permissionPromptTypeForNotificationStatus(status)
                            if let notificationPrompt = prompt {
                                // Show notification sheet immediately
                                self.permissionSheetType = notificationPrompt
                            } else {
                                // Both permissions granted, close any open sheets
                                self.permissionSheetType = nil
                            }
                        } else {
                            // Location still denied, update location sheet if needed
                            if locationStatus == .denied || locationStatus == .restricted {
                                // Show location sheet if not already showing notification sheet
                                if self.permissionSheetType != .notificationSettings && 
                                   self.permissionSheetType != .notificationRequest {
                                    self.permissionSheetType = .locationSettings
                                }
                            }
                            
                            // Also check notification status
                            let notificationPrompt = self.permissionPromptTypeForNotificationStatus(status)
                            if let prompt = notificationPrompt {
                                // If no sheet is showing, show notification sheet
                                if self.permissionSheetType == nil {
                                    self.permissionSheetType = prompt
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func removeAppLifecycleObserver() {
        if let observer = appBecameActiveObserver {
            NotificationCenter.default.removeObserver(observer)
            appBecameActiveObserver = nil
        }
        if let observer = permissionStatusObserver {
            NotificationCenter.default.removeObserver(observer)
            permissionStatusObserver = nil
        }
    }
    
    private func setupPermissionStatusListener() {
        // Remove existing observer if any
        if let observer = permissionStatusObserver {
            NotificationCenter.default.removeObserver(observer)
        }
        
        // Listen for permission status changes
        permissionStatusObserver = NotificationCenter.default.addObserver(
            forName: NSNotification.Name("PermissionStatusChanged"),
            object: nil,
            queue: .main
        ) { notification in
            guard let userInfo = notification.userInfo,
                  let locationStatus = userInfo["locationStatus"] as? CLAuthorizationStatus,
                  let notificationStatus = userInfo["notificationStatus"] as? UNAuthorizationStatus else {
                return
            }
            
            // Update permission sheet based on status
            // If location is granted, show notification sheet immediately
            if locationStatus == .authorizedAlways || locationStatus == .authorizedWhenInUse {
                // Location is granted, check notification
                let prompt = self.permissionPromptTypeForNotificationStatus(notificationStatus)
                if let notificationPrompt = prompt {
                    // Show notification sheet immediately
                    self.permissionSheetType = notificationPrompt
                } else {
                    // Both granted, close sheet
                    self.permissionSheetType = nil
                }
            } else {
                // Location still denied, update location sheet
                self.updatePermissionSheet(for: locationStatus)
            }
        }
    }
    
    private func checkPermissionsImmediately() {
        // Refresh location permission status immediately
        viewModel.refreshLocationPermissionStatus()
        
        // Get updated location status after refresh
        let locationStatus = viewModel.locationPermissionStatus
        
        // Update sheet based on location status
        updatePermissionSheet(for: locationStatus)
        
        // Check notification permission immediately
        notificationPermissionManager.refreshAuthorizationStatus { status in
            DispatchQueue.main.async {
                self.updateNotificationPermissionPrompt(for: status)
            }
        }
    }
    
    /// Stop enhanced socket connection monitoring
    private func stopEnhancedSocketConnectionMonitoring() {
        // Note: We don't stop monitoring completely to ensure reconnection works
        // The monitoring will continue in the background
        // socketService.stopConnectionMonitoring()
    }
    
    // MARK: - Connection Status Monitoring
    // NOTE: Socket connection status is managed automatically by SimpleSocketIOService
    // Views should not handle connection status changes - reconnection is automatic
    
    // MARK: - Permission Helpers
    
    private func updatePermissionSheet(for status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
            // Location is granted, check notification permission
            // Close location sheet immediately if it was open
            if permissionSheetType == .locationSettings || permissionSheetType == .locationRequest {
                permissionSheetType = nil
            }
            
            // Check notification permission immediately after location is granted
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.notificationPermissionManager.refreshAuthorizationStatus { newStatus in
                    DispatchQueue.main.async {
                        self.updateNotificationPermissionPrompt(for: newStatus)
                    }
                }
            }
        case .notDetermined:
            // Close sheet if location is not determined
            if permissionSheetType == .locationSettings || permissionSheetType == .locationRequest {
                permissionSheetType = nil
            }
        case .denied, .restricted:
            // Show location settings sheet - notification will be checked when this sheet is dismissed
            permissionSheetType = .locationSettings
        @unknown default:
            permissionSheetType = .locationSettings
        }
    }
    
    private func updateNotificationPermissionPrompt(for status: UNAuthorizationStatus) {
        let locationStatus = viewModel.locationPermissionStatus
        let prompt = permissionPromptTypeForNotificationStatus(status)
        
        // Close sheet immediately if permission is granted
        if status == .authorized || status == .provisional || status == .ephemeral {
            if permissionSheetType == .notificationSettings || permissionSheetType == .notificationRequest {
                permissionSheetType = nil
            }
            return
        }
        
        // If notification is denied/not determined, show notification sheet
        // Show notification sheet even if location is denied (user should be able to grant both)
        if let prompt = prompt {
            // Only show notification sheet if no other sheet is currently showing
            if permissionSheetType == nil || permissionSheetType == .notificationSettings || permissionSheetType == .notificationRequest {
                permissionSheetType = prompt
            }
        }
    }
    
    /// Check and show the next permission sheet in sequence
    private func checkAndShowNextPermissionSheet() {
        // Refresh location status first
        viewModel.refreshLocationPermissionStatus()
        let locationStatus = viewModel.locationPermissionStatus
        
        // Refresh notification status and then check
        notificationPermissionManager.refreshAuthorizationStatus { notificationStatus in
            DispatchQueue.main.async {
                // If location is still denied, we already showed location sheet, so check notification
                if locationStatus == .denied || locationStatus == .restricted {
                    // Location is denied, check notification status
                    let notificationPrompt = self.permissionPromptTypeForNotificationStatus(notificationStatus)
                    if let prompt = notificationPrompt {
                        // Show notification sheet immediately after location sheet is dismissed
                        self.permissionSheetType = prompt
                    }
                } else if locationStatus == .authorizedAlways || locationStatus == .authorizedWhenInUse {
                    // Location is granted, check notification
                    let notificationPrompt = self.permissionPromptTypeForNotificationStatus(notificationStatus)
                    if let prompt = notificationPrompt {
                        // Show notification sheet immediately after location is granted
                        self.permissionSheetType = prompt
                    } else {
                        // Both permissions granted, ensure sheet is closed
                        self.permissionSheetType = nil
                    }
                }
            }
        }
    }
    private func permissionPromptTypeForNotificationStatus(_ status: UNAuthorizationStatus) -> PermissionPromptType? {
        switch status {
        case .authorized, .provisional, .ephemeral:
            return nil
        case .notDetermined:
            return .notificationRequest
        case .denied:
            return .notificationSettings
        @unknown default:
            return .notificationSettings
        }
    }
    
    private func openAppSettings() {
        guard let settingsURL = URL(string: UIApplication.openSettingsURLString),
              UIApplication.shared.canOpenURL(settingsURL) else {
            return
        }
        
        UIApplication.shared.open(settingsURL, options: [:], completionHandler: nil)
    }
    
    private func setupChatNotificationListener() {
        NotificationCenter.default.addObserver(
            forName: .chatMessageReceived,
            object: nil,
            queue: .main
        ) { notification in
            guard let userInfo = notification.userInfo,
                  let bookingId = userInfo["bookingId"] as? Int,
                  let driverId = userInfo["driverId"] as? String,
                  let driverName = userInfo["driverName"] as? String else {
                return
            }
            
            // Auto-open disabled - user must manually open chat view
            // if !self.navigateToInbox {
            //     DispatchQueue.main.async {
            //         self.chatNotificationData = ChatNotificationData(
            //             bookingId: bookingId,
            //             driverId: driverId,
            //             driverName: driverName
            //         )
            //         self.navigateToInbox = true
            //     }
            // }
        }
    }
    
    // MARK: - User Profile Methods
    private func fetchUserProfile() async {
        let result = await userProfileService.fetchUserProfile()
        
        if result.success, let profileData = result.data {
            // Save profile data to storage
            StorageManager.shared.saveUserProfileData(profileData)
            
            // Also save name and email separately for quick access
            let fullName = profileData.fullName
            StorageManager.shared.saveUserProfile(name: fullName, email: profileData.email)
            
            print("✅ [DashboardView] Profile data saved and refreshing UI")
            
            // Refresh the profile view model to update UI
            userProfileVM.refreshProfile()
        }
    }
    
    // MARK: - Bookings Methods
    private func fetchUpcomingBookings() {
        // Set date range from today to future (next 3 months)
        let today = Date()
        let futureDate = Calendar.current.date(byAdding: .month, value: 3, to: today) ?? today
        
        bookingsViewModel.selectedWeekStart = today
        bookingsViewModel.selectedWeekEnd = futureDate
        bookingsViewModel.selectedTimePeriod = .custom
        
        // Fetch bookings
        bookingsViewModel.refreshBookings()
    }
    
    // MARK: - Refresh Methods
    private func refreshDashboard() async {
        // Refresh user profile
        await fetchUserProfile()
        
        // Refresh location
        viewModel.refreshCurrentLocation()
        
        // Refresh bookings
        fetchUpcomingBookings()
        
        // Ensure socket connection is maintained during refresh
        ensureSocketConnection()
    }
    
    // MARK: - Live Ride Methods (Passive Listening Only)
    
    
    // MARK: - Navigation Tracking Helper
    private func checkIfNavigationFromDrawerMenu() {
        // Check if drawer menu was open when navigation happened
        if showDrawerMenu {
            // Drawer is still open (navigation triggered before drawer closes)
            navigatedFromDrawerMenu = true
        } else if let timestamp = drawerMenuClosedTimestamp {
            // Check if navigation happened within 0.5 seconds of drawer closing
            let timeSinceDrawerClosed = Date().timeIntervalSince(timestamp)
            if timeSinceDrawerClosed < 0.5 {
                navigatedFromDrawerMenu = true
                drawerMenuClosedTimestamp = nil
            }
        }
    }

    /// Reopen drawer menu immediately if user returns from a drawer navigation
    private func reopenDrawerMenuIfNeeded() {
        if navigatedFromDrawerMenu {
            showDrawerMenu = true
            navigatedFromDrawerMenu = false
        }
    }
    
    // MARK: - Logout Methods
    private func handleLogout() {
        // Stop all monitoring and timers
        stopEnhancedSocketConnectionMonitoring()
        stopPeriodicConnectionCheck()
        
        // Disconnect from Firebase and Socket.IO
        firebaseService.unsubscribeFromUserTopic()
        
        socketService.disconnectForLogout()
        socketService.stopConnectionMonitoring()
        
        // Clear notification navigation state
        NotificationDataManager.shared.forceClearAllData()
        
        // Clear all local storage data
        StorageManager.shared.logout()
        
        // Close the drawer menu
        showDrawerMenu = false
        
        // Navigate to login screen
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            shouldNavigateToLogin = true
        }
    }
}

// MARK: - Permission Prompt Sheet
struct PermissionPromptSheet: View {
    let type: PermissionPromptType
    let onLocationRequest: () -> Void
    let onNotificationRequest: () -> Void
    let onOpenSettings: () -> Void
    
    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: iconName)
                .font(.system(size: 48))
                .foregroundColor(iconColor)
                .padding(.top, 12)
            
            VStack(spacing: 6) {
                Text(title)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.black)
                
                Text(message)
                    .font(.system(size: 15))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
            }
            .padding(.horizontal, 24)
            
            Button(action: primaryAction) {
                Text(primaryButtonLabel)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(iconColor)
                    .cornerRadius(12)
                    .padding(.horizontal, 24)
            }
            
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .presentationDetents([.fraction(0.35)])
        .presentationDragIndicator(.hidden)
    }
    
    private var iconName: String {
        switch type {
        case .locationRequest, .locationSettings:
            return "location.circle.fill"
        case .notificationRequest, .notificationSettings:
            return "bell.circle.fill"
        }
    }
    
    private var iconColor: Color {
        return .orange
    }
    
    private var title: String {
        switch type {
        case .locationRequest:
            return "Enable Location Access"
        case .locationSettings:
            return "Turn On Location in Settings"
        case .notificationRequest:
            return "Allow Notifications"
        case .notificationSettings:
            return "Turn On Notifications in Settings"
        }
    }
    
    private var message: String {
        switch type {
        case .locationRequest:
            return "Allow 1800LIMO to use your location so drivers can find you quickly and we can show accurate ETAs."
        case .locationSettings:
            return "Location access is required to match you with nearby drivers. Please enable Location Services for 1800LIMO in Settings."
        case .notificationRequest:
            return "Turn on notifications so you never miss ride updates, driver messages, or booking reminders."
        case .notificationSettings:
            return "Notifications are turned off. Enable them in Settings to stay informed about your trips."
        }
    }
    
    private var primaryButtonLabel: String {
        switch type {
        case .locationRequest:
            return "Allow Location Access"
        case .locationSettings:
            return "Open Settings"
        case .notificationRequest:
            return "Allow Notifications"
        case .notificationSettings:
            return "Open Settings"
        }
    }
    
    private var primaryAction: () -> Void {
        switch type {
        case .locationRequest:
            return onLocationRequest
        case .locationSettings:
            return onOpenSettings
        case .notificationRequest:
            return onNotificationRequest
        case .notificationSettings:
            return onOpenSettings
        }
    }
}

struct BottomSheetView: View {
    @Binding var isExpanded: Bool
    @Binding var searchText: String
    @ObservedObject var bookingsViewModel: UserBookingsViewModel
    @Binding var showScheduleRideSheet: Bool
    let onRefresh: () -> Void
    @State private var currentBookingIndex = 0
    @State private var navigateToEditBooking = false
    @State private var selectedBooking: UserBooking?
    @State private var repeatBooking: UserBooking?
    @State private var repeatBookingId: Int?
    @State private var isReturnFlow = false
    @State private var isRoundTripFlow = false
    @State private var showCancelConfirmation = false
    @State private var isCancellingBooking = false
    @State private var cancelResultMessage: String?
    @State private var showCancelResult = false
    @State private var cancellationWasSuccessful = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Drag Handle
            RoundedRectangle(cornerRadius: 2.5)
                .fill(Color.gray.opacity(0.3))
                .frame(width: 36, height: 5)
                .padding(.top, 8)
                .padding(.bottom, 16)
            
            // Content
            VStack(alignment: .leading, spacing: 20) {
                // Header
                VStack(alignment: .leading, spacing: 8) {
                    Text("Hey there, \(getUserName())")
                        .font(.system(size: 16, weight: .regular))
                        .foregroundColor(.black)
                    
                    Text("Schedule Your Booking")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(AppColors.primaryOrange)
                }
                .padding(.horizontal, 24)
                
                // Search Bar
                Button(action: {
                    showScheduleRideSheet = true
                }) {
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                            .padding(.leading, 16)
                        
                        Text("Tap here to Schedule")
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(.gray)
                            .padding(.vertical, 12)
                            .padding(.trailing, 16)
                        
                        Spacer()
                    }
                }
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .padding(.horizontal, 24)
                
                // Booking Slider
                if bookings.isEmpty {
                    // Empty state - centered
                    VStack(spacing: 12) {
                        Image(systemName: "calendar.badge.plus")
                            .font(.system(size: 32))
                            .foregroundColor(.gray)
                        Text("No upcoming bookings")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.gray)
                        Text("Tap above to schedule your first booking")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                    }
//                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .frame(maxWidth: .infinity,minHeight: 200)
                } else {
                    VStack(spacing: 16) {
                        // Booking Slider
                        TabView(selection: $currentBookingIndex) {
                            ForEach(Array(bookings.enumerated()), id: \.element.id) { index, booking in
                                UserBookingCard(
                                    booking: booking,
                                    onEditBooking: {
                                        // Handle edit booking - same as MyBooking
                                        selectedBooking = booking
                                        navigateToEditBooking = true
                                    },
                                    onCancelBooking: {
                                        selectedBooking = booking
                                        showCancelConfirmation = true
                                    },
                                    onRepeatBooking: {
                                        // Guard: Only navigate if booking ID is valid
                                        guard booking.id > 0 else {
                                            print("❌ Cannot repeat booking: Invalid booking ID")
                                            return
                                        }
                                        // Store booking ID directly - using item-based navigation ensures ID is captured
                                        repeatBooking = booking
                                        repeatBookingId = booking.id
                                        isReturnFlow = false
                                        isRoundTripFlow = false
                                        print("🔄 Setting up repeat booking with ID: \(booking.id)")
                                    },
                                    onReturnBooking: {
                                        // Guard: Only navigate if booking ID is valid
                                        guard booking.id > 0 else {
                                            print("❌ Cannot return booking: Invalid booking ID")
                                            return
                                        }
                                        // Store booking ID directly - using item-based navigation ensures ID is captured
                                        repeatBooking = booking
                                        repeatBookingId = booking.id
                                        isReturnFlow = true
                                        isRoundTripFlow = false
                                        print("🔄 Setting up return booking with ID: \(booking.id)")
                                    },
                                    onRoundTripBooking: {
                                        // Guard: Only navigate if booking ID is valid
                                        guard booking.id > 0 else {
                                            print("❌ Cannot round trip booking: Invalid booking ID")
                                            return
                                        }
                                        // Store booking ID directly - using item-based navigation ensures ID is captured
                                        repeatBooking = booking
                                        repeatBookingId = booking.id
                                        isReturnFlow = false
                                        isRoundTripFlow = true
                                        print("🔄 Setting up round trip booking with ID: \(booking.id)")
                                    }
                                )
                                .padding(.horizontal, 24)
                                .tag(index)
                            }
                        }
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                         .frame(height: isExpanded ? 300 : 300)
                        
                        // Page Indicators (Black Dots) - Just below the card
                        HStack(spacing: 8) {
                            ForEach(0..<bookings.count, id: \.self) { index in
                                Circle()
                                    .fill(index == currentBookingIndex ? Color.black : Color.black.opacity(0.3))
                                    .frame(width: 8, height: 8)
                            }
                        }

                        .padding(.top, 0)
                        .padding(.bottom, 30)                    }
                }
            }
//            .padding(.bottom, isExpanded ? 0 : 40)
        }
        .disabled(showCancelConfirmation || isCancellingBooking)
        .blur(radius: showCancelConfirmation ? 2 : 0)
        .overlay(cancelOverlay)
        .alert("Booking Cancellation", isPresented: $showCancelResult) {
            Button("OK") {
                showCancelResult = false
                cancelResultMessage = nil
                selectedBooking = nil
            }
        } message: {
            Text(cancelResultMessage ?? "Something went wrong.")
        }
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 10)
        .offset(y: isExpanded ? 0 : 200)
        .animation(.easeInOut(duration: 0.3), value: isExpanded)
        .gesture(
            DragGesture()
                .onEnded { value in
                    if value.translation.height > 50 {
                        isExpanded = false
                    } else if value.translation.height < -50 {
                        isExpanded = true
                        // Refresh data when bottom sheet expands
                        onRefresh()
                    }
                }
        )
        .onChange(of: isExpanded) { newValue in
            if newValue {
                // Refresh data when bottom sheet expands
                onRefresh()
            }
        }
        .fullScreenCover(isPresented: $navigateToEditBooking) {
            // When user returns from edit booking, refresh the bookings data
            onRefresh()
        } content: {
            ComprehensiveBookingView(
                isEditMode: true,
                editBookingId: selectedBooking?.id
            )
        }
        .fullScreenCover(item: Binding(
            get: { repeatBookingId.map { RepeatBookingItem(id: $0, isReturnFlow: isReturnFlow, isRoundTripFlow: isRoundTripFlow) } },
            set: { _ in
                resetRepeatFlowState(shouldRefresh: true)
            }
        )) { item in
            ComprehensiveBookingView(
                onComplete: {
                    resetRepeatFlowState(shouldRefresh: true)
                },
                rideData: nil,
                selectedVehicle: nil,
                isEditMode: false,
                editBookingId: nil,
                isRepeatMode: true,
                repeatBookingId: item.id,
                isReturnFlow: item.isReturnFlow,
                isRoundTripFlow: item.isRoundTripFlow
            )
        }
    }
    
    private var bookings: [UserBooking] {
        bookingsViewModel.bookings
    }
    
    private var cancelOverlay: some View {
        Group {
            if showCancelConfirmation, let booking = selectedBooking {
                ZStack {
                    Color.black.opacity(0.45)
                        .ignoresSafeArea()
                    CancelBookingConfirmationView(
                        booking: booking,
                        isProcessing: isCancellingBooking,
                        onEdit: handleCancelEditFromDialog,
                        onConfirm: confirmCancellation,
                        onDismiss: { showCancelConfirmation = false }
                    )
                    .padding(.horizontal, 24)
                }
                .transition(.opacity.combined(with: .scale))
            }
        }
    }
    
    private func handleCancelEditFromDialog() {
        showCancelConfirmation = false
        navigateToEditBooking = true
    }
    
    private func confirmCancellation() {
        guard let booking = selectedBooking else {
            return
        }
        
        isCancellingBooking = true
        cancellationWasSuccessful = false
        
        Task {
            do {
                let response = try await bookingsViewModel.cancelBooking(bookingId: booking.id)
                
                await MainActor.run {
                    isCancellingBooking = false
                    cancellationWasSuccessful = response.success
                    cancelResultMessage = response.message
                    showCancelConfirmation = false
                    showCancelResult = true
                    
                    if response.success {
                        onRefresh()
                    }
                }
            } catch {
                await MainActor.run {
                    isCancellingBooking = false
                    cancellationWasSuccessful = false
                    cancelResultMessage = error.localizedDescription
                    showCancelConfirmation = false
                    showCancelResult = true
                }
            }
        }
    }
    
    private func resetRepeatFlowState(shouldRefresh: Bool) {
        if shouldRefresh {
            onRefresh()
        }
        repeatBooking = nil
        repeatBookingId = nil
        isReturnFlow = false
        isRoundTripFlow = false
    }
    
    // MARK: - Helper Methods
    private func getUserName() -> String {
        if let profileData = StorageManager.shared.getUserProfileData() {
            return profileData.firstName
        }
        return "User"
    }
}




#Preview {
    DashboardView()
}

