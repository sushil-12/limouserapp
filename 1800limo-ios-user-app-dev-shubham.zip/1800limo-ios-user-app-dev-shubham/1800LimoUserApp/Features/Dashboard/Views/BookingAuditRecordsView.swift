import SwiftUI

struct BookingAuditRecordsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = BookingAuditRecordsViewModel()
    @State private var showLastWeek = false
    @State private var showSearch = false
    @FocusState private var isSearchFocused: Bool
    
    // Computed property to determine if Last Week should be shown automatically
    private var shouldShowLastWeekAuto: Bool {
        viewModel.todayEvents.isEmpty && viewModel.yesterdayEvents.isEmpty && !viewModel.lastWeekEvents.isEmpty
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            customHeader
            
            // Search Bar (shown when search is active)
            if showSearch {
                searchBar
            }
            
            // Content
            if viewModel.isLoading && viewModel.events.isEmpty {
                loadingView
            } else if viewModel.showError {
                errorView
            } else if viewModel.events.isEmpty {
                emptyStateView
            } else {
                notificationsList
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .onAppear {
            if viewModel.events.isEmpty {
                viewModel.fetchAuditRecords()
            }
            // Auto-show Last Week if Today/Yesterday are empty
            if shouldShowLastWeekAuto {
                showLastWeek = true
            }
        }
        .onChange(of: viewModel.todayEvents.isEmpty && viewModel.yesterdayEvents.isEmpty) { isEmpty in
            if isEmpty && !viewModel.lastWeekEvents.isEmpty {
                showLastWeek = true
            }
        }
    }
    
    // MARK: - Custom Header
    private var customHeader: some View {
        HStack {
            Button(action: {
                dismiss()
            }) {
                Image(systemName: "arrow.left")
                    .foregroundColor(.black)
                    .font(.system(size: 18, weight: .medium))
            }
            
            Spacer()
            
            Text("Notifications")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
            
            Spacer()
            
            Button(action: {
                withAnimation {
                    showSearch.toggle()
                    if showSearch {
                        // Focus search field after animation
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            isSearchFocused = true
                        }
                    } else {
                        // Clear search when hiding search bar
                        viewModel.clearSearch()
                    }
                }
            }) {
                Image(systemName: showSearch ? "xmark" : "magnifyingglass")
                    .foregroundColor(.black)
                    .font(.system(size: 18, weight: .medium))
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color(.systemGray6))
    }
    
    // MARK: - Search Bar
    private var searchBar: some View {
        HStack(spacing: 12) {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
                .font(.system(size: 16))
            
            TextField("Search notifications...", text: $viewModel.searchText)
                .font(.system(size: 16))
                .focused($isSearchFocused)
                .autocapitalization(.none)
                .disableAutocorrection(true)
            
            if !viewModel.searchText.isEmpty {
                Button(action: {
                    viewModel.clearSearch()
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                        .font(.system(size: 16))
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.white)
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(Color(.systemGray5)),
            alignment: .bottom
        )
    }
    
    // MARK: - Loading View
    private var loadingView: some View {
        ScrollView {
            VStack(spacing: 0) {
                // Search bar placeholder when active
                if showSearch {
                    HStack {
                        ShimmerText(width: 180, height: 16)
                        Spacer()
                        ShimmerCircle(size: 20)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.white)
                }
                
                VStack(spacing: 0) {
                    DateSectionHeader(title: "Today")
                    ForEach(0..<3) { _ in
                        NotificationRowShimmer()
                    }
                    
                    DateSectionHeader(title: "Yesterday")
                    ForEach(0..<2) { _ in
                        NotificationRowShimmer()
                    }
                }
            }
        }
        .background(Color.white)
    }
    
    // MARK: - Error View
    private var errorView: some View {
        VStack(spacing: 20) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 50))
                .foregroundColor(.red)
            
            Text("Error Loading Notifications")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.black)
            
            if let errorMessage = viewModel.errorMessage {
                Text(errorMessage)
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }
            
            Button("Retry") {
                viewModel.refresh()
            }
            .font(.system(size: 16, weight: .semibold))
            .foregroundColor(.white)
            .padding(.horizontal, 32)
            .padding(.vertical, 12)
            .background(AppColors.primaryOrange)
            .cornerRadius(8)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.top, 100)
    }
    
    // MARK: - Empty State View
    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Image(systemName: "bell.slash.fill")
                .font(.system(size: 50))
                .foregroundColor(.gray)
            
            Text("No Notifications")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.black)
            
            Text(viewModel.searchText.isEmpty ? "No notifications found." : "No results found for \"\(viewModel.searchText)\"")
                .font(.system(size: 14))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.top, 100)
    }
    
    // MARK: - Notifications List
    private var notificationsList: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                // Today Section
                if !viewModel.todayEvents.isEmpty {
                    DateSectionHeader(title: "Today")
                    ForEach(viewModel.todayEvents) { event in
                        SimpleNotificationRow(event: event, viewModel: viewModel)
                    }
                }
                
                // Yesterday Section
                if !viewModel.yesterdayEvents.isEmpty {
                    DateSectionHeader(title: "Yesterday")
                    ForEach(viewModel.yesterdayEvents) { event in
                        SimpleNotificationRow(event: event, viewModel: viewModel)
                    }
                }
                
                // Last Week Section
                if !viewModel.lastWeekEvents.isEmpty {
                    // If Today/Yesterday are empty, show Last Week automatically without button
                    if shouldShowLastWeekAuto {
                        DateSectionHeader(title: "Last Week")
                        ForEach(viewModel.lastWeekEvents) { event in
                            SimpleNotificationRow(event: event, viewModel: viewModel)
                        }
                    }
                }
                
                // Show more button
                if viewModel.hasMorePages {
                    Button(action: {
                        viewModel.loadNextPage()
                    }) {
                        HStack {
                            if viewModel.isLoading {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: AppColors.primaryOrange))
                            } else {
                                Text("Show More")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(AppColors.primaryOrange)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                    }
                    .disabled(viewModel.isLoading)
                }
                
                // Last Week Button at bottom (only if Today/Yesterday have events)
                if !shouldShowLastWeekAuto && !viewModel.lastWeekEvents.isEmpty {
                    Button(action: {
                        withAnimation {
                            showLastWeek.toggle()
                        }
                    }) {
                        HStack {
                            Text("Last Week")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.black)
                            
                            Spacer()
                            
                            Image(systemName: showLastWeek ? "chevron.up" : "chevron.down")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    
                    if showLastWeek {
                        ForEach(viewModel.lastWeekEvents) { event in
                            SimpleNotificationRow(event: event, viewModel: viewModel)
                        }
                    }
                }
            }
            .padding(.top, 8)
        }
        .refreshable {
            viewModel.refresh()
        }
    }
}

// MARK: - Date Section Header
struct DateSectionHeader: View {
    let title: String
    
    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.black)
            
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}

// MARK: - Simple Notification Row
struct SimpleNotificationRow: View {
    let event: BookingAuditEvent
    let viewModel: BookingAuditRecordsViewModel
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // Icon
            Image(systemName: viewModel.getIconName(for: event.event_type))
                .font(.system(size: 18, weight: .medium))
                .foregroundColor(viewModel.getIconColor(for: event.event_type))
                .frame(width: 40, height: 40)
            
            // Content
            VStack(alignment: .leading, spacing: 4) {
                // Title
                Text(event.title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.black)
                    .lineLimit(2)
                
                // Description
                Text(event.description)
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(.gray)
                    .lineLimit(2)
                
                // Time
                Text(event.timestamp_formatted)
                    .font(.system(size: 12, weight: .regular))
                    .foregroundColor(.gray.opacity(0.7))
                    .padding(.top, 2)
            }
            
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.white)
    }
}

// MARK: - Notification Shimmer Row
struct NotificationRowShimmer: View {
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            ShimmerCircle(size: 40)
                .overlay(
                    Circle()
                        .stroke(Color.gray.opacity(0.12), lineWidth: 1)
                )
            
            VStack(alignment: .leading, spacing: 6) {
                ShimmerText(width: 200, height: 14)
                ShimmerText(width: 240, height: 12)
                ShimmerText(width: 120, height: 10)
            }
            
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.white)
    }
}

#Preview {
    BookingAuditRecordsView()
}











