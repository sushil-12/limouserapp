import SwiftUI
import CoreLocation

// MARK: - Extra Stop Model
class ExtraStop: Identifiable, ObservableObject, Equatable {
    let id = UUID()
    @Published var address: String = ""
    @Published var addressVM = AddressAutocompleteViewModel()
    @Published var coordinate: LocationCoordinate?
    @Published var isLocationSelected: Bool = false
    @Published var bookingInstructions: String = ""
    
    static func == (lhs: ExtraStop, rhs: ExtraStop) -> Bool {
        return lhs.id == rhs.id && lhs.address == rhs.address
    }
}

// MARK: - Extra Stop Row View
struct ExtraStopRow: View {
    @ObservedObject var stop: ExtraStop
    let onRemove: () -> Void
    let onLocationSelected: (ExtraStop) -> Void
    let validateStop: (ExtraStop) -> String? // Validation function that returns error message if invalid
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            AddressAutocompleteField(
                viewModel: stop.addressVM,
                label: "STOP",
                placeholder: "Enter stop address",
                value: $stop.address,
                onLocationSelected: { address, coordinate, postalCode in
                    // Set the location first
                    stop.address = address
                    stop.coordinate = coordinate
                    stop.isLocationSelected = true
                    
                    // Validate the stop
                    if let errorMessage = validateStop(stop) {
                        // Validation failed - clear the selection and show error
                        stop.address = ""
                        stop.coordinate = nil
                        stop.isLocationSelected = false
                        // Error will be shown by parent view
                        return
                    }
                    
                    // Validation passed, notify parent
                    onLocationSelected(stop)
                }
            )

            Button(action: onRemove) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 20))
                    .foregroundColor(.red)
            }
            .frame(width: 30, height: 30)
            .padding(.top, 24)
        }
    }
}




struct ComprehensiveBookingView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: [Screen]
    @FocusState private var focusedField: Field?
    
    // Hide default back button
    private let shouldHideBackButton = true
    
    enum Field: Hashable {
        case pickupAirportSearch
        case dropoffAirportSearch
        case pickupFlightNumber
        case dropoffFlightNumber
        case originAirportCity
        case cruiseShipName
        case shipArrivalTime
        case specialInstructions
        // Return trip fields
        case returnPickupAirportSearch
        case returnDropoffAirportSearch
        case returnPickupFlightNumber
        case returnOriginAirportCity
        case returnCruiseShipName
        case returnShipArrivalTime
        case returnDropoffFlightNumber
        case returnSpecialInstructions
    }
    
    @State private var selectedServiceType: String? = "One Way"
    @State private var selectedTransferType: String? = "City to City"
    @State private var selectedMeetAndGreet: String? = "Driver - Text/call when on location"
    @State private var selectedHours = "2 hours minimum"
    @State private var numberOfVehicles = 1
    @State private var travelDate = "Jul 14, 2025"
    @State private var pickupTime = "12:00 AM"
    @State private var pickupAddress = "Hyderabad - Bangalore Hwy, Guru Raghav.."
    @State private var dropoffAddress = ""
    @State private var selectedPickupAirport: String? = nil
    @State private var selectedDropoffAirport: String? = nil
    @State private var pickupAirportSearch = ""
    @State private var dropoffAirportSearch = ""
    @State private var returnPickupAirportSearch = ""
    @State private var returnDropoffAirportSearch = ""
    @State private var selectedPickupAirline: String? = nil
    @State private var selectedDropoffAirline: String? = nil
    @State private var pickupFlightNumber = ""
    @State private var dropoffFlightNumber = ""
    @State private var returnPickupFlightNumber = ""
    @State private var returnDropoffFlightNumber = ""
    @State private var cruiseShipName = ""
    @State private var cruisePort = ""
    @State private var shipArrivalTime = ""
    @State private var originAirportCity = ""
    @State private var showInvalidLocationDialog = false
    @State private var invalidLocationMessage = "Pickup and drop-off cannot be the same. Please select different locations."
    @State private var invalidLocationDismissWorkItem: DispatchWorkItem?
    @State private var fieldErrors: [String: String] = [:]
    @State private var scrollTarget: String?
    @State private var extraStopValidationError: String?
    @State private var returnExtraStopValidationError: String?
    
    // MARK: - Extra Stop Validation
    private func validateExtraStop(_ stop: ExtraStop, isReturnTrip: Bool = false) -> String? {
        print("🔍 VALIDATING EXTRA STOP:")
        print("   - Stop address: '\(stop.address)'")
        print("   - Stop coordinate: \(stop.coordinate?.latitude ?? 0), \(stop.coordinate?.longitude ?? 0)")
        
        guard let stopCoord = stop.coordinate else {
            print("   - ❌ No stop coordinate, skipping validation")
            return nil
        }
        
    // Get the appropriate pickup and dropoff coordinates based on trip type
    let pickupCoord: LocationCoordinate?
    let dropoffCoord: LocationCoordinate?
    let pickupAddr: String
    let dropoffAddr: String
    let countries: (pickup: String?, dropoff: String?)
    
    if isReturnTrip {
        pickupCoord = returnPickupCoordinate ?? returnPickupAirportCoordinate ?? returnPickupCruiseCoordinate
        dropoffCoord = returnDropoffCoordinate ?? returnDropoffAirportCoordinate ?? returnDropoffCruiseCoordinate
        pickupAddr = returnPickupAddress
        dropoffAddr = returnDropoffAddress
        countries = resolveReturnCountries()
    } else {
        pickupCoord = effectiveOutboundPickupCoordinate()
        dropoffCoord = effectiveOutboundDropoffCoordinate()
        pickupAddr = pickupAddress
        dropoffAddr = dropoffAddress
        countries = resolveOutboundCountries()
    }
        
        print("   - Pickup address: '\(pickupAddr)'")
        print("   - Pickup coordinate: \(pickupCoord?.latitude ?? 0), \(pickupCoord?.longitude ?? 0)")
        print("   - Dropoff address: '\(dropoffAddr)'")
        print("   - Dropoff coordinate: \(dropoffCoord?.latitude ?? 0), \(dropoffCoord?.longitude ?? 0)")
        
        // Check if stop matches pickup (using existing coordinatesApproximatelyEqual function)
        if let pickup = pickupCoord, coordinatesApproximatelyEqual(stopCoord, pickup, tolerance: 0.002) {
            print("   - ⚠️ VALIDATION FAILED: Stop matches pickup coordinates!")
            return "Extra stop cannot be the same as pickup location. Please select a different location."
        }
        
        // Check if stop matches dropoff
        if let dropoff = dropoffCoord, coordinatesApproximatelyEqual(stopCoord, dropoff, tolerance: 0.002) {
            print("   - ⚠️ VALIDATION FAILED: Stop matches dropoff coordinates!")
            return "Extra stop cannot be the same as drop-off location. Please select a different location."
        }
        
        // Also check by address text
        let normalizedStopAddress = normalizeLocationText(stop.address)
        let normalizedPickupAddress = normalizeLocationText(pickupAddr)
        let normalizedDropoffAddress = normalizeLocationText(dropoffAddr)
        
        print("   - Normalized stop: '\(normalizedStopAddress)'")
        print("   - Normalized pickup: '\(normalizedPickupAddress)'")
        print("   - Normalized dropoff: '\(normalizedDropoffAddress)'")
        
        if !normalizedStopAddress.isEmpty && normalizedStopAddress == normalizedPickupAddress {
            print("   - ⚠️ VALIDATION FAILED: Stop matches pickup address!")
            return "Extra stop cannot be the same as pickup location. Please select a different location."
        }
        
        if !normalizedStopAddress.isEmpty && normalizedStopAddress == normalizedDropoffAddress {
            print("   - ⚠️ VALIDATION FAILED: Stop matches dropoff address!")
            return "Extra stop cannot be the same as drop-off location. Please select a different location."
        }
        
    // Country-level validation to align with driver app behavior
    let stopCountry = normalizeCountry(deriveCountryFromAddress(stop.address, viewModel: stop.addressVM))
    let pickupCountry = normalizeCountry(countries.pickup)
    let dropoffCountry = normalizeCountry(countries.dropoff)
    let countryErrorMessage = "Extra stop should be in the same country as pickup and drop-off."
    var allowedCountries = Set<String>()
    if let pickupCountry { allowedCountries.insert(pickupCountry) }
    if let dropoffCountry { allowedCountries.insert(dropoffCountry) }
    
    print("   - Country validation:")
    print("     Stop country: \(stopCountry ?? "nil")")
    print("     Pickup country: \(pickupCountry ?? "nil")")
    print("     Dropoff country: \(dropoffCountry ?? "nil")")
    print("     Allowed: \(allowedCountries)")
    
    if !allowedCountries.isEmpty {
        guard let stopCountry else {
            return countryErrorMessage
        }
        if !allowedCountries.contains(stopCountry) {
            return countryErrorMessage
        }
    } else {
        return countryErrorMessage
    }
    
    guard let _ = stopCountry else {
        return countryErrorMessage
    }
    
        print("   - ✅ VALIDATION PASSED: Stop is valid")
        return nil
    }
    
    private func normalizeLocationText(_ text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let collapsedWhitespace = trimmed.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
        let removedPunctuation = collapsedWhitespace.replacingOccurrences(of: "[,;]", with: " ", options: .regularExpression)
        return removedPunctuation.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    }
    
    private func showValidationError(_ message: String) {
        print("🚨 SHOWING VALIDATION ERROR:")
        print("   - Message: '\(message)'")
        print("   - Setting showInvalidLocationDialog = true")
        
        invalidLocationMessage = message
        showInvalidLocationDialog = true
        
        print("   - showInvalidLocationDialog is now: \(showInvalidLocationDialog)")
        
        // Auto-dismiss after 5 seconds
        invalidLocationDismissWorkItem?.cancel()
        let workItem = DispatchWorkItem {
            showInvalidLocationDialog = false
        }
        invalidLocationDismissWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0, execute: workItem)
    }
    
    // MARK: - Computed Properties for Display Names
    private var pickupAirlineDisplayName: String {
        guard let airlineId = selectedPickupAirline,
              let airline = airlineService.airlines.first(where: { $0.id == Int(airlineId) }) else {
            return "Select Airline"
        }
        return airline.displayName
    }
    
    // MARK: - Travel Time and Distance Calculation
    @State private var cachedTravelInfo: String = "Calculating route..."
    @State private var isCalculatingTravel = false
    
    private func getDynamicTravelInfo() -> String {
        // For all service types including charter tours, show actual distance and time
        // Return cached value if available
        if cachedTravelInfo != "Calculating route..." {
            return cachedTravelInfo
        }
        
        // Trigger calculation if not already calculating
        if !isCalculatingTravel {
            Task {
                await calculateAndCacheTravelInfo()
            }
        }
        
        return cachedTravelInfo
    }
    
    private func calculateAndCacheTravelInfo() async {
        guard !isCalculatingTravel else { return }
        
        await MainActor.run {
            isCalculatingTravel = true
        }
        
        defer {
            Task { @MainActor in
                isCalculatingTravel = false
            }
        }
        
        // Get coordinates
        guard let pickupLat = getOutboundPickupLatitude(),
              let pickupLong = getOutboundPickupLongitude(),
              let destLat = getOutboundDropoffLatitude(),
              let destLong = getOutboundDropoffLongitude() else {
            await MainActor.run {
                cachedTravelInfo = "Calculating route..."
            }
            return
        }
        
        // Use VehicleService to calculate road distance via Google Maps
        let pickupCoord = CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong)
        let dropoffCoord = CLLocationCoordinate2D(latitude: destLat, longitude: destLong)
        
        // Get extra stops coordinates if any
        let waypointCoords = extraStops.compactMap { stop -> CLLocationCoordinate2D? in
            guard let coord = stop.coordinate else { return nil }
            return CLLocationCoordinate2D(latitude: coord.latitude, longitude: coord.longitude)
        }
        
        let (distanceMeters, durationSeconds) = await vehicleService.calculateDistance(
            from: pickupCoord,
            to: dropoffCoord,
            waypoints: waypointCoords
        )
        
        // Convert meters to miles
        let distanceMiles = distanceMeters / 1609.34
        
        // Convert seconds to hours and minutes
        let totalMinutes = Int(durationSeconds / 60)
        let hours = totalMinutes / 60
        let minutes = totalMinutes % 60
        
        let distanceText = String(format: "%.1f", distanceMiles)
        
        let travelInfo: String
        if hours > 0 {
            travelInfo = "\(hours) hours, \(minutes) minutes / \(distanceText) miles"
        } else {
            travelInfo = "\(minutes) minutes / \(distanceText) miles"
        }
        
        await MainActor.run {
            cachedTravelInfo = travelInfo
        }
    }
    
    private func getOutboundPickupLatitude() -> Double? {
        if let coord = effectiveOutboundPickupCoordinate() {
            return coord.latitude
        }
        if let rideData = rideData {
            return rideData.pickupLat
        }
        return pickupCoordinate?.latitude
    }
    
    private func getOutboundPickupLongitude() -> Double? {
        if let coord = effectiveOutboundPickupCoordinate() {
            return coord.longitude
        }
        if let rideData = rideData {
            return rideData.pickupLong
        }
        return pickupCoordinate?.longitude
    }
    
    private func getOutboundDropoffLatitude() -> Double? {
        if let coord = effectiveOutboundDropoffCoordinate() {
            return coord.latitude
        }
        if let rideData = rideData {
            return rideData.destinationLat
        }
        return dropoffCoordinate?.latitude
    }
    
    private func getOutboundDropoffLongitude() -> Double? {
        if let coord = effectiveOutboundDropoffCoordinate() {
            return coord.longitude
        }
        if let rideData = rideData {
            return rideData.destinationLong
        }
        return dropoffCoordinate?.longitude
    }
    
    // MARK: - Return Trip Travel Info
    @State private var cachedReturnTravelInfo: String = "Calculating route..."
    @State private var isCalculatingReturnTravel = false
    
    private func getReturnTravelInfo() -> String {
        guard selectedServiceType == "Round Trip" else {
            return ""
        }
        
        // For all service types including charter tours, show actual distance and time
        // Return cached value if available
        if cachedReturnTravelInfo != "Calculating route..." {
            return cachedReturnTravelInfo
        }
        
        // Trigger calculation if not already calculating
        if !isCalculatingReturnTravel {
            Task {
                await calculateAndCacheReturnTravelInfo()
            }
        }
        
        return cachedReturnTravelInfo
    }
    
    private func calculateAndCacheReturnTravelInfo() async {
        guard !isCalculatingReturnTravel else { return }
        
        await MainActor.run {
            isCalculatingReturnTravel = true
        }
        
        defer {
            Task { @MainActor in
                isCalculatingReturnTravel = false
            }
        }
        
        // Get return trip coordinates
        guard let pickupLat = getReturnPickupLatitude(),
              let pickupLong = getReturnPickupLongitude(),
              let destLat = getReturnDropoffLatitude(),
              let destLong = getReturnDropoffLongitude() else {
            await MainActor.run {
                cachedReturnTravelInfo = "Calculating route..."
            }
            return
        }
        
        // Use VehicleService to calculate road distance via Google Maps
        let pickupCoord = CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong)
        let dropoffCoord = CLLocationCoordinate2D(latitude: destLat, longitude: destLong)
        
        // Get return extra stops coordinates if any
        let waypointCoords = returnExtraStops.compactMap { stop -> CLLocationCoordinate2D? in
            guard let coord = stop.coordinate else { return nil }
            return CLLocationCoordinate2D(latitude: coord.latitude, longitude: coord.longitude)
        }
        
        let (distanceMeters, durationSeconds) = await vehicleService.calculateDistance(
            from: pickupCoord,
            to: dropoffCoord,
            waypoints: waypointCoords
        )
        
        // Convert meters to miles
        let distanceMiles = distanceMeters / 1609.34
        
        // Convert seconds to hours and minutes
        let totalMinutes = Int(durationSeconds / 60)
        let hours = totalMinutes / 60
        let minutes = totalMinutes % 60
        
        let distanceText = String(format: "%.1f", distanceMiles)
        
        let travelInfo: String
        if hours > 0 {
            travelInfo = "\(hours) hours, \(minutes) minutes / \(distanceText) miles"
        } else {
            travelInfo = "\(minutes) minutes / \(distanceText) miles"
        }
        
        await MainActor.run {
            cachedReturnTravelInfo = travelInfo
        }
    }
    
    private func getReturnPickupLatitude() -> Double? {
        return returnPickupCoordinate?.latitude ?? returnPickupAirportCoordinate?.latitude ?? returnPickupCruiseCoordinate?.latitude
    }
    
    private func getReturnPickupLongitude() -> Double? {
        return returnPickupCoordinate?.longitude ?? returnPickupAirportCoordinate?.longitude ?? returnPickupCruiseCoordinate?.longitude
    }
    
    private func getReturnDropoffLatitude() -> Double? {
        return returnDropoffCoordinate?.latitude ?? returnDropoffAirportCoordinate?.latitude ?? returnDropoffCruiseCoordinate?.latitude
    }
    
    private func getReturnDropoffLongitude() -> Double? {
        return returnDropoffCoordinate?.longitude ?? returnDropoffAirportCoordinate?.longitude ?? returnDropoffCruiseCoordinate?.longitude
    }
    
    private var dropoffAirlineDisplayName: String {
        guard let airlineId = selectedDropoffAirline,
              let airline = airlineService.airlines.first(where: { $0.id == Int(airlineId) }) else {
            return "Select Airline"
        }
        return airline.displayName
    }
    
    private var returnPickupAirlineDisplayName: String {
        guard let airlineId = selectedReturnPickupAirline,
              let airline = airlineService.airlines.first(where: { $0.id == Int(airlineId) }) else {
            return "Select Airline"
        }
        return airline.displayName
    }
    
    private var returnDropoffAirlineDisplayName: String {
        guard let airlineId = selectedReturnDropoffAirline,
              let airline = airlineService.airlines.first(where: { $0.id == Int(airlineId) }) else {
            return "Select Airline"
        }
        return airline.displayName
    }
    
    // MARK: - Validation Logic
    private var isFormValid: Bool {
        guard let transferType = selectedTransferType else { 
            return false 
        }
        
        // Helper function to check if address is meaningful (not default placeholder)
        let isPickupAddressValid = !pickupAddress.isEmpty && 
                                  pickupAddress != "Hyderabad - Bangalore Hwy, Guru Raghav.." &&
                                  pickupAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
        let isDropoffAddressValid = !dropoffAddress.isEmpty && 
                                   dropoffAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
        
        // Validate outbound trip based on transfer type
        let isOutboundValid: Bool
        switch transferType {
        case "City to City":
            isOutboundValid = isPickupAddressValid && isDropoffAddressValid
            
        case "Airport to City":
            // Pickup: Airport fields, Dropoff: Address field
            // Note: originAirportCity is optional and not required
            isOutboundValid = (selectedPickupAirport != nil &&
                             selectedPickupAirline != nil &&
                             !pickupFlightNumber.isEmpty) &&
                             isDropoffAddressValid
            
        case "City to Airport":
            // Pickup: Address field, Dropoff: Airport fields
            isOutboundValid = isPickupAddressValid &&
                             (selectedDropoffAirport != nil &&
                             selectedDropoffAirline != nil &&
                             !dropoffFlightNumber.isEmpty)
            
        case "Airport to Airport":
            // Pickup: Airport fields, Dropoff: Airport fields
            // Note: originAirportCity is optional and not required
            isOutboundValid = (selectedPickupAirport != nil && selectedDropoffAirport != nil &&
                             selectedPickupAirline != nil && selectedDropoffAirline != nil &&
                             !pickupFlightNumber.isEmpty && !dropoffFlightNumber.isEmpty)
            
        case "City to Cruise Port":
            // Pickup: Address field, Dropoff: Cruise port fields (address + cruise details)
            isOutboundValid = isPickupAddressValid &&
                             (isDropoffAddressValid &&
                             !cruisePort.isEmpty &&
                             !cruiseShipName.isEmpty && !shipArrivalTime.isEmpty)
            
        case "Cruise Port to City":
            // Pickup: Cruise port fields (address + cruise details), Dropoff: Address field
            isOutboundValid = (isPickupAddressValid &&
                             !cruisePort.isEmpty &&
                             !cruiseShipName.isEmpty && !shipArrivalTime.isEmpty) &&
                             isDropoffAddressValid
            
        case "Airport to Cruise Port":
            // Pickup: Airport fields, Dropoff: Cruise port fields (address + cruise details)
            // Note: originAirportCity is optional and not required
            isOutboundValid = (selectedPickupAirport != nil &&
                             selectedPickupAirline != nil &&
                             !pickupFlightNumber.isEmpty) &&
                             (isDropoffAddressValid &&
                             !cruisePort.isEmpty &&
                             !cruiseShipName.isEmpty && !shipArrivalTime.isEmpty)
            
        case "Cruise Port to Airport":
            // Pickup: Cruise port fields (address + cruise details), Dropoff: Airport fields
            isOutboundValid = (isPickupAddressValid &&
                             !cruisePort.isEmpty &&
                             !cruiseShipName.isEmpty && !shipArrivalTime.isEmpty) &&
                             (selectedDropoffAirport != nil &&
                             selectedDropoffAirline != nil &&
                             !dropoffFlightNumber.isEmpty)
            
        default:
            return false
        }
        
        // Prevent same pickup/dropoff on outbound
        if let conflict = outboundLocationConflictReason() {
            return false
        }

        // If not a round trip, return outbound validation only
        guard selectedServiceType == "Round Trip" else {
            return isOutboundValid
        }
        
        // For round trip, validate return trip fields as well
        // Never mutate @State while SwiftUI is computing this property.
        // If the return trip fields have not been initialized yet, bail out
        // and wait for the dedicated initialization flows (onAppear/onChange) to run.
        if returnPickupAddress.isEmpty && returnDropoffAddress.isEmpty {
            return false
        }
        
        // Helper function to check if return address is meaningful
        let isReturnPickupAddressValid = !returnPickupAddress.isEmpty && 
                                        returnPickupAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
        let isReturnDropoffAddressValid = !returnDropoffAddress.isEmpty && 
                                         returnDropoffAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
        
        // Validate return trip based on field types: return pickup = outbound dropoff, return dropoff = outbound pickup
        let isReturnValid: Bool
        switch transferType {
        case "City to City":
            // Return pickup = outbound dropoff (city), return dropoff = outbound pickup (city)
            isReturnValid = isReturnPickupAddressValid && isReturnDropoffAddressValid
            
        case "Airport to City":
            // Return pickup = outbound dropoff (city), return dropoff = outbound pickup (airport)
            isReturnValid = isReturnPickupAddressValid &&
                           (selectedReturnDropoffAirport != nil &&
                           selectedReturnDropoffAirline != nil &&
                           !returnDropoffFlightNumber.isEmpty)
            
        case "City to Airport":
            // Return pickup = outbound dropoff (airport), return dropoff = outbound pickup (city)
            isReturnValid = (selectedReturnPickupAirport != nil &&
                           selectedReturnPickupAirline != nil &&
                           !returnPickupFlightNumber.isEmpty) &&
                           isReturnDropoffAddressValid
            
        case "Airport to Airport":
            // Return pickup = outbound dropoff (airport), return dropoff = outbound pickup (airport)
            // Note: returnOriginAirportCity is optional and not required
            isReturnValid = (selectedReturnPickupAirport != nil &&
                           selectedReturnPickupAirline != nil &&
                           !returnPickupFlightNumber.isEmpty) &&
                           (selectedReturnDropoffAirport != nil &&
                           selectedReturnDropoffAirline != nil &&
                           !returnDropoffFlightNumber.isEmpty)
            
        case "City to Cruise Port":
            // Return pickup = outbound dropoff (cruise port), return dropoff = outbound pickup (city)
            // Return pickup address IS the cruise port, so use it if returnCruisePort is empty
            let returnCruisePortForValidation = returnCruisePort.isEmpty ? returnPickupAddress : returnCruisePort
            isReturnValid = (isReturnPickupAddressValid &&
                           !returnCruisePortForValidation.isEmpty &&
                           !returnCruiseShipName.isEmpty && !returnShipArrivalTime.isEmpty) &&
                           isReturnDropoffAddressValid
            
        case "Cruise Port to City":
            // Return pickup = outbound dropoff (city), return dropoff = outbound pickup (cruise port)
            isReturnValid = isReturnPickupAddressValid &&
                           (isReturnDropoffAddressValid &&
                           !returnCruisePort.isEmpty &&
                           !returnCruiseShipName.isEmpty && !returnShipArrivalTime.isEmpty)
            
        case "Airport to Cruise Port":
            // Return pickup = outbound dropoff (cruise port), return dropoff = outbound pickup (airport)
            // Return pickup address IS the cruise port, so use it if returnCruisePort is empty
            let returnCruisePortForValidationAirport = returnCruisePort.isEmpty ? returnPickupAddress : returnCruisePort
            isReturnValid = (isReturnPickupAddressValid &&
                           !returnCruisePortForValidationAirport.isEmpty &&
                           !returnCruiseShipName.isEmpty && !returnShipArrivalTime.isEmpty) &&
                           (selectedReturnDropoffAirport != nil &&
                           selectedReturnDropoffAirline != nil &&
                           !returnDropoffFlightNumber.isEmpty)
            
        case "Cruise Port to Airport":
            // Return pickup = outbound dropoff (airport), return dropoff = outbound pickup (cruise port)
            isReturnValid = (selectedReturnPickupAirport != nil &&
                           selectedReturnPickupAirline != nil &&
                           !returnPickupFlightNumber.isEmpty) &&
                           (isReturnDropoffAddressValid &&
                           !returnCruisePort.isEmpty &&
                           !returnCruiseShipName.isEmpty && !returnShipArrivalTime.isEmpty)
            
        default:
            return false
        }
        
        // Prevent same pickup/dropoff on return leg
        if let conflict = returnLocationConflictReason() {
            return false
        }

        let isValid = isOutboundValid && isReturnValid
        return isValid
    }
    
    @ViewBuilder
    private func validationMessage(for key: String) -> some View {
        if let message = fieldErrors[key] {
            Text(message)
                .font(.system(size: 12, weight: .regular))
                .foregroundColor(.red)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.top, 4)
        }
    }
    
    // Helper function to check if a field has an error
    private func hasError(for key: String) -> Bool {
        return fieldErrors[key] != nil
    }
    
    // Helper function to clear error for a specific field
    private func clearError(for key: String) {
        if fieldErrors[key] != nil {
            fieldErrors.removeValue(forKey: key)
        }
    }
    
    // View modifier to add red border when field has error
    private func fieldBorder(for key: String) -> some View {
        Group {
            if hasError(for: key) {
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.red, lineWidth: 1.5)
            } else {
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.clear, lineWidth: 0)
            }
        }
    }
    
    private func focusField(for key: String) {
        switch key {
        case "pickupFlightNumber":
            focusedField = .pickupFlightNumber
        case "dropoffFlightNumber":
            focusedField = .dropoffFlightNumber
        case "originAirportCity":
            focusedField = .originAirportCity
        case "cruiseShipName":
            focusedField = .cruiseShipName
        case "shipArrivalTime":
            focusedField = .shipArrivalTime
        case "returnPickupFlightNumber":
            focusedField = .returnPickupFlightNumber
        case "returnDropoffFlightNumber":
            focusedField = .returnDropoffFlightNumber
        case "returnOriginAirportCity":
            focusedField = .returnOriginAirportCity
        case "returnCruiseShipName":
            focusedField = .returnCruiseShipName
        case "returnShipArrivalTime":
            focusedField = .returnShipArrivalTime
        default:
            focusedField = nil
        }
    }
    
    private func scrollTargetForKey(_ key: String, transferType: String?) -> String? {
        switch key {
        case "serviceType", "transferType":
            return "bookingDetailsSection"
        case "pickupAddress", "pickupAirport", "pickupAirline", "pickupFlightNumber", "originAirportCity":
            return "pickupSection"
        case "dropoffAddress", "dropoffAirport", "dropoffAirline", "dropoffFlightNumber":
            return "dropoffSection"
        case "cruisePort", "cruiseShipName", "shipArrivalTime":
            if let transferType = transferType, transferType.contains("Cruise Port to") {
                return "pickupSection"
            }
            return "dropoffSection"
        case "returnPickupAddress", "returnPickupAirport", "returnPickupAirline", "returnPickupFlightNumber", "returnOriginAirportCity":
            return "returnSection"
        case "returnDropoffAddress", "returnDropoffAirport", "returnDropoffAirline", "returnDropoffFlightNumber":
            return "returnSection"
        case "returnCruisePort", "returnCruiseShipName", "returnShipArrivalTime":
            return "returnSection"
        default:
            return nil
        }
    }
    
    private func validateFormAndShowErrors() -> Bool {
        // First, run location validation to check for conflicts (country mismatch, same location, etc.)
        validateOutboundLocations()
        validateReturnLocations()
        
        // Start with existing field errors (which may include location validation errors)
        var errors: [String: String] = fieldErrors
        var order: [String] = []
        
        func require(_ condition: Bool, key: String, message: String) {
            // Only add empty field error if:
            // 1. The condition is false (field is empty/invalid)
            // 2. There's no existing error for this key (preserve location validation errors)
            if !condition && errors[key] == nil {
                errors[key] = message
                order.append(key)
            }
        }
        
        guard let transferType = selectedTransferType else {
            require(false, key: "transferType", message: "Please select a transfer type.")
            fieldErrors = errors
            if let first = order.first {
                focusField(for: first)
                scrollTarget = scrollTargetForKey(first, transferType: nil)
            }
            return false
        }
        
        let isPickupAddressValid = !pickupAddress.isEmpty &&
        pickupAddress != "Hyderabad - Bangalore Hwy, Guru Raghav.." &&
        pickupAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
        let isDropoffAddressValid = !dropoffAddress.isEmpty &&
        dropoffAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
        
        switch transferType {
        case "City to City":
            require(isPickupAddressValid, key: "pickupAddress", message: "Pickup address is required.")
            require(isDropoffAddressValid, key: "dropoffAddress", message: "Drop-off address is required.")
        case "Airport to City":
            require(selectedPickupAirport != nil, key: "pickupAirport", message: "Select a pickup airport.")
            require(selectedPickupAirline != nil, key: "pickupAirline", message: "Select a pickup airline.")
            require(!pickupFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "pickupFlightNumber", message: "Enter the flight number.")
            require(isDropoffAddressValid, key: "dropoffAddress", message: "Drop-off address is required.")
        case "City to Airport":
            require(isPickupAddressValid, key: "pickupAddress", message: "Pickup address is required.")
            require(selectedDropoffAirport != nil, key: "dropoffAirport", message: "Select a drop-off airport.")
            require(selectedDropoffAirline != nil, key: "dropoffAirline", message: "Select a drop-off airline.")
            require(!dropoffFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "dropoffFlightNumber", message: "Enter the flight number.")
        case "Airport to Airport":
            require(selectedPickupAirport != nil, key: "pickupAirport", message: "Select a pickup airport.")
            require(selectedDropoffAirport != nil, key: "dropoffAirport", message: "Select a drop-off airport.")
            require(selectedPickupAirline != nil, key: "pickupAirline", message: "Select a pickup airline.")
            require(selectedDropoffAirline != nil, key: "dropoffAirline", message: "Select a drop-off airline.")
            require(!pickupFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "pickupFlightNumber", message: "Enter the pickup flight number.")
            require(!dropoffFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "dropoffFlightNumber", message: "Enter the drop-off flight number.")
        case "City to Cruise Port":
            require(isPickupAddressValid, key: "pickupAddress", message: "Pickup address is required.")
            require(isDropoffAddressValid, key: "dropoffAddress", message: "Drop-off address is required.")
            require(!cruisePort.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "cruisePort", message: "Cruise port is required.")
            require(!cruiseShipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "cruiseShipName", message: "Cruise ship name is required.")
            require(!shipArrivalTime.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "shipArrivalTime", message: "Arrival time is required.")
        case "Cruise Port to City":
            require(isDropoffAddressValid, key: "dropoffAddress", message: "Drop-off address is required.")
            require(!cruisePort.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "cruisePort", message: "Cruise port is required.")
            require(!cruiseShipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "cruiseShipName", message: "Cruise ship name is required.")
            require(!shipArrivalTime.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "shipArrivalTime", message: "Arrival time is required.")
        case "Airport to Cruise Port":
            require(selectedPickupAirport != nil, key: "pickupAirport", message: "Select a pickup airport.")
            require(selectedPickupAirline != nil, key: "pickupAirline", message: "Select a pickup airline.")
            require(!pickupFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "pickupFlightNumber", message: "Enter the flight number.")
            require(isDropoffAddressValid, key: "dropoffAddress", message: "Drop-off address is required.")
            require(!cruisePort.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "cruisePort", message: "Cruise port is required.")
            require(!cruiseShipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "cruiseShipName", message: "Cruise ship name is required.")
            require(!shipArrivalTime.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "shipArrivalTime", message: "Arrival time is required.")
        case "Cruise Port to Airport":
            require(!cruisePort.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "cruisePort", message: "Cruise port is required.")
            require(!cruiseShipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "cruiseShipName", message: "Cruise ship name is required.")
            require(!shipArrivalTime.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "shipArrivalTime", message: "Arrival time is required.")
            require(selectedDropoffAirport != nil, key: "dropoffAirport", message: "Select a drop-off airport.")
            require(selectedDropoffAirline != nil, key: "dropoffAirline", message: "Select a drop-off airline.")
            require(!dropoffFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "dropoffFlightNumber", message: "Enter the flight number.")
        default:
            break
        }
        
        if selectedServiceType == "Round Trip" {
            let isReturnPickupAddressValid = !returnPickupAddress.isEmpty &&
            returnPickupAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
            let isReturnDropoffAddressValid = !returnDropoffAddress.isEmpty &&
            returnDropoffAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
            
            switch transferType {
            case "City to City":
                require(isReturnPickupAddressValid, key: "returnPickupAddress", message: "Return pickup address is required.")
                require(isReturnDropoffAddressValid, key: "returnDropoffAddress", message: "Return drop-off address is required.")
            case "Airport to City":
                require(isReturnDropoffAddressValid, key: "returnDropoffAddress", message: "Return drop-off address is required.")
                require(selectedReturnDropoffAirport != nil, key: "returnDropoffAirport", message: "Select return drop-off airport.")
                require(selectedReturnDropoffAirline != nil, key: "returnDropoffAirline", message: "Select return drop-off airline.")
                require(!returnDropoffFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnDropoffFlightNumber", message: "Enter return flight number.")
            case "City to Airport":
                require(isReturnPickupAddressValid, key: "returnPickupAddress", message: "Return pickup address is required.")
                require(selectedReturnPickupAirport != nil, key: "returnPickupAirport", message: "Select return pickup airport.")
                require(selectedReturnPickupAirline != nil, key: "returnPickupAirline", message: "Select return pickup airline.")
                require(!returnPickupFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnPickupFlightNumber", message: "Enter return flight number.")
            case "Airport to Airport":
                require(selectedReturnPickupAirport != nil, key: "returnPickupAirport", message: "Select return pickup airport.")
                require(selectedReturnDropoffAirport != nil, key: "returnDropoffAirport", message: "Select return drop-off airport.")
                require(selectedReturnPickupAirline != nil, key: "returnPickupAirline", message: "Select return pickup airline.")
                require(selectedReturnDropoffAirline != nil, key: "returnDropoffAirline", message: "Select return drop-off airline.")
                require(!returnPickupFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnPickupFlightNumber", message: "Enter return pickup flight number.")
                require(!returnDropoffFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnDropoffFlightNumber", message: "Enter return drop-off flight number.")
            case "City to Cruise Port":
                require(isReturnPickupAddressValid, key: "returnPickupAddress", message: "Return pickup address is required.")
                // Return pickup address IS the cruise port, so use it if returnCruisePort is empty
                let returnCruisePortValue = returnCruisePort.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? returnPickupAddress.trimmingCharacters(in: .whitespacesAndNewlines) : returnCruisePort.trimmingCharacters(in: .whitespacesAndNewlines)
                require(!returnCruisePortValue.isEmpty, key: "returnCruisePort", message: "Return cruise port is required.")
                require(!returnCruiseShipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnCruiseShipName", message: "Return cruise ship name is required.")
                require(!returnShipArrivalTime.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnShipArrivalTime", message: "Return ship arrival time is required.")
                require(isReturnDropoffAddressValid, key: "returnDropoffAddress", message: "Return drop-off address is required.")
            case "Cruise Port to City":
                require(isReturnDropoffAddressValid, key: "returnDropoffAddress", message: "Return drop-off address is required.")
                require(!returnCruisePort.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnCruisePort", message: "Return cruise port is required.")
                require(!returnCruiseShipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnCruiseShipName", message: "Return cruise ship name is required.")
                require(!returnShipArrivalTime.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnShipArrivalTime", message: "Return ship arrival time is required.")
            case "Airport to Cruise Port":
                require(isReturnPickupAddressValid, key: "returnPickupAddress", message: "Return pickup address is required.")
                // Return pickup address IS the cruise port, so use it if returnCruisePort is empty
                let returnCruisePortValueForAirport = returnCruisePort.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? returnPickupAddress.trimmingCharacters(in: .whitespacesAndNewlines) : returnCruisePort.trimmingCharacters(in: .whitespacesAndNewlines)
                require(!returnCruisePortValueForAirport.isEmpty, key: "returnCruisePort", message: "Return cruise port is required.")
                require(!returnCruiseShipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnCruiseShipName", message: "Return cruise ship name is required.")
                require(!returnShipArrivalTime.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnShipArrivalTime", message: "Return ship arrival time is required.")
                require(selectedReturnDropoffAirport != nil, key: "returnDropoffAirport", message: "Select return drop-off airport.")
                require(selectedReturnDropoffAirline != nil, key: "returnDropoffAirline", message: "Select return drop-off airline.")
                require(!returnDropoffFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnDropoffFlightNumber", message: "Enter return flight number.")
            case "Cruise Port to Airport":
                require(!returnCruisePort.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnCruisePort", message: "Return cruise port is required.")
                require(!returnCruiseShipName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnCruiseShipName", message: "Return cruise ship name is required.")
                require(!returnShipArrivalTime.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnShipArrivalTime", message: "Return ship arrival time is required.")
                require(selectedReturnPickupAirport != nil, key: "returnPickupAirport", message: "Select return pickup airport.")
                require(selectedReturnPickupAirline != nil, key: "returnPickupAirline", message: "Select return pickup airline.")
                require(!returnPickupFlightNumber.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, key: "returnPickupFlightNumber", message: "Enter return flight number.")
            default:
                break
            }
        }
        
        // Update fieldErrors with merged errors
        // Location validation errors are preserved because we start with fieldErrors
        // Empty field errors are only added if the key doesn't exist (checked in require function)
        fieldErrors = errors
        
        if let first = order.first {
            focusField(for: first)
            scrollTarget = scrollTargetForKey(first, transferType: transferType)
            return false
        }
        
        scrollTarget = nil
        return errors.isEmpty && isFormValid
    }
    
    // Date and Time Picker States
    @State private var showDatePicker = false
    @State private var showTimePicker = false
    @State private var showCruiseTimePicker = false
    @State private var showReturnDatePicker = false
    @State private var showReturnTimePicker = false
    @State private var showReturnCruiseTimePicker = false
    @State private var selectedDate: Date
    @State private var selectedTime: Date
    @State private var selectedCruiseTime = Date()
    @State private var selectedReturnDate = Date()
    @State private var selectedReturnTime = Date()
    @State private var selectedReturnCruiseTime = Date()
    @State private var specialInstructions = "1. Driver - Text on location. Text the client a day before to confirm driver name, cell phone and booking details. Text client with ETA when en route"
    @State private var subtotal = 148.75
    @State private var grandTotal = 148.75
    @State private var returnSubtotal = 0.0
    @State private var returnGrandTotal = 0.0
    @State private var showSuccessScreen = false
    @State private var successData: CreateReservationData?
    @State private var successMessage = ""
    @State private var successCurrency: ReservationCurrencyInfo?
    @State private var hasDriverAssigned = false // Track if driver is assigned
    @State private var isLoading = false
    @State private var isLoadingRepeatData = false
    @State private var hasLoadedExistingRates = false
    @State private var isPrefillingData = false
    @State private var hasUserModifiedPricingInputs = false
    
    // Services
    @StateObject private var airportService = AirportService()
    @StateObject private var airlineService = AirlineService()
    @StateObject private var bookingRatesService = BookingRatesService()
    @StateObject private var createReservationService = CreateReservationService()
    @StateObject private var vehicleService = VehicleService()
    @StateObject private var editReservationService = EditReservationService()
    @StateObject private var pickupAddressVM = AddressAutocompleteViewModel()
    @StateObject private var dropoffAddressVM = AddressAutocompleteViewModel()
    
    // Separate viewModels for return trip fields
    @StateObject private var returnPickupAddressVM = AddressAutocompleteViewModel()
    @StateObject private var returnDropoffAddressVM = AddressAutocompleteViewModel()
    
    // Dropdown state
    @State private var openDropdown: String? = nil
    @State private var dropdownFrame: CGRect = .zero
    @State private var dropdownOptions: [String] = []
    @State private var dropdownSelected: Binding<String?>? = nil
    
    // Bottom sheet states
    @State private var showAirportBottomSheet = false
    @State private var showAirlineBottomSheet = false
    @State private var currentAirportType: String? = nil // "pickup", "dropoff", "returnPickup", "returnDropoff"
    @State private var currentAirlineType: String? = nil // "pickup", "dropoff", "returnPickup", "returnDropoff"
    
    // Meet and greet choices
    @State private var meetGreetChoices: [MeetGreetChoice] = []
    @State private var isLoadingMeetGreetChoices = false
    
    // Extra stops
    @State private var extraStops: [ExtraStop] = []
    @State private var returnExtraStops: [ExtraStop] = []
    
    // User data
    @State private var userData: User?
    @StateObject private var userProfileService = UserProfileService()
    
    // Location coordinates storage
    @State private var pickupCoordinate: LocationCoordinate?
    @State private var dropoffCoordinate: LocationCoordinate?
    @State private var pickupAirportCoordinate: LocationCoordinate?
    @State private var dropoffAirportCoordinate: LocationCoordinate?
    @State private var pickupCruiseCoordinate: LocationCoordinate?
    @State private var dropoffCruiseCoordinate: LocationCoordinate?
    
    // Return Trip Fields
    @State private var returnPickupAddress = ""
    @State private var returnDropoffAddress = ""
    @State private var selectedReturnPickupAirport: String? = nil
    @State private var selectedReturnDropoffAirport: String? = nil
    @State private var selectedReturnPickupAirline: String? = nil
    @State private var selectedReturnDropoffAirline: String? = nil
    @State private var returnOriginAirportCity = ""
    @State private var returnCruiseShipName = ""
    @State private var returnCruisePort = ""
    @State private var returnShipArrivalTime = ""
    @State private var returnTravelDate = "Jul 14, 2025"
    @State private var returnPickupTime = "12:00 AM"
    @State private var returnPickupCoordinate: LocationCoordinate?
    @State private var returnDropoffCoordinate: LocationCoordinate?
    @State private var returnPickupAirportCoordinate: LocationCoordinate?
    @State private var returnDropoffAirportCoordinate: LocationCoordinate?
    @State private var returnPickupCruiseCoordinate: LocationCoordinate?
    @State private var returnDropoffCruiseCoordinate: LocationCoordinate?
    
    private let geocodingService = GooglePlacesService()
    // Return journey specific fields
    @State private var selectedReturnServiceType: String? = "One Way"
    @State private var selectedReturnTransferType: String? = "City to City"
    @State private var selectedReturnMeetAndGreet: String? = "Driver - Text/call when on location"
    @State private var selectedReturnHours = "2 hours minimum"
    @State private var returnNumberOfVehicles = 1
    @State private var returnSpecialInstructions = ""
    
    // Parameters passed from previous screens
    let onComplete: (() -> Void)?
    let rideData: VehicleSelectionView.RideData?
    @State private var selectedVehicle: VehicleListingItem?
    
    // Edit/Repeat mode properties
    let isEditMode: Bool
    let editBookingId: Int?
    let isRepeatMode: Bool
    let repeatBookingId: Int?
    let isReturnFlow: Bool
    let isRoundTripFlow: Bool
    
    // Transfer type options
    private let transferTypes = [
        "City to City",
        "City to Airport",
        "Airport to City",
        "Airport to Airport",
        "City to Cruise Port",
        "Airport to Cruise Port",
        "Cruise Port to City",
        "Cruise Port to Airport"
    ]
    
    // Service type options
    private let serviceTypes = [
        "One Way",
        "Round Trip",
        "Charter Tour"
    ]
    
    // Hours options for charter tours
    private let hoursOptions = ["2 hours minimum", "3 hours", "4 hours", "5 hours", "6 hours", "8 hours", "10 hours", "12 hours"]
    
    // MARK: - Initializers
    init(
        onComplete: (() -> Void)? = nil,
        rideData: VehicleSelectionView.RideData? = nil,
        selectedVehicle: VehicleListingItem? = nil,
        isEditMode: Bool = false,
        editBookingId: Int? = nil,
        isRepeatMode: Bool = false,
        repeatBookingId: Int? = nil,
        isReturnFlow: Bool = false,
        isRoundTripFlow: Bool = false,
        path: Binding<[Screen]>? = nil
    ) {
        self.onComplete = onComplete
        self.rideData = rideData
        self._selectedVehicle = State(initialValue: selectedVehicle)
        self.isEditMode = isEditMode
        self.editBookingId = editBookingId
        self.isRepeatMode = isRepeatMode
        self.repeatBookingId = repeatBookingId
        self.isReturnFlow = isReturnFlow
        self.isRoundTripFlow = isRoundTripFlow
        // Use provided path or create a default binding that does nothing
        self._path = path ?? Binding<[Screen]>(get: { [] }, set: { _ in })
        
        // Check if driver is assigned from selected vehicle
        if let vehicle = selectedVehicle,
           let driverInfo = vehicle.driverInformation,
           let driverId = driverInfo.id,
           driverId > 0 {
            self._hasDriverAssigned = State(initialValue: true)
            print("✅ INIT: Driver IS assigned - driverId: \(driverId), driverName: \(driverInfo.name)")
        } else {
            self._hasDriverAssigned = State(initialValue: false)
            print("⚠️ INIT: Driver NOT assigned - will show notification message")
        }
        
        if isRepeatMode {
            print("🔄 INIT: Repeat mode enabled with booking ID: \(repeatBookingId?.description ?? "nil")")
            if isReturnFlow {
                print("🔄 INIT: Return flow enabled")
            } else if isRoundTripFlow {
                print("🔄 INIT: Round trip flow enabled")
            } else {
                print("🔄 INIT: Repeat flow enabled")
            }
        }
        
        // Initialize date and time from rideData if available (for NEW bookings from TimeSelectionView)
        if let rideData = rideData {
            print("🕐 INIT: Initializing date/time from rideData (NEW BOOKING MODE)")
            print("🕐 INIT: rideData.pickupDate = '\(rideData.pickupDate)'")
            print("🕐 INIT: rideData.pickupTime = '\(rideData.pickupTime)'")
            print("🕐 INIT: rideData.pickupLocation = '\(rideData.pickupLocation)'")
            print("🕐 INIT: rideData.destinationLocation = '\(rideData.destinationLocation)'")
            
            // Parse date and time together to ensure they're properly combined
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let parsedDate = dateFormatter.date(from: rideData.pickupDate) ?? Date()
            
            let timeFormatter = DateFormatter()
            timeFormatter.dateFormat = "HH:mm:ss"
            let parsedTime = timeFormatter.date(from: rideData.pickupTime)
            
            // CRITICAL FIX: Combine date and time components properly
            let calendar = Calendar.current
            let dateComponents = calendar.dateComponents([.year, .month, .day], from: parsedDate)
            
            if let parsedTime = parsedTime {
                let timeComponents = calendar.dateComponents([.hour, .minute, .second], from: parsedTime)
                
                var combinedComponents = DateComponents()
                combinedComponents.year = dateComponents.year
                combinedComponents.month = dateComponents.month
                combinedComponents.day = dateComponents.day
                combinedComponents.hour = timeComponents.hour
                combinedComponents.minute = timeComponents.minute
                combinedComponents.second = timeComponents.second
                
                if let combinedDateTime = calendar.date(from: combinedComponents) {
                    // Set selectedDate to the parsed date
                    self._selectedDate = State(initialValue: parsedDate)
                    print("🕐 INIT: selectedDate initialized to \(parsedDate)")
                    
                    // Set selectedTime to the COMBINED date+time
                    self._selectedTime = State(initialValue: combinedDateTime)
                    print("🕐 INIT: selectedTime initialized to COMBINED date+time: \(combinedDateTime)")
                    
                    // Set display strings
                    dateFormatter.dateFormat = "MMM dd, yyyy"
                    let displayDate = dateFormatter.string(from: parsedDate)
                    self._travelDate = State(initialValue: displayDate)
                    print("🕐 INIT: Display date string set to: \(displayDate)")
                    
                    timeFormatter.dateFormat = "h:mm a"
                    let displayTime = timeFormatter.string(from: combinedDateTime)
                    self._pickupTime = State(initialValue: displayTime)
                    print("🕐 INIT: Display time string set to: \(displayTime)")
                } else {
                    print("❌ INIT: Failed to combine date and time components")
                    self._selectedDate = State(initialValue: parsedDate)
                    self._selectedTime = State(initialValue: Date())
                }
            } else {
                print("❌ INIT: Failed to parse pickupTime '\(rideData.pickupTime)'")
                self._selectedDate = State(initialValue: parsedDate)
                self._selectedTime = State(initialValue: parsedDate) // Use parsed date as fallback
            }
        } else if isEditMode {
            print("🕐 INIT: Edit mode detected - date/time will be initialized from editData in loadEditData()")
            // Initialize with current date/time for edit mode - will be overridden in loadEditData()
            self._selectedDate = State(initialValue: Date())
            self._selectedTime = State(initialValue: Date())
        } else {
            print("🕐 INIT: No rideData provided - using current date/time")
            // Initialize with current date/time as fallback
            self._selectedDate = State(initialValue: Date())
            self._selectedTime = State(initialValue: Date())
        }
    }
    
    var body: some View {
        ZStack {
            NavigationView {
                ZStack {
                    Color.white.ignoresSafeArea(.all)
                    
                    VStack(spacing: 0) {
                        // Header
                        headerView
                        
                        // Scrollable content
                        ScrollViewReader { proxy in
                            ScrollView {
                                VStack(spacing: 24) {
                                    // Accounts Information Section
                                    accountsInformationSection
                                    
                                    // Booking Details Section
                                    bookingDetailsSection
                                        .id("bookingDetailsSection")
                                    
                                    // Pick-up Section
                                    pickupSection
                                        .id("pickupSection")
                                    
                                    // Drop-off Section
                                    dropoffSection
                                        .id("dropoffSection")
                                    
                                    // Outbound Special Instructions and Extra Stops (for all trips)
                                    outboundSpecialInstructionsAndExtraStopsSection
                                    
                                    // Return Trip Section (only for Round Trip and when return service type is also Round Trip)
                                    if selectedServiceType == "Round Trip" && selectedReturnServiceType == "Round Trip" {
                                        returnJourneySection
                                            .id("returnSection")
                                    }
                                            /* OLD RETURN TRIP CODE - TO BE REMOVED
                                            } else if let transferType = selectedTransferType, (transferType == "City to Airport" || transferType == "Airport to Airport" || transferType == "Cruise Port to Airport") {
                                                // Return pickup is airport (same as outbound dropoff when dropoff is airport)
                                                VStack(spacing: 16) {
                                                    // Airport selection
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("SELECT AIRPORT")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        Text("(search by code or name)")
                                                            .font(.system(size: 10, weight: .regular))
                                                            .foregroundColor(.gray)
                                                        
                                                        Button(action: {
                                                            currentAirportType = "returnPickup"
                                                            Task {
                                                                await airportService.fetchAllAirports()
                                                            }
                                                            showAirportBottomSheet = true
                                                        }) {
                                                            HStack {
                                                                Text(selectedReturnPickupAirport ?? "Search airports...")
                                                                    .font(.system(size: 14, weight: .medium))
                                                                    .foregroundColor(selectedReturnPickupAirport == nil ? .black : .black)
                                                                Spacer()
                                                                 Image("arrowIcon")

                                                                    .font(.system(size: 12, weight: .medium))
                                                                    .foregroundColor(.gray)
                                                            }
                                                            .padding(.horizontal, 16)
                                                            .padding(.vertical, 12)
                                                            .background(Color.gray.opacity(0.15))
                                                            .cornerRadius(8)
                                                        }
                                                        .buttonStyle(PlainButtonStyle())
                                                    }
                                                    
                                                    // Airline selection
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("SELECT AIRLINE")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        Button(action: {
                                                            currentAirlineType = "returnPickup"
                                                            showAirlineBottomSheet = true
                                                        }) {
                                                            HStack {
                                                                Text(returnPickupAirlineDisplayName)
                                                                    .font(.system(size: 14, weight: .medium))
                                                                    .foregroundColor(selectedReturnPickupAirline == nil ? .black : .black)
                                                                Spacer()
                                                                 Image("arrowIcon")

                                                                    .font(.system(size: 12, weight: .medium))
                                                                    .foregroundColor(.gray)
                                                            }
                                                            .padding(.horizontal, 16)
                                                            .padding(.vertical, 12)
                                                            .background(Color.gray.opacity(0.15))
                                                            .cornerRadius(8)
                                                        }
                                                        .buttonStyle(PlainButtonStyle())
                                                    }
                                                    
                                                    // Flight number
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("FLIGHT / TAIL #")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        AutoSelectTextField(
                                                            placeholder: "Enter flight number",
                                                            text: $returnPickupFlightNumber,
                                                            fontSize: 14,
                                                            fontWeight: .medium,
                                                            textColor: .gray
                                                        )
                                                        .padding(.horizontal, 16)
                                                        .padding(.vertical, 12)
                                                        .background(Color.gray.opacity(0.15))
                                                        .cornerRadius(8)
                                                    }
                                                    
                                                    // Origin Airport / City
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("Departing Airport / City")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        AutoSelectTextField(
                                                            placeholder: "Enter origin airport/city",
                                                            text: $returnOriginAirportCity,
                                                            fontSize: 14,
                                                            fontWeight: .medium,
                                                            textColor: .gray
                                                        )
                                                        .padding(.horizontal, 16)
                                                        .padding(.vertical, 12)
                                                        .background(Color.gray.opacity(0.15))
                                                        .cornerRadius(8)
                                                    }
                                                }
                                            } else if let transferType = selectedTransferType, (transferType == "City to Cruise Port" || transferType == "Airport to Cruise Port") {
                                                // Return pickup is cruise port (same as outbound dropoff when dropoff is cruise port)
                                                VStack(spacing: 16) {
                                                    AddressAutocompleteField(
                                                        viewModel: returnPickupAddressVM,
                                                        label: "RETURN PICKUP ADDRESS",
                                                        placeholder: "Enter return pickup address",
                                                        value: $returnPickupAddress,
                                                        hasError: hasError(for: "returnPickupAddress"),
                                                        onLocationSelected: { address, coordinate, postalCode in
                                                            returnPickupAddress = address
                                                            returnPickupCoordinate = coordinate
                                                            print("📍 RETURN PICKUP ADDRESS UPDATED - Address: '\(address)', Coord: \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                                                            print("📍 STORED RETURN PICKUP COORDINATE: \(returnPickupCoordinate?.latitude ?? 0), \(returnPickupCoordinate?.longitude ?? 0)")
                                                            
                                                            // Clear error and validate locations
                                                            clearError(for: "returnPickupAddress")
                                                            validateReturnLocations()
                                                            
                                                            // Automatically call API after return address selection - exactly like outbound
                                                            Task {
                                                                await fetchBookingRates()
                                                            }
                                                        }
                                                    )
                                                    .onChange(of: returnPickupAddress) { newValue in
                                                        // Validate when address changes (user types manually)
                                                        if !newValue.isEmpty {
                                                            validateReturnLocations()
                                                        }
                                                    }
                                                    validationMessage(for: "returnPickupAddress")
                                                
                                                // Cruise port name
                                                VStack(alignment: .leading, spacing: 8) {
                                                    Text("CRUISE PORT")
                                                        .font(.system(size: 12, weight: .medium))
                                                        .foregroundColor(.gray)
                                                    
                                                    AutoSelectTextField(
                                                        placeholder: "Enter cruise port",
                                                        text: $returnCruisePort,
                                                        fontSize: 14,
                                                        fontWeight: .medium,
                                                        textColor: .gray
                                                    )
                                                        .padding(.horizontal, 16)
                                                        .padding(.vertical, 12)
                                                        .background(Color.gray.opacity(0.15))
                                                        .cornerRadius(8)
                                                        .overlay(
                                                            RoundedRectangle(cornerRadius: 8)
                                                                .stroke(hasError(for: "returnCruisePort") ? Color.red : Color.clear, lineWidth: hasError(for: "returnCruisePort") ? 1.5 : 0)
                                                        )
                                                }
                                                    
                                                    // Cruise ship name
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("CRUISE SHIP NAME")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        AutoSelectTextField(
                                                            placeholder: "Enter cruise ship name",
                                                            text: $returnCruiseShipName,
                                                            fontSize: 14,
                                                            fontWeight: .medium,
                                                            textColor: .gray
                                                        )
                                                            .padding(.horizontal, 16)
                                                            .padding(.vertical, 12)
                                                            .background(Color.gray.opacity(0.15))
                                                            .cornerRadius(8)
                                                            .overlay(
                                                                RoundedRectangle(cornerRadius: 8)
                                                                    .stroke(hasError(for: "returnCruiseShipName") ? Color.red : Color.clear, lineWidth: hasError(for: "returnCruiseShipName") ? 1.5 : 0)
                                                            )
                                                    }
                                                    
                                                    // Ship arrival time
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("SHIP ARRIVAL TIME")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        Button(action: {
                                                            // Don't reinitialize - use the selectedReturnCruiseTime that was already set
                                                            showReturnCruiseTimePicker = true
                                                        }) {
                                                            HStack {
                                                                Image(systemName: "clock")
                                                                    .font(.system(size: 16, weight: .medium))
                                                                    .foregroundColor(.gray)
                                                                
                                                                AutoSelectTextField(
                                                                    placeholder: "Enter arrival time",
                                                                    text: $returnShipArrivalTime,
                                                                    fontSize: 14,
                                                                    fontWeight: .medium,
                                                                    textColor: .gray,
                                                                    isEnabled: false
                                                                )
                                                                .disabled(true)
                                                            }
                                                            .padding(.horizontal, 16)
                                                            .padding(.vertical, 12)
                                                            .background(Color.gray.opacity(0.15))
                                                            .cornerRadius(8)
                                                            .overlay(
                                                                RoundedRectangle(cornerRadius: 8)
                                                                    .stroke(hasError(for: "returnShipArrivalTime") ? Color.red : Color.clear, lineWidth: hasError(for: "returnShipArrivalTime") ? 1.5 : 0)
                                                            )
                                                            .contentShape(Rectangle())
                                                        }
                                                        .buttonStyle(PlainButtonStyle())
                                                        
                                                        validationMessage(for: "returnShipArrivalTime")
                                                    }
                                                }
                                            }
                                        }
                                        
                                        // Return Dropoff Section
                                        VStack(alignment: .leading, spacing: 16) {
                                            Text("Return Drop-off")
                                                .font(.system(size: 16, weight: .semibold))
                                                .foregroundColor(.gray)
                                            
                                            // Dynamic return dropoff fields based on OUTBOUND PICKUP type
                                            if let transferType = selectedTransferType, (transferType == "City to City" || transferType == "City to Airport" || transferType == "City to Cruise Port") {
                                                // Return dropoff is city (same as outbound pickup when pickup is city)
                                                AddressAutocompleteField(
                                                    viewModel: returnDropoffAddressVM,
                                                    label: "RETURN DROPOFF ADDRESS",
                                                    placeholder: "Enter return dropoff address",
                                                    value: $returnDropoffAddress,
                                                    hasError: hasError(for: "returnDropoffAddress"),
                                                    onLocationSelected: { address, coordinate, postalCode in
                                                        returnDropoffAddress = address
                                                        returnDropoffCoordinate = coordinate
                                                        print("📍 RETURN DROPOFF ADDRESS UPDATED - Address: '\(address)', Coord: \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                                                        print("📍 STORED RETURN DROPOFF COORDINATE: \(returnDropoffCoordinate?.latitude ?? 0), \(returnDropoffCoordinate?.longitude ?? 0)")
                                                        
                                                        // Clear error and validate locations
                                                        clearError(for: "returnDropoffAddress")
                                                        validateReturnLocations()
                                                        
                                                        // Automatically call API after return address selection - exactly like outbound
                                                        Task {
                                                            await fetchBookingRates()
                                                        }
                                                    }
                                                )
                                                .onChange(of: returnDropoffAddress) { newValue in
                                                    // Validate when address changes (user types manually)
                                                    if !newValue.isEmpty {
                                                        validateReturnLocations()
                                                    }
                                                }
                                                validationMessage(for: "returnDropoffAddress")
                                            } else if let transferType = selectedTransferType, (transferType == "Airport to City" || transferType == "Airport to Airport" || transferType == "Airport to Cruise Port") {
                                                // Return dropoff is airport (same as outbound pickup when pickup is airport)
                                                VStack(spacing: 16) {
                                                    // Airport selection
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("SELECT AIRPORT")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        Text("(search by code or name)")
                                                            .font(.system(size: 10, weight: .regular))
                                                            .foregroundColor(.gray)
                                                        
                                                        Button(action: {
                                                            currentAirportType = "returnDropoff"
                                                            Task {
                                                                await airportService.fetchAllAirports()
                                                            }
                                                            showAirportBottomSheet = true
                                                        }) {
                                                            HStack {
                                                                Text(selectedReturnDropoffAirport ?? "Search airports...")
                                                                    .font(.system(size: 14, weight: .medium))
                                                                    .foregroundColor(selectedReturnDropoffAirport == nil ? .black : .black)
                                                                Spacer()
                                                                 Image("arrowIcon")

                                                                    .font(.system(size: 12, weight: .medium))
                                                                    .foregroundColor(.gray)
                                                            }
                                                            .padding(.horizontal, 16)
                                                            .padding(.vertical, 12)
                                                            .background(Color.gray.opacity(0.15))
                                                            .cornerRadius(8)
                                                        }
                                                        .buttonStyle(PlainButtonStyle())
                                                    }
                                                    
                                                    // Airline selection
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("SELECT AIRLINE")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        Button(action: {
                                                            currentAirlineType = "returnDropoff"
                                                            showAirlineBottomSheet = true
                                                        }) {
                                                            HStack {
                                                                Text(returnDropoffAirlineDisplayName)
                                                                    .font(.system(size: 14, weight: .medium))
                                                                    .foregroundColor(selectedReturnDropoffAirline == nil ? .black : .black)
                                                                Spacer()
                                                                 Image("arrowIcon")

                                                                    .font(.system(size: 12, weight: .medium))
                                                                    .foregroundColor(.gray)
                                                            }
                                                            .padding(.horizontal, 16)
                                                            .padding(.vertical, 12)
                                                            .background(Color.gray.opacity(0.15))
                                                            .cornerRadius(8)
                                                        }
                                                        .buttonStyle(PlainButtonStyle())
                                                    }
                                                    
                                                    // Flight number
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("FLIGHT / TAIL #")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        AutoSelectTextField(
                                                            placeholder: "Enter flight number",
                                                            text: $returnDropoffFlightNumber,
                                                            fontSize: 14,
                                                            fontWeight: .medium,
                                                            textColor: .gray
                                                        )
                                                        .padding(.horizontal, 16)
                                                        .padding(.vertical, 12)
                                                        .background(Color.gray.opacity(0.15))
                                                        .cornerRadius(8)
                                                    }
                                                }
                                            } else if let transferType = selectedTransferType, (transferType == "Cruise Port to City" || transferType == "Cruise Port to Airport") {
                                                // Return dropoff is cruise port (same as outbound pickup when pickup is cruise port)
                                                VStack(spacing: 16) {
                                                    AddressAutocompleteField(
                                                        viewModel: returnDropoffAddressVM,
                                                        label: "RETURN DROPOFF ADDRESS",
                                                        placeholder: "Enter return dropoff address",
                                                        value: $returnDropoffAddress,
                                                        hasError: hasError(for: "returnDropoffAddress"),
                                                        onLocationSelected: { address, coordinate, postalCode in
                                                            returnDropoffAddress = address
                                                            returnDropoffCoordinate = coordinate
                                                            print("📍 RETURN DROPOFF ADDRESS UPDATED (second instance) - Address: '\(address)', Coord: \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                                                            print("📍 STORED RETURN DROPOFF COORDINATE: \(returnDropoffCoordinate?.latitude ?? 0), \(returnDropoffCoordinate?.longitude ?? 0)")
                                                            
                                                            // Clear error and validate locations
                                                            clearError(for: "returnDropoffAddress")
                                                            validateReturnLocations()
                                                            
                                                            // Automatically call API after return address selection - exactly like outbound
                                                            Task {
                                                                await fetchBookingRates()
                                                            }
                                                        }
                                                    )
                                                    .onChange(of: returnDropoffAddress) { newValue in
                                                        // Validate when address changes (user types manually)
                                                        if !newValue.isEmpty {
                                                            validateReturnLocations()
                                                        }
                                                    }
                                                    validationMessage(for: "returnDropoffAddress")
                                                    
                                                // Cruise port name
                                                VStack(alignment: .leading, spacing: 8) {
                                                    Text("CRUISE PORT")
                                                        .font(.system(size: 12, weight: .medium))
                                                        .foregroundColor(.gray)
                                                    
                                                    AutoSelectTextField(
                                                        placeholder: "Enter cruise port",
                                                        text: $returnCruisePort,
                                                        fontSize: 14,
                                                        fontWeight: .medium,
                                                        textColor: .gray
                                                    )
                                                    .padding(.horizontal, 16)
                                                    .padding(.vertical, 12)
                                                    .background(Color.gray.opacity(0.15))
                                                    .cornerRadius(8)
                                                }
                                                
                                                    // Cruise ship name
                                                    VStack(alignment: .leading, spacing: 8) {
                                                        Text("CRUISE SHIP NAME")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        AutoSelectTextField(
                                                            placeholder: "Enter cruise ship name",
                                                            text: $returnCruiseShipName,
                                                            fontSize: 14,
                                                            fontWeight: .medium,
                                                            textColor: .gray
                                                        )
                                                        .padding(.horizontal, 16)
                                                        .padding(.vertical, 12)
                                                        .background(Color.gray.opacity(0.15))
                                                        .cornerRadius(8)
                                                    }
                                                    
                                                    // Ship arrival time
                                                    VStack(alignment: .leading, spacing: 8) {
                                                    Text("SHIP DEPARTURE TIME")
                                                            .font(.system(size: 12, weight: .medium))
                                                            .foregroundColor(.gray)
                                                        
                                                        Button(action: {
                                                            // Don't reinitialize - use the selectedReturnCruiseTime that was already set
                                                            showReturnCruiseTimePicker = true
                                                        }) {
                                                            HStack {
                                                                Image(systemName: "clock")
                                                                    .font(.system(size: 16, weight: .medium))
                                                                    .foregroundColor(.gray)
                                                                
                                                                AutoSelectTextField(
                                                                    placeholder: "Enter arrival time",
                                                                    text: $returnShipArrivalTime,
                                                                    fontSize: 14,
                                                                    fontWeight: .medium,
                                                                    textColor: .gray,
                                                                    isEnabled: false
                                                                )
                                                                .disabled(true)
                                                            }
                                                            .padding(.horizontal, 16)
                                                            .padding(.vertical, 12)
                                                            .background(Color.gray.opacity(0.15))
                                                            .cornerRadius(8)
                                                            .contentShape(Rectangle())
                                                        }
                                                        .buttonStyle(PlainButtonStyle())
                                                    }
                                                }
                                            }
                                        }
                                        .onAppear {
                                            // Initialize return trip fields when section appears
                                            initializeReturnTripFields()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                                initializeReturnTripFields()
                                            }
                                        }
                                    }
                                    */ // END OF OLD RETURN TRIP CODE
                                    
                                    // Transportation Details Section
                                    transportationDetailsSection
                                    
                                    // Booking Summary Section
                                    bookingSummarySection
                                }
                                .padding(.horizontal, 24)
                                .padding(.bottom, 20) // Extra padding for the Next button
                            }
                            .onTapGesture {
                                // Dismiss keyboard when tapping anywhere on the scroll view
                                focusedField = nil
                            }
                            .onChange(of: focusedField) { field in
                                // Auto-scroll to focused field
                                if let field = field {
                                    withAnimation(.easeInOut(duration: 0.5)) {
                                        switch field {
                                        case .pickupAirportSearch:
                                            proxy.scrollTo("pickupAirportSearch", anchor: .center)
                                        case .dropoffAirportSearch:
                                            proxy.scrollTo("dropoffAirportSearch", anchor: .center)
                                        case .pickupFlightNumber:
                                            proxy.scrollTo("pickupFlightNumber", anchor: .center)
                                        case .dropoffFlightNumber:
                                            proxy.scrollTo("dropoffFlightNumber", anchor: .center)
                                        case .originAirportCity:
                                            proxy.scrollTo("originAirportCity", anchor: .center)
                                        case .cruiseShipName:
                                            proxy.scrollTo("cruiseShipName", anchor: .center)
                                        case .shipArrivalTime:
                                            proxy.scrollTo("shipArrivalTime", anchor: .center)
                                        case .specialInstructions:
                                            proxy.scrollTo("specialInstructions", anchor: .center)
                                        // Return trip fields
                                        case .returnPickupAirportSearch:
                                            proxy.scrollTo("returnPickupAirportSearch", anchor: .center)
                                        case .returnDropoffAirportSearch:
                                            proxy.scrollTo("returnDropoffAirportSearch", anchor: .center)
                                        case .returnPickupFlightNumber:
                                            proxy.scrollTo("returnPickupFlightNumber", anchor: .center)
                                        case .returnOriginAirportCity:
                                            proxy.scrollTo("returnOriginAirportCity", anchor: .center)
                                        case .returnCruiseShipName:
                                            proxy.scrollTo("returnCruiseShipName", anchor: .center)
                                        case .returnShipArrivalTime:
                                            proxy.scrollTo("returnShipArrivalTime", anchor: .center)
                                        case .returnDropoffFlightNumber:
                                            proxy.scrollTo("returnDropoffFlightNumber", anchor: .center)
                                        case .returnSpecialInstructions:
                                            proxy.scrollTo("returnSpecialInstructions", anchor: .center)
                                        }
                                    }
                                }
                            }
                            .onChange(of: scrollTarget) { target in
                                guard let target = target else { return }
                                withAnimation(.easeInOut(duration: 0.4)) {
                                    proxy.scrollTo(target, anchor: .top)
                                }
                                DispatchQueue.main.async {
                                    scrollTarget = nil
                                }
                            }
                        }
                        
                        // Next Button
                        nextButton
                            .simultaneousGesture(TapGesture().onEnded {
                                // Dismiss keyboard when button is tapped
                                focusedField = nil
                                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                            })
                    }
                }
                .navigationBarHidden(true)
                .navigationBarBackButtonHidden(shouldHideBackButton)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar(.hidden, for: .navigationBar)
                .coordinateSpace(name: "dropdownArea")
                .task {
                    // Date/time initialization is now handled in init() method
                    // No need to override here as it was already properly initialized
                    print("🕐 TASK: Date/time already initialized in init() method")
                    if let rideData = rideData {
                        print("🕐 TASK: Confirming selectedDate = \(selectedDate)")
                        print("🕐 TASK: Confirming selectedTime = \(selectedTime)")
                        print("🕐 TASK: rideData.pickupDate = '\(rideData.pickupDate)'")
                        print("🕐 TASK: rideData.pickupTime = '\(rideData.pickupTime)'")
                    }
                }
                .onAppear {
                    loadUserData()
                    loadUserProfile()
                    if isEditMode {
                        print("🔄 EDIT MODE: Loading edit data for booking ID: \(editBookingId ?? 0)")
                        loadEditData()
                } else if isRepeatMode {
                    print("🔄 REPEAT MODE: Loading repeat data for booking ID: \(repeatBookingId ?? 0)")
                    // Set loading state immediately before calling loadRepeatData
                    isLoadingRepeatData = true
                    loadRepeatData()
                    } else {
                        print("🔄 NORMAL MODE: Loading booking details from rideData")
                        updateBookingDetails()
                        loadInitialData()
                    }
                    
                    // Initialize return trip fields if Round Trip is selected
                    if selectedServiceType == "Round Trip" {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            initializeReturnTripFields()
                        }
                    }
                }
                .onChange(of: selectedServiceType) { _ in
                    if isPrefillingData {
                        return
                    }
                    // CRITICAL FIX: For Round Trip, initialize return fields FIRST before refreshing rates
                    if selectedServiceType == "Round Trip" {
                        // Initialize return trip fields immediately to ensure coordinates are set
                        initializeReturnTripFields()
                        
                        // Ensure airports are loaded if needed for coordinate lookup
                        Task {
                            // Wait a moment for immediate coordinate lookups to complete
                            try? await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
                            
                            // If airports list is empty, fetch them to enable coordinate lookups
                            if airportService.airports.isEmpty {
                                await airportService.fetchAllAirports()
                                // Re-run initialization to pick up coordinates from fetched airports
                                await MainActor.run {
                                    initializeReturnTripFields()
                                }
                            }
                            
                            // Wait a bit more for async coordinate lookups to complete
                            try? await Task.sleep(nanoseconds: 200_000_000) // 0.2 seconds
                            
                            // Now refresh rates with properly initialized coordinates
                            await MainActor.run {
                                refreshRates()
                            }
                        }
                    } else {
                        // For non-round-trip service types, refresh rates immediately
                        refreshRates()
                    }
                    // Reset hours selection when switching away from Charter Tour
                    if selectedServiceType != "Charter Tour" {
                        selectedHours = "2 hours minimum"
                    }
                }
                .onChange(of: selectedTransferType) { newTransferType in
                    // Clear validation error when user selects a transfer type
                    clearError(for: "transferType")
                    if isPrefillingData {
                        return
                    }
                    print("🔄 TRANSFER TYPE CHANGED TO: \(newTransferType ?? "nil")")
                    
                    // Handle transfer type changes that require airport field updates
                    if let transferType = newTransferType {
                        print("🔄 DETAILED TRANSFER TYPE HANDLING:")
                        print("  - New Transfer Type: \(transferType)")
                        print("  - Current Pickup Airport: \(selectedPickupAirport ?? "nil")")
                        print("  - Current Dropoff Airport: \(selectedDropoffAirport ?? "nil")")
                        print("  - Current Pickup Address: \(pickupAddress)")
                        print("  - Current Dropoff Address: \(dropoffAddress)")
                        
                        // Handle PICKUP changes
                        if transferType.contains("Airport to") {
                            // Pickup is now airport - clear city address, ensure airport is ready for selection
                            print("🔄 PICKUP: Now airport-based - clearing city address")
                            if !pickupAddress.isEmpty {
                                pickupAddress = ""
                                pickupAddressVM.input = ""
                                pickupCoordinate = nil
                            }
                            // Check if airport is already selected from previous state
                            if let existingAirport = selectedPickupAirport, !existingAirport.isEmpty {
                                print("🔄 PICKUP: Airport already selected from previous state: \(existingAirport)")
                                // Keep the existing airport selection
                            } else {
                                print("🔄 PICKUP: No airport selected - user needs to select one")
                            }
                        } else {
                            // Pickup is now city - clear airport selection, ensure address is ready
                            print("🔄 PICKUP: Now city-based - clearing airport selection")
                            if selectedPickupAirport?.isEmpty == false {
                                selectedPickupAirport = nil
                                pickupAirportCoordinate = nil
                            }
                        }
                        
                        // Handle DROPOFF changes
                        if transferType.contains("to Airport") {
                            // Dropoff is now airport - clear city address, ensure airport is ready for selection
                            print("🔄 DROPOFF: Now airport-based - clearing city address")
                            if !dropoffAddress.isEmpty {
                                dropoffAddress = ""
                                dropoffAddressVM.input = ""
                                dropoffCoordinate = nil
                            }
                            // Check if airport is already selected from previous state
                            if let existingAirport = selectedDropoffAirport, !existingAirport.isEmpty {
                                print("🔄 DROPOFF: Airport already selected from previous state: \(existingAirport)")
                                // Keep the existing airport selection
                            } else {
                                print("🔄 DROPOFF: No airport selected - user needs to select one")
                            }
                        } else {
                            // Dropoff is now city - clear airport selection, ensure address is ready
                            print("🔄 DROPOFF: Now city-based - clearing airport selection")
                            if selectedDropoffAirport?.isEmpty == false {
                                selectedDropoffAirport = nil
                                dropoffAirportCoordinate = nil
                            }
                        }
                        
                        print("🔄 AFTER TRANSFER TYPE CHANGE:")
                        print("  - Pickup Airport: \(selectedPickupAirport ?? "nil")")
                        print("  - Dropoff Airport: \(selectedDropoffAirport ?? "nil")")
                        print("  - Pickup Address: \(pickupAddress)")
                        print("  - Dropoff Address: \(dropoffAddress)")
                        
                        // Special handling for Airport to Airport scenario
                        if transferType == "Airport to Airport" {
                            print("🔄 SPECIAL HANDLING: Airport to Airport transfer type detected")
                            
                            // Update return transfer type to match the new transfer type
                            selectedReturnTransferType = "Airport to Airport"
                            print("🔄 SPECIAL: Updated return transfer type to: \(selectedReturnTransferType ?? "nil")")
                            
                            // Ensure addresses are properly cleared for airport-to-airport
                            if pickupAddress.isEmpty {
                                pickupAddress = ""
                            }
                            if dropoffAddress.isEmpty {
                                dropoffAddress = ""
                            }
                            print("🔄 SPECIAL: Ensured addresses are cleared for airport-to-airport")
                            
                            
                            // Handle pickup airport selection for Airport to Airport
                            if (selectedPickupAirport?.isEmpty != false), let rideData = rideData {
                                if rideData.pickupType == "airport" && !rideData.selectedPickupAirport.isEmpty {
                                    // Original was airport-based pickup, use that airport
                                    print("🔄 SPECIAL: Setting pickup airport from original pickup: \(rideData.selectedPickupAirport)")
                                    selectedPickupAirport = rideData.selectedPickupAirport
                                    if let pickupLat = rideData.pickupLat, let pickupLong = rideData.pickupLong {
                                        pickupAirportCoordinate = LocationCoordinate(latitude: pickupLat, longitude: pickupLong)
                                    }
                                } else if rideData.dropoffType == "airport" && !rideData.selectedDestinationAirport.isEmpty {
                                    // Original was city-to-airport, DON'T auto-select pickup airport
                                    // Let user manually select pickup airport
                                    print("🔄 SPECIAL: Original was city-to-airport, clearing pickup airport for user selection")
                                    selectedPickupAirport = nil
                                    pickupAirportCoordinate = nil
                                } else {
                                    // No airport data available, clear for user selection
                                    print("🔄 SPECIAL: No airport data available, clearing pickup airport for user selection")
                                    selectedPickupAirport = nil
                                    pickupAirportCoordinate = nil
                                }
                            } else {
                                // If pickup airport is already selected, keep it but ensure it's valid
                                if let existingPickupAirport = selectedPickupAirport, !existingPickupAirport.isEmpty {
                                    print("🔄 SPECIAL: Pickup airport already selected: \(existingPickupAirport)")
                                } else {
                                    print("🔄 SPECIAL: No pickup airport selected, user needs to select one")
                                }
                            }
                            
                            // If dropoff airport is not selected but we have rideData with airport info, try to use it
                            if (selectedDropoffAirport?.isEmpty != false), let rideData = rideData {
                                if rideData.dropoffType == "airport" && !rideData.selectedDestinationAirport.isEmpty {
                                    print("🔄 SPECIAL: Setting dropoff airport from rideData: \(rideData.selectedDestinationAirport)")
                                    selectedDropoffAirport = rideData.selectedDestinationAirport
                                    if let dropoffLat = rideData.destinationLat, let dropoffLong = rideData.destinationLong {
                                        dropoffAirportCoordinate = LocationCoordinate(latitude: dropoffLat, longitude: dropoffLong)
                                    }
                                }
                            }
                            
                            print("🔄 SPECIAL HANDLING COMPLETE:")
                            print("  - Pickup Airport: \(selectedPickupAirport ?? "nil")")
                            print("  - Dropoff Airport: \(selectedDropoffAirport ?? "nil")")
                            print("  - Return Transfer Type: \(selectedReturnTransferType ?? "nil")")
                        }
                    }
                    
                    // Force UI refresh to show correct fields for new transfer type
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    refreshRates()
                        // NOTE: initializeReturnTripFields() should NOT be called here
                        // as it swaps outbound/return data which corrupts airport selections
                        // Only call it when specifically handling return trip changes
                    }
                }
                .onChange(of: selectedHours) { newValue in
                    print("🕐 selectedHours changed to: '\(newValue)'")
                    if isPrefillingData { return }
                    hasUserModifiedPricingInputs = true
                    refreshRates()
                }
                .onChange(of: numberOfVehicles) { _ in
                    if isPrefillingData { return }
                    hasUserModifiedPricingInputs = true
                    refreshRates()
                }
                .onChange(of: pickupAddress) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "pickupAddress")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: dropoffAddress) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "dropoffAddress")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: selectedPickupAirport) { newPickupAirport in
                    // Clear validation error when user selects an airport
                    clearError(for: "pickupAirport")
                    print("🔄 PICKUP AIRPORT CHANGED: \(newPickupAirport ?? "nil")")
                    print("🔄 CURRENT STATE BEFORE UPDATE:")
                    print("  - Pickup Airport: \(selectedPickupAirport ?? "nil")")
                    print("  - Dropoff Airport: \(selectedDropoffAirport ?? "nil")")
                    print("  - Transfer Type: \(selectedTransferType ?? "nil")")
                    
                    // Update pickup airport coordinates when airport is selected
                    if let airportName = newPickupAirport, !airportName.isEmpty {
                        if let airport = airportService.airports.first(where: { $0.displayName == airportName }) {
                            pickupAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                            print("✅ PICKUP AIRPORT COORDINATE UPDATED: \(airport.lat ?? 0), \(airport.long ?? 0)")
                        } else {
                            print("❌ PICKUP AIRPORT NOT FOUND IN SERVICE: \(airportName)")
                        }
                    } else {
                        pickupAirportCoordinate = nil
                        print("🔄 PICKUP AIRPORT COORDINATE CLEARED")
                    }
                    
                    print("🔄 CURRENT STATE AFTER UPDATE:")
                    print("  - Pickup Airport: \(selectedPickupAirport ?? "nil")")
                    print("  - Dropoff Airport: \(selectedDropoffAirport ?? "nil")")
                    
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                    
                    // Prevent auto-prefill airport changes from triggering recalculation in edit mode
                    if isEditMode && !hasUserModifiedPricingInputs && hasLoadedExistingRates {
                        print("ℹ️ EDIT MODE: Ignoring pickup airport change from prefill (no user modification yet)")
                        return
                    }
                    
                    // Validate locations immediately to show errors
                    validateOutboundLocations()
                    
                    // Refresh rates when airport selection changes
                    if !isPrefillingData { hasUserModifiedPricingInputs = true }
                    refreshRates()
                }
                .onChange(of: selectedDropoffAirport) { newDropoffAirport in
                    // Clear validation error when user selects an airport
                    clearError(for: "dropoffAirport")
                    print("🔄 DROPOFF AIRPORT CHANGED: \(newDropoffAirport ?? "nil")")
                    
                    // Update dropoff airport coordinates when airport is selected
                    if let airportName = newDropoffAirport, !airportName.isEmpty {
                        if let airport = airportService.airports.first(where: { $0.displayName == airportName }) {
                            dropoffAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                            print("✅ DROPOFF AIRPORT COORDINATE UPDATED: \(airport.lat ?? 0), \(airport.long ?? 0)")
                        } else {
                            print("❌ DROPOFF AIRPORT NOT FOUND IN SERVICE: \(airportName)")
                        }
                    } else {
                        dropoffAirportCoordinate = nil
                        print("🔄 DROPOFF AIRPORT COORDINATE CLEARED")
                    }
                    
                    // Validate locations immediately to show errors
                    validateOutboundLocations()
                    
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                    
                    // Prevent auto-prefill airport changes from triggering recalculation in edit mode
                    if isEditMode && !hasUserModifiedPricingInputs && hasLoadedExistingRates {
                        print("ℹ️ EDIT MODE: Ignoring dropoff airport change from prefill (no user modification yet)")
                        return
                    }
                    
                    // Refresh rates when airport selection changes
                    if !isPrefillingData { hasUserModifiedPricingInputs = true }
                    refreshRates()
                }
                .onChange(of: selectedPickupAirline) { _ in
                    // Clear validation error when user selects an airline
                    clearError(for: "pickupAirline")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: selectedDropoffAirline) { _ in
                    // Clear validation error when user selects an airline
                    clearError(for: "dropoffAirline")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: pickupFlightNumber) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "pickupFlightNumber")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: dropoffFlightNumber) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "dropoffFlightNumber")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: pickupAirportSearch) { _ in
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: dropoffAirportSearch) { _ in
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: extraStops) { _ in
                    if isPrefillingData {
                        return
                    }
                    hasUserModifiedPricingInputs = true
                    refreshRates()
                }
                .onChange(of: originAirportCity) { _ in
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: cruisePort) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "cruisePort")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: cruiseShipName) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "cruiseShipName")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                .onChange(of: shipArrivalTime) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "shipArrivalTime")
                    // NOTE: initializeReturnTripFields() should NOT be called here
                    // as it swaps outbound/return data which corrupts airport selections
                    // Return trip fields should only be initialized when service type changes to Round Trip
                }
                // Return trip field change handlers
                .onChange(of: returnPickupAddress) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "returnPickupAddress")
                    if isPrefillingData { return }
                    hasUserModifiedPricingInputs = true
                    refreshReturnRates()
                }
                .onChange(of: returnDropoffAddress) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "returnDropoffAddress")
                    if isPrefillingData { return }
                    hasUserModifiedPricingInputs = true
                    refreshReturnRates()
                }
                .onChange(of: selectedReturnPickupAirport) { _ in
                    // Clear validation error when user selects an airport
                    clearError(for: "returnPickupAirport")
                    if isPrefillingData { return }
                    hasUserModifiedPricingInputs = true
                    refreshReturnRates()
                }
                .onChange(of: selectedReturnDropoffAirport) { _ in
                    // Clear validation error when user selects an airport
                    clearError(for: "returnDropoffAirport")
                    if isPrefillingData { return }
                    hasUserModifiedPricingInputs = true
                    refreshReturnRates()
                }
                .onChange(of: selectedReturnPickupAirline) { _ in
                    // Clear validation error when user selects an airline
                    clearError(for: "returnPickupAirline")
                    refreshReturnRates()
                }
                .onChange(of: selectedReturnDropoffAirline) { _ in
                    // Clear validation error when user selects an airline
                    clearError(for: "returnDropoffAirline")
                    refreshReturnRates()
                }
                .onChange(of: returnPickupFlightNumber) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "returnPickupFlightNumber")
                    refreshReturnRates()
                }
                .onChange(of: returnDropoffFlightNumber) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "returnDropoffFlightNumber")
                    refreshReturnRates()
                }
                .onChange(of: returnOriginAirportCity) { _ in
                    refreshReturnRates()
                }
                .onChange(of: returnCruisePort) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "returnCruisePort")
                    refreshReturnRates()
                }
                .onChange(of: returnCruiseShipName) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "returnCruiseShipName")
                    refreshReturnRates()
                }
                .onChange(of: returnShipArrivalTime) { _ in
                    // Clear validation error when user starts typing
                    clearError(for: "returnShipArrivalTime")
                    refreshReturnRates()
                }
                .onChange(of: returnExtraStops) { _ in
                    if isPrefillingData {
                        return
                    }
                    hasUserModifiedPricingInputs = true
                    refreshReturnRates()
                }
                .onChange(of: selectedReturnServiceType) { newValue in
                    if isPrefillingData {
                        return
                    }
                    // When return service type changes, clear return extra stops and special instructions
                    if newValue != selectedServiceType {
                        returnExtraStops.removeAll()
                        returnSpecialInstructions = ""
                    }
                    refreshReturnRates()
                }
                .onChange(of: selectedDate) { newDate in
                    // Update display string when selectedDate changes
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "MMM dd, yyyy"
                    travelDate = dateFormatter.string(from: newDate)
                    print("🕐 selectedDate changed - Updated travelDate display to: '\(travelDate)'")
                }
                .onChange(of: selectedTime) { newTime in
                    // Update display string when selectedTime changes
                    let timeFormatter = DateFormatter()
                    timeFormatter.dateFormat = "h:mm a"
                    pickupTime = timeFormatter.string(from: newTime)
                    print("🕐 selectedTime changed - Updated pickupTime display to: '\(pickupTime)'")
                }
                .overlay(dropdownOverlay)
            }
            .navigationBarBackButtonHidden(shouldHideBackButton)
            
            // Loading overlay for repeat mode - simple loader only
            if isRepeatMode && isLoadingRepeatData {
                VStack {
                    Spacer()
                    ProgressView()
                        .scaleEffect(1.2)
                        .progressViewStyle(CircularProgressViewStyle(tint: .orange))
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.white.opacity(0.8))
                .zIndex(3000)
            }
            
            if showInvalidLocationDialog {
                invalidLocationBanner
                    .zIndex(2000)
            }
            
            // Success Screen - Outside NavigationView
            if showSuccessScreen {
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                    .overlay(
                        BookingSuccessScreen(
                            onOK: {
                                print("🔚 Success screen closed - navigating back to dashboard")
                                // Clear entire path to go directly to DashboardView (if path is available)
                                if !path.isEmpty {
                                    path.removeAll()
                                }
                                onComplete?()
                                // Dismiss all sheets simultaneously using the manager
                                SheetDismissalManager.shared.dismissAllSheets()
                            },
                            hasDriverAssigned: hasDriverAssigned
                        )
                    )
                    .onAppear {
                        print("🎉 SUCCESS SCREEN APPEARED - showSuccessScreen: \(showSuccessScreen), hasDriverAssigned: \(hasDriverAssigned)")
                    }
            }
            
            // Date Picker Overlay - Travel Date
            if showDatePicker {
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        showDatePicker = false
                    }
                
                DatePickerView(
                    selectedDate: $selectedDate,
                    showDatePicker: Binding(
                        get: { showDatePicker },
                        set: { newValue in
                            if !newValue {
                                updateTravelDate()
                            }
                            showDatePicker = newValue
                        }
                    )
                )
            }
            
            // Date Picker Overlay - Return Date
            if showReturnDatePicker {
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        showReturnDatePicker = false
                    }
                
                DatePickerView(
                    selectedDate: $selectedReturnDate,
                    showDatePicker: Binding(
                        get: { showReturnDatePicker },
                        set: { newValue in
                            if !newValue {
                                updateReturnDate()
                            }
                            showReturnDatePicker = newValue
                        }
                    )
                )
            }
            
        }
        .onAppear {
            print("🔍 VIEW APPEARED - showSuccessScreen: \(showSuccessScreen)")
        }
        .onReceive(NotificationCenter.default.publisher(for: .dismissAllSheets)) { _ in
            print("🔚 ComprehensiveBookingView received dismiss notification")
            // Don't hide success screen yet - keep it visible
        }
        .onReceive(NotificationCenter.default.publisher(for: .forceDismissAllSheets)) { _ in
            print("🔚 ComprehensiveBookingView received force dismiss notification")
            // Hide success screen at the very last moment
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
                showSuccessScreen = false
            }
            // Don't dismiss this view - let parent sheets handle dismissal
        }
        
        // MARK: - Bottom Sheets
        .sheet(isPresented: $showAirportBottomSheet) {
            SearchableBottomSheet<Airport>(
                title: "Select Airport",
                items: airportService.airports,
                selectedItem: .constant(nil),
                isPresented: $showAirportBottomSheet,
                onItemSelected: { airport in
                    handleAirportSelection(airport: airport)
                },
                onSearchChanged: { searchQuery in
                    Task {
                        await airportService.searchAirportsAPI(query: searchQuery)
                    }
                }
            )
            .presentationDetents([.medium, .large])
        }
        
        .sheet(isPresented: $showAirlineBottomSheet) {
            SearchableBottomSheet<Airline>(
                title: "Select Airline",
                items: airlineService.airlines,
                selectedItem: .constant(nil),
                isPresented: $showAirlineBottomSheet,
                onItemSelected: { airline in
                    handleAirlineSelection(airline: airline)
                },
                onSearchChanged: { searchQuery in
                    Task {
                        await airlineService.searchAirlines(query: searchQuery)
                    }
                }
            )
            .presentationDetents([.medium, .large])
        }
        
        // Time Picker Bottom Sheet - Pickup Time
        .appBottomSheet(
            isPresented: Binding(
                get: { showTimePicker },
                set: { newValue in
                    if !newValue {
                        updatePickupTime()
                    }
                    showTimePicker = newValue
                }
            ),
            title: nil,
            showDragIndicator: true,
            dismissOnTapOutside: true
        ) {
            TimePickerView(
                selectedTime: $selectedTime,
                showTimePicker: Binding(
                    get: { showTimePicker },
                    set: { newValue in
                        if !newValue {
                            updatePickupTime()
                        }
                        showTimePicker = newValue
                    }
                ),
                selectedDate: $selectedDate
            )
            .frame(maxWidth: .infinity)
        }
        
        // Time Picker Bottom Sheet - Cruise Arrival Time
        .appBottomSheet(
            isPresented: Binding(
                get: { showCruiseTimePicker },
                set: { newValue in
                    if !newValue {
                        updateCruiseTime()
                    }
                    showCruiseTimePicker = newValue
                }
            ),
            title: nil,
            showDragIndicator: true,
            dismissOnTapOutside: true
        ) {
            TimePickerView(
                selectedTime: $selectedCruiseTime,
                showTimePicker: Binding(
                    get: { showCruiseTimePicker },
                    set: { newValue in
                        if !newValue {
                            updateCruiseTime()
                        }
                        showCruiseTimePicker = newValue
                    }
                ),
                selectedDate: $selectedDate
            )
            .frame(maxWidth: .infinity)
        }
        
        // Time Picker Bottom Sheet - Return Time
        .appBottomSheet(
            isPresented: Binding(
                get: { showReturnTimePicker },
                set: { newValue in
                    if !newValue {
                        updateReturnTime()
                    }
                    showReturnTimePicker = newValue
                }
            ),
            title: nil,
            showDragIndicator: true,
            dismissOnTapOutside: true
        ) {
            TimePickerView(
                selectedTime: $selectedReturnTime,
                showTimePicker: Binding(
                    get: { showReturnTimePicker },
                    set: { newValue in
                        if !newValue {
                            updateReturnTime()
                        }
                        showReturnTimePicker = newValue
                    }
                ),
                selectedDate: $selectedReturnDate
            )
            .frame(maxWidth: .infinity)
        }
        
        // Time Picker Bottom Sheet - Return Cruise Arrival Time
        .appBottomSheet(
            isPresented: Binding(
                get: { showReturnCruiseTimePicker },
                set: { newValue in
                    if !newValue {
                        updateReturnCruiseTime()
                    }
                    showReturnCruiseTimePicker = newValue
                }
            ),
            title: nil,
            showDragIndicator: true,
            dismissOnTapOutside: true
        ) {
            TimePickerView(
                selectedTime: $selectedReturnCruiseTime,
                showTimePicker: Binding(
                    get: { showReturnCruiseTimePicker },
                    set: { newValue in
                        if !newValue {
                            updateReturnCruiseTime()
                        }
                        showReturnCruiseTimePicker = newValue
                    }
                ),
                selectedDate: $selectedReturnDate
            )
            .frame(maxWidth: .infinity)
        }
    }
    
    // MARK: - Dropdown Background Overlay
    private var backgroundOverlay: some View {
        Color.black.opacity(0.001)
            .ignoresSafeArea()
            .onTapGesture { openDropdown = nil }
            .zIndex(100)
    }
    
    // MARK: - Regular Dropdown Options
    private var regularDropdownOptions: some View {
        VStack(spacing: 0) {
            if dropdownOptions.count <= 5 {
                // For small lists, don't use ScrollView
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(dropdownOptions, id: \.self) { option in
                        Button(action: {
                            // Handle airline selections differently
                            if openDropdown?.contains("Airline") == true {
                                handleAirlineSelection(option: option)
                            } else {
                                dropdownSelected?.wrappedValue = option
                            }
                            openDropdown = nil
                        }) {
                            HStack {
                                Text(option)
                                    .foregroundColor(.black)
                                    .padding(.vertical, 8)
                                    .padding(.horizontal, 12)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                if isOptionSelected(option: option) {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(AppColors.primaryOrange)
                                }
                            }
                            .background(isOptionSelected(option: option) ? Color.gray.opacity(0.2) : Color.white)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            } else {
                // For larger lists, use ScrollView
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(dropdownOptions, id: \.self) { option in
                            Button(action: {
                                // Handle airline selections differently
                                if openDropdown?.contains("Airline") == true {
                                    handleAirlineSelection(option: option)
                                } else {
                                    dropdownSelected?.wrappedValue = option
                                }
                                openDropdown = nil
                            }) {
                                HStack {
                                    Text(option)
                                        .foregroundColor(.black)
                                        .padding(.vertical, 8)
                                        .padding(.horizontal, 12)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    if isOptionSelected(option: option) {
                                        Image(systemName: "checkmark")
                                            .foregroundColor(AppColors.primaryOrange)
                                    }
                                }
                                .background(isOptionSelected(option: option) ? Color.gray.opacity(0.2) : Color.white)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
                .frame(maxHeight: min(CGFloat(dropdownOptions.count) * 36, 200))
            }
        }
        .frame(width: min(max(dropdownFrame.width - 8, 200), UIScreen.main.bounds.width - 30))
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.12), radius: 12, x: 0, y: 4)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.black.opacity(0.08), lineWidth: 0.5)
        )
        .position(x: dropdownFrame.midX, y: dropdownFrame.maxY + getDropdownPosition())
        .zIndex(1000)
    }
    
    // MARK: - Dropdown Overlay
    private var dropdownOverlay: some View {
        ZStack {
            if let dropdownSelected = dropdownSelected, openDropdown != nil {
                backgroundOverlay
                
                // Regular dropdown options (for non-airport dropdowns)
                if openDropdown != "pickupAirport" && openDropdown != "dropoffAirport" && openDropdown != "returnPickupAirport" && openDropdown != "returnDropoffAirport" {
                    regularDropdownOptions
                }
                
                // Airport dropdown with search and scroll
                if openDropdown == "pickupAirport" || openDropdown == "dropoffAirport" || openDropdown == "returnPickupAirport" || openDropdown == "returnDropoffAirport" {
                    airportDropdownOptions
                }
            }
        }
    }
    
    private var invalidLocationBanner: some View {
        VStack {
            Spacer()
                .frame(height: 220)
            HStack(alignment: .center, spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color(red: 1.0, green: 0.94, blue: 0.94))
                        .frame(width: 36, height: 36)
                    Circle()
                        .stroke(Color(red: 0.93, green: 0.46, blue: 0.46), lineWidth: 1)
                        .frame(width: 36, height: 36)
                    Image(systemName: "info.circle.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(Color(red: 0.78, green: 0.12, blue: 0.12))
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(invalidLocationTitle())
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(Color(red: 0.78, green: 0.12, blue: 0.12))
                    Text(invalidLocationSubtitle())
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(Color(red: 0.58, green: 0.16, blue: 0.16))
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .fill(Color(red: 1.0, green: 0.95, blue: 0.95))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(Color(red: 0.94, green: 0.47, blue: 0.47), lineWidth: 1)
            )
            .padding(.horizontal, 24)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .allowsHitTesting(false)
        .transition(.opacity)
        .animation(.easeInOut(duration: 0.25), value: showInvalidLocationDialog)
    }
    
    private func invalidLocationTitle() -> String {
        let message = invalidLocationMessage.lowercased()
        if message.contains("country") {
            return "Pickup and drop countries must match"
        }
        if message.contains("same") {
            return "Pickup and drop locations are same"
        }
        return "Invalid location selected"
    }
    
    private func invalidLocationSubtitle() -> String {
        let message = invalidLocationMessage.lowercased()
        if message.contains("country") {
            return "Please select pickup and drop-off within the same country."
        }
        if message.contains("same") {
            return "Please change your pickup or drop location."
        }
        return invalidLocationMessage
    }
    
    // MARK: - Airport Dropdown Options
    private var airportDropdownOptions: some View {
        VStack(alignment: .leading, spacing: 0) {
                        // Search field
                        HStack {
                            if openDropdown == "pickupAirport" {
                                AutoSelectTextField(
                                    placeholder: "Search airports...",
                                    text: $pickupAirportSearch,
                                    fontSize: 14,
                                    fontWeight: .medium,
                                    textColor: .gray
                                )
                                .padding(.vertical, 8)
                                .padding(.horizontal, 12)
                                .onChange(of: pickupAirportSearch) { newValue in
                                    Task {
                                        await airportService.searchAirports(query: newValue)
                                    }
                                }
                            } else if openDropdown == "dropoffAirport" {
                                AutoSelectTextField(
                                    placeholder: "Search airports...",
                                    text: $dropoffAirportSearch,
                                    fontSize: 14,
                                    fontWeight: .medium,
                                    textColor: .gray
                                )
                                .padding(.vertical, 8)
                                .padding(.horizontal, 12)
                                .onChange(of: dropoffAirportSearch) { newValue in
                                    Task {
                                        await airportService.searchAirports(query: newValue)
                                    }
                                }
                            } else if openDropdown == "returnPickupAirport" {
                                AutoSelectTextField(
                                    placeholder: "Search airports...",
                                    text: $returnPickupAirportSearch,
                                    fontSize: 14,
                                    fontWeight: .medium,
                                    textColor: .gray
                                )
                                .padding(.vertical, 8)
                                .padding(.horizontal, 12)
                                .onChange(of: returnPickupAirportSearch) { newValue in
                                    Task {
                                        await airportService.searchAirports(query: newValue)
                                    }
                                }
                            } else if openDropdown == "returnDropoffAirport" {
                                AutoSelectTextField(
                                    placeholder: "Search airports...",
                                    text: $returnDropoffAirportSearch,
                                    fontSize: 14,
                                    fontWeight: .medium,
                                    textColor: .gray
                                )
                                .padding(.vertical, 8)
                                .padding(.horizontal, 12)
                                .onChange(of: returnDropoffAirportSearch) { newValue in
                                    Task {
                                        await airportService.searchAirports(query: newValue)
                                    }
                                }
                            }
                        }
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(8)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        
                        // Airport list with scroll
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 0) {
                                ForEach(airportService.airports, id: \.id) { airport in
                                    Button(action: {
                                        if openDropdown == "pickupAirport" {
                                            selectedPickupAirport = airport.displayName
                                            pickupAirportSearch = airport.displayName
                                            // Store airport coordinates
                                            pickupAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                                            print("📍 PICKUP AIRPORT COORDINATE STORED: \(airport.lat ?? 0), \(airport.long ?? 0)")
                                        } else if openDropdown == "dropoffAirport" {
                                            selectedDropoffAirport = airport.displayName
                                            dropoffAirportSearch = airport.displayName
                                            // Store airport coordinates
                                            dropoffAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                                            print("📍 DROPOFF AIRPORT COORDINATE STORED: \(airport.lat ?? 0), \(airport.long ?? 0)")
                                        } else if openDropdown == "returnPickupAirport" {
                                            selectedReturnPickupAirport = airport.displayName
                                            returnPickupAirportSearch = airport.displayName
                                            // Store airport coordinates
                                            returnPickupAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                                            print("📍 RETURN PICKUP AIRPORT COORDINATE STORED: \(airport.lat ?? 0), \(airport.long ?? 0)")
                                            print("📍 RETURN PICKUP AIRPORT UPDATED - Airport: '\(airport.displayName)', Coord: \(airport.lat ?? 0), \(airport.long ?? 0)")
                                        } else if openDropdown == "returnDropoffAirport" {
                                            selectedReturnDropoffAirport = airport.displayName
                                            returnDropoffAirportSearch = airport.displayName
                                            // Store airport coordinates
                                            returnDropoffAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                                            print("📍 RETURN DROPOFF AIRPORT COORDINATE STORED: \(airport.lat ?? 0), \(airport.long ?? 0)")
                                            print("📍 RETURN DROPOFF AIRPORT UPDATED - Airport: '\(airport.displayName)', Coord: \(airport.lat ?? 0), \(airport.long ?? 0)")
                                        }
                                        
                                        // Capture dropdown name before clearing
                                        let dropdownName = openDropdown
                                        openDropdown = nil
                                        
                                        // Automatically call API after airport selection - exactly like outbound
                                        Task {
                                            await fetchBookingRates()
                                        }
                                    }) {
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(airport.displayName)
                                                .font(.system(size: 14, weight: .medium))
                                                .foregroundColor(.gray)
                                            Text("\(airport.city), \(airport.country)")
                                                .font(.system(size: 12, weight: .regular))
                                                .foregroundColor(.gray)
                                        }
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 8)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .background(Color.white)
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                    
                                    if airport.id != airportService.airports.last?.id {
                                        Divider()
                                            .padding(.leading, 12)
                                    }
                                }
                            }
                        }
                        .frame(maxHeight: 300)
                    }
                    .frame(width: min(max(dropdownFrame.width - 8, 200), UIScreen.main.bounds.width - 30))
                    .background(Color.white)
                    .cornerRadius(12)
                    .shadow(color: Color.black.opacity(0.12), radius: 12, x: 0, y: 4)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.black.opacity(0.08), lineWidth: 0.5)
                    )
                    .position(x: dropdownFrame.midX, y: dropdownFrame.maxY + getDropdownPosition())
                    .zIndex(1000)
    }
    
    // MARK: - Private Methods
    
    private func handleAirlineSelection(option: String) {
        // Find the airline by display name and set the corresponding ID
        guard let airline = airlineService.airlines.first(where: { $0.displayName == option }) else {
            print("❌ Could not find airline with display name: \(option)")
            return
        }
        
        let airlineId = String(airline.id)
        
        switch openDropdown {
        case "pickupAirline":
            selectedPickupAirline = airlineId
        case "dropoffAirline":
            selectedDropoffAirline = airlineId
        case "returnPickupAirline":
            selectedReturnPickupAirline = airlineId
        case "returnDropoffAirline":
            selectedReturnDropoffAirline = airlineId
        default:
            print("❌ Unknown airline dropdown: \(openDropdown ?? "nil")")
        }
        
        print("✅ Selected airline: \(option) with ID: \(airlineId) for dropdown: \(openDropdown ?? "nil")")
    }
    
    private func isOptionSelected(option: String) -> Bool {
        // For airline dropdowns, check if the option matches the selected airline's display name
        if openDropdown?.contains("Airline") == true {
            switch openDropdown {
            case "pickupAirline":
                if let airlineId = selectedPickupAirline,
                   let airline = airlineService.airlines.first(where: { String($0.id) == airlineId }) {
                    return airline.displayName == option
                }
            case "dropoffAirline":
                if let airlineId = selectedDropoffAirline,
                   let airline = airlineService.airlines.first(where: { String($0.id) == airlineId }) {
                    return airline.displayName == option
                }
            case "returnPickupAirline":
                if let airlineId = selectedReturnPickupAirline,
                   let airline = airlineService.airlines.first(where: { String($0.id) == airlineId }) {
                    return airline.displayName == option
                }
            case "returnDropoffAirline":
                if let airlineId = selectedReturnDropoffAirline,
                   let airline = airlineService.airlines.first(where: { String($0.id) == airlineId }) {
                    return airline.displayName == option
                }
            default:
                break
            }
            return false
        } else {
            // For non-airline dropdowns, use the original logic
            return dropdownSelected?.wrappedValue == option
        }
    }
    
    private func loadUserData() {
        userData = StorageManager.shared.getUserData()
    }
    
    private func loadUserProfile() {
        Task {
            let result = await userProfileService.fetchUserProfile()
            if result.success {
                print("✅ User profile loaded successfully")
            } else {
                print("❌ Failed to load user profile: \(result.error ?? "Unknown error")")
            }
        }
    }
    
    // MARK: - User Information Helper Methods
    private func getUserDisplayName() -> String {
        // Try to get from user profile service first
        if let profileData = userProfileService.userProfile {
            return profileData.fullName
        }
        
        // Fallback to storage manager
        if let name = StorageManager.shared.getUserName() {
            return name
        }
        
        // Final fallback
        return "User"
    }
    
    private func getUserEmail() -> String {
        // Try to get from user profile service first
        if let profileData = userProfileService.userProfile {
            return profileData.email
        }
        
        // Fallback to storage manager
        if let email = StorageManager.shared.getUserEmail() {
            return email
        }
        
        // Final fallback
        return "N/A"
    }
    
    private func getUserMobile() -> String {
        // Try to get from user profile service first
        if let profileData = userProfileService.userProfile {
            return profileData.fullMobileNumber
        }
        
        // Fallback to storage manager
        if let mobile = StorageManager.shared.getUserMobile() {
            return mobile
        }
        
        // Fallback to basic user data
        if let userData = userData {
            return userData.phone
        }
        
        // Final fallback
        return "N/A"
    }
    
    private func getUserZipCode() -> String {
        // Try to get from user profile service first
        if let profileData = userProfileService.userProfile {
            return profileData.zip
        }
        
        // Final fallback
        return "N/A"
    }
    
    private func getUserAddress() -> String {
        // Try to get from user profile service first
        if let profileData = userProfileService.userProfile {
            return profileData.fullAddress
        }
        
        // Fallback to storage manager
        if let address = StorageManager.shared.getUserAddress() {
            return address
        }
        
        // Fallback to pickup address if available
        if let rideData = rideData, !rideData.pickupLocation.isEmpty {
            return rideData.pickupLocation
        }
        
        // Final fallback
        return pickupAddress
    }
    
    private func getUserCountry() -> String {
        // Try to get from user profile service first
        if let profileData = userProfileService.userProfile {
            return profileData.country
        }
        
        // Final fallback
        return "United States"
    }
    
    private func loadInitialData() {
        Task {
            await airportService.fetchAllAirports()
            await airlineService.fetchAirlines()
            await fetchMeetGreetChoices()
            
            // In edit mode, rates must come from reservation-rates on first load.
            // Skip the generic booking-rates call here; fetchBookingRates will be
            // invoked after edit data is prefilling, which will hit reservation-rates.
            if isEditMode {
                return
            }
            
            await fetchBookingRates()
        }
    }
    
    private func fetchMeetGreetChoices() async {
        isLoadingMeetGreetChoices = true
        
        let endpoint = APIEndpoints.meetGreetChoices
        
        do {
            let response: MeetGreetResponse = try await NetworkService.shared.request(
                endpoint: endpoint,
                responseType: MeetGreetResponse.self
            )
            
            if response.success {
                meetGreetChoices = response.data.meetGreets
                print("✅ Meet and greet choices loaded: \(meetGreetChoices.count) options")
            } else {
                print("❌ Failed to fetch meet and greet choices: \(response.message)")
            }
        } catch {
            print("❌ Failed to fetch meet and greet choices: \(error)")
        }
        
        isLoadingMeetGreetChoices = false
    }
    
    // MARK: - Hours Multiplier Helper
    private func getHoursMultiplier() -> Double {
        // For charter tours, multiply by number of hours
        if selectedServiceType == "Charter Tour" {
            let hoursString = selectedHours.replacingOccurrences(of: " hours minimum", with: "").replacingOccurrences(of: " hours", with: "")
            let hours = Double(hoursString) ?? 2.0
            print("🕐 Charter Tour - Hours: \(hoursString) -> Multiplier: \(hours)")
            return hours
        }
        
        // For other service types, no multiplier
        return 1.0
    }
    
    // Helper function to calculate the sum of all_inclusive_rates for percentage calculations
    private func calculateBaseRatesSum(from rateArray: BookingRateArray) -> Double {
        var sum: Double = 0.0
        let hoursMultiplier = getHoursMultiplier()
        
        // Add all base rates
        for (key, item) in rateArray.allInclusiveRates {
            let adjustedBaserate: Double
            // For Charter Tour (hourly rates), only multiply Base_Rate baserate
            if selectedServiceType == "Charter Tour" && key == "Base_Rate" {
                adjustedBaserate = item.baserate * hoursMultiplier
            } else {
                adjustedBaserate = item.baserate
            }
            sum += adjustedBaserate
        }
        
        print("🔄 ComprehensiveBookingView - Total base rates sum for percentage calculation: \(sum)")
        return sum
    }
    
    private func calculateTotalsFromRateArray(_ rateArray: BookingRateArray) -> (subtotal: Double, grandTotal: Double) {
        var totalBaserate: Double = 0
        var allInclusiveBaserate: Double = 0
        
        // Get hours multiplier for charter tours
        let hoursMultiplier = getHoursMultiplier()
        
        print("📊 PROCESSING ALL_INCLUSIVE_RATES - Total items: \(rateArray.allInclusiveRates.count)")
        
        // Sum all baserate values from ALL items in all_inclusive_rates (whatever comes from API)
        for (key, rateItem) in rateArray.allInclusiveRates {
            let adjustedBaserate: Double
            // For Charter Tour (hourly rates), only multiply Base_Rate baserate
            if selectedServiceType == "Charter Tour" && key == "Base_Rate" {
                adjustedBaserate = rateItem.baserate * hoursMultiplier
                print("  ✓ \(key): \(rateItem.baserate) × \(hoursMultiplier) = \(adjustedBaserate)")
            } else {
                adjustedBaserate = rateItem.baserate
                print("  ✓ \(key): \(adjustedBaserate)")
            }
            totalBaserate += adjustedBaserate
            allInclusiveBaserate += adjustedBaserate
        }
        print("  → All Inclusive Baserate Sum: \(allInclusiveBaserate)")
        
        print("📦 PROCESSING AMENITIES - Total items: \(rateArray.amenities.count)")
        // Sum all baserate values from ALL amenities (no multiplier for hourly rates)
        for (key, rateItem) in rateArray.amenities {
            print("  ✓ \(key): \(rateItem.baserate)")
            totalBaserate += rateItem.baserate
        }
        
        print("💰 PROCESSING TAXES - Total items: \(rateArray.taxes.count)")
        // Calculate base rates sum for percentage calculations
        let baseRatesSum = calculateBaseRatesSum(from: rateArray)
        
        // Process taxes: check if type is "percent" and calculate accordingly
        for (key, taxItem) in rateArray.taxes {
            let isPercentage = taxItem.type == "percent"
            
            if isPercentage {
                // Calculate percentage of base rates sum
                let percentageValue = taxItem.baserate
                let calculatedAmount = (baseRatesSum * percentageValue) / 100.0
                totalBaserate += calculatedAmount
                print("  ✓ \(key): \(percentageValue)% of \(baseRatesSum) = \(calculatedAmount) (percentage)")
            } else {
                // Flat rate
                totalBaserate += taxItem.baserate
                print("  ✓ \(key): \(taxItem.baserate) (flat)")
            }
        }
        
        print("📋 PROCESSING MISC - Total items: \(rateArray.misc.count)")
        // Sum all baserate values from ALL misc items (no multiplier for hourly rates)
        for (key, rateItem) in rateArray.misc {
            print("  ✓ \(key): \(rateItem.baserate)")
            totalBaserate += rateItem.baserate
        }
        
        // Calculate subtotal: total baserate + 25% of all_inclusive_rates baserate
        let twentyFivePercentOfAllInclusive = allInclusiveBaserate * 0.25
        let calculatedSubtotal = totalBaserate + twentyFivePercentOfAllInclusive
        
        // Grand total = subtotal × number of vehicles
        let calculatedGrandTotal = calculatedSubtotal * Double(numberOfVehicles)
        
        print("📊 RATE CALCULATION BREAKDOWN:")
        print("Service Type: \(selectedServiceType ?? "Unknown")")
        print("Hours Multiplier: \(hoursMultiplier)")
        print("All Inclusive Baserate (adjusted): \(allInclusiveBaserate)")
        print("Total Baserate (all categories, adjusted): \(totalBaserate)")
        print("25% of All Inclusive: \(twentyFivePercentOfAllInclusive)")
        print("Calculated Subtotal: \(calculatedSubtotal)")
        print("Number of Vehicles: \(numberOfVehicles)")
        print("Calculated Grand Total: \(calculatedGrandTotal) (Subtotal × \(numberOfVehicles))")
        
        return (subtotal: calculatedSubtotal, grandTotal: calculatedGrandTotal)
    }
    
    private func calculateReturnTotalsFromReturnRateArray(_ returnRateArray: BookingRateArray) -> (returnSubtotal: Double, returnGrandTotal: Double) {
        var totalBaserate: Double = 0
        var allInclusiveBaserate: Double = 0
        
        // Get hours multiplier for charter tours
        let hoursMultiplier = getHoursMultiplier()
        
        print("📊 PROCESSING RETURN ALL_INCLUSIVE_RATES - Total items: \(returnRateArray.allInclusiveRates.count)")
        
        // Sum all baserate values from ALL items in all_inclusive_rates (whatever comes from API)
        for (key, rateItem) in returnRateArray.allInclusiveRates {
            let adjustedBaserate: Double
            // For Charter Tour (hourly rates), only multiply Base_Rate baserate
            if selectedServiceType == "Charter Tour" && key == "Base_Rate" {
                adjustedBaserate = rateItem.baserate * hoursMultiplier
                print("  ✓ \(key): \(rateItem.baserate) × \(hoursMultiplier) = \(adjustedBaserate)")
            } else {
                adjustedBaserate = rateItem.baserate
                print("  ✓ \(key): \(adjustedBaserate)")
            }
            totalBaserate += adjustedBaserate
            allInclusiveBaserate += adjustedBaserate
        }
        print("  → Return All Inclusive Baserate Sum: \(allInclusiveBaserate)")
        
        print("📦 PROCESSING RETURN AMENITIES - Total items: \(returnRateArray.amenities.count)")
        // Sum all baserate values from ALL amenities (no multiplier for hourly rates)
        for (key, rateItem) in returnRateArray.amenities {
            print("  ✓ \(key): \(rateItem.baserate)")
            totalBaserate += rateItem.baserate
        }
        
        print("💰 PROCESSING RETURN TAXES - Total items: \(returnRateArray.taxes.count)")
        // Calculate base rates sum for percentage calculations
        let returnBaseRatesSum = calculateBaseRatesSum(from: returnRateArray)
        
        // Process return taxes: check if type is "percent" and calculate accordingly
        for (key, taxItem) in returnRateArray.taxes {
            let isPercentage = taxItem.type == "percent"
            
            if isPercentage {
                // Calculate percentage of base rates sum
                let percentageValue = taxItem.baserate
                let calculatedAmount = (returnBaseRatesSum * percentageValue) / 100.0
                totalBaserate += calculatedAmount
                print("  ✓ \(key): \(percentageValue)% of \(returnBaseRatesSum) = \(calculatedAmount) (percentage)")
            } else {
                // Flat rate
                totalBaserate += taxItem.baserate
                print("  ✓ \(key): \(taxItem.baserate) (flat)")
            }
        }
        
        print("📋 PROCESSING RETURN MISC - Total items: \(returnRateArray.misc.count)")
        // Sum all baserate values from ALL misc items (no multiplier for hourly rates)
        for (key, rateItem) in returnRateArray.misc {
            print("  ✓ \(key): \(rateItem.baserate)")
            totalBaserate += rateItem.baserate
        }
        
        // Calculate return subtotal: total baserate + 25% of all_inclusive_rates baserate
        let twentyFivePercentOfAllInclusive = allInclusiveBaserate * 0.25
        let calculatedReturnSubtotal = totalBaserate + twentyFivePercentOfAllInclusive
        
        // Return grand total = return subtotal × number of vehicles
        let calculatedReturnGrandTotal = calculatedReturnSubtotal * Double(numberOfVehicles)
        
        print("📊 RETURN RATE CALCULATION BREAKDOWN:")
        print("Service Type: \(selectedServiceType ?? "Unknown")")
        print("Hours Multiplier: \(hoursMultiplier)")
        print("Return All Inclusive Baserate (adjusted): \(allInclusiveBaserate)")
        print("Return Total Baserate (all categories, adjusted): \(totalBaserate)")
        print("Return 25% of All Inclusive: \(twentyFivePercentOfAllInclusive)")
        print("Calculated Return Subtotal: \(calculatedReturnSubtotal)")
        print("Number of Vehicles: \(numberOfVehicles)")
        print("Calculated Return Grand Total: \(calculatedReturnGrandTotal) (Return Subtotal × \(numberOfVehicles))")
        
        return (returnSubtotal: calculatedReturnSubtotal, returnGrandTotal: calculatedReturnGrandTotal)
    }
    
    private func fetchBookingRates() async {
        print("🔄 FETCHING BOOKING RATES...")
        print("Edit Mode: \(isEditMode)")

        // Validate locations and set field errors instead of showing toast
        await MainActor.run {
            validateOutboundLocations()
            validateReturnLocations()
        }
        
        // Block API if pickup and dropoff are the same
        if let conflict = outboundLocationConflictReason(), isOutboundSelectionComplete() {
            print("❌ Validation failed (Outbound): \(conflict) Blocking API call.")
            
            // Show error in UI - set field errors and show banner
            await MainActor.run {
                // Set errors on relevant fields based on transfer type
                let transfer = selectedTransferType ?? "City to City"
                let needsPickupAddress = transfer == "City to City" || transfer == "City to Airport" || transfer == "City to Cruise Port" || transfer == "Cruise Port to City" || transfer == "Cruise Port to Airport"
                let needsDropoffAddress = transfer == "City to City" || transfer == "Airport to City" || transfer == "Cruise Port to City" || transfer == "City to Cruise Port" || transfer == "Airport to Cruise Port"
                let needsPickupAirport = transfer == "Airport to City" || transfer == "Airport to Airport" || transfer == "Airport to Cruise Port"
                let needsDropoffAirport = transfer == "City to Airport" || transfer == "Airport to Airport" || transfer == "Cruise Port to Airport"
                
                // Set errors on both pickup and dropoff fields
                if needsPickupAddress {
                    fieldErrors["pickupAddress"] = conflict
                } else if needsPickupAirport {
                    fieldErrors["pickupAirport"] = conflict
                }
                
                if needsDropoffAddress {
                    fieldErrors["dropoffAddress"] = conflict
                } else if needsDropoffAirport {
                    fieldErrors["dropoffAirport"] = conflict
                }
                
                // Don't show toast - field errors below fields are enough
            }
            return
        }
        
        if let conflict = returnLocationConflictReason(), isReturnSelectionComplete() {
            print("❌ Validation failed (Return): \(conflict) Blocking API call.")
            
            // Show error in UI - set field errors and show banner
            await MainActor.run {
                // Set errors on relevant return fields based on transfer type
                let transfer = selectedReturnTransferType ?? "City to City"
                let needsPickupAddress = transfer == "City to City" || transfer == "City to Airport" || transfer == "City to Cruise Port" || transfer == "Cruise Port to City" || transfer == "Cruise Port to Airport"
                let needsDropoffAddress = transfer == "City to City" || transfer == "Airport to City" || transfer == "Cruise Port to City" || transfer == "City to Cruise Port" || transfer == "Airport to Cruise Port"
                let needsPickupAirport = transfer == "Airport to City" || transfer == "Airport to Airport" || transfer == "Airport to Cruise Port"
                let needsDropoffAirport = transfer == "City to Airport" || transfer == "Airport to Airport" || transfer == "Cruise Port to Airport"
                
                // Set errors on both return pickup and dropoff fields
                if needsPickupAddress {
                    fieldErrors["returnPickupAddress"] = conflict
                } else if needsPickupAirport {
                    fieldErrors["returnPickupAirport"] = conflict
                }
                
                if needsDropoffAddress {
                    fieldErrors["returnDropoffAddress"] = conflict
                } else if needsDropoffAirport {
                    fieldErrors["returnDropoffAirport"] = conflict
                }
                
                // Don't show toast - field errors below fields are enough
            }
            return
        }

        // EDIT MODE FIRST LOAD: always fetch reservation rates exactly once, even if there are extra stops.
        if isEditMode && !hasLoadedExistingRates, let bookingId = editBookingId {
            print("🔄 EDIT MODE (Initial Load): Forcing reservation-rates API for booking ID: \(bookingId)")
            await bookingRatesService.fetchReservationRates(bookingId: bookingId)
            await MainActor.run {
                hasLoadedExistingRates = true
            }
        }

        // EDIT MODE: If we already loaded reservation rates and user hasn't changed pricing inputs, reuse them
        if isEditMode && hasLoadedExistingRates && !hasUserModifiedPricingInputs {
            print("🔄 EDIT MODE (No user changes): Using previously loaded reservation rates, skipping recalculation")
            
            // Ensure UI reflects the last fetched reservation rates even when we skip recalculation
            if let existingRates = bookingRatesService.ratesData {
                await MainActor.run {
                    subtotal = existingRates.subTotal
                    grandTotal = existingRates.grandTotal
                    
                    // Preserve return leg totals if present
                    if selectedServiceType == "Round Trip", let returnRateArray = existingRates.retrunRateArray {
                        let calculatedReturnTotals = calculateReturnTotalsFromReturnRateArray(returnRateArray)
                        returnSubtotal = calculatedReturnTotals.returnSubtotal
                        returnGrandTotal = calculatedReturnTotals.returnGrandTotal
                    }
                }
            }
            return
        }
        
        // In edit mode, check if we need to recalculate rates
        // Use booking rates API when service type is Round Trip (to calculate return rates) 
        // Always recalculate for round trips in edit mode to get return rates
        // CRITICAL FIX: Also recalculate if extra stops are present or have changed
        let isEditModeRoundTrip = isEditMode && selectedServiceType == "Round Trip"
        let hasExtraStops = !extraStops.filter { $0.isLocationSelected && $0.coordinate != nil }.isEmpty
        let hasReturnExtraStops = !returnExtraStops.filter { $0.isLocationSelected && $0.coordinate != nil }.isEmpty
        let needsRecalculation = isEditModeRoundTrip || hasExtraStops || hasReturnExtraStops
        
        // For repeat/return mode: Use reservation-rates API if we haven't loaded rates yet OR if we're still in repeat mode without changes
        // Only switch to booking-rates-vehicle if user has made changes (extra stops, round trip, etc.)
        let shouldUseExistingRatesForRepeat = isRepeatMode && selectedServiceType != "Round Trip" && !hasExtraStops && !hasReturnExtraStops
        
        if shouldUseExistingRatesForRepeat, let bookingId = repeatBookingId {
            if !hasLoadedExistingRates {
                print("🔄 REPEAT MODE (Prefill): Using reservation-rates API for booking ID: \(bookingId)")
                await bookingRatesService.fetchReservationRates(bookingId: bookingId)
                await MainActor.run {
                    hasLoadedExistingRates = true
                }
            } else {
                print("🔄 REPEAT MODE (No Changes): Continuing to use existing rates, skipping API call")
                return // Don't recalculate if we already have rates and no changes were made
            }
        } else if isEditMode && !needsRecalculation, let bookingId = editBookingId {
            // In edit mode for one-way WITHOUT extra stops, use the reservation rates API (fetch existing rates)
            print("🔄 EDIT MODE (One Way, No Extra Stops): Using reservation-rates API for booking ID: \(bookingId)")
            await bookingRatesService.fetchReservationRates(bookingId: bookingId)
            await MainActor.run {
                hasLoadedExistingRates = true
            }
        } else {
            // Normal mode (create) OR edit mode with round trip/extra stops: use the regular booking rates API to recalculate
            if isEditMode {
                if isEditModeRoundTrip {
                    print("🔄 EDIT MODE (Round Trip): Recalculating rates with booking-rates-vehicle API")
                } else if hasExtraStops {
                    print("🔄 EDIT MODE (One Way with Extra Stops): Recalculating rates with booking-rates-vehicle API")
                } else if hasReturnExtraStops {
                    print("🔄 EDIT MODE (One Way with Return Extra Stops): Recalculating rates with booking-rates-vehicle API")
                }
            } else if isRepeatMode {
                print("🔄 REPEAT MODE (Recalculation): Using booking-rates-vehicle API (user made changes)")
            } else {
                print("🔄 NORMAL MODE (CREATE): Using booking-rates-vehicle API")
            }
            print("Extra stops with locations: \(extraStops.filter { $0.isLocationSelected }.count)")
            
            // ALWAYS recalculate distance before hitting API
            let calculatedDistance = await calculateDistance()
            print("📏 RECALCULATED DISTANCE: \(calculatedDistance) meters")
            
            // CRITICAL FIX: For round trips, ALSO recalculate return distance - exactly like outbound distance above
            if selectedServiceType == "Round Trip" {
                print("🔄 RECALCULATING RETURN DISTANCE AS WELL")
                let calculatedReturnDistance = await calculateReturnDistance()
                print("📏 RECALCULATED RETURN DISTANCE: \(calculatedReturnDistance) meters")
            }
            
            let request = await createBookingRatesRequest()
            print("🚀 CALLING BOOKING RATES API WITH DISTANCE: \(request.distance) meters")
            print("🚀 CALLING BOOKING RATES API WITH RETURN DISTANCE: \(request.returnDistance) meters")
            print("🕐 BOOKING RATES REQUEST - noOfHours: '\(request.noOfHours)'")
            print("🕐 BOOKING RATES REQUEST - serviceType: '\(request.serviceType)'")
            print("🕐 BOOKING RATES REQUEST - rideData.bookingHour: '\(rideData?.bookingHour ?? "nil")'")
            await bookingRatesService.fetchBookingRates(request: request)
        }
        
        // Update pricing with API response (same for both edit and normal mode)
        if let ratesData = bookingRatesService.ratesData {
            let calculatedTotals = calculateTotalsFromRateArray(ratesData.rateArray)
            subtotal = calculatedTotals.subtotal
            grandTotal = calculatedTotals.grandTotal
            print("✅ Rates updated - Calculated Subtotal: \(subtotal), Calculated Grand Total: \(grandTotal)")
            
            // For round trips, calculate return pricing from the same response
            if selectedServiceType == "Round Trip", let returnRateArray = ratesData.retrunRateArray {
                let calculatedReturnTotals = calculateReturnTotalsFromReturnRateArray(returnRateArray)
                returnSubtotal = calculatedReturnTotals.returnSubtotal
                returnGrandTotal = calculatedReturnTotals.returnGrandTotal
                print("✅ Return rates updated from same response - Calculated Return Subtotal: \(returnSubtotal), Calculated Return Grand Total: \(returnGrandTotal)")
            } else if selectedServiceType == "Round Trip" {
                // Reset return pricing if no return rate array in response
                returnSubtotal = 0.0
                returnGrandTotal = 0.0
                print("❌ No return rate array found in response for round trip")
            }
        } else {
            print("❌ No rates data received from API")
        }
    }

    // MARK: - Location Helpers
    private func effectiveOutboundPickupCoordinate() -> LocationCoordinate? {
        let transfer = selectedTransferType ?? "City to City"
        switch transfer {
        case "Airport to City", "Airport to Airport", "Airport to Cruise Port":
            return pickupAirportCoordinate ?? pickupCoordinate
        case "Cruise Port to City", "Cruise Port to Airport":
            return pickupCruiseCoordinate ?? pickupCoordinate
        default:
            return pickupCoordinate
        }
    }
    
    private func effectiveOutboundDropoffCoordinate() -> LocationCoordinate? {
        let transfer = selectedTransferType ?? "City to City"
        switch transfer {
        case "City to Airport", "Airport to Airport", "Cruise Port to Airport":
            return dropoffAirportCoordinate ?? dropoffCoordinate
        case "City to Cruise Port", "Airport to Cruise Port":
            return dropoffCruiseCoordinate ?? dropoffCoordinate
        default:
            return dropoffCoordinate
        }
    }
    
    private func outboundPickupText() -> String {
        let transfer = selectedTransferType ?? "City to City"
        switch transfer {
        case "Airport to City", "Airport to Airport", "Airport to Cruise Port":
            return (selectedPickupAirport ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        default:
            return pickupAddress.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    
    private func outboundDropoffText() -> String {
        let transfer = selectedTransferType ?? "City to City"
        switch transfer {
        case "City to Airport", "Airport to Airport", "Cruise Port to Airport":
            return (selectedDropoffAirport ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        default:
            return dropoffAddress.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    
    private func returnPickupText() -> String {
        let transfer = selectedReturnTransferType ?? "City to City"
        switch transfer {
        case "Airport to City", "Airport to Airport", "Airport to Cruise Port":
            return (selectedReturnPickupAirport ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        default:
            return returnPickupAddress.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    
    private func returnDropoffText() -> String {
        let transfer = selectedReturnTransferType ?? "City to City"
        switch transfer {
        case "City to Airport", "Airport to Airport", "Cruise Port to Airport":
            return (selectedReturnDropoffAirport ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        default:
            return returnDropoffAddress.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    
    private func coordinatesApproximatelyEqual(_ lhs: LocationCoordinate, _ rhs: LocationCoordinate, tolerance: Double = 0.00001) -> Bool {
        return abs(lhs.latitude - rhs.latitude) < tolerance && abs(lhs.longitude - rhs.longitude) < tolerance
    }
    
    // MARK: - Same Location Validation
    private func areOutboundLocationsSame() -> Bool {
        if let pickup = effectiveOutboundPickupCoordinate(),
           let dropoff = effectiveOutboundDropoffCoordinate(),
           coordinatesApproximatelyEqual(pickup, dropoff) {
            return true
        }
        
        let pickupString = outboundPickupText()
        let dropoffString = outboundDropoffText()
        
        if !pickupString.isEmpty && !dropoffString.isEmpty {
            return pickupString.caseInsensitiveCompare(dropoffString) == .orderedSame
        }
        
        return false
    }
    
    private func areReturnLocationsSame() -> Bool {
        guard selectedServiceType == "Round Trip" else { return false }
        
        if let pickup = getReturnPickupCoordinate(),
           let dropoff = getReturnDropoffCoordinate(),
           coordinatesApproximatelyEqual(pickup, dropoff) {
            return true
        }
        
        let pickupString = returnPickupText()
        let dropoffString = returnDropoffText()
        if !pickupString.isEmpty && !dropoffString.isEmpty {
            return pickupString.caseInsensitiveCompare(dropoffString) == .orderedSame
        }
        
        return false
    }
    
    private func deriveCountryFromAddress(_ address: String, viewModel: AddressAutocompleteViewModel?) -> String? {
        if let selected = viewModel?.selectedCountry,
           !selected.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return selected
        }
        return extractCountry(from: address)
    }
    
    private func resolveAirportCountry(selection: String?, coordinate: LocationCoordinate?) -> String? {
        if let selection = selection {
            if let airport = airportService.airports.first(where: { $0.displayName == selection || $0.fullDisplayName == selection }) {
                return airport.country
            }
        }
        
        if let coordinate = coordinate {
            if let airport = airportService.airports.first(where: {
                guard let lat = $0.lat, let long = $0.long else { return false }
                let airportCoord = LocationCoordinate(latitude: lat, longitude: long)
                return coordinatesApproximatelyEqual(airportCoord, coordinate, tolerance: 0.01)
            }) {
                return airport.country
            }
        }
        
        return nil
    }
    
    private func normalizeCountry(_ country: String?) -> String? {
        guard let rawValue = country?.trimmingCharacters(in: .whitespacesAndNewlines), !rawValue.isEmpty else {
            return nil
        }
        
        let cleaned = rawValue.replacingOccurrences(of: ".", with: "")
        let uppercased = cleaned.uppercased()
        let compact = uppercased.replacingOccurrences(of: " ", with: "")
        let containsDigit = compact.rangeOfCharacter(from: .decimalDigits) != nil
        
        switch compact {
        case "UNITEDSTATESOFAMERICA", "UNITEDSTATES", "USA", "US":
            return "UNITED STATES"
        case "UNITEDKINGDOM", "GREATBRITAIN", "BRITAIN", "ENGLAND", "UK":
            return "UNITED KINGDOM"
        case "UNITEDARABEMIRATES", "UAE":
            return "UNITED ARAB EMIRATES"
        default:
            break
        }
        
        if containsDigit {
            return nil
        }
        
        if compact.count <= 3 {
            return nil
        }
        
        return uppercased
    }
    
    private func extractCountry(from address: String) -> String? {
        let separators = CharacterSet(charactersIn: ",;")
        let components = address
            .components(separatedBy: separators)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        
        for component in components.reversed() {
            if component.rangeOfCharacter(from: .letters) != nil {
                return component
            }
        }
        return nil
    }
    
    private func resolveOutboundCountries() -> (pickup: String?, dropoff: String?) {
        let transfer = selectedTransferType ?? "City to City"
        switch transfer {
        case "City to Airport":
            return (
                deriveCountryFromAddress(pickupAddress, viewModel: pickupAddressVM),
                resolveAirportCountry(selection: selectedDropoffAirport, coordinate: dropoffAirportCoordinate)
            )
        case "Airport to City":
            return (
                resolveAirportCountry(selection: selectedPickupAirport, coordinate: pickupAirportCoordinate),
                deriveCountryFromAddress(dropoffAddress, viewModel: dropoffAddressVM)
            )
        case "Airport to Airport":
            return (
                resolveAirportCountry(selection: selectedPickupAirport, coordinate: pickupAirportCoordinate),
                resolveAirportCountry(selection: selectedDropoffAirport, coordinate: dropoffAirportCoordinate)
            )
        case "Airport to Cruise Port":
            return (
                resolveAirportCountry(selection: selectedPickupAirport, coordinate: pickupAirportCoordinate),
                deriveCountryFromAddress(dropoffAddress, viewModel: dropoffAddressVM)
            )
        case "Cruise Port to Airport":
            return (
                deriveCountryFromAddress(pickupAddress, viewModel: pickupAddressVM),
                resolveAirportCountry(selection: selectedDropoffAirport, coordinate: dropoffAirportCoordinate)
            )
        default:
            return (
                deriveCountryFromAddress(pickupAddress, viewModel: pickupAddressVM),
                deriveCountryFromAddress(dropoffAddress, viewModel: dropoffAddressVM)
            )
        }
    }
    
    private func resolveReturnCountries() -> (pickup: String?, dropoff: String?) {
        let transfer = selectedReturnTransferType ?? "City to City"
        switch transfer {
        case "City to Airport":
            return (
                deriveCountryFromAddress(returnPickupAddress, viewModel: returnPickupAddressVM),
                resolveAirportCountry(selection: selectedReturnDropoffAirport, coordinate: returnDropoffAirportCoordinate)
            )
        case "Airport to City":
            return (
                resolveAirportCountry(selection: selectedReturnPickupAirport, coordinate: returnPickupAirportCoordinate),
                deriveCountryFromAddress(returnDropoffAddress, viewModel: returnDropoffAddressVM)
            )
        case "Airport to Airport":
            return (
                resolveAirportCountry(selection: selectedReturnPickupAirport, coordinate: returnPickupAirportCoordinate),
                resolveAirportCountry(selection: selectedReturnDropoffAirport, coordinate: returnDropoffAirportCoordinate)
            )
        case "Airport to Cruise Port":
            return (
                resolveAirportCountry(selection: selectedReturnPickupAirport, coordinate: returnPickupAirportCoordinate),
                deriveCountryFromAddress(returnDropoffAddress, viewModel: returnDropoffAddressVM)
            )
        case "Cruise Port to Airport":
            return (
                deriveCountryFromAddress(returnPickupAddress, viewModel: returnPickupAddressVM),
                resolveAirportCountry(selection: selectedReturnDropoffAirport, coordinate: returnDropoffAirportCoordinate)
            )
        default:
            return (
                deriveCountryFromAddress(returnPickupAddress, viewModel: returnPickupAddressVM),
                deriveCountryFromAddress(returnDropoffAddress, viewModel: returnDropoffAddressVM)
            )
        }
    }
    
    private func outboundLocationConflictReason() -> String? {
        if areOutboundLocationsSame() {
            return "Pickup and drop-off cannot be the same. Please select different locations."
        }
        
        let countries = resolveOutboundCountries()
        if let pickupCountry = normalizeCountry(countries.pickup),
           let dropoffCountry = normalizeCountry(countries.dropoff),
           pickupCountry != dropoffCountry {
            return "Pickup and drop-off must be in the same country. Please select valid locations."
        }
        
        return nil
    }
    
    private func returnLocationConflictReason() -> String? {
        guard selectedServiceType == "Round Trip",
              selectedReturnServiceType == "Round Trip" else { return nil }
        
        if areReturnLocationsSame() {
            return "Return pickup and drop-off cannot be the same. Please select different locations."
        }
        
        let countries = resolveReturnCountries()
        if let pickupCountry = normalizeCountry(countries.pickup),
           let dropoffCountry = normalizeCountry(countries.dropoff),
           pickupCountry != dropoffCountry {
            return "Return pickup and drop-off must be in the same country. Please select valid locations."
        }
        
        return nil
    }
    
    // MARK: - Location Validation for Field Errors
    private func validateOutboundLocations() {
        let transfer = selectedTransferType ?? "City to City"
        
        // Validate pickup location is selected from suggestions
        var pickupCoord: LocationCoordinate?
        var dropoffCoord: LocationCoordinate?
        
        switch transfer {
        case "City to City", "City to Airport", "City to Cruise Port":
            pickupCoord = pickupCoordinate
        case "Airport to City", "Airport to Airport", "Airport to Cruise Port":
            pickupCoord = pickupAirportCoordinate
        case "Cruise Port to City", "Cruise Port to Airport":
            pickupCoord = pickupCruiseCoordinate ?? pickupCoordinate
        default:
            pickupCoord = pickupCoordinate
        }
        
        switch transfer {
        case "City to City", "Airport to City", "Cruise Port to City":
            dropoffCoord = dropoffCoordinate
        case "City to Airport", "Airport to Airport", "Cruise Port to Airport":
            dropoffCoord = dropoffAirportCoordinate
        case "City to Cruise Port", "Airport to Cruise Port":
            dropoffCoord = dropoffCruiseCoordinate ?? dropoffCoordinate
        default:
            dropoffCoord = dropoffCoordinate
        }
        
        // Check if pickup location is selected from suggestions
        let needsPickupAddress = transfer == "City to City" || transfer == "City to Airport" || transfer == "City to Cruise Port" || transfer == "Cruise Port to City" || transfer == "Cruise Port to Airport"
        
        // Check if dropoff location is selected from suggestions
        let needsDropoffAddress = transfer == "City to City" || transfer == "Airport to City" || transfer == "Cruise Port to City" || transfer == "City to Cruise Port" || transfer == "Airport to Cruise Port"
        
        // Check if pickup is airport
        let needsPickupAirport = transfer == "Airport to City" || transfer == "Airport to Airport" || transfer == "Airport to Cruise Port"
        
        // Check if dropoff is airport
        let needsDropoffAirport = transfer == "City to Airport" || transfer == "Airport to Airport" || transfer == "Cruise Port to Airport"
        
        // Check for location conflicts once and store the result
        let conflictReason = outboundLocationConflictReason()
        
        // Validate pickup location
        if needsPickupAddress {
            let isPickupAddressValid = !pickupAddress.isEmpty && 
                                      pickupAddress != "Hyderabad - Bangalore Hwy, Guru Raghav.." &&
                                      pickupAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
            
            // Check if pickup has an error
            let pickupNeedsCoordinate = isPickupAddressValid && pickupCoord == nil
            let pickupHasConflict = conflictReason != nil && pickupCoord != nil
            
            if pickupNeedsCoordinate {
                // Invalid: address entered but no coordinate selected
                fieldErrors["pickupAddress"] = "Please select a location from the suggestions."
            } else if pickupHasConflict {
                // Invalid: conflict detected
                fieldErrors["pickupAddress"] = conflictReason!
            } else if pickupCoord != nil && conflictReason == nil {
                // Valid: has coordinate and no conflict - only clear location validation errors
                // Don't clear empty field errors (those are handled by validateFormAndShowErrors)
                if let existingError = fieldErrors["pickupAddress"] {
                    let lowercased = existingError.lowercased()
                    // Only clear if it's a location validation error, not an empty field error
                    if lowercased.contains("country") || lowercased.contains("same") || lowercased.contains("invalid location") || lowercased.contains("select a location from") {
                        clearError(for: "pickupAddress")
                    }
                }
            }
        }
        
        // Validate pickup airport
        if needsPickupAirport {
            let pickupHasConflict = conflictReason != nil && pickupCoord != nil
            let pickupAirportNotSelected = selectedPickupAirport == nil || selectedPickupAirport?.isEmpty == true
            
            if pickupAirportNotSelected {
                // Airport not selected - only set error if it's required validation, not conflict
                // Don't override conflict errors
                if conflictReason == nil {
                    // Only set required error if not already set by conflict
                    if fieldErrors["pickupAirport"] == nil {
                        // This will be handled by validateFormAndShowErrors for required fields
                    }
                }
            } else if pickupHasConflict {
                // Invalid: conflict detected - show error on airport field
                fieldErrors["pickupAirport"] = conflictReason!
            } else if pickupCoord != nil && conflictReason == nil {
                // Valid: has coordinate and no conflict - only clear location validation errors
                // Don't clear empty field errors (those are handled by validateFormAndShowErrors)
                if let existingError = fieldErrors["pickupAirport"] {
                    let lowercased = existingError.lowercased()
                    // Only clear if it's a location validation error, not an empty field error
                    if lowercased.contains("country") || lowercased.contains("same") || lowercased.contains("invalid location") {
                        clearError(for: "pickupAirport")
                    }
                }
            }
        }
        
        // Validate dropoff location
        if needsDropoffAddress {
            let isDropoffAddressValid = !dropoffAddress.isEmpty && 
                                       dropoffAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
            
            // Check if dropoff has an error
            let dropoffNeedsCoordinate = isDropoffAddressValid && dropoffCoord == nil
            let dropoffHasConflict = conflictReason != nil && dropoffCoord != nil
            
            if dropoffNeedsCoordinate {
                // Invalid: address entered but no coordinate selected
                fieldErrors["dropoffAddress"] = "Please select a location from the suggestions."
            } else if dropoffHasConflict {
                // Invalid: conflict detected
                fieldErrors["dropoffAddress"] = conflictReason!
            } else if dropoffCoord != nil && conflictReason == nil {
                // Valid: has coordinate and no conflict - only clear location validation errors
                // Don't clear empty field errors (those are handled by validateFormAndShowErrors)
                if let existingError = fieldErrors["dropoffAddress"] {
                    let lowercased = existingError.lowercased()
                    // Only clear if it's a location validation error, not an empty field error
                    if lowercased.contains("country") || lowercased.contains("same") || lowercased.contains("invalid location") || lowercased.contains("select a location from") {
                        clearError(for: "dropoffAddress")
                    }
                }
            }
        }
        
        // Validate dropoff airport
        if needsDropoffAirport {
            let dropoffHasConflict = conflictReason != nil && dropoffCoord != nil
            let dropoffAirportNotSelected = selectedDropoffAirport == nil || selectedDropoffAirport?.isEmpty == true
            
            if dropoffAirportNotSelected {
                // Airport not selected - only set error if it's required validation, not conflict
                // Don't override conflict errors
                if conflictReason == nil {
                    // Only set required error if not already set by conflict
                    if fieldErrors["dropoffAirport"] == nil {
                        // This will be handled by validateFormAndShowErrors for required fields
                    }
                }
            } else if dropoffHasConflict {
                // Invalid: conflict detected - show error on airport field
                fieldErrors["dropoffAirport"] = conflictReason!
            } else if dropoffCoord != nil && conflictReason == nil {
                // Valid: has coordinate and no conflict - only clear location validation errors
                // Don't clear empty field errors (those are handled by validateFormAndShowErrors)
                if let existingError = fieldErrors["dropoffAirport"] {
                    let lowercased = existingError.lowercased()
                    // Only clear if it's a location validation error, not an empty field error
                    if lowercased.contains("country") || lowercased.contains("same") || lowercased.contains("invalid location") {
                        clearError(for: "dropoffAirport")
                    }
                }
            }
        }
    }
    
    private func validateReturnLocations() {
        guard selectedServiceType == "Round Trip",
              selectedReturnServiceType == "Round Trip" else { return }
        
        let transfer = selectedReturnTransferType ?? "City to City"
        
        // Validate return pickup location is selected from suggestions
        var returnPickupCoord: LocationCoordinate?
        var returnDropoffCoord: LocationCoordinate?
        
        switch transfer {
        case "City to City", "City to Airport", "City to Cruise Port":
            returnPickupCoord = returnPickupCoordinate
        case "Airport to City", "Airport to Airport", "Airport to Cruise Port":
            returnPickupCoord = returnPickupAirportCoordinate
        case "Cruise Port to City", "Cruise Port to Airport":
            returnPickupCoord = returnPickupCruiseCoordinate ?? returnPickupCoordinate
        default:
            returnPickupCoord = returnPickupCoordinate
        }
        
        switch transfer {
        case "City to City", "Airport to City", "Cruise Port to City":
            returnDropoffCoord = returnDropoffCoordinate
        case "City to Airport", "Airport to Airport", "Cruise Port to Airport":
            returnDropoffCoord = returnDropoffAirportCoordinate
        case "City to Cruise Port", "Airport to Cruise Port":
            returnDropoffCoord = returnDropoffCruiseCoordinate ?? returnDropoffCoordinate
        default:
            returnDropoffCoord = returnDropoffCoordinate
        }
        
        // Check if return pickup location is selected from suggestions
        let needsReturnPickupAddress = transfer == "City to City" || transfer == "City to Airport" || transfer == "City to Cruise Port" || transfer == "Cruise Port to City" || transfer == "Cruise Port to Airport"
        
        // Check if return dropoff location is selected from suggestions
        let needsReturnDropoffAddress = transfer == "City to City" || transfer == "Airport to City" || transfer == "Cruise Port to City" || transfer == "City to Cruise Port" || transfer == "Airport to Cruise Port"
        
        // Check if return pickup is airport
        let needsReturnPickupAirport = transfer == "Airport to City" || transfer == "Airport to Airport" || transfer == "Airport to Cruise Port"
        
        // Check if return dropoff is airport
        let needsReturnDropoffAirport = transfer == "City to Airport" || transfer == "Airport to Airport" || transfer == "Cruise Port to Airport"
        
        // Check for location conflicts once and store the result
        let conflictReason = returnLocationConflictReason()
        
        // Validate return pickup location
        if needsReturnPickupAddress {
            let isReturnPickupAddressValid = !returnPickupAddress.isEmpty && 
                                            returnPickupAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
            
            // Check if return pickup has an error
            let returnPickupNeedsCoordinate = isReturnPickupAddressValid && returnPickupCoord == nil
            let returnPickupHasConflict = conflictReason != nil && returnPickupCoord != nil
            
            if returnPickupNeedsCoordinate {
                // Invalid: address entered but no coordinate selected
                fieldErrors["returnPickupAddress"] = "Please select a location from the suggestions."
            } else if returnPickupHasConflict {
                // Invalid: conflict detected
                fieldErrors["returnPickupAddress"] = conflictReason!
            } else if returnPickupCoord != nil && conflictReason == nil {
                // Valid: has coordinate and no conflict - only clear location validation errors
                // Don't clear empty field errors (those are handled by validateFormAndShowErrors)
                if let existingError = fieldErrors["returnPickupAddress"] {
                    let lowercased = existingError.lowercased()
                    // Only clear if it's a location validation error, not an empty field error
                    if lowercased.contains("country") || lowercased.contains("same") || lowercased.contains("invalid location") || lowercased.contains("select a location from") {
                        clearError(for: "returnPickupAddress")
                    }
                }
            }
        }
        
        // Validate return pickup airport
        if needsReturnPickupAirport {
            let returnPickupHasConflict = conflictReason != nil && returnPickupCoord != nil
            let returnPickupAirportNotSelected = selectedReturnPickupAirport == nil || selectedReturnPickupAirport?.isEmpty == true
            
            if returnPickupAirportNotSelected {
                // Airport not selected - only set error if it's required validation, not conflict
                // Don't override conflict errors
                if conflictReason == nil {
                    // Only set required error if not already set by conflict
                    if fieldErrors["returnPickupAirport"] == nil {
                        // This will be handled by validateFormAndShowErrors for required fields
                    }
                }
            } else if returnPickupHasConflict {
                // Invalid: conflict detected - show error on airport field
                fieldErrors["returnPickupAirport"] = conflictReason!
            } else if returnPickupCoord != nil && conflictReason == nil {
                // Valid: has coordinate and no conflict - only clear location validation errors
                // Don't clear empty field errors (those are handled by validateFormAndShowErrors)
                if let existingError = fieldErrors["returnPickupAirport"] {
                    let lowercased = existingError.lowercased()
                    // Only clear if it's a location validation error, not an empty field error
                    if lowercased.contains("country") || lowercased.contains("same") || lowercased.contains("invalid location") {
                        clearError(for: "returnPickupAirport")
                    }
                }
            }
        }
        
        // Validate return dropoff location
        if needsReturnDropoffAddress {
            let isReturnDropoffAddressValid = !returnDropoffAddress.isEmpty && 
                                             returnDropoffAddress.trimmingCharacters(in: .whitespacesAndNewlines).count > 5
            
            // Check if return dropoff has an error
            let returnDropoffNeedsCoordinate = isReturnDropoffAddressValid && returnDropoffCoord == nil
            let returnDropoffHasConflict = conflictReason != nil && returnDropoffCoord != nil
            
            if returnDropoffNeedsCoordinate {
                // Invalid: address entered but no coordinate selected
                fieldErrors["returnDropoffAddress"] = "Please select a location from the suggestions."
            } else if returnDropoffHasConflict {
                // Invalid: conflict detected
                fieldErrors["returnDropoffAddress"] = conflictReason!
            } else if returnDropoffCoord != nil && conflictReason == nil {
                // Valid: has coordinate and no conflict - only clear location validation errors
                // Don't clear empty field errors (those are handled by validateFormAndShowErrors)
                if let existingError = fieldErrors["returnDropoffAddress"] {
                    let lowercased = existingError.lowercased()
                    // Only clear if it's a location validation error, not an empty field error
                    if lowercased.contains("country") || lowercased.contains("same") || lowercased.contains("invalid location") || lowercased.contains("select a location from") {
                        clearError(for: "returnDropoffAddress")
                    }
                }
            }
        }
        
        // Validate return dropoff airport
        if needsReturnDropoffAirport {
            let returnDropoffHasConflict = conflictReason != nil && returnDropoffCoord != nil
            let returnDropoffAirportNotSelected = selectedReturnDropoffAirport == nil || selectedReturnDropoffAirport?.isEmpty == true
            
            if returnDropoffAirportNotSelected {
                // Airport not selected - only set error if it's required validation, not conflict
                // Don't override conflict errors
                if conflictReason == nil {
                    // Only set required error if not already set by conflict
                    if fieldErrors["returnDropoffAirport"] == nil {
                        // This will be handled by validateFormAndShowErrors for required fields
                    }
                }
            } else if returnDropoffHasConflict {
                // Invalid: conflict detected - show error on airport field
                fieldErrors["returnDropoffAirport"] = conflictReason!
            } else if returnDropoffCoord != nil && conflictReason == nil {
                // Valid: has coordinate and no conflict - only clear location validation errors
                // Don't clear empty field errors (those are handled by validateFormAndShowErrors)
                if let existingError = fieldErrors["returnDropoffAirport"] {
                    let lowercased = existingError.lowercased()
                    // Only clear if it's a location validation error, not an empty field error
                    if lowercased.contains("country") || lowercased.contains("same") || lowercased.contains("invalid location") {
                        clearError(for: "returnDropoffAirport")
                    }
                }
            }
        }
    }
    
    private func isOutboundSelectionComplete() -> Bool {
        let transfer = selectedTransferType ?? "City to City"
        switch transfer {
        case "City to City":
            return pickupCoordinate != nil && dropoffCoordinate != nil
        case "City to Airport":
            return pickupCoordinate != nil && dropoffAirportCoordinate != nil
        case "Airport to City":
            return pickupAirportCoordinate != nil && dropoffCoordinate != nil
        case "Airport to Airport":
            return pickupAirportCoordinate != nil && dropoffAirportCoordinate != nil
        case "City to Cruise Port":
            return pickupCoordinate != nil && (dropoffCruiseCoordinate ?? dropoffCoordinate) != nil
        case "Cruise Port to City":
            return (pickupCruiseCoordinate ?? pickupCoordinate) != nil && dropoffCoordinate != nil
        case "Airport to Cruise Port":
            return pickupAirportCoordinate != nil && (dropoffCruiseCoordinate ?? dropoffCoordinate) != nil
        case "Cruise Port to Airport":
            return (pickupCruiseCoordinate ?? pickupCoordinate) != nil && dropoffAirportCoordinate != nil
        default:
            return pickupCoordinate != nil && dropoffCoordinate != nil
        }
    }
    
    private func isReturnSelectionComplete() -> Bool {
        guard selectedServiceType == "Round Trip",
              selectedReturnServiceType == "Round Trip" else { return false }
        
        let transfer = selectedReturnTransferType ?? "City to City"
        switch transfer {
        case "City to City":
            return returnPickupCoordinate != nil && returnDropoffCoordinate != nil
        case "City to Airport":
            return returnPickupCoordinate != nil && returnDropoffAirportCoordinate != nil
        case "Airport to City":
            return returnPickupAirportCoordinate != nil && returnDropoffCoordinate != nil
        case "Airport to Airport":
            return returnPickupAirportCoordinate != nil && returnDropoffAirportCoordinate != nil
        case "City to Cruise Port":
            return returnPickupCoordinate != nil && (returnDropoffCruiseCoordinate ?? returnDropoffCoordinate) != nil
        case "Cruise Port to City":
            return (returnPickupCruiseCoordinate ?? returnPickupCoordinate) != nil && returnDropoffCoordinate != nil
        case "Airport to Cruise Port":
            return returnPickupAirportCoordinate != nil && (returnDropoffCruiseCoordinate ?? returnDropoffCoordinate) != nil
        case "Cruise Port to Airport":
            return (returnPickupCruiseCoordinate ?? returnPickupCoordinate) != nil && returnDropoffAirportCoordinate != nil
        default:
            return returnPickupCoordinate != nil && returnDropoffCoordinate != nil
        }
    }
    
    private func getNoOfHoursForService(serviceType: String) -> String {
        print("🕐 getNoOfHoursForService called with serviceType: '\(serviceType)'")
        print("🕐 isEditMode: \(isEditMode)")
        print("🕐 selectedServiceType: '\(selectedServiceType ?? "nil")'")
        print("🕐 selectedHours: '\(selectedHours)'")
        
        // In edit mode, use hours from edit data
        if isEditMode {
            if let editData = editReservationService.editData {
                let hours = editData.numberOfHours ?? 0
                print("🕐 EDIT MODE - Using hours from edit data: \(hours)")
                return "\(hours)"
            } else {
                print("🕐 EDIT MODE - No edit data available, using default '2'")
                return "2"
            }
        }
        
        // For charter tours, use the selectedHours from UI
        if serviceType == "charter_tour" || serviceType == "chartertour" {
            print("🕐 This is a charter tour service")
            // Extract hours from selectedHours string (e.g., "4 hours" or "2 hours minimum" -> "4" or "2")
            let hoursString = selectedHours.replacingOccurrences(of: " hours minimum", with: "").replacingOccurrences(of: " hours", with: "")
            let hours = Int(hoursString) ?? 2
            print("🕐 ✅ Using selectedHours from UI: '\(selectedHours)' -> '\(hours)'")
            return "\(hours)"
        }
        
        // For other service types (one_way, round_trip), use "0"
        print("🕐 Non-charter service type, using '0'")
        return "0"
    }
    
    private func getNoOfHoursForServiceInt(serviceType: String) -> Int {
        print("🕐 getNoOfHoursForServiceInt called with serviceType: '\(serviceType)'")
        print("🕐 isEditMode: \(isEditMode)")
        print("🕐 selectedHours: '\(selectedHours)'")
        
        // In edit mode, use hours from edit data
        if isEditMode {
            if let editData = editReservationService.editData {
                let hours = editData.numberOfHours ?? 0
                print("🕐 EDIT MODE - Using hours from edit data: \(hours)")
                return hours
            } else {
                print("🕐 EDIT MODE - No edit data available, using default 2")
                return 2
            }
        }
        
        // For charter tours, use the selectedHours from UI
        if serviceType == "charter_tour" || serviceType == "chartertour" {
            // Extract hours from selectedHours string (e.g., "4 hours" or "2 hours minimum" -> 4 or 2)
            let hoursString = selectedHours.replacingOccurrences(of: " hours minimum", with: "").replacingOccurrences(of: " hours", with: "")
            let hours = Int(hoursString) ?? 2
            print("🕐 ✅ Using selectedHours from UI: '\(selectedHours)' -> \(hours)")
            return hours
        }
        
        // For other service types (one_way, round_trip), use 0
        print("🕐 Non-charter service type, using 0")
        return 0
    }
    
    private func createBookingRatesRequest() async -> BookingRatesRequest {
        // Map transfer type from UI to API format
        let transferType = mapTransferTypeToAPI(selectedTransferType ?? "City to City")
        
        // Map service type from UI to API format
        let serviceType = mapServiceTypeToAPI(selectedServiceType ?? "One Way")
        
        // Calculate distance using Google Maps Directions API for accurate road distance
        let distance = await calculateDistance()
        print("📏 CALCULATED DISTANCE IN REQUEST: \(distance) meters")
        
        // Get extra stops with coordinates
        let extraStopsRequests = extraStops.compactMap { stop -> ExtraStopRequest? in
            guard !stop.address.isEmpty,
                  let coordinate = stop.coordinate else {
                return nil
            }
            
            return ExtraStopRequest(
                address: stop.address,
                latitude: coordinate.latitude,
                longitude: coordinate.longitude,
                rate: "out_town", // Default rate for extra stops
                bookingInstructions: "" // Empty for now, can be added later
            )
        }
        print("📍 EXTRA STOPS REQUESTS: \(extraStopsRequests.count) stops")
        for (index, stop) in extraStopsRequests.enumerated() {
            print("Stop \(index + 1): \(stop.address) (\(stop.latitude), \(stop.longitude))")
        }
        
        // Print the complete extra stops payload structure
        if !extraStopsRequests.isEmpty {
            print("📦 EXTRA STOPS API PAYLOAD:")
            do {
                let encoder = JSONEncoder()
                encoder.outputFormatting = .prettyPrinted
                let extraStopsData = try encoder.encode(extraStopsRequests)
                if let extraStopsString = String(data: extraStopsData, encoding: .utf8) {
                    print(extraStopsString)
                }
            } catch {
                print("Error encoding extra stops: \(error)")
            }
        }
        
        // Calculate return distance for round trips using return trip fields
        let returnDistance = (serviceType == "round_trip") ? Int(await calculateReturnDistance()) : 0
        print("📏 RETURN DISTANCE IN REQUEST: \(returnDistance) meters (serviceType: \(serviceType))")
        
        // Determine isMasterVehicle based on edit mode and affiliate_type
        let isMasterVehicle: Bool
        if isEditMode {
            // In edit mode, check affiliate_type from edit data
            if let editData = editReservationService.editData {
                isMasterVehicle = editData.affiliateType == "unassigned"
                print("🔍 EDIT MODE - isMasterVehicle: \(isMasterVehicle) (affiliate_type: \(editData.affiliateType ?? "nil"))")
            } else {
                isMasterVehicle = false
                print("🔍 EDIT MODE - No edit data available, using false")
            }
        } else {
            // In normal mode, use selectedVehicle's isMasterVehicle property
            isMasterVehicle = selectedVehicle?.isMasterVehicle ?? false
            print("🔍 NORMAL MODE - isMasterVehicle: \(isMasterVehicle)")
        }
        
        // Resolve vehicleId for booking rates.
        // In edit mode when isMasterVehicle is true and the payload came with vehicle_id null/0,
        // backend expects vehicle_type instead. The web sends 1 in that case, so mirror that here.
        let resolvedVehicleId: Int = {
            let id = selectedVehicle?.id ?? 0
            if isMasterVehicle && id == 0 {
                let fallback = editReservationService.editData?.vehicleType ?? 1
                print("⚙️ Fallback vehicle_id=\(fallback) because master vehicle has no vehicle_id in edit payload")
                return fallback
            }
            return id == 0 ? 1 : id
        }()
        
        return BookingRatesRequest(
            vehicleId: resolvedVehicleId, // fallback to vehicle_type (1) when master vehicle id missing
            transferType: transferType,
            serviceType: serviceType,
            numberOfVehicles: numberOfVehicles,
            distance: distance,
            returnDistance: returnDistance,
            noOfHours: getNoOfHoursForService(serviceType: serviceType), // Use appropriate hours based on service type
            isMasterVehicle: isMasterVehicle,
            extraStops: extraStopsRequests,
            returnExtraStops: returnExtraStops.compactMap { stop -> ExtraStopRequest? in
                guard !stop.address.isEmpty,
                      let coordinate = stop.coordinate else {
                    return nil
                }
                return ExtraStopRequest(
                    address: stop.address,
                    latitude: coordinate.latitude,
                    longitude: coordinate.longitude,
                    rate: "0",
                    bookingInstructions: stop.bookingInstructions
                )
            },
            pickupTime: pickupTime,
            returnPickupTime: "12:00 PM", // Default for round trips
            returnVehicleId: resolvedVehicleId, // keep return vehicle consistent with outbound
            returnAffiliateType: "affiliate" // Use "affiliate" like web instead of "unassigned"
        )
    }
    
    private func createReturnBookingRatesRequest() async -> BookingRatesRequest {
        // Map transfer type from UI to API format
        let transferType = mapTransferTypeToAPI(selectedTransferType ?? "City to City")
        
        // Map service type from UI to API format
        let serviceType = mapServiceTypeToAPI(selectedServiceType ?? "One Way")
        
        // Get return coordinates (swapped pickup/dropoff)
        let returnPickupCoord = self.getDropoffCoordinate() // Return pickup is original dropoff
        let returnDropoffCoord = self.getPickupCoordinate() // Return dropoff is original pickup
        
        // Calculate return distance (same as forward distance for round trip)
        let returnDistance = await calculateDistance()
        
        // Get return extra stops (if any)
        let returnExtraStopsRequests = returnExtraStops.compactMap { stop -> ExtraStopRequest? in
            guard !stop.address.isEmpty,
                  let coordinate = stop.coordinate else {
                return nil
            }
            return ExtraStopRequest(
                address: stop.address,
                latitude: coordinate.latitude,
                longitude: coordinate.longitude,
                rate: "out_town",
                bookingInstructions: ""
            )
        }
        
        // Determine isMasterVehicle based on mode
        let isMasterVehicle: Bool
        if isEditMode, let editData = editReservationService.editData {
            // In edit mode, derive isMasterVehicle from affiliateType
            isMasterVehicle = editData.affiliateType == "unassigned"
            print("🔍 EDIT MODE - isMasterVehicle from editData: \(isMasterVehicle) (affiliate_type: \(editData.affiliateType ?? "nil"))")
        } else {
            // In normal mode, use selectedVehicle's isMasterVehicle property
            isMasterVehicle = selectedVehicle?.isMasterVehicle ?? false
            print("🔍 NORMAL MODE - isMasterVehicle: \(isMasterVehicle)")
        }
        
        print("🔍 RETURN COORDINATE DEBUG:")
        print("  Return Pickup Coord: \(returnPickupCoord?.latitude ?? 0), \(returnPickupCoord?.longitude ?? 0)")
        print("  Return Dropoff Coord: \(returnDropoffCoord?.latitude ?? 0), \(returnDropoffCoord?.longitude ?? 0)")
        print("  Return Distance: \(returnDistance)")
        
        return BookingRatesRequest(
            vehicleId: selectedVehicle?.id ?? 1, // Use selected vehicle ID or default to 1
            transferType: transferType,
            serviceType: serviceType,
            numberOfVehicles: numberOfVehicles,
            distance: returnDistance, // Use return distance
            returnDistance: 0, // No return distance for return journey
            noOfHours: getNoOfHoursForService(serviceType: serviceType),
            isMasterVehicle: isMasterVehicle,
            extraStops: [], // No extra stops for return journey
            returnExtraStops: returnExtraStopsRequests,
            pickupTime: pickupTime, // Use original pickup time for return journey
            returnPickupTime: "12:00 PM", // Default for return journey
            returnVehicleId: selectedVehicle?.id ?? 1, // Use same vehicle ID for return
            returnAffiliateType: "affiliate"
        )
    }
    
    private func mapTransferTypeToAPI(_ transferType: String) -> String {
        switch transferType {
        case "City to City":
            return "city_to_city"
        case "City to Airport":
            return "city_to_airport"
        case "Airport to City":
            return "airport_to_city"
        case "Airport to Airport":
            return "airport_to_airport"
        case "City to Cruise Port":
            return "city_to_cruise"
        case "Airport to Cruise Port":
            return "airport_to_cruise"
        case "Cruise Port to City":
            return "cruise_to_city"
        case "Cruise Port to Airport":
            return "cruise_to_airport"
        default:
            return "city_to_city"
        }
    }
    
    private func mapReturnTransferTypeToAPI(_ transferType: String) -> String {
        switch transferType {
        case "city_to_city":
            return "city_to_city"
        case "city_to_airport":
            return "airport_to_city"
        case "airport_to_city":
            return "city_to_airport"
        case "airport_to_airport":
            return "airport_to_airport"
        case "city_to_cruise":
            return "cruise_to_city"
        case "airport_to_cruise":
            return "cruise_to_airport"
        case "cruise_to_city":
            return "city_to_cruise"
        case "cruise_to_airport":
            return "airport_to_cruise"
        default:
            return "city_to_city"
        }
    }
    
    private func mapServiceTypeToAPI(_ serviceType: String) -> String {
        switch serviceType {
        case "One Way":
            return "one_way"
        case "Round Trip":
            return "round_trip"
        case "Charter Tour":
            return "charter_tour"
        default:
            return "one_way"
        }
    }
    
    private func calculateDistance() async -> Int {
        // Get pickup and dropoff coordinates based on transfer type
        let pickupCoord = self.getPickupCoordinate() ?? self.getFallbackPickupCoordinate()
        let dropoffCoord = self.getDropoffCoordinate() ?? self.getFallbackDropoffCoordinate()
        
        guard let pickup = pickupCoord, let dropoff = dropoffCoord else {
            print("❌ Missing coordinates, returning default distance")
            return 265400 // Return default distance if coordinates are missing
        }
        
        print("📍 DISTANCE CALCULATION:")
        print("Transfer Type: \(selectedTransferType ?? "Unknown")")
        print("Pickup: \(pickup.latitude), \(pickup.longitude)")
        print("Dropoff: \(dropoff.latitude), \(dropoff.longitude)")
        
        // Calculate distance including extra stops
        return await calculateDistanceWithExtraStops(
            pickup: pickup,
            dropoff: dropoff,
            extraStops: extraStops.filter { $0.isLocationSelected && $0.coordinate != nil }
        )
    }
    
    
    private func calculateDistanceWithExtraStops(
        pickup: LocationCoordinate,
        dropoff: LocationCoordinate,
        extraStops: [ExtraStop]
    ) async -> Int {
        // If no extra stops, calculate direct distance
        if extraStops.isEmpty {
            let pickupCoord = CLLocationCoordinate2D(latitude: pickup.latitude, longitude: pickup.longitude)
            let dropoffCoord = CLLocationCoordinate2D(latitude: dropoff.latitude, longitude: dropoff.longitude)
            let (distance, _) = await vehicleService.calculateDistance(from: pickupCoord, to: dropoffCoord)
            return Int(distance)
        }
        
        let pickupCoord = CLLocationCoordinate2D(latitude: pickup.latitude, longitude: pickup.longitude)
        let dropoffCoord = CLLocationCoordinate2D(latitude: dropoff.latitude, longitude: dropoff.longitude)
        let waypointCoords = extraStops.compactMap { $0.coordinate }
            .map { CLLocationCoordinate2D(latitude: $0.latitude, longitude: $0.longitude) }
        
        let (distance, _) = await vehicleService.calculateDistance(
            from: pickupCoord,
            to: dropoffCoord,
            waypoints: waypointCoords
        )
        
        print("📍 DISTANCE CALCULATION WITH EXTRA STOPS (Google Directions waypoints):")
        print("Pickup: \(pickup.latitude), \(pickup.longitude)")
        print("Extra Stops: \(waypointCoords.count)")
        for (index, stop) in waypointCoords.enumerated() {
            print("Stop \(index + 1): \(stop.latitude), \(stop.longitude)")
        }
        print("Dropoff: \(dropoff.latitude), \(dropoff.longitude)")
        print("Total Distance: \(Int(distance)) meters")
        
        return Int(distance)
    }
    
    private func calculateJourneyTime() async -> Int {
        // Get pickup and dropoff coordinates based on transfer type
        let pickupCoord = self.getPickupCoordinate() ?? self.getFallbackPickupCoordinate()
        let dropoffCoord = self.getDropoffCoordinate() ?? self.getFallbackDropoffCoordinate()
        
        guard let pickup = pickupCoord, let dropoff = dropoffCoord else {
            print("❌ Missing coordinates, returning default journey time")
            return 17022 // Return default time if coordinates are missing (in seconds)
        }
        
        print("⏱️ JOURNEY TIME CALCULATION:")
        print("Transfer Type: \(selectedTransferType ?? "Unknown")")
        print("Pickup: \(pickup.latitude), \(pickup.longitude)")
        print("Dropoff: \(dropoff.latitude), \(dropoff.longitude)")
        
        // Calculate time including extra stops
        return await calculateTimeWithExtraStops(
            pickup: pickup,
            dropoff: dropoff,
            extraStops: extraStops.filter { $0.isLocationSelected && $0.coordinate != nil }
        )
    }
    
    private func calculateTimeWithExtraStops(
        pickup: LocationCoordinate,
        dropoff: LocationCoordinate,
        extraStops: [ExtraStop]
    ) async -> Int {
        // If no extra stops, calculate direct time
        if extraStops.isEmpty {
            let pickupCoord = CLLocationCoordinate2D(latitude: pickup.latitude, longitude: pickup.longitude)
            let dropoffCoord = CLLocationCoordinate2D(latitude: dropoff.latitude, longitude: dropoff.longitude)
            let (_, time) = await vehicleService.calculateDistance(from: pickupCoord, to: dropoffCoord)
            return Int(time)
        }
        
        let pickupCoord = CLLocationCoordinate2D(latitude: pickup.latitude, longitude: pickup.longitude)
        let dropoffCoord = CLLocationCoordinate2D(latitude: dropoff.latitude, longitude: dropoff.longitude)
        let waypointCoords = extraStops.compactMap { $0.coordinate }
            .map { CLLocationCoordinate2D(latitude: $0.latitude, longitude: $0.longitude) }
        
        let (_, time) = await vehicleService.calculateDistance(
            from: pickupCoord,
            to: dropoffCoord,
            waypoints: waypointCoords
        )
        
        print("⏱️ TIME CALCULATION WITH EXTRA STOPS (Google Directions waypoints):")
        print("Pickup: \(pickup.latitude), \(pickup.longitude)")
        print("Extra Stops: \(waypointCoords.count)")
        for (index, stop) in waypointCoords.enumerated() {
            print("Stop \(index + 1): \(stop.latitude), \(stop.longitude)")
        }
        print("Dropoff: \(dropoff.latitude), \(dropoff.longitude)")
        print("Total Time: \(time) seconds")
        return Int(time)
    }
    
    private func calculateReturnDistance() async -> Int {
        // CRITICAL FIX: Only use ACTUAL return coordinates from return address fields - NEVER from outbound fallbacks
        print("🔍 CALCULATING RETURN DISTANCE - choosing exact returned coordinates:")
        
        // STEP 1: Get return coordinates EXACTLY from return fields:
        let pickupCoordinate = self.getReturnPickupCoordinate() 
        let dropoffCoordinate = self.getReturnDropoffCoordinate()
        
        print("✅ ACTUAL Return Pickup FROM return address field: \(pickupCoordinate?.latitude ?? 0), \(pickupCoordinate?.longitude ?? 0)")
        print("✅ ACTUAL Return Dropoff FROM return address field: \(dropoffCoordinate?.latitude ?? 0), \(dropoffCoordinate?.longitude ?? 0)")
        
        // STEP 2: Ensure we DO have real return coordinates - never use outbound fallback
        guard let returnPickup = pickupCoordinate, let returnDropoff = dropoffCoordinate else {
            print("❌ Must have fistness return pickup & dropoff coord to proceed - PROBABLY DEFAULT STORED PROVIDED above")
            print("❌ PROVIDE (returnPickupCoordinate, returnDropoffCoordinate): \"(\(returnPickupAddress)\", \"\(returnDropoffAddress)\") not set!")
            return 265400
        }
        
        print("  FROM returnPickupCoordinate (return address direct): LAT \(returnPickup.latitude), LNG \(returnPickup.longitude)")
        print("  FROM returnDropoffCoordinate (return address direct): LAT \(returnDropoff.latitude), LNG \(returnDropoff.longitude)")
        
        // STEP 3: Never anything fallback, Back stitch the return journey directly
        let distance = await calculateDistanceWithExtraStops(
            pickup: returnPickup,
            dropoff: returnDropoff, 
            extraStops: returnExtraStops.filter { $0.isLocationSelected && $0.coordinate != nil }
        )
        
        print("📍 FINAL RETURN DISTANCE OK: \(distance) meters - based on current return address coordinates")
        return distance
    }
    
    private func calculateReturnJourneyTime() async -> Int {
        // CRITICAL FIX: Use ONLY return journey coordinates via getReturnPickupCoordinate & getReturnDropoffCoordinate
        // NEVER use outbound fallbacks or assumptions
        
        print("⏱️ RETURN JOURNEY TIME CALCULATION - using only return fields")
        
        guard let returnPickup = getReturnPickupCoordinate(),
              let returnDropoff = getReturnDropoffCoordinate() else {
            print("❌ Missing return coordinates for journey time, returning default time")
            return 17022
        }

        print("⏱️ Return Journey - from return components only:") 
        print("  returnPickup (from getReturnPickupCoordinate): \(returnPickup.latitude), \(returnPickup.longitude)")
        print("  returnDropoff (from getReturnDropoffCoordinate): \(returnDropoff.latitude), \(returnDropoff.longitude)")
        
        // Use RETURN extra stops, not outbound extra stops  
        return await calculateTimeWithExtraStops(
            pickup: returnPickup,
            dropoff: returnDropoff, 
            extraStops: returnExtraStops.filter { $0.isLocationSelected && $0.coordinate != nil }
        )
    }
    
    // MARK: - Transfer Type Helper Functions
    private func getReturnTransferType() -> String? {
        guard let transferType = selectedTransferType else { return nil }
        
        // Reverse the transfer type for return trip
        switch transferType {
        case "City to City":
            return "City to City"
        case "City to Airport":
            return "Airport to City"
        case "City to Cruise Port":
            return "Cruise Port to City"
        case "Airport to City":
            return "City to Airport"
        case "Airport to Airport":
            return "Airport to Airport"
        case "Airport to Cruise Port":
            return "Cruise Port to Airport"
        case "Cruise Port to City":
            return "City to Cruise Port"
        case "Cruise Port to Airport":
            return "Airport to Cruise Port"
        default:
            return transferType
        }
    }
    
    // MARK: - Return Trip Field Initialization
    private func initializeReturnTripFields() {
        print("🚨 CRITICAL: initializeReturnTripFields() called - this SWAPS outbound/return data!")
        print("🚨 WARNING: This function should ONLY be called for return trip management!")
        print("🔄 INITIALIZING RETURN TRIP FIELDS:")
        print("  Outbound Transfer Type: \(selectedTransferType ?? "nil")")
        print("  Outbound Pickup Address: '\(pickupAddress)'")
        print("  Outbound Dropoff Address: '\(dropoffAddress)'")
        print("  Outbound Pickup Airport: '\(selectedPickupAirport ?? "none")'")
        print("  Outbound Dropoff Airport: '\(selectedDropoffAirport ?? "none")'")
        print("  Outbound Pickup Airline: '\(selectedPickupAirline ?? "none")'")
        print("  Outbound Dropoff Airline: '\(selectedDropoffAirline ?? "none")'")
        
        // 🚨 CRITICAL FIX: Simple field value copying from outbound to return with SWAP logic
        // Exact rule: Outbound pickup values → Return dropoff fields, Outbound dropoff values → Return pickup fields
        
        print("🔄 FIELD VALUE TRANSFER:")
        print("   OUTBOUND PICKUP VALUES → RETURN DROPOFF FIELDS")
        print("   OUTBOUND DROPOFF VALUES → RETURN PICKUP FIELDS")
        
        // ========== ADDRESS TRANSFER ==========
        // Take outbound pickup ADDRESS get return dropoff ADDRESS field 
        returnDropoffAddress = pickupAddress  // outbound pickup → return dropoff
        // Take outbound dropoff ADDRESS and put to return pickup ADDRESS field  
        returnPickupAddress = dropoffAddress   // outbound dropoff → return pickup
        
        // ========== AIRPORT TRANSFER ==========  
        // Take outbound pickup AIRPORT and put to return dropoff AIRPORT field
        selectedReturnDropoffAirport = selectedPickupAirport   // outbound pickup airport → return dropoff airport
        // Take outbound dropoff AIRPORT and put to return pickup AIRPORT field  
        selectedReturnPickupAirport = selectedDropoffAirport    // outbound dropoff airport → return pickup airport
        
        // ========== AIRLINE TRANSFER ==========
        // Take outbound pickup AIRLINE and put to return dropoff AIRLINE field  
        selectedReturnDropoffAirline = selectedPickupAirline   // outbound pickup airline → return dropoff airline
        // Take outbound dropoff AIRLINE and put to return pickup AIRLINE field  
        selectedReturnPickupAirline = selectedDropoffAirline    // outbound dropoff airline → return pickup airline
        
        // ========== FLIGHT TRANSFER ========== 
        // Take outbound pickup FLIGHT and put to return dropoff FLIGHT field  
        returnDropoffFlightNumber = pickupFlightNumber  // outbound pickup flight → return dropoff flight
        // Take outbound dropoff FLIGHT and put to return pickup FLIGHT field  
        returnPickupFlightNumber = dropoffFlightNumber  // outbound dropoff flight → return pickup flight
        
        // ========== AIRPORT SEARCH TRANSFER ==========
        returnDropoffAirportSearch = pickupAirportSearch   // outbound pickup airport search → return dropoff airport search
        returnPickupAirportSearch = dropoffAirportSearch   // outbound dropoff airport search → return pickup airport search
        
        // ========== COORDINATE TRANSFER ==========
        returnDropoffCoordinate = pickupCoordinate         // outbound pickup coordinate → return dropoff coordinate
        returnPickupCoordinate = dropoffCoordinate         // outbound dropoff coordinate → return pickup coordinate
        returnDropoffAirportCoordinate = pickupAirportCoordinate  
        returnPickupAirportCoordinate = dropoffAirportCoordinate
        returnDropoffCruiseCoordinate = pickupCruiseCoordinate
        returnPickupCruiseCoordinate = dropoffCruiseCoordinate
        
        // CRITICAL FIX: Ensure airport coordinates are set if they're missing
        // If return pickup airport name exists but coordinate is missing, look it up
        if let returnPickupAirportName = selectedReturnPickupAirport, returnPickupAirportCoordinate == nil {
            print("🔍 RETURN PICKUP AIRPORT COORDINATE MISSING - Looking up: \(returnPickupAirportName)")
            if let airport = airportService.airports.first(where: { $0.displayName == returnPickupAirportName }) {
                returnPickupAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                print("✅ FOUND AND SET RETURN PICKUP AIRPORT COORDINATE: \(airport.lat ?? 0), \(airport.long ?? 0)")
            } else {
                print("⚠️ RETURN PICKUP AIRPORT NOT FOUND IN AIRPORTS LIST - May need to fetch airports first")
                // Try to fetch airports if list is empty
                Task {
                    await airportService.fetchAllAirports()
                    if let airport = airportService.airports.first(where: { $0.displayName == returnPickupAirportName }) {
                        await MainActor.run {
                            returnPickupAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                            print("✅ FOUND AND SET RETURN PICKUP AIRPORT COORDINATE (after fetch): \(airport.lat ?? 0), \(airport.long ?? 0)")
                        }
                    }
                }
            }
        }
        
        // If return dropoff airport name exists but coordinate is missing, look it up
        if let returnDropoffAirportName = selectedReturnDropoffAirport, returnDropoffAirportCoordinate == nil {
            print("🔍 RETURN DROPOFF AIRPORT COORDINATE MISSING - Looking up: \(returnDropoffAirportName)")
            if let airport = airportService.airports.first(where: { $0.displayName == returnDropoffAirportName }) {
                returnDropoffAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                print("✅ FOUND AND SET RETURN DROPOFF AIRPORT COORDINATE: \(airport.lat ?? 0), \(airport.long ?? 0)")
            } else {
                print("⚠️ RETURN DROPOFF AIRPORT NOT FOUND IN AIRPORTS LIST - May need to fetch airports first")
                // Try to fetch airports if list is empty
                Task {
                    await airportService.fetchAllAirports()
                    if let airport = airportService.airports.first(where: { $0.displayName == returnDropoffAirportName }) {
                        await MainActor.run {
                            returnDropoffAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                            print("✅ FOUND AND SET RETURN DROPOFF AIRPORT COORDINATE (after fetch): \(airport.lat ?? 0), \(airport.long ?? 0)")
                        }
                    }
                }
            }
        }
        
        // ========== CRUISE INFO TRANSFER ==========  
        returnCruiseShipName = cruiseShipName
        returnCruisePort = cruisePort
        returnShipArrivalTime = shipArrivalTime
        
        // Reset origin airport city
        returnOriginAirportCity = ""
        
        print("🚨 AFTER SWAP - THIS IS WHERE THE PROBLEM OCCURS:")
        print("  Outbound Transfer Type: '\(selectedTransferType ?? "none")'")
        print("  Return Transfer Type: '\(getReversedTransferType() ?? "none")'")
        print("  Return Pickup Address: '\(returnPickupAddress)' (from outbound dropoff)")
        print("  Return Dropoff Address: '\(returnDropoffAddress)' (from outbound pickup)")
        print("  Return Pickup Airport: '\(selectedReturnPickupAirport ?? "none")' (from outbound dropoff)")
        print("  Return Dropoff Airport: '\(selectedReturnDropoffAirport ?? "none")' (from outbound pickup)")
        print("🚨 CRITICAL: This function SWAPS data - should NOT be called during transfer type changes!")
        
        // CRITICAL: Also ensure outbound airport coordinates are available if airports are selected
        // This is important because return fields depend on outbound coordinates
        if let dropoffAirportName = selectedDropoffAirport, dropoffAirportCoordinate == nil {
            print("🔍 OUTBOUND DROPOFF AIRPORT COORDINATE MISSING - Looking up: \(dropoffAirportName)")
            if let airport = airportService.airports.first(where: { $0.displayName == dropoffAirportName }) {
                dropoffAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                // Update return pickup coordinate since it depends on this
                returnPickupAirportCoordinate = dropoffAirportCoordinate
                print("✅ FOUND AND SET OUTBOUND DROPOFF AIRPORT COORDINATE: \(airport.lat ?? 0), \(airport.long ?? 0)")
            }
        }
        
        if let pickupAirportName = selectedPickupAirport, pickupAirportCoordinate == nil {
            print("🔍 OUTBOUND PICKUP AIRPORT COORDINATE MISSING - Looking up: \(pickupAirportName)")
            if let airport = airportService.airports.first(where: { $0.displayName == pickupAirportName }) {
                pickupAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
                // Update return dropoff coordinate since it depends on this
                returnDropoffAirportCoordinate = pickupAirportCoordinate
                print("✅ FOUND AND SET OUTBOUND PICKUP AIRPORT COORDINATE: \(airport.lat ?? 0), \(airport.long ?? 0)")
            }
        }
        
        // Update viewModel inputs and common fields
        updateReturnViewModelInputs()
        updateCommonReturnFields() 
        initializeCommonReturnFields() // Initialize service-level settings
        
        print("🔄 Return trip fields initialized with complete outbound reversal")
        
        // Force UI update to trigger validation
        // Note: SwiftUI Views automatically update when @State properties change
    }
    
    // Helper method for basic field reversal when transfer type is unknown
    private func performBasicFieldReversal() {
        returnPickupAddress = dropoffAddress
        returnDropoffAddress = pickupAddress
        selectedReturnPickupAirport = selectedDropoffAirport
        selectedReturnDropoffAirport = selectedPickupAirport
        selectedReturnPickupAirline = selectedDropoffAirline
        selectedReturnDropoffAirline = selectedPickupAirline
        returnPickupFlightNumber = dropoffFlightNumber
        returnDropoffFlightNumber = pickupFlightNumber
        returnPickupAirportSearch = dropoffAirportSearch
        returnDropoffAirportSearch = pickupAirportSearch
    }
    
    // Helper method to update common return fields that don't depend on transfer type
    private func updateCommonReturnFields() {
        // Copy coordinates based on field reversal
        if returnPickupAddress == dropoffAddress {
            returnPickupCoordinate = dropoffCoordinate
            returnPickupAirportCoordinate = dropoffAirportCoordinate
            returnPickupCruiseCoordinate = dropoffCruiseCoordinate
        }
        if returnDropoffAddress == pickupAddress {
            returnDropoffCoordinate = pickupCoordinate
            returnDropoffAirportCoordinate = pickupAirportCoordinate
            returnDropoffCruiseCoordinate = pickupCruiseCoordinate
        } else {
            returnDropoffCoordinate = dropoffCoordinate
            returnDropoffAirportCoordinate = dropoffAirportCoordinate
            returnDropoffCruiseCoordinate = dropoffCruiseCoordinate
        }
        
        // Default fields for all return types
        returnOriginAirportCity = ""
        returnTravelDate = travelDate
        returnPickupTime = pickupTime
    }
    
    // Helper method to update viewModel inputs for return trip
    private func updateReturnViewModelInputs() {
        returnPickupAddressVM.input = returnPickupAddress
        returnDropoffAddressVM.input = returnDropoffAddress
    }
    
    // Helper method to initialize common return fields that don't depend on transfer type
    private func initializeCommonReturnFields() {
        selectedReturnServiceType = selectedServiceType // Match the main service type for round trips
        selectedReturnTransferType = getReversedTransferType() // REVERSE transfer type for return
        selectedReturnMeetAndGreet = selectedMeetAndGreet // Keep same meet and greet
        selectedReturnHours = selectedHours // Keep same hours
        returnNumberOfVehicles = numberOfVehicles // Keep same number of vehicles
        returnSpecialInstructions = specialInstructions // Pre-fill with outbound special instructions
    }
    
    // Helper method to reverse the transfer type for return trips
    private func getReversedTransferType() -> String? {
        guard let outboundTransferType = selectedTransferType else {
            return "City to City" // Default fallback
        }
        
        print("🔄 REVERSING TRANSFER TYPE:")
        print("  Outbound: '\(outboundTransferType)'")
        
        // Create the exact reverse mapping
        switch outboundTransferType {
        case "City to City":
            return "City to City"  // Same for city-city
            
        case "City to Airport":
            return "Airport to City"  // Reversed!
            
        case "Airport to City":
            return "City to Airport"  // Reversed!
            
        case "Airport to Airport":
            return "Airport to Airport"  // Same
            
        case "City to Cruise Port":
            return "Cruise Port to City"  // Reversed!
            
        case "Cruise Port to City":
            return "City to Cruise Port"  // Reversed!
            
        case "Airport to Cruise Port":
            return "Cruise Port to Airport"  // Reversed!
            
        case "Cruise Port to Airport":
            return "Airport to Cruise Port"  // Reversed!
            
        case "Cruise Port to Cruise Port":
            return "Cruise Port to Cruise Port"  // Same
            
        default:
            print("🔄 Unknown transfer type '\(outboundTransferType)', returning default: City to City")
            return "City to City"
        }
    }
    
    private func getReturnPickupCoordinate() -> LocationCoordinate? {
        // CRITICAL FIX: Prioritize airport coordinates over address coordinates to correctly respond to airport changes
        // Priority: Return pickup airport > Return pickup address > Return pickup cruise
        if let coord = returnPickupAirportCoordinate {
            print("📍 RETURN PICKUP AIRPORT COORD SELECTED: \(coord.latitude), \(coord.longitude)")
            return coord
        } else if let coord = returnPickupCoordinate {
            print("📍 RETURN PICKUP ADDRESS COORD SELECTED: \(coord.latitude), \(coord.longitude)")
            return coord
        } else if let coord = returnPickupCruiseCoordinate {
            print("📍 RETURN PICKUP CRUISE COORD SELECTED: \(coord.latitude), \(coord.longitude)")
            return coord
        }
        print("❌ NO RETURN PICKUP COORDINATE FOUND")
        return nil
    }
    
    private func getReturnDropoffCoordinate() -> LocationCoordinate? {
        // CRITICAL FIX: Prioritize airport coordinates over address coordinates to correctly respond to airport changes
        // Priority: Return dropoff airport > Return dropoff address > Return dropoff cruise
        if let coord = returnDropoffAirportCoordinate {
            print("📍 RETURN DROPOFF AIRPORT COORD SELECTED: \(coord.latitude), \(coord.longitude)")
            return coord
        } else if let coord = returnDropoffCoordinate {
            print("📍 RETURN DROPOFF ADDRESS COORD SELECTED: \(coord.latitude), \(coord.longitude)")
            return coord
        } else if let coord = returnDropoffCruiseCoordinate {
            print("📍 RETURN DROPOFF CRUISE COORD SELECTED: \(coord.latitude), \(coord.longitude)")
            return coord
        }
        print("❌ NO RETURN DROPOFF COORDINATE FOUND")
        return nil
    }
    
    private func getFallbackReturnPickupCoordinate() -> LocationCoordinate? {
        // CRITICAL FIX: Don't fallback to outbound dropoff coordinate - instead, return nil so we know there's a coordinate issue
        // and can debug from signals in calculateReturnDistance()
        print("⚠️ WARNING: No return pickup coordinate found - returning nil to catch coordinate assignment issues")
        return nil
    }
    
    private func getFallbackReturnDropoffCoordinate() -> LocationCoordinate? {
        // CRITICAL FIX: Don't fallback to outbound pickup coordinate - instead, return nil so we know there's a coordinate issue  
        // and can debug from signals in calculateReturnDistance()
        print("⚠️ WARNING: No return dropoff coordinate found - returning nil to catch coordinate assignment issues")
        return nil
    }
    
    private func refreshRates() {
        dismissInvalidLocationBannerIfResolved()
        
        // In edit mode, do not recalc unless we already loaded reservation rates
        // and the user has explicitly changed a pricing input.
        if isEditMode {
            if !hasLoadedExistingRates {
                print("ℹ️ EDIT MODE: Skipping refreshRates() because existing rates not loaded yet")
                return
            }
            if !hasUserModifiedPricingInputs {
                print("ℹ️ EDIT MODE: Skipping refreshRates() because user has not changed pricing inputs")
                return
            }
        }
        
        Task {
            await fetchBookingRates()
        }
    }
    
    private func refreshReturnRates() {
        dismissInvalidLocationBannerIfResolved()
        
        if isEditMode {
            if !hasLoadedExistingRates {
                print("ℹ️ EDIT MODE: Skipping refreshReturnRates() because existing rates not loaded yet")
                return
            }
            if !hasUserModifiedPricingInputs {
                print("ℹ️ EDIT MODE: Skipping refreshReturnRates() because user has not changed pricing inputs")
                return
            }
        }
        
        Task {
            // For return trips, call fetchBookingRates EXACTLY like outbound - ensuring exact same behavior as outbound changes
            print("🔄 REFRESHING RETURN RATES - using identical logic to outbound address/airport changes")
            
            // MANDATORY: Force exact coordinate refresh embedded directly into this flow
            if selectedServiceType == "Round Trip" {
                print("📍 MANDATORY RETURN COORDINATE VERIFICATION")
                // Force entries to re-scan immediately by testing coordinate coordinates
                print("Return Pickup Address: '\(returnPickupAddress)'")
                print("Return Dropoff Address: '\(returnDropoffAddress)'")
                print("Return Pickup Coord Direct Check: \(returnPickupCoordinate?.latitude ?? 0), \(returnPickupCoordinate?.longitude ?? 0)")
                print("Return Dropoff Coord Direct Check: \(returnDropoffCoordinate?.latitude ?? 0), \(returnDropoffCoordinate?.longitude ?? 0)")
                
                // Force coordinate reproduction pre-hitting actual rate call
                let verifiedDistance = await calculateReturnDistance()
                print("📍 MANDATORY Return Distance: \(verifiedDistance) meters")
            }
            
            // BEHAVIOR NOW: Must hit fetchBookingRates, which triggers the main "recalculation" path LIKE OUTBOUND does.
            await fetchBookingRates()
        }
    }
    
    private func dismissInvalidLocationBannerIfResolved() {
        guard showInvalidLocationDialog else { return }
        
        let outboundConflict = outboundLocationConflictReason()
        let returnConflict = returnLocationConflictReason()
        let isRoundTrip = selectedServiceType == "Round Trip" && selectedReturnServiceType == "Round Trip"
        
        if outboundConflict == nil && (!isRoundTrip || returnConflict == nil) {
            invalidLocationDismissWorkItem?.cancel()
            showInvalidLocationDialog = false
        }
    }
    
    private func showInvalidLocationToast(_ message: String) {
        invalidLocationDismissWorkItem?.cancel()
        invalidLocationMessage = message
        
        withAnimation(.easeInOut(duration: 0.2)) {
            showInvalidLocationDialog = true
        }
        
        let workItem = DispatchWorkItem {
            withAnimation(.easeInOut(duration: 0.2)) {
                showInvalidLocationDialog = false
            }
        }
        invalidLocationDismissWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: workItem)
    }
    
    private func updateBookingDetails() {
        guard let rideData = rideData else { 
            print("❌ updateBookingDetails: rideData is nil")
            return 
        }
        
        isPrefillingData = true
        
        print("🕐 ===== UPDATE BOOKING DETAILS CALLED =====")
        print("🕐 updateBookingDetails - rideData.pickupDate: '\(rideData.pickupDate)'")
        print("🕐 updateBookingDetails - rideData.pickupTime: '\(rideData.pickupTime)'")
        print("🕐 updateBookingDetails - rideData.bookingHour: '\(rideData.bookingHour)'")
        print("🕐 updateBookingDetails - rideData.serviceType: '\(rideData.serviceType)'")
        
        // Update service type based on ride data
        switch rideData.serviceType {
        case "one_way":
            selectedServiceType = "One Way"
        case "round_trip":
            selectedServiceType = "Round Trip"
        case "charter_tour", "chartertour":
            selectedServiceType = "Charter Tour"
            // Update selected hours for charter tours
            if !rideData.bookingHour.isEmpty && rideData.bookingHour != "0" {
                let hourValue = rideData.bookingHour
                if hourValue == "2" {
                    selectedHours = "2 hours minimum"
                } else {
                    selectedHours = "\(hourValue) hours"
                }
                print("🕐 Updated selectedHours to: \(selectedHours)")
            }
        default:
            selectedServiceType = "One Way"
        }
        
        // Update transfer type based on pickup and dropoff types
        print("🚢 COMPREHENSIVE BOOKING DEBUG:")
        print("RideData Pickup Type: '\(rideData.pickupType)'")
        print("RideData Dropoff Type: '\(rideData.dropoffType)'")
        
        if rideData.pickupType == "city" && rideData.dropoffType == "city" {
            selectedTransferType = "City to City"
        } else if rideData.pickupType == "airport" && rideData.dropoffType == "city" {
            selectedTransferType = "Airport to City"
        } else if rideData.pickupType == "city" && rideData.dropoffType == "airport" {
            selectedTransferType = "City to Airport"
        } else if rideData.pickupType == "airport" && rideData.dropoffType == "airport" {
            selectedTransferType = "Airport to Airport"
        } else if rideData.pickupType == "city" && rideData.dropoffType == "cruise" {
            selectedTransferType = "City to Cruise Port"
        } else if rideData.pickupType == "cruise" && rideData.dropoffType == "city" {
            selectedTransferType = "Cruise Port to City"
        } else if rideData.pickupType == "airport" && rideData.dropoffType == "cruise" {
            selectedTransferType = "Airport to Cruise Port"
        } else if rideData.pickupType == "cruise" && rideData.dropoffType == "airport" {
            selectedTransferType = "Cruise Port to Airport"
        }
        
        print("Selected Transfer Type: '\(selectedTransferType ?? "nil")'")
        
        // Update pickup address
        pickupAddress = rideData.pickupLocation
        pickupAddressVM.input = rideData.pickupLocation
        
        // Update dropoff address
        dropoffAddress = rideData.destinationLocation
        dropoffAddressVM.input = rideData.destinationLocation
        
        // Update selected airports based on transfer type
        if rideData.pickupType == "airport" {
            selectedPickupAirport = rideData.selectedPickupAirport
            // Initialize origin airport/city for airport transfers
            originAirportCity = "" // This will be filled by user input
        }
        if rideData.dropoffType == "airport" {
            selectedDropoffAirport = rideData.selectedDestinationAirport
        }
        
        // Initialize coordinates from rideData
        if let pickupLat = rideData.pickupLat, let pickupLong = rideData.pickupLong {
            pickupCoordinate = LocationCoordinate(latitude: pickupLat, longitude: pickupLong)
        }
        if let dropoffLat = rideData.destinationLat, let dropoffLong = rideData.destinationLong {
            dropoffCoordinate = LocationCoordinate(latitude: dropoffLat, longitude: dropoffLong)
        }
        
        // Update travel date and time
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if let date = dateFormatter.date(from: rideData.pickupDate) {
            // Check if selectedDate matches the rideData date
            let calendar = Calendar.current
            if !calendar.isDate(selectedDate, inSameDayAs: date) {
                print("⚠️ WARNING: selectedDate (\(selectedDate)) does not match rideData date (\(date))")
                print("⚠️ FIXING: Setting selectedDate to match rideData date")
                selectedDate = date
                print("✅ FIXED: selectedDate now set to: \(selectedDate)")
            } else {
                print("✅ CONFIRMED: selectedDate matches rideData date")
            }
            
            // Update the display string using selectedDate (which has been corrected above)
            dateFormatter.dateFormat = "MMM dd, yyyy"
            travelDate = dateFormatter.string(from: selectedDate)
            print("🕐 updateBookingDetails: Updated travelDate display string to: \(travelDate)")
        }
        
        // Update pickup time
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm:ss"
        if let time = timeFormatter.date(from: rideData.pickupTime) {
            // Check if selectedTime matches the rideData time
            let calendar = Calendar.current
            let selectedComponents = calendar.dateComponents([.hour, .minute], from: selectedTime)
            let rideDataComponents = calendar.dateComponents([.hour, .minute], from: time)
            
            if selectedComponents.hour != rideDataComponents.hour || selectedComponents.minute != rideDataComponents.minute {
                print("⚠️ WARNING: selectedTime (\(selectedTime)) does not match rideData time (\(time))")
                print("⚠️ FIXING: Setting selectedTime to match rideData time")
                
                // Combine the rideData time with the selectedDate to create proper Date
                let dateComponents = calendar.dateComponents([.year, .month, .day], from: selectedDate)
                let timeComponents = calendar.dateComponents([.hour, .minute, .second], from: time)
                
                var combinedComponents = DateComponents()
                combinedComponents.year = dateComponents.year
                combinedComponents.month = dateComponents.month
                combinedComponents.day = dateComponents.day
                combinedComponents.hour = timeComponents.hour
                combinedComponents.minute = timeComponents.minute
                combinedComponents.second = timeComponents.second
                
                if let correctedTime = calendar.date(from: combinedComponents) {
                    selectedTime = correctedTime
                    print("✅ FIXED: selectedTime now set to: \(selectedTime)")
                }
            } else {
                print("✅ CONFIRMED: selectedTime matches rideData time")
            }
            
            // Update the display string using selectedTime (which has been corrected above)
            timeFormatter.dateFormat = "h:mm a"
            pickupTime = timeFormatter.string(from: selectedTime)
            print("🕐 updateBookingDetails: Updated pickupTime display string to: \(pickupTime)")
        }
        
        // Update number of vehicles from rideData
        numberOfVehicles = rideData.noOfVehicles
        
        // Update pricing based on selected vehicle
        if let vehicle = selectedVehicle {
            subtotal = vehicle.getPrice(for: rideData.serviceType) ?? 148.75
            grandTotal = subtotal * Double(numberOfVehicles)
        }
        
        DispatchQueue.main.async {
            self.isPrefillingData = false
        }
    }
    
    private func loadEditData() {
        guard let bookingId = editBookingId else { return }
        
        Task {
            await editReservationService.fetchEditReservation(bookingId: bookingId)
            
            await MainActor.run {
                if let editData = editReservationService.editData {
                    print("🔄 EDIT DATA LOADED - About to prefill data")
                    prefillDataFromEditResponse(editData)
                    print("🔄 EDIT DATA PREFILLED - Checking final values:")
                    print("  pickupFlightNumber: '\(pickupFlightNumber)'")
                    print("  dropoffFlightNumber: '\(dropoffFlightNumber)'")
                    print("  originAirportCity: '\(originAirportCity)'")
                } else {
                    print("❌ EDIT DATA IS NIL - Cannot prefill")
                }
            }
            
            // Fetch booking rates after prefilling data (outside MainActor block)
            await fetchBookingRates()
        }
    }

    private func loadRepeatData() {
        print("🔄 loadRepeatData called with repeatBookingId: \(repeatBookingId?.description ?? "nil")")
        print("🔄 loadRepeatData: isReturnFlow = \(isReturnFlow), isRoundTripFlow = \(isRoundTripFlow)")
        guard let bookingId = repeatBookingId else {
            print("❌ loadRepeatData: repeatBookingId is nil - cannot load data")
            isLoadingRepeatData = false
            return
        }
        
        print("✅ loadRepeatData: Starting to load data for booking ID: \(bookingId), isReturnFlow: \(isReturnFlow), isRoundTripFlow: \(isRoundTripFlow)")
        // Loading state is already set in onAppear before calling this function
        
        Task {
            await airportService.fetchAllAirports()
            await airlineService.fetchAirlines()
            await fetchMeetGreetChoices()
            
            // Call appropriate API based on flow type
            if isRoundTripFlow {
                print("🔄 Calling ROUND TRIP API for booking ID: \(bookingId)")
                await editReservationService.fetchRoundTripReservation(bookingId: bookingId)
            } else if isReturnFlow {
                print("🔄 Calling RETURN API for booking ID: \(bookingId)")
                await editReservationService.fetchReturnReservation(bookingId: bookingId)
            } else {
                print("🔄 Calling REPEAT API for booking ID: \(bookingId)")
                await editReservationService.fetchRepeatReservation(bookingId: bookingId)
            }
            
            await MainActor.run {
                if let repeatData = editReservationService.repeatData {
                    if isRoundTripFlow {
                        print("🔄 ROUND TRIP DATA LOADED - About to prefill data")
                        print("🔄 Round Trip Service Type from API: \(repeatData.serviceType)")
                        print("🔄 Round Trip Return Transfer Type from API: \(repeatData.returnTransferType ?? "nil")")
                    } else if isReturnFlow {
                        print("🔄 RETURN DATA LOADED - About to prefill data")
                    } else {
                        print("🔄 REPEAT DATA LOADED - About to prefill data")
                    }
                    prefillDataFromEditResponse(repeatData)
                } else {
                    print("❌ DATA IS NIL - Cannot prefill")
                }
            }
            
            // Note: Return API already returns swapped data, so we use it as-is without any swapping
            
            await fetchBookingRates()
            
            await MainActor.run {
                self.isLoadingRepeatData = false
            }
        }
    }
    
    private func prefillDataFromEditResponse(_ editData: EditReservationData) {
        print("🔄 PREFILLING DATA FROM EDIT RESPONSE:")
        hasLoadedExistingRates = false
        isPrefillingData = true
        hasUserModifiedPricingInputs = false
        print("  isReturnFlow: \(isReturnFlow)")
        print("  isRoundTripFlow: \(isRoundTripFlow)")
        print("  isRepeatMode: \(isRepeatMode)")
        print("Transfer Type: \(editData.transferType)")
        print("Service Type: \(editData.serviceType)")
        print("Pickup Address: \(editData.pickupAddress ?? "nil")")
        print("Dropoff Address: \(editData.dropoffAddress ?? "nil")")
        print("Vehicle Details:")
        print("  Vehicle Type: \(editData.vehicleType ?? -1)")
        print("  Vehicle ID: \(editData.vehicleId ?? -1)")
        print("  Vehicle Year: \(editData.vehicleYear ?? "nil")")
        print("  Vehicle Make: \(editData.vehicleMake ?? -1)")
        print("  Vehicle Model: \(editData.vehicleModel ?? -1)")
        print("  Vehicle Type Name: \(editData.vehicleTypeName ?? "nil")")
        print("  Vehicle Make Name: \(editData.vehicleMakeName ?? "nil")")
        print("  Vehicle Model Name: \(editData.vehicleModelName ?? "nil")")
        print("  Vehicle Year Name: \(editData.vehicleYearName ?? "nil")")
        print("  Vehicle Color Name: \(editData.vehicleColorName ?? "nil")")
        print("  Vehicle License Plate: \(editData.vehicleLicensePlate ?? "nil")")
        print("  Vehicle Seats: \(editData.vehicleSeats ?? -1)")
        print("Driver Details:")
        print("  Driver Name: \(editData.driverName ?? "nil")")
        print("  Driver Cell: \(editData.driverCell ?? "nil")")
        print("  Driver Email: \(editData.driverEmail ?? "nil")")
        print("Booking Details:")
        print("  Total Passengers: \(editData.totalPassengers)")
        print("  Luggage Count: \(editData.luggageCount)")
        print("  Number of Vehicles: \(editData.numberOfVehicles ?? -1)")
        print("  Booking Instructions: \(editData.bookingInstructions ?? "nil")")
        print("Affiliate Details:")
        print("  Affiliate Type: \(editData.affiliateType ?? "nil")")
        print("  Is Master Vehicle: \(editData.affiliateType == "unassigned" ? "true" : "false")")
        print("Airport Details:")
        print("  Pickup Airport ID: \(editData.pickupAirport ?? "nil")")
        print("  Dropoff Airport ID: \(editData.dropoffAirport ?? "nil")")
        print("  Pickup Airport Latitude: \(editData.pickupAirportLatitude ?? 0)")
        print("  Pickup Airport Longitude: \(editData.pickupAirportLongitude ?? 0)")
        print("  Dropoff Airport Latitude: \(editData.dropoffAirportLatitude ?? 0)")
        print("  Dropoff Airport Longitude: \(editData.dropoffAirportLongitude ?? 0)")
        print("Airline Details:")
        print("  Pickup Airline ID: \(editData.pickupAirline ?? "nil")")
        print("  Dropoff Airline ID: \(editData.dropoffAirline ?? "nil")")
        print("  Pickup Flight: \(editData.pickupFlight ?? "nil")")
        print("  Dropoff Flight: \(editData.dropoffFlight ?? "nil")")
        print("  Origin Airport City: \(editData.originAirportCity ?? "nil")")
        print("Cruise Details:")
        print("  Cruise Name: \(editData.cruiseName ?? "nil")")
        print("  Cruise Port: \(editData.cruisePort ?? "nil")")
        print("  Cruise Time: \(editData.cruiseTime ?? "nil")")
        print("Extra Stops Details:")
        print("  Extra Stops: \(editData.extraStops ?? "nil")")
        print("  Return Extra Stops: \(editData.returnExtraStops ?? "nil")")
        
        // Create VehicleListingItem from edit data
        createVehicleFromEditData(editData)
        
        // Update service type - handle both "roundtrip" and "round_trip"
        let serviceTypeLower = editData.serviceType.lowercased()
        
        // For round trip flow, always set to Round Trip
        if isRoundTripFlow {
            selectedServiceType = "Round Trip"
            selectedReturnServiceType = "Round Trip"
        } else {
            switch serviceTypeLower {
            case "oneway", "one_way":
                selectedServiceType = "One Way"
            case "round_trip", "roundtrip":
                selectedServiceType = "Round Trip"
                selectedReturnServiceType = "Round Trip"
            case "charter_tour", "chartertour":
                selectedServiceType = "Charter Tour"
                // Update selected hours for charter tours from edit data
                if let numberOfHours = editData.numberOfHours, numberOfHours > 0 {
                    if numberOfHours == 2 {
                        selectedHours = "2 hours minimum"
                    } else {
                        selectedHours = "\(numberOfHours) hours"
                    }
                }
            default:
                selectedServiceType = "One Way"
            }
        }
        
        // Update transfer type - use as-is from API (return API already returns swapped data)
        // Handle both underscore and potential variations in API response
        let transferTypeLower = editData.transferType.lowercased()
        switch transferTypeLower {
        case "city_to_city", "citytocity":
            selectedTransferType = "City to City"
        case "city_to_airport", "citytoairport":
            selectedTransferType = "City to Airport"
        case "airport_to_city", "airporttocity":
            selectedTransferType = "Airport to City"
        case "airport_to_airport", "airporttoairport":
            selectedTransferType = "Airport to Airport"
        case "city_to_cruise", "citytocruise", "city_to_cruiseport", "citytocruiseport":
            selectedTransferType = "City to Cruise Port"
        case "airport_to_cruise", "airporttocruise", "airport_to_cruiseport", "airporttocruiseport":
            selectedTransferType = "Airport to Cruise Port"
        case "cruise_to_city", "cruisetocity", "cruiseport_to_city", "cruiseporttocity":
            selectedTransferType = "Cruise Port to City"
        case "cruise_to_airport", "cruisetoairport", "cruiseport_to_airport", "cruiseporttoairport":
            selectedTransferType = "Cruise Port to Airport"
        default:
            print("⚠️ Unknown transfer type from API: '\(editData.transferType)' - will infer from data")
            selectedTransferType = "City to City" // Will be corrected by inference function
        }
        print("🔄 Transfer Type from API: '\(editData.transferType)' -> Mapped to: '\(selectedTransferType ?? "nil")'")
        
        // Update return transfer type for round trips
        if isRoundTripFlow || selectedServiceType == "Round Trip", let returnTransferType = editData.returnTransferType {
            let returnTransferTypeLower = returnTransferType.lowercased()
            switch returnTransferTypeLower {
            case "city_to_city", "citytocity":
                selectedReturnTransferType = "City to City"
            case "city_to_airport", "citytoairport":
                selectedReturnTransferType = "City to Airport"
            case "airport_to_city", "airporttocity":
                selectedReturnTransferType = "Airport to City"
            case "airport_to_airport", "airporttoairport":
                selectedReturnTransferType = "Airport to Airport"
            case "city_to_cruise", "citytocruise", "city_to_cruiseport", "citytocruiseport":
                selectedReturnTransferType = "City to Cruise Port"
            case "airport_to_cruise", "airporttocruise", "airport_to_cruiseport", "airporttocruiseport":
                selectedReturnTransferType = "Airport to Cruise Port"
            case "cruise_to_city", "cruisetocity", "cruiseport_to_city", "cruiseporttocity":
                selectedReturnTransferType = "Cruise Port to City"
            case "cruise_to_airport", "cruisetoairport", "cruiseport_to_airport", "cruiseporttoairport":
                selectedReturnTransferType = "Cruise Port to Airport"
            default:
                print("⚠️ Unknown return transfer type from API: '\(returnTransferType)' - will infer from data")
                selectedReturnTransferType = "City to City" // Will be corrected by inference function
            }
            print("🔄 Return Transfer Type from API: '\(returnTransferType)' -> Mapped to: '\(selectedReturnTransferType ?? "nil")'")
        }
        
        // Update addresses - use as-is from API (return API already returns swapped data)
        pickupAddress = editData.pickupAddress ?? ""
        pickupAddressVM.input = editData.pickupAddress ?? ""
        
        // For round trips, handle case where dropoff is empty but dropoff_address has value
        if editData.serviceType == "roundtrip" || selectedServiceType == "Round Trip" {
            print("🔄 ROUND TRIP: Handling dropoff address pre-fill")
            print("  dropoff: '\(editData.dropoff ?? "nil")'")
            print("  dropoff_address: '\(editData.dropoffAddress ?? "nil")'")
            print("  dropoff_airport: '\(editData.dropoffAirport ?? "nil")'")
            
            if let dropoffAddr = editData.dropoffAddress, !dropoffAddr.isEmpty {
                dropoffAddress = dropoffAddr
                dropoffAddressVM.input = dropoffAddr
                print("  ✅ Using dropoff_address: '\(dropoffAddr)'")
            } else if let dropoff = editData.dropoff, !dropoff.isEmpty {
                dropoffAddress = dropoff
                dropoffAddressVM.input = dropoff
                print("  ✅ Using dropoff: '\(dropoff)'")
            } else {
                dropoffAddress = ""
                dropoffAddressVM.input = ""
                print("  ⚠️ Both dropoff and dropoff_address are empty")
            }
        } else {
            dropoffAddress = editData.dropoffAddress ?? ""
            dropoffAddressVM.input = editData.dropoffAddress ?? ""
        }
        
        // Update return trip addresses
        // For round trips, handle case where return_pickup_address is empty but return_pickup_airport has value
        if editData.serviceType == "roundtrip" || selectedServiceType == "Round Trip" {
            print("🔄 ROUND TRIP: Handling return pickup address pre-fill")
            print("  return_pickup: '\(editData.returnPickup ?? "nil")'")
            print("  return_pickup_address: '\(editData.returnPickupAddress ?? "nil")'")
            print("  return_pickup_airport: '\(editData.returnPickupAirport ?? "nil")'")
            
            if let returnPickupAddr = editData.returnPickupAddress, !returnPickupAddr.isEmpty {
                returnPickupAddress = returnPickupAddr
                returnPickupAddressVM.input = returnPickupAddr
                print("  ✅ Using return_pickup_address: '\(returnPickupAddr)'")
            } else if let returnPickup = editData.returnPickup, !returnPickup.isEmpty {
                returnPickupAddress = returnPickup
                returnPickupAddressVM.input = returnPickup
                print("  ✅ Using return_pickup: '\(returnPickup)'")
            } else {
                // If return_pickup_address is empty but return_pickup_airport has value, 
                // we'll handle this in updateAirportsFromEditDataDirectly
                returnPickupAddress = ""
                returnPickupAddressVM.input = ""
                print("  ⚠️ Both return_pickup and return_pickup_address are empty - will try to set from airport")
            }
        } else {
            returnPickupAddress = editData.returnPickupAddress ?? ""
            returnPickupAddressVM.input = editData.returnPickupAddress ?? ""
        }
        
        returnDropoffAddress = editData.returnDropoffAddress ?? ""
        returnDropoffAddressVM.input = editData.returnDropoffAddress ?? ""
        
        // Update coordinates - use as-is from API (return API already returns swapped data)
        if let lat = editData.pickupLatitude, let lng = editData.pickupLongitude {
            pickupCoordinate = LocationCoordinate(latitude: lat, longitude: lng)
        }
        
        // Handle dropoff coordinates - if they're 0.0, it might be an airport, so check airport coordinates
        if let lat = editData.dropoffLatitude, let lng = editData.dropoffLongitude, lat != 0.0 || lng != 0.0 {
            dropoffCoordinate = LocationCoordinate(latitude: lat, longitude: lng)
        } else if let airportLat = editData.dropoffAirportLatitude, let airportLng = editData.dropoffAirportLongitude {
            // If dropoff coordinates are 0.0, use airport coordinates instead
            dropoffCoordinate = LocationCoordinate(latitude: airportLat, longitude: airportLng)
            print("🔄 Using dropoff airport coordinates (\(airportLat), \(airportLng)) instead of 0.0 coordinates")
        }
        
        // Update airport coordinates - use as-is from API
        if let lat = editData.pickupAirportLatitude, let lng = editData.pickupAirportLongitude {
            pickupAirportCoordinate = LocationCoordinate(latitude: lat, longitude: lng)
        }
        
        if let lat = editData.dropoffAirportLatitude, let lng = editData.dropoffAirportLongitude {
            dropoffAirportCoordinate = LocationCoordinate(latitude: lat, longitude: lng)
        }
        
        // Update return pickup airport coordinates
        if let lat = editData.returnPickupAirportLatitude, let lng = editData.returnPickupAirportLongitude {
            returnPickupAirportCoordinate = LocationCoordinate(latitude: lat, longitude: lng)
        }
        
        // Update return dropoff airport coordinates
        if let lat = editData.returnDropoffAirportLatitude, let lng = editData.returnDropoffAirportLongitude {
            returnDropoffAirportCoordinate = LocationCoordinate(latitude: lat, longitude: lng)
        }
        
        // Update return trip coordinates
        // Handle return pickup coordinates - if they're 0.0, it might be an airport, so check airport coordinates
        if let lat = editData.returnPickupLatitude, let lng = editData.returnPickupLongitude, lat != 0.0 || lng != 0.0 {
            returnPickupCoordinate = LocationCoordinate(latitude: lat, longitude: lng)
        } else if let airportLat = editData.returnPickupAirportLatitude, let airportLng = editData.returnPickupAirportLongitude {
            // If return pickup coordinates are 0.0, use airport coordinates instead
            returnPickupCoordinate = LocationCoordinate(latitude: airportLat, longitude: airportLng)
            print("🔄 Using return pickup airport coordinates (\(airportLat), \(airportLng)) instead of 0.0 coordinates")
        }
        
        if let lat = editData.returnDropoffLatitude, let lng = editData.returnDropoffLongitude {
            returnDropoffCoordinate = LocationCoordinate(latitude: lat, longitude: lng)
        }
        
        // Update travel date and time
        print("🕐 EDIT MODE: Setting date/time from editData")
        print("🕐 EDIT MODE: editData.pickupDate = '\(editData.pickupDate)'")
        print("🕐 EDIT MODE: editData.pickupTime = '\(editData.pickupTime)'")
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if let date = dateFormatter.date(from: editData.pickupDate) {
            // Set the Date object for picker
            selectedDate = date
            // Set the string display
            dateFormatter.dateFormat = "MMM dd, yyyy"
            travelDate = dateFormatter.string(from: date)
            print("🕐 EDIT MODE: ✅ selectedDate set to: \(date)")
        } else {
            print("❌ EDIT MODE: Failed to parse editData.pickupDate '\(editData.pickupDate)'")
        }
        
        // Update pickup time
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "h:mm a"
        pickupTime = editData.pickupTime
        // Parse and set the Date object for picker
        if let time = timeFormatter.date(from: editData.pickupTime) {
            selectedTime = time
            print("🕐 EDIT MODE: ✅ selectedTime set to: \(time)")
        } else {
            print("❌ EDIT MODE: Failed to parse editData.pickupTime '\(editData.pickupTime)' with format 'h:mm a'")
        }
        
        // Update return trip date and time
        if let returnDate = editData.returnPickupDate, !returnDate.isEmpty {
            let returnDateFormatter = DateFormatter()
            returnDateFormatter.dateFormat = "yyyy-MM-dd"
            if let returnDateObj = returnDateFormatter.date(from: returnDate) {
                // Set the Date object for picker
                selectedReturnDate = returnDateObj
                // Set the string display
                returnDateFormatter.dateFormat = "MMM dd, yyyy"
                returnTravelDate = returnDateFormatter.string(from: returnDateObj)
                print("🕐 Initialized selectedReturnDate from editData: \(returnDateObj)")
            }
        }
        
        if let returnTime = editData.returnPickupTime, !returnTime.isEmpty {
            returnPickupTime = returnTime
            // Parse and set the Date object for picker
            let returnTimeFormatter = DateFormatter()
            returnTimeFormatter.dateFormat = "h:mm a"
            if let returnTimeObj = returnTimeFormatter.date(from: returnTime) {
                selectedReturnTime = returnTimeObj
                print("🕐 Initialized selectedReturnTime from editData: \(returnTimeObj)")
            }
        }
        
        // Update passenger count
        // This will be handled by the UI components
        
        // Update special instructions
        specialInstructions = editData.bookingInstructions ?? ""
        
        // Update flight numbers - use as-is from API (return API already returns swapped data)
        pickupFlightNumber = editData.pickupFlight ?? ""
        dropoffFlightNumber = editData.dropoffFlight ?? ""
        
        // Update return trip flight fields
        returnPickupFlightNumber = editData.returnPickupFlight ?? ""
        returnDropoffFlightNumber = editData.returnDropoffFlight ?? ""
        
        // Update origin airport city first
        originAirportCity = editData.originAirportCity ?? ""
        
        // Update return origin airport city with fallback logic
        // If return_origin_airport_city is null, use departing_airport_city
        if let returnOriginCity = editData.returnOriginAirportCity, !returnOriginCity.isEmpty {
            returnOriginAirportCity = returnOriginCity
        } else if let departingCity = editData.departingAirportCity, !departingCity.isEmpty {
            returnOriginAirportCity = departingCity
        } else {
            returnOriginAirportCity = ""
        }
        
        // If return_origin_airport_city is null, prefill origin_airport_city with departing_airport_city
        if (editData.returnOriginAirportCity == nil || editData.returnOriginAirportCity?.isEmpty == true) {
            if let departingCity = editData.departingAirportCity, !departingCity.isEmpty {
                originAirportCity = departingCity
            }
        }
        
        print("🔄 SETTING FLIGHT FIELDS:")
        print("  pickupFlightNumber: '\(pickupFlightNumber)'")
        print("  dropoffFlightNumber: '\(dropoffFlightNumber)'")
        print("  originAirportCity: '\(originAirportCity)'")
        print("  returnPickupFlightNumber: '\(returnPickupFlightNumber)'")
        print("  returnDropoffFlightNumber: '\(returnDropoffFlightNumber)'")
        print("  returnOriginAirportCity: '\(returnOriginAirportCity)' (fallback from departing_airport_city: '\(editData.departingAirportCity ?? "nil")')")
        print("  originAirportCity: '\(originAirportCity)' (prefilled with departing_airport_city when return_origin_airport_city is null)")
        
        // Update cruise details
        cruiseShipName = editData.cruiseName ?? ""
        shipArrivalTime = editData.cruiseTime ?? ""
        cruisePort = editData.cruisePort ?? ""
        // Parse and set the Date object for cruise time picker
        if let cruiseTime = editData.cruiseTime, !cruiseTime.isEmpty {
            let cruiseTimeFormatter = DateFormatter()
            cruiseTimeFormatter.dateFormat = "h:mm a"
            if let cruiseTimeObj = cruiseTimeFormatter.date(from: cruiseTime) {
                selectedCruiseTime = cruiseTimeObj
                print("🕐 Initialized selectedCruiseTime from editData: \(cruiseTimeObj)")
            }
        }
        
        // Update return cruise details
        returnCruiseShipName = editData.returnCruiseName ?? ""
        returnShipArrivalTime = editData.returnCruiseTime ?? ""
        returnCruisePort = editData.returnCruisePort ?? ""
        // Parse and set the Date object for return cruise time picker
        if let returnCruiseTime = editData.returnCruiseTime, !returnCruiseTime.isEmpty {
            let returnCruiseTimeFormatter = DateFormatter()
            returnCruiseTimeFormatter.dateFormat = "h:mm a"
            if let returnCruiseTimeObj = returnCruiseTimeFormatter.date(from: returnCruiseTime) {
                selectedReturnCruiseTime = returnCruiseTimeObj
                print("🕐 Initialized selectedReturnCruiseTime from editData: \(returnCruiseTimeObj)")
            }
        }
        
        // Update meet and greet
        selectedMeetAndGreet = editData.meetGreetChoiceName ?? ""
        
        // Update return meet and greet for round trips
        if isRoundTripFlow || selectedServiceType == "Round Trip", let returnMeetGreetId = editData.returnMeetGreetChoices {
            // Find meet and greet choice by ID
            if let meetGreet = meetGreetChoices.first(where: { $0.id == returnMeetGreetId }) {
                selectedReturnMeetAndGreet = meetGreet.message
                print("✅ Return Meet and Greet Set: \(meetGreet.message)")
            } else {
                // If not found in loaded choices, try fetching and setting later
                print("⚠️ Return Meet and Greet ID \(returnMeetGreetId) not found in loaded choices")
            }
        }
        
        // CRITICAL FIX: Update airports from editData FIRST (before transfer type inference)
        // This ensures airports are available for transfer type inference
        // We need to check editData for airports regardless of current transfer type
        updateAirportsFromEditDataDirectly(editData)
        
        // Update airport selections based on transfer type (this will use the airports we just set)
        updateAirportSelectionsFromEditData(editData)
        
        // Update airline selections
        updateAirlineSelectionsFromEditData(editData)
        
        // Update cruise selections if applicable
        updateCruiseSelectionsFromEditData(editData)
        
        // Update number of vehicles
        numberOfVehicles = editData.numberOfVehicles ?? 1
        
        // Pre-fill extra stops if they exist
        prefillExtraStopsFromEditData(editData)
        
        restoreMissingCoordinatesAfterPrefill()
        
        // CRITICAL FIX: Infer and correct transfer type based on actual data (cruise ports, airports, addresses)
        // This ensures transfer type is correctly set even if API returns incorrect/missing transfer type
        inferAndCorrectTransferTypeFromData(editData: editData)
        
        // Load initial data after prefilling
        loadInitialData()
        
        DispatchQueue.main.async {
            self.isPrefillingData = false
        }
    }
    
    private func prefillExtraStopsFromEditData(_ editData: EditReservationData) {
        print("🔄 PREFILLING EXTRA STOPS FROM EDIT DATA:")
        print("Extra Stops: \(editData.extraStops ?? "nil")")
        print("Return Extra Stops: \(editData.returnExtraStops ?? "nil")")
        
        // Clear existing extra stops
        extraStops.removeAll()
        
        // Parse extra stops from edit data
        if let extraStopsString = editData.extraStops, !extraStopsString.isEmpty {
            // Try to parse as JSON array first (new format)
            if let extraStopsData = extraStopsString.data(using: .utf8),
               let extraStopsArray = try? JSONSerialization.jsonObject(with: extraStopsData) as? [[String: Any]] {
                
                print("  Parsing extra stops as JSON array with \(extraStopsArray.count) stops")
                
                for stopData in extraStopsArray {
                    if let address = stopData["address"] as? String, !address.isEmpty {
                        let newStop = ExtraStop()
                        newStop.address = address
                        newStop.addressVM.input = address
                        newStop.isLocationSelected = true
                        
                        // Set coordinates if available (string, number, or NSNumber)
                        if let coordinate = extractCoordinate(from: stopData) {
                            newStop.coordinate = coordinate
                            print("  Added extra stop with coordinates: \(address) (\(coordinate.latitude), \(coordinate.longitude))")
                        } else {
                            print("  Added extra stop: \(address)")
                        }
                        
                        extraStops.append(newStop)
                    }
                }
            } else {
                // Fallback to comma-separated string parsing (old format)
                print("  Parsing extra stops as comma-separated string")
                let stopAddresses = extraStopsString.components(separatedBy: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                
                for address in stopAddresses {
                    if !address.isEmpty {
                        let newStop = ExtraStop()
                        newStop.address = address
                        newStop.addressVM.input = address
                        newStop.isLocationSelected = true
                        extraStops.append(newStop)
                        print("  Added extra stop: \(address)")
                    }
                }
            }
        }
        
        // For round trips, also handle return extra stops
        if selectedServiceType == "Round Trip", let returnExtraStopsString = editData.returnExtraStops, !returnExtraStopsString.isEmpty {
            // Try to parse as JSON array first (new format)
            if let returnExtraStopsData = returnExtraStopsString.data(using: .utf8),
               let returnExtraStopsArray = try? JSONSerialization.jsonObject(with: returnExtraStopsData) as? [[String: Any]] {
                
                print("  Parsing return extra stops as JSON array with \(returnExtraStopsArray.count) stops")
                
                for stopData in returnExtraStopsArray {
                    if let address = stopData["address"] as? String, !address.isEmpty {
                        let newStop = ExtraStop()
                        newStop.address = address
                        newStop.addressVM.input = address
                        newStop.isLocationSelected = true
                        
                        // Set coordinates if available (string, number, or NSNumber)
                        if let coordinate = extractCoordinate(from: stopData) {
                            newStop.coordinate = coordinate
                            print("  Added return extra stop with coordinates: \(address) (\(coordinate.latitude), \(coordinate.longitude))")
                        } else {
                            print("  Added return extra stop: \(address)")
                        }
                        
                        // CRITICAL FIX: Add to returnExtraStops array, not extraStops
                        returnExtraStops.append(newStop)
                    }
                }
            } else {
                // Fallback to comma-separated string parsing (old format)
                print("  Parsing return extra stops as comma-separated string")
                let returnStopAddresses = returnExtraStopsString.components(separatedBy: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                
                for address in returnStopAddresses {
                    if !address.isEmpty {
                        let newStop = ExtraStop()
                        newStop.address = address
                        newStop.addressVM.input = address
                        newStop.isLocationSelected = true
                        // CRITICAL FIX: Add to returnExtraStops array, not extraStops
                        returnExtraStops.append(newStop)
                        print("  Added return extra stop: \(address)")
                    }
                }
            }
        }
        
        print("  Total outbound extra stops prefilled: \(extraStops.count)")
        print("  Total return extra stops prefilled: \(returnExtraStops.count)")
    }

    private func extractCoordinate(from stopData: [String: Any]) -> LocationCoordinate? {
        guard
            let latitude = parseCoordinateValue(stopData["latitude"] ?? stopData["lat"]),
            let longitude = parseCoordinateValue(stopData["longitude"] ?? stopData["lng"] ?? stopData["lon"])
        else {
            return nil
        }
        return LocationCoordinate(latitude: latitude, longitude: longitude)
    }

    private func parseCoordinateValue(_ rawValue: Any?) -> Double? {
        switch rawValue {
        case let string as String:
            return Double(string.trimmingCharacters(in: .whitespacesAndNewlines))
        case let number as NSNumber:
            return number.doubleValue
        case let double as Double:
            return double
        case let int as Int:
            return Double(int)
        default:
            return nil
        }
    }

    private func prepareReturnFlow() {
        print("🔄 PREPARING RETURN FLOW FROM REPEAT MODE")
        
        let originalPickupAddress = pickupAddress
        let originalPickupCoordinate = pickupCoordinate
        let originalPickupAirportCoordinate = pickupAirportCoordinate
        let originalPickupCruiseCoordinate = pickupCruiseCoordinate
        let originalPickupAirport = selectedPickupAirport
        let originalPickupAirline = selectedPickupAirline
        let originalPickupFlight = pickupFlightNumber
        let originalPickupAirportSearch = pickupAirportSearch
        
        let originalDropoffAddress = dropoffAddress
        let originalDropoffCoordinate = dropoffCoordinate
        let originalDropoffAirportCoordinate = dropoffAirportCoordinate
        let originalDropoffCruiseCoordinate = dropoffCruiseCoordinate
        let originalDropoffAirport = selectedDropoffAirport
        let originalDropoffAirline = selectedDropoffAirline
        let originalDropoffFlight = dropoffFlightNumber
        let originalDropoffAirportSearch = dropoffAirportSearch
        
        let reversedTransfer = getReversedTransferType() ?? "City to City"
        
        pickupAddress = originalDropoffAddress
        pickupCoordinate = originalDropoffCoordinate
        pickupAirportCoordinate = originalDropoffAirportCoordinate
        pickupCruiseCoordinate = originalDropoffCruiseCoordinate
        selectedPickupAirport = originalDropoffAirport
        selectedPickupAirline = originalDropoffAirline
        pickupFlightNumber = originalDropoffFlight
        pickupAirportSearch = originalDropoffAirportSearch
        
        dropoffAddress = originalPickupAddress
        dropoffCoordinate = originalPickupCoordinate
        dropoffAirportCoordinate = originalPickupAirportCoordinate
        dropoffCruiseCoordinate = originalPickupCruiseCoordinate
        selectedDropoffAirport = originalPickupAirport
        selectedDropoffAirline = originalPickupAirline
        dropoffFlightNumber = originalPickupFlight
        dropoffAirportSearch = originalPickupAirportSearch
        originAirportCity = returnOriginAirportCity.isEmpty ? originAirportCity : returnOriginAirportCity
        
        pickupAddressVM.input = pickupAddress
        dropoffAddressVM.input = dropoffAddress
        
        selectedTransferType = reversedTransfer
        selectedReturnTransferType = reversedTransfer
        selectedServiceType = "One Way"
        selectedReturnServiceType = "One Way"
        selectedReturnMeetAndGreet = selectedMeetAndGreet
        selectedReturnHours = selectedHours
        returnNumberOfVehicles = numberOfVehicles
        
        selectedReturnPickupAirport = nil
        selectedReturnDropoffAirport = nil
        selectedReturnPickupAirline = nil
        selectedReturnDropoffAirline = nil
        returnPickupFlightNumber = ""
        returnDropoffFlightNumber = ""
        returnOriginAirportCity = ""
        returnPickupAddress = ""
        returnDropoffAddress = ""
        returnPickupCoordinate = nil
        returnDropoffCoordinate = nil
        returnPickupAirportCoordinate = nil
        returnDropoffAirportCoordinate = nil
        returnPickupCruiseCoordinate = nil
        returnDropoffCruiseCoordinate = nil
        returnCruisePort = ""
        returnCruiseShipName = ""
        returnShipArrivalTime = ""
        returnPickupAirportSearch = ""
        returnDropoffAirportSearch = ""
        returnExtraStops.removeAll()
        
        print("✅ RETURN FLOW PREPARED WITH REVERSED ADDRESSES AND TRANSFER TYPE: \(reversedTransfer)")
    }
    
    private func createVehicleFromEditData(_ editData: EditReservationData) {
        // Create VehicleDetails from edit data
        let vehicleDetails = VehicleDetails(
            make: editData.vehicleMakeName ?? "Unknown",
            model: editData.vehicleModelName ?? "Unknown",
            year: editData.vehicleYearName ?? "Unknown"
        )
        
        // Create DriverInformation from edit data
        let driverInfo = DriverInformation(
            insuranceLimit: "1M", // Default value
            id: editData.driverId,
            name: editData.driverName ?? "Driver",
            gender: editData.driverGender ?? "Male",
            email: editData.driverEmail,
            phone: editData.driverCell ?? "",
            cellIsd: "+1", // Default value
            cellNumber: editData.driverCell ?? "",
            starRating: "4.5", // Default value
            background: "Background Checked", // Default value
            dress: "Business Casual", // Default value
            languages: "English", // Default value
            experience: "5+ Years", // Default value
            imageUrl: editData.driverImage ?? ""
        )
        
        // Create VehicleListingItem from edit data
        let vehicle = VehicleListingItem(
            id: editData.vehicleId ?? 0,
            affiliateId: editData.affiliateId,
            badgeCity: nil,
            affiliateType: editData.affiliateType,
            affiliateCompany: nil,
            affiliatePhone: nil,
            affiliateName: nil,
            name: editData.vehicleTypeName ?? "Vehicle",
            vehicleTypeId: editData.vehicleType,
            passenger: editData.vehicleSeats ?? 4,
            luggage: editData.luggageCount,
            latitude: nil,
            longitude: nil,
            distance: nil,
            createdBy: nil,
            numberOfVehicles: editData.numberOfVehicles,
            cancellationPolicy: nil,
            isMasterVehicle: editData.affiliateType == "unassigned",
            driverInformation: driverInfo,
            amenities: nil,
            vehicleImages: editData.vehicleImages ?? [],
            vehicleDetails: vehicleDetails,
            rateBreakdownOneWay: nil,
            rateBreakdownRoundTrip: nil,
            rateBreakdownCharterTour: nil
        )
        
        // Update the selectedVehicle state
        selectedVehicle = vehicle
        
        print("✅ Created VehicleListingItem from edit data:")
        print("  Vehicle Name: \(vehicle.name)")
        print("  Vehicle Details: \(vehicle.vehicleDetails?.make ?? "N/A") \(vehicle.vehicleDetails?.model ?? "N/A") \(vehicle.vehicleDetails?.year ?? "N/A")")
        print("  Driver Name: \(vehicle.driverInformation?.name ?? "N/A")")
        print("  Driver Phone: \(vehicle.driverInformation?.cellNumber ?? "N/A")")
        print("  Affiliate Type: \(vehicle.affiliateType ?? "N/A")")
        print("  Is Master Vehicle: \(vehicle.isMasterVehicle ?? false)")
    }
    
    /// Updates airports directly from editData regardless of transfer type
    /// This ensures airports are available for transfer type inference
    private func updateAirportsFromEditDataDirectly(_ editData: EditReservationData) {
        print("🔄 UPDATING AIRPORTS DIRECTLY FROM EDIT DATA (for inference):")
        print("  pickup_airport: \(editData.pickupAirport ?? "nil"), dropoff_airport: \(editData.dropoffAirport ?? "nil")")
        
        // Try synchronous update first (if airports are already loaded)
        // Update pickup airport if available in editData
        if let pickupAirportId = editData.pickupAirport, !pickupAirportId.isEmpty {
            if let airport = airportService.airports.first(where: { $0.id == Int(pickupAirportId) }) {
                selectedPickupAirport = airport.displayName
                // Use coordinates from API if available
                if let apiLat = editData.pickupAirportLatitude, let apiLng = editData.pickupAirportLongitude {
                    pickupAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                } else {
                    pickupAirportCoordinate = LocationCoordinate(
                        latitude: airport.lat ?? 0,
                        longitude: airport.long ?? 0
                    )
                }
                print("✅ Pickup Airport Set Directly (sync): \(airport.displayName) (ID: \(pickupAirportId))")
            } else {
                // If not found, fetch asynchronously
                Task {
                    await airportService.fetchAllAirports()
                    await MainActor.run {
                        if let airport = airportService.airports.first(where: { $0.id == Int(pickupAirportId) }) {
                            selectedPickupAirport = airport.displayName
                            if let apiLat = editData.pickupAirportLatitude, let apiLng = editData.pickupAirportLongitude {
                                pickupAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                            } else {
                                pickupAirportCoordinate = LocationCoordinate(
                                    latitude: airport.lat ?? 0,
                                    longitude: airport.long ?? 0
                                )
                            }
                            print("✅ Pickup Airport Set Directly (async): \(airport.displayName) (ID: \(pickupAirportId))")
                        }
                    }
                }
            }
        }
        
        // Update dropoff airport if available in editData
        if let dropoffAirportId = editData.dropoffAirport, !dropoffAirportId.isEmpty {
            if let airport = airportService.airports.first(where: { $0.id == Int(dropoffAirportId) }) {
                selectedDropoffAirport = airport.displayName
                // Use coordinates from API if available
                if let apiLat = editData.dropoffAirportLatitude, let apiLng = editData.dropoffAirportLongitude {
                    dropoffAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                } else {
                    dropoffAirportCoordinate = LocationCoordinate(
                        latitude: airport.lat ?? 0,
                        longitude: airport.long ?? 0
                    )
                }
                print("✅ Dropoff Airport Set Directly (sync): \(airport.displayName) (ID: \(dropoffAirportId))")
            } else {
                // If not found, fetch asynchronously
                Task {
                    await airportService.fetchAllAirports()
                    await MainActor.run {
                        if let airport = airportService.airports.first(where: { $0.id == Int(dropoffAirportId) }) {
                            selectedDropoffAirport = airport.displayName
                            if let apiLat = editData.dropoffAirportLatitude, let apiLng = editData.dropoffAirportLongitude {
                                dropoffAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                            } else {
                                dropoffAirportCoordinate = LocationCoordinate(
                                    latitude: airport.lat ?? 0,
                                    longitude: airport.long ?? 0
                                )
                            }
                            print("✅ Dropoff Airport Set Directly (async): \(airport.displayName) (ID: \(dropoffAirportId))")
                        }
                    }
                }
            }
        }
        
        // Update return airports for round trips
        if isRoundTripFlow || selectedServiceType == "Round Trip" {
            if let returnPickupAirportId = editData.returnPickupAirport, !returnPickupAirportId.isEmpty {
                if let airport = airportService.airports.first(where: { $0.id == Int(returnPickupAirportId) }) {
                    selectedReturnPickupAirport = airport.displayName
                    // Use coordinates from API if available, otherwise use airport service coordinates
                    if let apiLat = editData.returnPickupAirportLatitude, let apiLng = editData.returnPickupAirportLongitude {
                        returnPickupAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                        print("✅ Return Pickup Airport Set Directly (sync): \(airport.displayName) (ID: \(returnPickupAirportId)) with API coordinates (\(apiLat), \(apiLng))")
                    } else {
                        returnPickupAirportCoordinate = LocationCoordinate(
                            latitude: airport.lat ?? 0,
                            longitude: airport.long ?? 0
                        )
                        print("✅ Return Pickup Airport Set Directly (sync): \(airport.displayName) (ID: \(returnPickupAirportId)) with service coordinates")
                    }
                    // If return_pickup_address is empty, set it from airport name
                    if returnPickupAddress.isEmpty {
                        returnPickupAddress = airport.displayName
                        returnPickupAddressVM.input = airport.displayName
                        print("✅ Return Pickup Address set from airport: \(airport.displayName)")
                    }
                } else {
                    Task {
                        await airportService.fetchAllAirports()
                        await MainActor.run {
                            if let airport = airportService.airports.first(where: { $0.id == Int(returnPickupAirportId) }) {
                                selectedReturnPickupAirport = airport.displayName
                                // Use coordinates from API if available
                                if let apiLat = editData.returnPickupAirportLatitude, let apiLng = editData.returnPickupAirportLongitude {
                                    returnPickupAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                                } else {
                                    returnPickupAirportCoordinate = LocationCoordinate(
                                        latitude: airport.lat ?? 0,
                                        longitude: airport.long ?? 0
                                    )
                                }
                                // If return_pickup_address is empty, set it from airport name
                                if returnPickupAddress.isEmpty {
                                    returnPickupAddress = airport.displayName
                                    returnPickupAddressVM.input = airport.displayName
                                }
                                print("✅ Return Pickup Airport Set Directly (async): \(airport.displayName) (ID: \(returnPickupAirportId))")
                            }
                        }
                    }
                }
            }
            
            if let returnDropoffAirportId = editData.returnDropoffAirport, !returnDropoffAirportId.isEmpty {
                if let airport = airportService.airports.first(where: { $0.id == Int(returnDropoffAirportId) }) {
                    selectedReturnDropoffAirport = airport.displayName
                    // Use coordinates from API if available, otherwise use airport service coordinates
                    if let apiLat = editData.returnDropoffAirportLatitude, let apiLng = editData.returnDropoffAirportLongitude {
                        returnDropoffAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                        print("✅ Return Dropoff Airport Set Directly (sync): \(airport.displayName) (ID: \(returnDropoffAirportId)) with API coordinates (\(apiLat), \(apiLng))")
                    } else {
                        returnDropoffAirportCoordinate = LocationCoordinate(
                            latitude: airport.lat ?? 0,
                            longitude: airport.long ?? 0
                        )
                        print("✅ Return Dropoff Airport Set Directly (sync): \(airport.displayName) (ID: \(returnDropoffAirportId)) with service coordinates")
                    }
                } else {
                    Task {
                        await airportService.fetchAllAirports()
                        await MainActor.run {
                            if let airport = airportService.airports.first(where: { $0.id == Int(returnDropoffAirportId) }) {
                                selectedReturnDropoffAirport = airport.displayName
                                // Use coordinates from API if available
                                if let apiLat = editData.returnDropoffAirportLatitude, let apiLng = editData.returnDropoffAirportLongitude {
                                    returnDropoffAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                                } else {
                                    returnDropoffAirportCoordinate = LocationCoordinate(
                                        latitude: airport.lat ?? 0,
                                        longitude: airport.long ?? 0
                                    )
                                }
                                print("✅ Return Dropoff Airport Set Directly (async): \(airport.displayName) (ID: \(returnDropoffAirportId))")
                            }
                        }
                    }
                }
            }
        }
    }
    
    private func updateAirportSelectionsFromEditData(_ editData: EditReservationData) {
        print("🔄 UPDATING AIRPORT SELECTIONS FROM EDIT DATA:")
        print("  isReturnFlow: \(isReturnFlow)")
        print("  selectedTransferType: \(selectedTransferType ?? "nil")")
        print("  API - pickup_airport: \(editData.pickupAirport ?? "nil"), dropoff_airport: \(editData.dropoffAirport ?? "nil")")
        
        // Update pickup airport if transfer type involves airport
        // Since airports are already fetched in loadRepeatData, we can set them synchronously
        // Use data as-is from API (return API already returns swapped data)
        if let transferType = selectedTransferType {
            // Determine which side needs airports based on the transfer type
            let needsPickupAirport = transferType == "Airport to City" || transferType == "Airport to Airport" || transferType == "Airport to Cruise Port" || transferType == "Cruise Port to Airport"
            let needsDropoffAirport = transferType == "City to Airport" || transferType == "Airport to Airport" || transferType == "City to Cruise Port" || transferType == "Cruise Port to City" || transferType == "Airport to Cruise Port" || transferType == "Cruise Port to Airport"
            
            if transferType.contains("Airport") {
                // Use airports as-is from API (return API already returns swapped data)
                let pickupAirportId = editData.pickupAirport
                let dropoffAirportId = editData.dropoffAirport
                let pickupAirportLat = editData.pickupAirportLatitude
                let pickupAirportLng = editData.pickupAirportLongitude
                let dropoffAirportLat = editData.dropoffAirportLatitude
                let dropoffAirportLng = editData.dropoffAirportLongitude
                
                print("  Transfer Type: \(transferType)")
                print("  needsPickupAirport: \(needsPickupAirport)")
                print("  needsDropoffAirport: \(needsDropoffAirport)")
                print("  pickupAirportId: \(pickupAirportId ?? "nil")")
                print("  dropoffAirportId: \(dropoffAirportId ?? "nil")")
                
                // Only set pickup airport if transfer type requires it
                if needsPickupAirport, let airportId = pickupAirportId, !airportId.isEmpty {
                    // Find airport by ID and set the selection (airports should already be loaded)
                    if let airport = airportService.airports.first(where: { $0.id == Int(airportId) }) {
                        selectedPickupAirport = airport.displayName
                        // Use coordinates from API if available, otherwise use airport service coordinates
                        if let apiLat = pickupAirportLat, let apiLng = pickupAirportLng {
                            pickupAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                            print("✅ Pickup Airport Set: \(airport.displayName) (ID: \(airportId)) with API coordinates (\(apiLat), \(apiLng))")
                        } else {
                            pickupAirportCoordinate = LocationCoordinate(
                                latitude: airport.lat ?? 0,
                                longitude: airport.long ?? 0
                            )
                            print("✅ Pickup Airport Set: \(airport.displayName) (ID: \(airportId)) with service coordinates")
                        }
                    } else {
                        // If not found, try async fetch (fallback)
                        print("⚠️ Pickup Airport not found in loaded list, fetching...")
                        Task {
                            await airportService.fetchAllAirports()
                            if let airport = airportService.airports.first(where: { $0.id == Int(airportId) }) {
                                await MainActor.run {
                                    selectedPickupAirport = airport.displayName
                                    // Use coordinates from API if available
                                    if let apiLat = pickupAirportLat, let apiLng = pickupAirportLng {
                                        pickupAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                                    } else {
                                        pickupAirportCoordinate = LocationCoordinate(
                                            latitude: airport.lat ?? 0,
                                            longitude: airport.long ?? 0
                                        )
                                    }
                                    print("✅ Pickup Airport Set (async): \(airport.displayName) (ID: \(airportId))")
                                }
                            } else {
                                print("❌ Pickup Airport not found for ID: \(airportId)")
                            }
                        }
                    }
                } else if needsPickupAirport {
                    // Clear pickup airport if transfer type requires it but we don't have one
                    selectedPickupAirport = nil
                    pickupAirportCoordinate = nil
                    print("  🔄 Cleared pickup airport (transfer type requires it but no airport in data)")
                }
                
                // Only set dropoff airport if transfer type requires it
                if needsDropoffAirport, let airportId = dropoffAirportId, !airportId.isEmpty {
                    // Find airport by ID and set the selection (airports should already be loaded)
                    if let airport = airportService.airports.first(where: { $0.id == Int(airportId) }) {
                        selectedDropoffAirport = airport.displayName
                        // Use coordinates from API if available, otherwise use airport service coordinates
                        if let apiLat = dropoffAirportLat, let apiLng = dropoffAirportLng {
                            dropoffAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                            print("✅ Dropoff Airport Set: \(airport.displayName) (ID: \(airportId)) with API coordinates (\(apiLat), \(apiLng))")
                        } else {
                            dropoffAirportCoordinate = LocationCoordinate(
                                latitude: airport.lat ?? 0,
                                longitude: airport.long ?? 0
                            )
                            print("✅ Dropoff Airport Set: \(airport.displayName) (ID: \(airportId)) with service coordinates")
                        }
                    } else {
                        // If not found, try async fetch (fallback)
                        print("⚠️ Dropoff Airport not found in loaded list, fetching...")
                        Task {
                            await airportService.fetchAllAirports()
                            if let airport = airportService.airports.first(where: { $0.id == Int(airportId) }) {
                                await MainActor.run {
                                    selectedDropoffAirport = airport.displayName
                                    // Use coordinates from API if available
                                    if let apiLat = dropoffAirportLat, let apiLng = dropoffAirportLng {
                                        dropoffAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                                    } else {
                                        dropoffAirportCoordinate = LocationCoordinate(
                                            latitude: airport.lat ?? 0,
                                            longitude: airport.long ?? 0
                                        )
                                    }
                                    print("✅ Dropoff Airport Set (async): \(airport.displayName) (ID: \(airportId))")
                                }
                            } else {
                                print("❌ Dropoff Airport not found for ID: \(airportId)")
                            }
                        }
                    }
                } else if needsDropoffAirport {
                    // Clear dropoff airport if transfer type requires it but we don't have one
                    selectedDropoffAirport = nil
                    dropoffAirportCoordinate = nil
                    print("  🔄 Cleared dropoff airport (transfer type requires it but no airport in data)")
                }
            }
        }
        
        // Update return trip airports for round trips
        if isRoundTripFlow || selectedServiceType == "Round Trip", let returnTransferType = selectedReturnTransferType {
            print("🔄 UPDATING RETURN TRIP AIRPORT SELECTIONS:")
            print("  Return Transfer Type: \(returnTransferType)")
            
            let needsReturnPickupAirport = returnTransferType == "Airport to City" || returnTransferType == "Airport to Airport" || returnTransferType == "Airport to Cruise Port" || returnTransferType == "Cruise Port to Airport"
            let needsReturnDropoffAirport = returnTransferType == "City to Airport" || returnTransferType == "Airport to Airport" || returnTransferType == "City to Cruise Port" || returnTransferType == "Cruise Port to City" || returnTransferType == "Airport to Cruise Port" || returnTransferType == "Cruise Port to Airport"
            
            if returnTransferType.contains("Airport") {
                let returnPickupAirportId = editData.returnPickupAirport
                let returnDropoffAirportId = editData.returnDropoffAirport
                
                // Handle return pickup airport
                if needsReturnPickupAirport, let airportId = returnPickupAirportId, !airportId.isEmpty {
                    let returnPickupAirportLat = editData.returnPickupAirportLatitude
                    let returnPickupAirportLng = editData.returnPickupAirportLongitude
                    
                    if let airport = airportService.airports.first(where: { $0.id == Int(airportId) }) {
                        selectedReturnPickupAirport = airport.displayName
                        // Use coordinates from API if available, otherwise use airport service coordinates
                        if let apiLat = returnPickupAirportLat, let apiLng = returnPickupAirportLng {
                            returnPickupAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                            print("✅ Return Pickup Airport Set: \(airport.displayName) (ID: \(airportId)) with API coordinates (\(apiLat), \(apiLng))")
                        } else {
                            returnPickupAirportCoordinate = LocationCoordinate(
                                latitude: airport.lat ?? 0,
                                longitude: airport.long ?? 0
                            )
                            print("✅ Return Pickup Airport Set: \(airport.displayName) (ID: \(airportId)) with service coordinates")
                        }
                    } else {
                        Task {
                            await airportService.fetchAllAirports()
                            if let airport = airportService.airports.first(where: { $0.id == Int(airportId) }) {
                                await MainActor.run {
                                    selectedReturnPickupAirport = airport.displayName
                                    // Use coordinates from API if available
                                    if let apiLat = returnPickupAirportLat, let apiLng = returnPickupAirportLng {
                                        returnPickupAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                                    } else {
                                        returnPickupAirportCoordinate = LocationCoordinate(
                                            latitude: airport.lat ?? 0,
                                            longitude: airport.long ?? 0
                                        )
                                    }
                                    print("✅ Return Pickup Airport Set (async): \(airport.displayName) (ID: \(airportId))")
                                }
                            }
                        }
                    }
                }
                
                // Handle return dropoff airport
                if needsReturnDropoffAirport, let airportId = returnDropoffAirportId, !airportId.isEmpty {
                    let returnDropoffAirportLat = editData.returnDropoffAirportLatitude
                    let returnDropoffAirportLng = editData.returnDropoffAirportLongitude
                    
                    if let airport = airportService.airports.first(where: { $0.id == Int(airportId) }) {
                        selectedReturnDropoffAirport = airport.displayName
                        // Use coordinates from API if available, otherwise use airport service coordinates
                        if let apiLat = returnDropoffAirportLat, let apiLng = returnDropoffAirportLng {
                            returnDropoffAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                            print("✅ Return Dropoff Airport Set: \(airport.displayName) (ID: \(airportId)) with API coordinates (\(apiLat), \(apiLng))")
                        } else {
                            returnDropoffAirportCoordinate = LocationCoordinate(
                                latitude: airport.lat ?? 0,
                                longitude: airport.long ?? 0
                            )
                            print("✅ Return Dropoff Airport Set: \(airport.displayName) (ID: \(airportId)) with service coordinates")
                        }
                    } else {
                        Task {
                            await airportService.fetchAllAirports()
                            if let airport = airportService.airports.first(where: { $0.id == Int(airportId) }) {
                                await MainActor.run {
                                    selectedReturnDropoffAirport = airport.displayName
                                    // Use coordinates from API if available
                                    if let apiLat = returnDropoffAirportLat, let apiLng = returnDropoffAirportLng {
                                        returnDropoffAirportCoordinate = LocationCoordinate(latitude: apiLat, longitude: apiLng)
                                    } else {
                                        returnDropoffAirportCoordinate = LocationCoordinate(
                                            latitude: airport.lat ?? 0,
                                            longitude: airport.long ?? 0
                                        )
                                    }
                                    print("✅ Return Dropoff Airport Set (async): \(airport.displayName) (ID: \(airportId))")
                                }
                            }
                        }
                    }
                }
            }
        }
        
        print("  Final - Pickup Airport: \(selectedPickupAirport ?? "nil"), Dropoff Airport: \(selectedDropoffAirport ?? "nil")")
        print("  Final - Return Pickup Airport: \(selectedReturnPickupAirport ?? "nil"), Return Dropoff Airport: \(selectedReturnDropoffAirport ?? "nil")")
    }
    
    private func updateAirlineSelectionsFromEditData(_ editData: EditReservationData) {
        print("🔄 UPDATING AIRLINE SELECTIONS FROM EDIT DATA:")
        print("  isReturnFlow: \(isReturnFlow)")
        
        // Use airlines as-is from API (return API already returns swapped data)
        let pickupAirlineId = editData.pickupAirline
        let dropoffAirlineId = editData.dropoffAirline
        
        // Update pickup airline if available - store ID as string for consistency
        if let airlineId = pickupAirlineId, !airlineId.isEmpty {
            Task {
                await airlineService.fetchAirlines()
                await MainActor.run {
                    if let airline = airlineService.airlines.first(where: { $0.id == Int(airlineId) }) {
                        selectedPickupAirline = airline.id.description
                        print("✅ Pickup Airline Set: \(airline.fullDisplayName) (ID: \(airlineId))")
                    } else {
                        // If airline not found in list, still set the ID
                        selectedPickupAirline = airlineId
                        print("⚠️ Pickup Airline ID \(airlineId) not found in list, using ID directly")
                    }
                }
            }
        }
        
        // Update dropoff airline if available - store ID as string for consistency
        if let airlineId = dropoffAirlineId, !airlineId.isEmpty {
            Task {
                await airlineService.fetchAirlines()
                await MainActor.run {
                    if let airline = airlineService.airlines.first(where: { $0.id == Int(airlineId) }) {
                        selectedDropoffAirline = airline.id.description
                        print("✅ Dropoff Airline Set: \(airline.fullDisplayName) (ID: \(airlineId))")
                    } else {
                        // If airline not found in list, still set the ID
                        selectedDropoffAirline = airlineId
                        print("⚠️ Dropoff Airline ID \(airlineId) not found in list, using ID directly")
                    }
                }
            }
        }
        
        // Update return pickup airline if available (for round trips)
        if let returnPickupAirlineId = editData.returnPickupAirline, !returnPickupAirlineId.isEmpty {
            Task {
                await airlineService.fetchAirlines()
                await MainActor.run {
                    if let airline = airlineService.airlines.first(where: { $0.id == Int(returnPickupAirlineId) }) {
                        selectedReturnPickupAirline = airline.id.description
                        print("✅ Return Pickup Airline Set: \(airline.fullDisplayName) (ID: \(returnPickupAirlineId))")
                    } else {
                        // If airline not found in list, still set the ID
                        selectedReturnPickupAirline = returnPickupAirlineId
                        print("⚠️ Return Pickup Airline ID \(returnPickupAirlineId) not found in list, using ID directly")
                    }
                }
            }
        }
        
        // Update return dropoff airline if available (for round trips)
        if let returnDropoffAirlineId = editData.returnDropoffAirline, !returnDropoffAirlineId.isEmpty {
            Task {
                await airlineService.fetchAirlines()
                await MainActor.run {
                    if let airline = airlineService.airlines.first(where: { $0.id == Int(returnDropoffAirlineId) }) {
                        selectedReturnDropoffAirline = airline.id.description
                        print("✅ Return Dropoff Airline Set: \(airline.fullDisplayName) (ID: \(returnDropoffAirlineId))")
                    } else {
                        // If airline not found in list, still set the ID
                        selectedReturnDropoffAirline = returnDropoffAirlineId
                        print("⚠️ Return Dropoff Airline ID \(returnDropoffAirlineId) not found in list, using ID directly")
                    }
                }
            }
        }
        
        print("  Pickup Airline ID: \(editData.pickupAirline ?? "nil")")
        print("  Dropoff Airline ID: \(editData.dropoffAirline ?? "nil")")
        print("  Return Pickup Airline ID: \(editData.returnPickupAirline ?? "nil")")
        print("  Return Dropoff Airline ID: \(editData.returnDropoffAirline ?? "nil")")
    }
    
    private func updateCruiseSelectionsFromEditData(_ editData: EditReservationData) {
        print("🔄 UPDATING CRUISE SELECTIONS FROM EDIT DATA:")
        
        // Update cruise details if transfer type involves cruise
        if let transferType = selectedTransferType {
            if transferType.contains("Cruise") {
                // Update cruise ship name
                if !(editData.cruiseName?.isEmpty ?? true) {
                    cruiseShipName = editData.cruiseName ?? ""
                    print("✅ Cruise Ship Name Set: \(cruiseShipName)")
                }
                
                // Update cruise time
                if !(editData.cruiseTime?.isEmpty ?? true) {
                    shipArrivalTime = editData.cruiseTime ?? ""
                    print("✅ Cruise Time Set: \(shipArrivalTime)")
                }
                
                // Update cruise port if available
                if !(editData.cruisePort?.isEmpty ?? true) {
                    cruisePort = editData.cruisePort ?? ""
                    print("✅ Cruise Port Set: \(cruisePort)")
                } else {
                    cruisePort = ""
                }
            }
            
            if let returnCruisePortValue = editData.returnCruisePort, !returnCruisePortValue.isEmpty {
                returnCruisePort = returnCruisePortValue
                print("✅ Return Cruise Port Set: \(returnCruisePort)")
            } else if !transferType.contains("Cruise") {
                returnCruisePort = ""
            }
        }
        
        print("  Cruise Name: \(editData.cruiseName ?? "nil")")
        print("  Cruise Port: \(editData.cruisePort ?? "nil")")
        print("  Cruise Time: \(editData.cruiseTime ?? "nil")")
        print("  Return Cruise Port: \(editData.returnCruisePort ?? "nil")")
    }
    
    private func getDropdownPosition() -> CGFloat {
        // Calculate dropdown position based on screen height and dropdown size
        let screenHeight = UIScreen.main.bounds.height
        let dropdownHeight = min(CGFloat(dropdownOptions.count) * 36, 200)
        let availableSpaceBelow = screenHeight - dropdownFrame.maxY
        
        if availableSpaceBelow >= dropdownHeight + 20 {
            return 8 // Position below the button
        } else {
            return -dropdownHeight - 8 // Position above the button
        }
    }

    private func restoreMissingCoordinatesAfterPrefill() {
        let outboundTransferType = selectedTransferType ?? "City to City"
        let inferredReturnTransferType = selectedReturnTransferType ?? getReversedTransferType() ?? "City to City"
        
        restoreCoordinateIfNeeded(for: pickupAddress, coordinate: pickupCoordinate) { coordinate in
            pickupCoordinate = coordinate
            if transferRequiresCruisePickup(outboundTransferType) {
                pickupCruiseCoordinate = coordinate
            }
        }
        
        restoreCoordinateIfNeeded(for: dropoffAddress, coordinate: dropoffCoordinate) { coordinate in
            dropoffCoordinate = coordinate
            if transferRequiresCruiseDropoff(outboundTransferType) {
                dropoffCruiseCoordinate = coordinate
            }
        }
        
        restoreCoordinateIfNeeded(for: returnPickupAddress, coordinate: returnPickupCoordinate) { coordinate in
            returnPickupCoordinate = coordinate
            if transferRequiresCruisePickup(inferredReturnTransferType) {
                returnPickupCruiseCoordinate = coordinate
            }
        }
        
        restoreCoordinateIfNeeded(for: returnDropoffAddress, coordinate: returnDropoffCoordinate) { coordinate in
            returnDropoffCoordinate = coordinate
            if transferRequiresCruiseDropoff(inferredReturnTransferType) {
                returnDropoffCruiseCoordinate = coordinate
            }
        }
    }
    
    private func restoreCoordinateIfNeeded(for address: String,
                                           coordinate: LocationCoordinate?,
                                           completion: @escaping (LocationCoordinate) -> Void) {
        guard isCoordinateMissing(coordinate), !address.isEmpty else {
            return
        }
        
        print("📍 Restoring missing coordinate via geocoding for address: \(address)")
        geocodingService.fetchCoordinates(for: address) { coordinate in
            guard let coordinate = coordinate else {
                print("❌ Geocoding failed for address: \(address)")
                return
            }
            DispatchQueue.main.async {
                completion(coordinate)
            }
        }
    }
    
    private func isCoordinateMissing(_ coordinate: LocationCoordinate?) -> Bool {
        guard let coordinate = coordinate else { return true }
        return coordinate.latitude == 0 && coordinate.longitude == 0
    }
    
    private func transferRequiresCruisePickup(_ transferType: String) -> Bool {
        return transferType == "Cruise Port to City" || transferType == "Cruise Port to Airport"
    }
    
    private func transferRequiresCruiseDropoff(_ transferType: String) -> Bool {
        return transferType == "City to Cruise Port" || transferType == "Airport to Cruise Port"
    }
    
    // MARK: - Transfer Type Inference and Correction
    
    /// Infers and corrects transfer type based on actual data (cruise ports, airports, addresses)
    /// This is critical for edit/repeat/return/round trip flows where API might return incorrect transfer type
    private func inferAndCorrectTransferTypeFromData(editData: EditReservationData? = nil) {
        print("🔍 INFERRING TRANSFER TYPE FROM ACTUAL DATA:")
        print("  Outbound - pickupAddress: '\(pickupAddress)', dropoffAddress: '\(dropoffAddress)'")
        print("  Outbound - pickupAirport: '\(selectedPickupAirport ?? "nil")', dropoffAirport: '\(selectedDropoffAirport ?? "nil")'")
        print("  Outbound - cruisePort: '\(cruisePort)'")
        
        // Infer outbound transfer type
        let inferredOutboundType = inferTransferType(
            pickupAddress: pickupAddress,
            dropoffAddress: dropoffAddress,
            pickupAirport: selectedPickupAirport,
            dropoffAirport: selectedDropoffAirport,
            cruisePort: cruisePort,
            editData: editData,
            isReturn: false
        )
        
        if let inferred = inferredOutboundType, inferred != selectedTransferType {
            print("⚠️ TRANSFER TYPE MISMATCH - Correcting outbound transfer type:")
            print("  Current: '\(selectedTransferType ?? "nil")'")
            print("  Inferred: '\(inferred)'")
            print("  Based on: pickupAirport=\(selectedPickupAirport != nil ? "yes" : "no"), dropoffAirport=\(selectedDropoffAirport != nil ? "yes" : "no"), cruisePort=\(cruisePort.isEmpty ? "no" : "yes")")
            selectedTransferType = inferred
            print("✅ Outbound transfer type corrected to: '\(selectedTransferType ?? "nil")'")
        } else {
            print("✅ Outbound transfer type is correct: '\(selectedTransferType ?? "nil")'")
        }
        
        // Infer return transfer type for round trips
        if isRoundTripFlow || selectedServiceType == "Round Trip" {
            print("  Return - returnPickupAddress: '\(returnPickupAddress)', returnDropoffAddress: '\(returnDropoffAddress)'")
            print("  Return - returnPickupAirport: '\(selectedReturnPickupAirport ?? "nil")', returnDropoffAirport: '\(selectedReturnDropoffAirport ?? "nil")'")
            print("  Return - returnCruisePort: '\(returnCruisePort)'")
            
            let inferredReturnType = inferTransferType(
                pickupAddress: returnPickupAddress,
                dropoffAddress: returnDropoffAddress,
                pickupAirport: selectedReturnPickupAirport,
                dropoffAirport: selectedReturnDropoffAirport,
                cruisePort: returnCruisePort, // Use returnCruisePort for return trips
                editData: editData,
                isReturn: true
            )
            
            if let inferred = inferredReturnType, inferred != selectedReturnTransferType {
                print("⚠️ TRANSFER TYPE MISMATCH - Correcting return transfer type:")
                print("  Current: '\(selectedReturnTransferType ?? "nil")'")
                print("  Inferred: '\(inferred)'")
                print("  Based on: returnPickupAirport=\(selectedReturnPickupAirport != nil ? "yes" : "no"), returnDropoffAirport=\(selectedReturnDropoffAirport != nil ? "yes" : "no"), returnCruisePort=\(returnCruisePort.isEmpty ? "no" : "yes")")
                selectedReturnTransferType = inferred
                print("✅ Return transfer type corrected to: '\(selectedReturnTransferType ?? "nil")'")
            } else {
                print("✅ Return transfer type is correct: '\(selectedReturnTransferType ?? "nil")'")
            }
        }
    }
    
    /// Infers transfer type from location data by checking what data is actually present
    private func inferTransferType(
        pickupAddress: String,
        dropoffAddress: String,
        pickupAirport: String?,
        dropoffAirport: String?,
        cruisePort: String,
        editData: EditReservationData?,
        isReturn: Bool
    ) -> String? {
        // Get cruise port data - for outbound use cruisePort, for return use returnCruisePort
        let cruisePortData: String
        if isReturn {
            cruisePortData = returnCruisePort.isEmpty ? (editData?.returnCruisePort ?? "") : returnCruisePort
        } else {
            cruisePortData = cruisePort.isEmpty ? (editData?.cruisePort ?? "") : cruisePort
        }
        
        let hasCruisePort = !cruisePortData.isEmpty
        
        // CRITICAL FIX: Check for airports from multiple sources
        // 1. From state variables (selectedPickupAirport/selectedDropoffAirport)
        // 2. From editData directly (pickupAirport/dropoffAirport IDs)
        // 3. From airport coordinates (pickupAirportCoordinate/dropoffAirportCoordinate)
        var hasPickupAirport = pickupAirport != nil && !pickupAirport!.isEmpty
        var hasDropoffAirport = dropoffAirport != nil && !dropoffAirport!.isEmpty
        
        // Check editData for airport IDs if state variables don't have airports
        if !hasPickupAirport, let editData = editData {
            let airportId = isReturn ? editData.returnPickupAirport : editData.pickupAirport
            hasPickupAirport = airportId != nil && !airportId!.isEmpty
            if hasPickupAirport {
                print("🔍 Airport detection: Found pickup airport from editData: \(airportId ?? "nil")")
            }
        }
        
        if !hasDropoffAirport, let editData = editData {
            let airportId = isReturn ? editData.returnDropoffAirport : editData.dropoffAirport
            hasDropoffAirport = airportId != nil && !airportId!.isEmpty
            if hasDropoffAirport {
                print("🔍 Airport detection: Found dropoff airport from editData: \(airportId ?? "nil")")
            }
        }
        
        // Check airport coordinates as additional confirmation
        let hasPickupAirportCoordinate = isReturn ? (returnPickupAirportCoordinate != nil) : (pickupAirportCoordinate != nil)
        let hasDropoffAirportCoordinate = isReturn ? (returnDropoffAirportCoordinate != nil) : (dropoffAirportCoordinate != nil)
        
        if !hasPickupAirport && hasPickupAirportCoordinate {
            hasPickupAirport = true
            print("🔍 Airport detection: Found pickup airport from coordinates")
        }
        
        if !hasDropoffAirport && hasDropoffAirportCoordinate {
            hasDropoffAirport = true
            print("🔍 Airport detection: Found dropoff airport from coordinates")
        }
        
        let hasPickupAddress = !pickupAddress.isEmpty
        let hasDropoffAddress = !dropoffAddress.isEmpty
        
        print("🔍 Airport detection summary - hasPickupAirport: \(hasPickupAirport), hasDropoffAirport: \(hasDropoffAirport)")
        
        // Determine which side has cruise port based on data patterns
        // If pickup has airport, pickup cannot be cruise port
        // If dropoff has airport, dropoff cannot be cruise port
        // If cruise port exists and one side has airport, the other side is cruise port
        // If cruise port exists and neither side has airport, check addresses to determine
        
        var isPickupCruisePort = false
        var isDropoffCruisePort = false
        
        if hasCruisePort {
            if hasPickupAirport {
                // Pickup is airport, so dropoff must be cruise port (if cruise port exists)
                isPickupCruisePort = false
                isDropoffCruisePort = true
                print("🔍 Cruise port detection: Pickup is airport, so dropoff is cruise port")
            } else if hasDropoffAirport {
                // Dropoff is airport, so pickup must be cruise port
                isPickupCruisePort = true
                isDropoffCruisePort = false
                print("🔍 Cruise port detection: Dropoff is airport, so pickup is cruise port")
            } else {
                // Neither side has airport - need to infer from addresses, editData, or cruise port coordinates
                // First, check editData to see original transfer type if available
                if let editData = editData {
                    let originalTransferType = isReturn ? editData.returnTransferType : editData.transferType
                    if let original = originalTransferType {
                        let originalLower = original.lowercased()
                        // Use original transfer type to determine which side has cruise port
                        if originalLower.contains("cruise_to") || originalLower == "cruise_to_city" || originalLower == "cruise_to_airport" || originalLower == "cruiseport_to_city" || originalLower == "cruiseport_to_airport" {
                            isPickupCruisePort = true
                            isDropoffCruisePort = false
                            print("🔍 Cruise port detection: From original transfer type '\(original)' - pickup is cruise port")
                        } else if originalLower.contains("_to_cruise") || originalLower == "city_to_cruise" || originalLower == "airport_to_cruise" || originalLower == "city_to_cruiseport" || originalLower == "airport_to_cruiseport" {
                            isPickupCruisePort = false
                            isDropoffCruisePort = true
                            print("🔍 Cruise port detection: From original transfer type '\(original)' - dropoff is cruise port")
                        } else {
                            // Can't determine from original, check if we have cruise port coordinates
                            // Check if pickup or dropoff coordinate matches cruise port coordinate
                            let pickupIsCruise = isReturn ? (pickupCruiseCoordinate != nil || returnPickupCruiseCoordinate != nil) : (pickupCruiseCoordinate != nil)
                            let dropoffIsCruise = isReturn ? (dropoffCruiseCoordinate != nil || returnDropoffCruiseCoordinate != nil) : (dropoffCruiseCoordinate != nil)
                            
                            if pickupIsCruise {
                                isPickupCruisePort = true
                                isDropoffCruisePort = false
                                print("🔍 Cruise port detection: From cruise coordinates - pickup is cruise port")
                            } else if dropoffIsCruise {
                                isPickupCruisePort = false
                                isDropoffCruisePort = true
                                print("🔍 Cruise port detection: From cruise coordinates - dropoff is cruise port")
                            } else {
                                // Use address heuristics as last resort
                                isPickupCruisePort = !hasPickupAddress || (hasDropoffAddress && pickupAddress.count < dropoffAddress.count)
                                isDropoffCruisePort = !isPickupCruisePort
                                print("🔍 Cruise port detection: Using address heuristics - pickup is cruise port: \(isPickupCruisePort)")
                            }
                        }
                    } else {
                        // No original transfer type, check cruise port coordinates
                        let pickupIsCruise = isReturn ? (pickupCruiseCoordinate != nil || returnPickupCruiseCoordinate != nil) : (pickupCruiseCoordinate != nil)
                        let dropoffIsCruise = isReturn ? (dropoffCruiseCoordinate != nil || returnDropoffCruiseCoordinate != nil) : (dropoffCruiseCoordinate != nil)
                        
                        if pickupIsCruise {
                            isPickupCruisePort = true
                            isDropoffCruisePort = false
                            print("🔍 Cruise port detection: From cruise coordinates (no original type) - pickup is cruise port")
                        } else if dropoffIsCruise {
                            isPickupCruisePort = false
                            isDropoffCruisePort = true
                            print("🔍 Cruise port detection: From cruise coordinates (no original type) - dropoff is cruise port")
                        } else {
                            // Use address heuristics as last resort
                            isPickupCruisePort = !hasPickupAddress || (hasDropoffAddress && pickupAddress.count < dropoffAddress.count)
                            isDropoffCruisePort = !isPickupCruisePort
                            print("🔍 Cruise port detection: Using address heuristics (no original type) - pickup is cruise port: \(isPickupCruisePort)")
                        }
                    }
                } else {
                    // No editData, check cruise port coordinates
                    let pickupIsCruise = isReturn ? (pickupCruiseCoordinate != nil || returnPickupCruiseCoordinate != nil) : (pickupCruiseCoordinate != nil)
                    let dropoffIsCruise = isReturn ? (dropoffCruiseCoordinate != nil || returnDropoffCruiseCoordinate != nil) : (dropoffCruiseCoordinate != nil)
                    
                    if pickupIsCruise {
                        isPickupCruisePort = true
                        isDropoffCruisePort = false
                        print("🔍 Cruise port detection: From cruise coordinates (no editData) - pickup is cruise port")
                    } else if dropoffIsCruise {
                        isPickupCruisePort = false
                        isDropoffCruisePort = true
                        print("🔍 Cruise port detection: From cruise coordinates (no editData) - dropoff is cruise port")
                    } else {
                        // Use address heuristics as last resort
                        isPickupCruisePort = !hasPickupAddress || (hasDropoffAddress && pickupAddress.count < dropoffAddress.count)
                        isDropoffCruisePort = !isPickupCruisePort
                        print("🔍 Cruise port detection: Using address heuristics (no editData) - pickup is cruise port: \(isPickupCruisePort)")
                    }
                }
            }
        }
        
        // Infer transfer type based on what we have
        // PRIORITIZE AIRPORT DETECTION FIRST (more definitive than cruise port)
        // Then handle cruise port cases
        // Finally handle city cases
        
        // Airport to Airport
        if hasPickupAirport && hasDropoffAirport {
            print("🔍 Transfer type inference: Airport to Airport")
            return "Airport to Airport"
        }
        // Airport to Cruise Port
        else if hasPickupAirport && isDropoffCruisePort {
            print("🔍 Transfer type inference: Airport to Cruise Port")
            return "Airport to Cruise Port"
        }
        // Airport to City
        else if hasPickupAirport && !hasDropoffAirport && !isDropoffCruisePort {
            print("🔍 Transfer type inference: Airport to City")
            return "Airport to City"
        }
        // Cruise Port to Airport
        else if isPickupCruisePort && hasDropoffAirport {
            print("🔍 Transfer type inference: Cruise Port to Airport")
            return "Cruise Port to Airport"
        }
        // City to Airport
        else if !hasPickupAirport && !isPickupCruisePort && hasDropoffAirport {
            print("🔍 Transfer type inference: City to Airport")
            return "City to Airport"
        }
        // Cruise Port to Cruise Port
        else if isPickupCruisePort && isDropoffCruisePort {
            print("🔍 Transfer type inference: Cruise Port to Cruise Port")
            return "Cruise Port to Cruise Port" // Edge case
        }
        // Cruise Port to City
        else if isPickupCruisePort && !hasDropoffAirport && !isDropoffCruisePort {
            print("🔍 Transfer type inference: Cruise Port to City")
            return "Cruise Port to City"
        }
        // City to Cruise Port
        else if !hasPickupAirport && !isPickupCruisePort && isDropoffCruisePort {
            print("🔍 Transfer type inference: City to Cruise Port")
            return "City to Cruise Port"
        }
        // Default to City to City
        else {
            print("🔍 Transfer type inference: City to City (default)")
            return "City to City"
        }
    }
    
    // MARK: - Date and Time Format Helpers
    
    private func formatDateForAPI(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }
    
    private func formatDateForUI(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy"
        return formatter.string(from: date)
    }
    
    private func formatTimeForAPI(_ time: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: time)
    }
    
    private func formatTimeForUI(_ time: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        return formatter.string(from: time)
    }
    
    private func parseDateFromUI(_ dateString: String) -> Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy"
        return formatter.date(from: dateString)
    }
    
    private func parseTimeFromUI(_ timeString: String) -> Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        return formatter.date(from: timeString)
    }
    
    private func updateTravelDate() {
        travelDate = formatDateForUI(selectedDate)
    }
    
    // Helper function to check if time is between 12 AM (00:00) to 5 AM (05:59)
    private func isEarlyMorningHours(_ time: Date) -> Bool {
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: time)
        // Check if hour is 0, 1, 2, 3, 4, or 5 (12 AM to 5:59 AM) - inclusive
        return hour >= 0 && hour <= 5
    }
    
    private func updatePickupTime() {
        let previousPickupTime = pickupTime
        pickupTime = formatTimeForUI(selectedTime)
        
        // Check if time actually changed (skip initial default)
        let timeChanged = previousPickupTime != pickupTime
        if !timeChanged {
            return
        }
        
        // Check if the new time is in early morning hours (12 AM to 5 AM inclusive)
        let isInEarlyMorning = isEarlyMorningHours(selectedTime)
        
        // Check if previous time was also in early morning range
        let previousTimeWasEarlyMorning: Bool = {
            if let previousTimeDate = parseTimeFromUI(previousPickupTime) {
                return isEarlyMorningHours(previousTimeDate)
            }
            return false
        }()
        
        // Call rates API if:
        // 1. New time is in early morning range (12 AM, 1 AM, 2 AM, 3 AM, 4 AM, 5 AM), OR
        // 2. User was already in early morning range and changed time (even if still in range)
        let shouldRefreshRates = isInEarlyMorning || previousTimeWasEarlyMorning
        
        if shouldRefreshRates {
            print("🕐 Early morning hours detected (12 AM - 5 AM). Refreshing rates...")
            print("  Previous time: \(previousPickupTime) (was in early morning: \(previousTimeWasEarlyMorning))")
            print("  New time: \(pickupTime) (is in early morning: \(isInEarlyMorning))")
            print("  Time changed: \(timeChanged)")
            Task {
                await refreshRates()
            }
        }
    }
    
    private func updateCruiseTime() {
        shipArrivalTime = formatTimeForUI(selectedCruiseTime)
    }
    
    private func updateReturnDate() {
        returnTravelDate = formatDateForUI(selectedReturnDate)
    }
    
    private func updateReturnTime() {
        returnPickupTime = formatTimeForUI(selectedReturnTime)
    }
    
    private func updateReturnCruiseTime() {
        returnShipArrivalTime = formatTimeForUI(selectedReturnCruiseTime)
    }
    
    // MARK: - Extra Stop Functions
    private func addExtraStop() {
    guard isOutboundExtraStopButtonEnabled else {
            extraStopValidationError = "Extra stop should be in the same country as pickup and drop-off."
            showInvalidLocationDialog = false
        return
    }
        guard extraStopValidationError == nil else { return }
        let newStop = ExtraStop()
        extraStops.append(newStop)
    }

private var isOutboundExtraStopButtonEnabled: Bool {
    let transfer = selectedTransferType ?? "City to City"
    switch transfer {
    case "City to City", "City to Cruise Port":
        return !pickupAddress.isEmpty && !dropoffAddress.isEmpty
    case "City to Airport":
        return !pickupAddress.isEmpty && !(selectedDropoffAirport ?? "").isEmpty
    case "Airport to City", "Airport to Cruise Port":
        return !(selectedPickupAirport ?? "").isEmpty && !dropoffAddress.isEmpty
    case "Airport to Airport":
        return !(selectedPickupAirport ?? "").isEmpty && !(selectedDropoffAirport ?? "").isEmpty
    case "Cruise Port to Airport":
        return !pickupAddress.isEmpty && !(selectedDropoffAirport ?? "").isEmpty
    default:
        return !pickupAddress.isEmpty && !dropoffAddress.isEmpty
    }
}

private func addReturnExtraStop() {
    guard isReturnExtraStopButtonEnabled else {
            returnExtraStopValidationError = "Extra stop should be in the same country as pickup and drop-off."
            showInvalidLocationDialog = false
        return
    }
        guard returnExtraStopValidationError == nil else { return }
    let newStop = ExtraStop()
    newStop.address = ""
    newStop.coordinate = nil
    returnExtraStops.append(newStop)
    // Refresh return rates when return extra stop is added
    refreshReturnRates()
}

private var isReturnExtraStopButtonEnabled: Bool {
    let transfer = selectedReturnTransferType ?? "City to City"
    switch transfer {
    case "City to City", "City to Cruise Port":
        return !returnPickupAddress.isEmpty && !returnDropoffAddress.isEmpty
    case "City to Airport":
        return !returnPickupAddress.isEmpty && !(selectedReturnDropoffAirport ?? "").isEmpty
    case "Airport to City", "Airport to Cruise Port":
        return !(selectedReturnPickupAirport ?? "").isEmpty && !returnDropoffAddress.isEmpty
    case "Airport to Airport":
        return !(selectedReturnPickupAirport ?? "").isEmpty && !(selectedReturnDropoffAirport ?? "").isEmpty
    case "Cruise Port to Airport":
        return !returnPickupAddress.isEmpty && !(selectedReturnDropoffAirport ?? "").isEmpty
    default:
        return !returnPickupAddress.isEmpty && !returnDropoffAddress.isEmpty
    }
}

private var hasBlockingExtraStopError: Bool {
    (extraStopValidationError ?? returnExtraStopValidationError) != nil
}
    
    private func removeExtraStop(_ stop: ExtraStop) {
        extraStops.removeAll { $0.id == stop.id }
        extraStopValidationError = nil
        showInvalidLocationDialog = false
        // Refresh rates when extra stop is removed
        Task {
            await fetchBookingRates()
        }
    }
    
    // MARK: - Header View
    private var headerView: some View {
        HStack {
            Button(action: {
                dismiss()
            }) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.black)
            }
            
            Spacer()
            
            Text(headerTitle)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.black)
            
            Spacer()
            
            // Invisible button to balance the layout
            Button(action: {}) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.clear)
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 16)
        .padding(.bottom, 24)
    }
    
    // MARK: - Header Title
    private var headerTitle: String {
        let serviceType = selectedServiceType ?? "One Way"
        if isEditMode {
            return "Edit \(serviceType)"
        } else {
            return "Create \(serviceType)"
        }
    }
    
    // MARK: - Accounts Information Section
    private var accountsInformationSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Accounts Information")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppColors.primaryOrange)
            
            VStack(spacing: 0) {
                                    VStack(alignment: .leading, spacing: 8) {
                                        HStack(){
                                            accountInfoRow(label: "NAME", value: getUserDisplayName())
                                            accountInfoRow(label: "MOBILE", value: getUserMobile())


                                        }
                                        HStack(){
                                            accountInfoRow(label: "EMAIL", value: getUserEmail())
                                         



                                        }
                                        HStack(){
                                            accountInfoRow(label: "ZIP", value: getUserZipCode())

                                            accountInfoRow(label: "COUNTRY", value: getUserCountry())
                                        }
                        accountInfoRow(label: "ADDRESS", value: getUserAddress())
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    
                }
            
            .padding(20)
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 2)
        }
    }
    
    private func accountInfoRow(label: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.black)
            Text(value)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.gray)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    
    // MARK: - Booking Details Section
    private var bookingDetailsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Booking Details")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppColors.primaryOrange)
            
            VStack(spacing: 16) {
                // Service Type Dropdown
                VStack(alignment: .leading, spacing: 8) {
                    Text("SERVICE TYPE")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.gray)
                    
                    Button(action: {
                        openDropdown = openDropdown == "serviceType" ? nil : "serviceType"
                        if openDropdown == "serviceType" {
                            dropdownOptions = serviceTypes
                            dropdownSelected = $selectedServiceType
                        }
                    }) {
                        HStack {
                            Text(selectedServiceType ?? "Select Service Type")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.black)
                            Spacer()
                             Image("arrowIcon")

                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(8)
                    }
                    .buttonStyle(PlainButtonStyle())
                    .background(
                        GeometryReader { geo in
                            Color.clear
                                .onChange(of: openDropdown) { open in
                                    if open == "serviceType" {
                                        let frame = geo.frame(in: .named("dropdownArea"))
                                        dropdownFrame = frame
                                    }
                                }
                        }
                    )
                    
                    validationMessage(for: "transferType")
                }
                
                // Transfer Type Dropdown
                VStack(alignment: .leading, spacing: 8) {
                    Text("TRANSFER TYPE")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.gray)
                    
                    Button(action: {
                        openDropdown = openDropdown == "transferType" ? nil : "transferType"
                        if openDropdown == "transferType" {
                            dropdownOptions = transferTypes
                            dropdownSelected = Binding(
                                get: { selectedTransferType },
                                set: { newValue in
                                    print("🔄 TRANSFER TYPE DROPDOWN SELECTION: \(newValue ?? "nil")")
                                    selectedTransferType = newValue
                                    // The onChange handler will take care of the field updates
                                }
                            )
                        }
                    }) {
                        HStack {
                            Text(selectedTransferType ?? "Select Transfer Type")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.black)
                            Spacer()
                             Image("arrowIcon")

                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(8)
                    }
                    .buttonStyle(PlainButtonStyle())
                    .background(
                        GeometryReader { geo in
                            Color.clear
                                .onChange(of: openDropdown) { open in
                                    if open == "transferType" {
                                        let frame = geo.frame(in: .named("dropdownArea"))
                                        dropdownFrame = frame
                                    }
                                }
                        }
                    )
                }
                
                // Meet and Greet Choices Dropdown
                VStack(alignment: .leading, spacing: 8) {
                    Text("MEET AND GREET CHOICES")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.gray)
                    
                    Button(action: {
                        openDropdown = openDropdown == "meetGreet" ? nil : "meetGreet"
                        if openDropdown == "meetGreet" {
                            dropdownOptions = meetGreetChoices.map { $0.message }
                            dropdownSelected = $selectedMeetAndGreet
                        }
                    }) {
                        HStack {
                            Text(selectedMeetAndGreet ?? "Select Meet & Greet")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.black)
                            Spacer()
                             Image("arrowIcon")

                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(8)
                    }
                    .buttonStyle(PlainButtonStyle())
                    .background(
                        GeometryReader { geo in
                            Color.clear
                                .onChange(of: openDropdown) { open in
                                    if open == "meetGreet" {
                                        let frame = geo.frame(in: .named("dropdownArea"))
                                        dropdownFrame = frame
                                    }
                                }
                        }
                    )
                }
                
                // Hours Selection (only for Charter Tour)
                if selectedServiceType == "Charter Tour" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("NUMBER OF HOURS")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            openDropdown = openDropdown == "hours" ? nil : "hours"
                            if openDropdown == "hours" {
                                dropdownOptions = hoursOptions
                                dropdownSelected = Binding(
                                    get: { selectedHours },
                                    set: { selectedHours = $0 ?? "2 hours minimum" }
                                )
                            }
                        }) {
                            HStack {
                                Text(selectedHours)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(.gray)
                                Spacer()
                                 Image("arrowIcon")

                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                        }
                        .buttonStyle(PlainButtonStyle())
                        .background(
                            GeometryReader { geo in
                                Color.clear
                                    .onChange(of: openDropdown) { open in
                                        if open == "hours" {
                                            let frame = geo.frame(in: .named("dropdownArea"))
                                            dropdownFrame = frame
                                        }
                                    }
                            }
                        )
                    }
                }
                
                // Number of Vehicles
                VStack(alignment: .leading, spacing: 8) {
                    Text("NUMBER OF VEHICLES")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.gray)
                    
                    AutoSelectTextField(
                        placeholder: "",
                        text: Binding(
                            get: { String(numberOfVehicles) },
                            set: { newValue in
                                if let intValue = Int(newValue), intValue > 0 {
                                    numberOfVehicles = intValue
                                } else if newValue.isEmpty {
                                    numberOfVehicles = 1
                                }
                            }
                        ),
                        keyboardType: .numberPad,
                        fontSize: 14,
                        fontWeight: .medium,
                        textColor: .black
                    )
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
                }
                
                // Travel Time and Distance
                TravelInfoSection(
                    travelInfo: getDynamicTravelInfo(),
                    showDivider: true
                )
                .onChange(of: pickupCoordinate) { _ in
                    Task {
                        cachedTravelInfo = "Calculating route..."
                        await calculateAndCacheTravelInfo()
                    }
                }
                .onChange(of: dropoffCoordinate) { _ in
                    Task {
                        cachedTravelInfo = "Calculating route..."
                        await calculateAndCacheTravelInfo()
                    }
                }
                .onChange(of: pickupAirportCoordinate) { _ in
                    Task {
                        cachedTravelInfo = "Calculating route..."
                        await calculateAndCacheTravelInfo()
                    }
                }
                .onChange(of: dropoffAirportCoordinate) { _ in
                    Task {
                        cachedTravelInfo = "Calculating route..."
                        await calculateAndCacheTravelInfo()
                    }
                }
                .onChange(of: extraStops.count) { _ in
                    Task {
                        cachedTravelInfo = "Calculating route..."
                        await calculateAndCacheTravelInfo()
                    }
                }
            }
        }
    }
    
    // MARK: - Pick-up Section
    private var pickupSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Pick-up")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppColors.primaryOrange)
            
            VStack(spacing: 16) {
                // Travel Date & Pickup Time
                HStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("TRAVEL DATE")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            // Don't reinitialize - use the selectedDate that was already set
                            print("⭐️⭐️⭐️ OPENING DATE PICKER ⭐️⭐️⭐️")
                            print("⭐️ selectedDate = \(selectedDate)")
                            print("⭐️ travelDate string = '\(travelDate)'")
                            let formatter = DateFormatter()
                            formatter.dateFormat = "yyyy-MM-dd"
                            print("⭐️ selectedDate formatted = '\(formatter.string(from: selectedDate))'")
                            showDatePicker = true
                        }) {
                        HStack {
                            Text(travelDate)
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.black)
                            Spacer()
                            Image(systemName: "calendar")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(.gray)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(8)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("PICKUP TIME")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            // Don't reinitialize - use the selectedTime that was already set
                            print("⭐️⭐️⭐️ OPENING TIME PICKER ⭐️⭐️⭐️")
                            print("⭐️ selectedTime = \(selectedTime)")
                            print("⭐️ pickupTime string = '\(pickupTime)'")
                            let formatter = DateFormatter()
                            formatter.dateFormat = "HH:mm:ss"
                            print("⭐️ selectedTime formatted = '\(formatter.string(from: selectedTime))'")
                            showTimePicker = true
                        }) {
                        HStack {
                            Text(pickupTime)
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.black)
                            Spacer()
                                Image(systemName: "clock")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(.gray)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(8)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                
                // Dynamic pickup fields based on transfer type
                if let transferType = selectedTransferType, transferType == "City to City" {
                    // City pickup - show address field
                    AddressAutocompleteField(
                        viewModel: pickupAddressVM,
                        label: "PICKUP ADDRESS",
                        placeholder: "Enter pickup address",
                        value: $pickupAddress,
                        hasError: hasError(for: "pickupAddress"),
                        onLocationSelected: { address, coordinate, postalCode in
                            pickupAddress = address
                            pickupCoordinate = coordinate
                            print("📍 PICKUP ADDRESS SELECTED: \(address) - \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                            print("📍 STORED PICKUP COORDINATE: \(pickupCoordinate?.latitude ?? 0), \(pickupCoordinate?.longitude ?? 0)")
                            
                            // Clear error and validate locations
                            clearError(for: "pickupAddress")
                            validateOutboundLocations()
                            
                            // Automatically call API after address selection
                            Task {
                                await fetchBookingRates()
                            }
                        }
                    )
                    .onChange(of: pickupAddress) { newValue in
                        // Validate when address changes (user types manually)
                        if !newValue.isEmpty {
                            validateOutboundLocations()
                        }
                    }
                    validationMessage(for: "pickupAddress")
                } else if let transferType = selectedTransferType, (transferType == "City to Airport" || transferType == "City to Cruise Port") {
                    // City pickup - show address field
                    AddressAutocompleteField(
                        viewModel: pickupAddressVM,
                        label: "PICKUP ADDRESS",
                        placeholder: "Enter pickup address",
                        value: $pickupAddress,
                        hasError: hasError(for: "pickupAddress"),
                        onLocationSelected: { address, coordinate, postalCode in
                            pickupAddress = address
                            pickupCoordinate = coordinate
                            print("📍 PICKUP ADDRESS SELECTED: \(address) - \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                            
                            // Clear error and validate locations
                            clearError(for: "pickupAddress")
                            validateOutboundLocations()
                            
                            // Automatically call API after address selection
                            Task {
                                await fetchBookingRates()
                            }
                        }
                    )
                    .onChange(of: pickupAddress) { newValue in
                        // Validate when address changes (user types manually)
                        if !newValue.isEmpty {
                            validateOutboundLocations()
                        }
                    }
                    validationMessage(for: "pickupAddress")
                } else if let transferType = selectedTransferType, (transferType == "Airport to City" || transferType == "Airport to Airport" || transferType == "Airport to Cruise Port") {
                    // Airport pickup - show airport and airline fields
                    VStack(spacing: 16) {
                        // Airport selection
                        VStack(alignment: .leading, spacing: 8) {
                            Text("SELECT AIRPORT")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            Text("(search by code or name)")
                                .font(.system(size: 10, weight: .regular))
                                .foregroundColor(.gray)
                            
                            Button(action: {
                                print("🛫 Opening airport bottom sheet with \(airportService.airports.count) airports")
                                currentAirportType = "pickup"
                                Task {
                                    await airportService.fetchAllAirports()
                                    // Only show the sheet after airports are loaded
                                    await MainActor.run {
                                        showAirportBottomSheet = true
                                    }
                                }
                            }) {
                                HStack {
                                    Text(selectedPickupAirport ?? "Search airports...")
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(selectedPickupAirport == nil ? .black : .black)
                                    Spacer()
                                     Image("arrowIcon")

                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(.gray)
                                }
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(hasError(for: "pickupAirport") ? Color.red : Color.clear, lineWidth: hasError(for: "pickupAirport") ? 1.5 : 0)
                                )
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            validationMessage(for: "pickupAirport")
                        }
                        
                        // Airline selection
                        VStack(alignment: .leading, spacing: 8) {
                            Text("SELECT AIRLINE")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            Button(action: {
                                currentAirlineType = "pickup"
                                showAirlineBottomSheet = true
                            }) {
                                HStack {
                                    Text(pickupAirlineDisplayName)
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(selectedPickupAirline == nil ? .black : .black)
                                    Spacer()
                                     Image("arrowIcon")

                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(.gray)
                                }
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(hasError(for: "pickupAirline") ? Color.red : Color.clear, lineWidth: hasError(for: "pickupAirline") ? 1.5 : 0)
                                )
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            validationMessage(for: "pickupAirline")
                        }
                        
                        // Flight number
                        VStack(alignment: .leading, spacing: 8) {
                            Text("FLIGHT / TAIL #")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            AutoSelectTextField(
                                placeholder: "Enter flight number",
                                text: $pickupFlightNumber,
                                fontSize: 14,
                                fontWeight: .medium,
                                textColor: .black
                            )
                            .focused($focusedField, equals: .pickupFlightNumber)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "pickupFlightNumber") ? Color.red : Color.clear, lineWidth: hasError(for: "pickupFlightNumber") ? 1.5 : 0)
                            )
                            
                            validationMessage(for: "pickupFlightNumber")
                        }
                        
                        // Origin Airport / City
                        VStack(alignment: .leading, spacing: 8) {
                            Text("ORIGIN AIRPORT / CITY")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            AutoSelectTextField(
                                placeholder: "Enter origin airport or city",
                                text: $originAirportCity,
                                fontSize: 14,
                                fontWeight: .medium,
                                textColor: .gray
                            )
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                        }
                    }
                } else if let transferType = selectedTransferType, (transferType == "Cruise Port to City" || transferType == "Cruise Port to Airport") {
                    // Cruise port pickup - show address field with cruise ship details
                    VStack(spacing: 16) {
                        AddressAutocompleteField(
                            viewModel: pickupAddressVM,
                            label: "PICKUP ADDRESS",
                            placeholder: "Enter pickup address",
                            value: $pickupAddress,
                            hasError: hasError(for: "pickupAddress"),
                            onLocationSelected: { address, coordinate, postalCode in
                                pickupAddress = address
                                pickupCruiseCoordinate = coordinate
                                print("📍 PICKUP CRUISE PORT SELECTED: \(address) - \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                                
                                // Clear error and validate locations
                                clearError(for: "pickupAddress")
                                validateOutboundLocations()
                                
                                // Automatically call API after address selection
                                Task {
                                    await fetchBookingRates()
                                }
                            }
                        )
                        .onChange(of: pickupAddress) { newValue in
                            // Validate when address changes (user types manually)
                            if !newValue.isEmpty {
                                validateOutboundLocations()
                            }
                        }
                        
                        validationMessage(for: "pickupAddress")
                        
                        // Cruise port name
                        VStack(alignment: .leading, spacing: 8) {
                            Text("CRUISE PORT")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            AutoSelectTextField(
                                placeholder: "Enter cruise port",
                                text: $cruisePort,
                                fontSize: 14,
                                fontWeight: .medium,
                                textColor: .black
                            )
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "cruisePort") ? Color.red : Color.clear, lineWidth: hasError(for: "cruisePort") ? 1.5 : 0)
                            )
                            
                            validationMessage(for: "cruisePort")
                        }
                        
                        // Cruise ship name
                        VStack(alignment: .leading, spacing: 8) {
                            Text("CRUISE SHIP NAME")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            AutoSelectTextField(
                                placeholder: "Enter cruise ship name",
                                text: $cruiseShipName,
                                fontSize: 14,
                                fontWeight: .medium,
                                textColor: .black
                            )
                            .focused($focusedField, equals: .cruiseShipName)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "cruiseShipName") ? Color.red : Color.clear, lineWidth: hasError(for: "cruiseShipName") ? 1.5 : 0)
                            )
                            
                            validationMessage(for: "cruiseShipName")
                        }
                        
                        // Ship arrival time
                        VStack(alignment: .leading, spacing: 8) {
                            Text("SHIP ARRIVAL TIME")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            Button(action: {
                                // Don't reinitialize - use the selectedCruiseTime that was already set
                                showCruiseTimePicker = true
                            }) {
                                HStack {
                                    Image(systemName: "clock")
                                        .font(.system(size: 16, weight: .medium))
                                        .foregroundColor(.gray)
                                    
                                    AutoSelectTextField(
                                        placeholder: "Enter arrival time",
                                        text: $shipArrivalTime,
                                        fontSize: 14,
                                        fontWeight: .medium,
                                        textColor: .black,
                                        isEnabled: false
                                    )
                                    .disabled(true)
                                }
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(hasError(for: "shipArrivalTime") ? Color.red : Color.clear, lineWidth: hasError(for: "shipArrivalTime") ? 1.5 : 0)
                                )
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            validationMessage(for: "shipArrivalTime")
                        }
                    }
                }
            }
        }
    }
    
    // MARK: - Drop-off Section
    private var dropoffSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Drop-off")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppColors.primaryOrange)
            
            VStack(spacing: 16) {
                // Dynamic dropoff fields based on transfer type
                if let transferType = selectedTransferType, transferType == "City to City" {
                    // City dropoff - show address field
                    AddressAutocompleteField(
                        viewModel: dropoffAddressVM,
                        label: "DROP-OFF ADDRESS",
                        placeholder: "Enter drop-off address",
                        value: $dropoffAddress,
                        hasError: hasError(for: "dropoffAddress"),
                        onLocationSelected: { address, coordinate, postalCode in
                            dropoffAddress = address
                            dropoffCoordinate = coordinate
                            print("📍 DROPOFF ADDRESS SELECTED: \(address) - \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                            
                            // Clear error and validate locations
                            clearError(for: "dropoffAddress")
                            validateOutboundLocations()
                            
                            // Automatically call API after address selection
                            Task {
                                await fetchBookingRates()
                            }
                        }
                    )
                    .onChange(of: dropoffAddress) { newValue in
                        // Validate when address changes (user types manually)
                        if !newValue.isEmpty {
                            validateOutboundLocations()
                        }
                    }
                    validationMessage(for: "dropoffAddress")
                } else if let transferType = selectedTransferType, (transferType == "Airport to City" || transferType == "Cruise Port to City") {
                    // City dropoff - show address field
                    AddressAutocompleteField(
                        viewModel: dropoffAddressVM,
                        label: "DROP-OFF ADDRESS",
                        placeholder: "Enter drop-off address",
                        value: $dropoffAddress,
                        hasError: hasError(for: "dropoffAddress"),
                        onLocationSelected: { address, coordinate, postalCode in
                            dropoffAddress = address
                            dropoffCoordinate = coordinate
                            print("📍 DROPOFF ADDRESS SELECTED: \(address) - \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                            
                            // Clear error and validate locations
                            clearError(for: "dropoffAddress")
                            validateOutboundLocations()
                            
                            // Automatically call API after address selection
                            Task {
                                await fetchBookingRates()
                            }
                        }
                    )
                    .onChange(of: dropoffAddress) { newValue in
                        // Validate when address changes (user types manually)
                        if !newValue.isEmpty {
                            validateOutboundLocations()
                        }
                    }
                    validationMessage(for: "dropoffAddress")
                } else if let transferType = selectedTransferType, (transferType == "City to Airport" || transferType == "Airport to Airport" || transferType == "Cruise Port to Airport") {
                    // Airport dropoff - show airport and airline fields
                    VStack(spacing: 16) {
                        // Airport selection
                        VStack(alignment: .leading, spacing: 8) {
                            Text("SELECT AIRPORT")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            Text("(search by code or name)")
                                .font(.system(size: 10, weight: .regular))
                                .foregroundColor(.gray)
                            
                            Button(action: {
                                currentAirportType = "dropoff"
                                Task {
                                    await airportService.fetchAllAirports()
                                    // Only show the sheet after airports are loaded
                                    await MainActor.run {
                                        showAirportBottomSheet = true
                                    }
                                }
                            }) {
                                HStack {
                                    Text(selectedDropoffAirport ?? "Search airports...")
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(selectedDropoffAirport == nil ? .black : .black)
                                    Spacer()
                                     Image("arrowIcon")

                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(.gray)
                                }
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(hasError(for: "dropoffAirport") ? Color.red : Color.clear, lineWidth: hasError(for: "dropoffAirport") ? 1.5 : 0)
                                )
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            validationMessage(for: "dropoffAirport")
                        }
                        
                        // Airline selection
                        VStack(alignment: .leading, spacing: 8) {
                            Text("SELECT AIRLINE")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            Button(action: {
                                currentAirlineType = "dropoff"
                                showAirlineBottomSheet = true
                            }) {
                                HStack {
                                    Text(dropoffAirlineDisplayName)
                                        .font(.system(size: 14, weight: .medium))
                                        .foregroundColor(selectedDropoffAirline == nil ? .black : .black)
                                    Spacer()
                                     Image("arrowIcon")

                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(.gray)
                                }
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(hasError(for: "dropoffAirline") ? Color.red : Color.clear, lineWidth: hasError(for: "dropoffAirline") ? 1.5 : 0)
                                )
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            validationMessage(for: "dropoffAirline")
                        }
                        
                        // Flight number
                        VStack(alignment: .leading, spacing: 8) {
                            Text("FLIGHT / TAIL #")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            AutoSelectTextField(
                                placeholder: "Enter flight number",
                                text: $dropoffFlightNumber,
                                fontSize: 14,
                                fontWeight: .medium,
                                textColor: .black
                            )
                            .focused($focusedField, equals: .dropoffFlightNumber)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "dropoffFlightNumber") ? Color.red : Color.clear, lineWidth: hasError(for: "dropoffFlightNumber") ? 1.5 : 0)
                            )
                            
                            validationMessage(for: "dropoffFlightNumber")
                        }
                    }
                } else if let transferType = selectedTransferType, (transferType == "City to Cruise Port" || transferType == "Airport to Cruise Port") {
                    // Cruise port dropoff - show address field with cruise ship details
                    VStack(spacing: 16) {
                        AddressAutocompleteField(
                            viewModel: dropoffAddressVM,
                            label: "DROP-OFF ADDRESS",
                            placeholder: "Enter drop-off address",
                            value: $dropoffAddress,
                            hasError: hasError(for: "dropoffAddress"),
                            onLocationSelected: { address, coordinate, postalCode in
                                dropoffAddress = address
                                dropoffCruiseCoordinate = coordinate
                                print("📍 DROPOFF CRUISE PORT SELECTED: \(address) - \(coordinate?.latitude ?? 0), \(coordinate?.longitude ?? 0)")
                                
                                // Clear error and validate locations
                                clearError(for: "dropoffAddress")
                                validateOutboundLocations()
                                
                                // Automatically call API after address selection
                                Task {
                                    await fetchBookingRates()
                                }
                            }
                        )
                        .onChange(of: dropoffAddress) { newValue in
                            // Validate when address changes (user types manually)
                            if !newValue.isEmpty {
                                validateOutboundLocations()
                            }
                        }
                        
                        validationMessage(for: "dropoffAddress")
                        
                        // Cruise port name
                        VStack(alignment: .leading, spacing: 8) {
                            Text("CRUISE PORT")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            AutoSelectTextField(
                                placeholder: "Enter cruise port",
                                text: $cruisePort,
                                fontSize: 14,
                                fontWeight: .medium,
                                textColor: .black
                            )
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "cruisePort") ? Color.red : Color.clear, lineWidth: hasError(for: "cruisePort") ? 1.5 : 0)
                            )
                            
                            validationMessage(for: "cruisePort")
                        }
                        
                        // Cruise ship name
                        VStack(alignment: .leading, spacing: 8) {
                            Text("CRUISE SHIP NAME")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            AutoSelectTextField(
                                placeholder: "Enter cruise ship name",
                                text: $cruiseShipName,
                                fontSize: 14,
                                fontWeight: .medium,
                                textColor: .black
                            )
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "cruiseShipName") ? Color.red : Color.clear, lineWidth: hasError(for: "cruiseShipName") ? 1.5 : 0)
                            )
                            
                            validationMessage(for: "cruiseShipName")
                        }
                        
                        // Ship arrival time
                        VStack(alignment: .leading, spacing: 8) {
                            Text("SHIP DEPARTURE TIME")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            Button(action: {
                                // Don't reinitialize - use the selectedCruiseTime that was already set
                                showCruiseTimePicker = true
                            }) {
                                HStack {
                                    Image(systemName: "clock")
                                        .font(.system(size: 16, weight: .medium))
                                        .foregroundColor(.black)
                                    
                                    AutoSelectTextField(
                                        placeholder: "Enter arrival time",
                                        text: $shipArrivalTime,
                                        fontSize: 14,
                                        fontWeight: .medium,
                                        textColor: .black,
                                        isEnabled: false
                                    )
                                    .disabled(true)
                                }
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(hasError(for: "shipArrivalTime") ? Color.red : Color.clear, lineWidth: hasError(for: "shipArrivalTime") ? 1.5 : 0)
                                )
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            validationMessage(for: "shipArrivalTime")
                        }
                    }
                }
            }
        }
    }
    
    
    // MARK: - Transportation Details Section
    private var transportationDetailsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Transportation Details")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppColors.primaryOrange)
            
            VStack(spacing: 16) {
                // Driver Details Card
                driverDetailsCard
                
                // Vehicle Details Card
                vehicleDetailsCard
            }
        }
    }
    
    private var driverDetailsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("DRIVER DETAILS")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.gray)
            
            HStack(spacing: 12) {
                // Driver Image
                AsyncImage(url: URL(string: getDriverImageUrl())) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                } placeholder: {
                    Circle()
                        .fill(Color.black.opacity(0.2))
                        .overlay(
                            Image(systemName: "person.fill")
                                .font(.system(size: 24))
                                .foregroundColor(.gray)
                        )
                }
                .frame(width: 50, height: 50)
                .clipShape(Circle())
                
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(getDriverName())
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.black)
                        
                        Spacer()
                        
//                        // Rating
//                        HStack(spacing: 4) {
//                            Image(systemName: "star.fill")
//                                .font(.system(size: 10))
//                                .foregroundColor(.gray)
//                            Text(getDriverRating())
//                                .font(.system(size: 12, weight: .medium))
//                                .foregroundColor(.white)
//                        }
//                        .padding(.horizontal, 8)
//                        .padding(.vertical, 4)
//                        .background(Color.black)
//                        .cornerRadius(12)
                    }
                    
                    HStack(spacing: 8) {
                        Text(getDriverGender())
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.black)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                        
                        Button(action: {
                            // Handle phone call action
                            if let phoneURL = URL(string: "tel:\(getDriverPhone())") {
                                UIApplication.shared.open(phoneURL)
                            }
                        }) {
                            Text(getDriverPhone())
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.white)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(AppColors.primaryOrange)
                                .cornerRadius(8)
                        }
                    }
                }
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
    
    // MARK: - Driver Information Helper Functions
    private func getDriverImageUrl() -> String {
        return selectedVehicle?.driverInformation?.imageUrl ?? ""
    }
    
    private func getDriverName() -> String {
        return selectedVehicle?.driverInformation?.name ?? "1800limo Chauffeurs"
    }
    
    private func getDriverPhone() -> String {
        let isd = selectedVehicle?.driverInformation?.cellIsd ?? "+1"
        let number = selectedVehicle?.driverInformation?.cellNumber ?? "800546626"
        return "\(isd) \(number)"
    }
    
    private func getDriverRating() -> String {
        return selectedVehicle?.driverInformation?.starRating ?? "4.5"
    }
    
    private func getDriverGender() -> String {
        let gender = selectedVehicle?.driverInformation?.gender ?? "Male"
        // Show "LGBTQ" instead of "other" or "Other"
        if gender.lowercased() == "other" {
            return "LGBTQ"
        }
        return gender
    }
    
    private func getDriverDress() -> String {
        return selectedVehicle?.driverInformation?.dress ?? "Business Casual"
    }
    
    private func getDriverExperience() -> String {
        return selectedVehicle?.driverInformation?.experience ?? "20+ Years"
    }
    
    private func getDriverLanguages() -> String {
        return selectedVehicle?.driverInformation?.languages ?? "English"
    }
    
    private func getInsuranceLimit() -> String {
        return selectedVehicle?.driverInformation?.insuranceLimit ?? "$500,000"
    }
    
    private var vehicleDetailsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("VEHICLE DETAILS")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.gray)
            
            HStack(spacing: 12) {
                // Vehicle Image
                AsyncImage(url: URL(string: selectedVehicle?.vehicleImages.first ?? "")) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 80, height: 60)
                        .cornerRadius(8)
                } placeholder: {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.black.opacity(0.2))
                        .frame(width: 80, height: 60)
                        .overlay(
                            Image(systemName: "car.fill")
                                .font(.system(size: 32))
                                .foregroundColor(.gray)
                        )
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text(selectedVehicle?.name ?? "Mid-Size Sedan")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.black)
                    
                    HStack(spacing: 8) {
                        if let vehicleDetails = selectedVehicle?.vehicleDetails {
                            Text(vehicleDetails.make)
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.black)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                            
                            Text(vehicleDetails.model)
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.black)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                            
                            Text(vehicleDetails.year)
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.black)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                        } else {
                            Text("Vehicle Details")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.black)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.gray.opacity(0.15))
                                .cornerRadius(8)
                        }
                    }
                }
                
                Spacer()
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
    
    
    // MARK: - Outbound Special Instructions and Extra Stops Section
    private var outboundSpecialInstructionsAndExtraStopsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            
            // ✅ Outbound Special Instructions
            VStack(alignment: .leading, spacing: 8) {
                Text("SPECIAL INSTRUCTIONS / EXACT BUILDING NAME")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.orange)
                
                TextEditor(text: $specialInstructions)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.black)
                    .scrollContentBackground(.hidden) // ✅ Remove default white
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .frame(minHeight: 80)
                    .background(Color.gray.opacity(0.15)) // ✅ Apply your black
                    .cornerRadius(8)
                    .focused($focusedField, equals: .specialInstructions)
                    .id("specialInstructions")
            }
            
            // ✅ Outbound Extra Stops Section
            VStack(alignment: .leading, spacing: 12) {
                Text("EXTRA STOPS")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.black)
                
                if !extraStops.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(Array(extraStops.enumerated()), id: \.element.id) { index, stop in
                            ExtraStopRow(
                                stop: stop,
                                onRemove: { removeExtraStop(stop) },
                                onLocationSelected: { selectedStop in
                                    // Automatically call booking rates API when extra stop location is selected
                                    Task {
                                        await fetchBookingRates()
                                    }
                                },
                                validateStop: { stop in
                                    // Validate for outbound trip
                                    if let errorMessage = validateExtraStop(stop, isReturnTrip: false) {
                                        extraStopValidationError = errorMessage
                                        showInvalidLocationDialog = false
                                        return errorMessage
                                    }
                                    extraStopValidationError = nil
                                    return nil
                                }
                            )
                        }
                    }
                }
                
                if let extraStopValidationError {
                    Text(extraStopValidationError)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.red)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(6)
                }
                
                if !isOutboundExtraStopButtonEnabled {
                Text("Extra stop should be in the same country as pickup and drop-off.")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.red)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(6)
                }
                
                Button(action: {
                    addExtraStop()
                }) {
                    Text("Add Extra Stop")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background((isOutboundExtraStopButtonEnabled && extraStopValidationError == nil) ? AppColors.primaryOrange : AppColors.greenColor.opacity(0.4))
                        .cornerRadius(8)
                }
                .disabled(!isOutboundExtraStopButtonEnabled || extraStopValidationError != nil)
            }
        }
    }

    
    
    // MARK: - Booking Summary Section
    private var bookingSummarySection: some View {
        VStack(spacing: 16) {
            // Outbound Trip Section
            VStack(spacing: 8) {
                if selectedServiceType == "Round Trip" {
                    Text("OUTBOUND TRIP")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                
                HStack {
                    Text("SUB TOTAL")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                    Spacer()
                    Text("\(currencySymbol) \(String(format: "%.2f", subtotal))")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(AppColors.primaryOrange)
                }
                
                HStack {
                    Text("NO. OF VEHICLES")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                    Spacer()
                    Text("x \(numberOfVehicles)")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(AppColors.primaryOrange)
                }
                
                HStack {
                    Text("GRAND TOTAL")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.gray)
                    Spacer()
                    Text("\(currencySymbol) \(String(format: "%.2f", grandTotal))")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(AppColors.primaryOrange)
                }
            }
            
            // Return Trip Section (only for Round Trip and when return service type is also Round Trip)
            if selectedServiceType == "Round Trip" && selectedReturnServiceType == "Round Trip" {
                VStack(spacing: 8) {
                    Text("RETURN TRIP")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    HStack {
                        Text("SUB TOTAL")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.gray)
                        Spacer()
                        Text("\(currencySymbol) \(String(format: "%.2f", returnSubtotal))")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(AppColors.primaryOrange)
                    }
                    
                    HStack {
                        Text("NO. OF VEHICLES")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.gray)
                        Spacer()
                        Text("x \(numberOfVehicles)")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(AppColors.primaryOrange)
                    }
                    
                    HStack {
                        Text("GRAND TOTAL")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.gray)
                        Spacer()
                        Text("\(currencySymbol) \(String(format: "%.2f", returnGrandTotal))")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(AppColors.primaryOrange)
                    }
                }
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
    
    private var currencySymbol: String {
        return bookingRatesService.currency?.symbol ?? "$"
    }
    
    // MARK: - Create Reservation
    private func createReservation() async {
        // 🚨 CRITICAL FIX: Prevent duplicate API calls
        // Check if already loading - if so, return immediately
        let alreadyLoading = await MainActor.run {
            let isCurrentlyLoading = self.isLoading || self.createReservationService.isLoading
            if isCurrentlyLoading {
                print("⚠️ Duplicate call prevented - already processing reservation")
            } else {
                // Set loading state IMMEDIATELY to prevent duplicate calls
                self.isLoading = true
            }
            return isCurrentlyLoading
        }
        
        guard !alreadyLoading else {
            return
        }
        
        // Final safety check before any create/update API - validate and set field errors
        await MainActor.run {
            validateOutboundLocations()
            validateReturnLocations()
        }
        
        if let conflict = outboundLocationConflictReason() {
            print("❌ Create/update blocked (Outbound): \(conflict)")
            await MainActor.run {
                self.isLoading = false
            }
            return
        }
        if let conflict = returnLocationConflictReason() {
            print("❌ Create/update blocked (Return): \(conflict)")
            await MainActor.run {
                self.isLoading = false
            }
            return
        }
        
        if isEditMode {
            print("🚀 Updating reservation in edit mode...")
            await updateReservation()
        } else if isRepeatMode {
            print("🚀 Duplicating reservation in repeat mode...")
            await duplicateReservation()
            await MainActor.run {
                self.isLoading = false
            }
        } else {
            print("🚀 Creating new reservation...")
            await createNewReservation()
            await MainActor.run {
                self.isLoading = false
            }
        }
    }
    
    private func createNewReservation() async {
        // Build the create reservation request
        let request = await buildCreateReservationRequest()
        
        // Call the API and get the result directly
        let result = await createReservationService.createReservation(request: request)
        
        // Handle response
        print("🔍 DEBUGGING SUCCESS RESPONSE:")
        print("  success: \(result.success)")
        print("  data: \(result.data?.reservationId ?? 0)")
        print("  error: \(result.error ?? "nil")")
        
        if result.success, let reservationData = result.data {
            print("✅ Reservation created successfully: \(reservationData.reservationId)")
            print("✅ Order ID: \(reservationData.orderId)")
            
            // Show success screen
            await MainActor.run {
                print("🔄 Setting success screen data on main thread...")
                self.successData = reservationData
                self.successMessage = "Reservation has been created successfully."
                self.successCurrency = result.currency
                self.showSuccessScreen = true
                print("✅ Success screen should now be visible: \(self.showSuccessScreen)")
                print("✅ Success data set: \(self.successData?.reservationId ?? 0)")
            }
        } else if let errorMessage = result.error {
            print("❌ Reservation creation failed: \(errorMessage)")
            // Loading state will be reset by caller
            // TODO: Show error alert
        } else {
            print("❌ No reservation data and no error message - this shouldn't happen")
            // Loading state will be reset by caller
        }
    }

    private func duplicateReservation() async {
        let request = await buildCreateReservationRequest()
        
        let result = await createReservationService.duplicateReservation(request: request)
        
        print("🔍 DEBUGGING DUPLICATE RESPONSE:")
        print("  success: \(result.success)")
        print("  data: \(result.data?.reservationId ?? 0)")
        print("  error: \(result.error ?? "nil")")
        
        if result.success, let reservationData = result.data {
            print("✅ Reservation duplicated successfully: \(reservationData.reservationId)")
            await MainActor.run {
                self.successData = reservationData
                self.successMessage = "Reservation has been duplicated successfully."
                self.successCurrency = result.currency
                self.showSuccessScreen = true
            }
        } else if let errorMessage = result.error {
            print("❌ Duplicate reservation failed: \(errorMessage)")
            // Loading state will be reset by caller
        } else {
            print("❌ Duplicate reservation returned no data and no error")
            // Loading state will be reset by caller
        }
    }
    
    private func updateReservation() async {
        // Show loader
        DispatchQueue.main.async {
            self.isLoading = true
        }
        
        // Build the edit reservation request
        let request = await buildEditReservationRequest()
        
        // Call the edit API and get the result directly
        let result = await editReservationService.updateReservation(request: request)
        
        // Handle response
        print("🔍 DEBUGGING EDIT SUCCESS RESPONSE:")
        print("  success: \(result.success)")
        print("  data: \(result.data?.reservationId ?? "nil")")
        print("  error: \(result.error ?? "nil")")
        
        DispatchQueue.main.async {
            self.isLoading = false
            
            if result.success, let updateData = result.data {
                print("✅ Reservation updated successfully: \(updateData.reservationId)")
                print("🔄 Navigating back to booking list...")
                
                // Navigate back to booking list instead of showing success screen
                self.dismiss()
            } else {
                print("❌ Failed to update reservation: \(result.error ?? "Unknown error")")
                // Handle error - you might want to show an alert
                print("❌ Edit reservation failed: \(result.error ?? "Unknown error")")
            }
        }
    }
    
    private func buildCreateReservationRequest() async -> CreateReservationRequest {
        // Map service type
        let serviceType = mapServiceTypeToAPI(selectedServiceType ?? "One Way")
        
        // Map transfer type
        let transferType = mapTransferTypeToAPI(selectedTransferType ?? "City to City")
        let returnTransferType = mapTransferTypeToAPI(selectedReturnTransferType ?? "City to City")
        
        // Get coordinates once and store them
        let pickupCoord = self.getPickupCoordinate()
        let dropoffCoord = self.getDropoffCoordinate()
        
        // Calculate distance and time once
        let journeyDistance = Int(await calculateDistance())
        let journeyTime = Int(await calculateJourneyTime())
        
        // Calculate return journey distance and time for round trip
        let returnJourneyDistance: Int
        let returnJourneyTime: Int
        if serviceType == "round_trip" {
            // For round trip, return journey should be calculated from dropoff to pickup
            returnJourneyDistance = Int(await calculateReturnDistance())
            returnJourneyTime = Int(await calculateReturnJourneyTime())
        } else {
            returnJourneyDistance = 0
            returnJourneyTime = 0
        }
        
        print("🔍 COORDINATE DEBUG:")
        print("  Pickup Coord: \(pickupCoord?.latitude ?? 0), \(pickupCoord?.longitude ?? 0)")
        print("  Dropoff Coord: \(dropoffCoord?.latitude ?? 0), \(dropoffCoord?.longitude ?? 0)")
        print("  Pickup Airport Coord: \(pickupAirportCoordinate?.latitude ?? 0), \(pickupAirportCoordinate?.longitude ?? 0)")
        print("  Dropoff Airport Coord: \(dropoffAirportCoordinate?.latitude ?? 0), \(dropoffAirportCoordinate?.longitude ?? 0)")
        print("  Journey Distance: \(journeyDistance)")
        
        // Get extra stops
        let extraStopsRequests = extraStops.compactMap { stop -> ExtraStopRequest? in
            guard !stop.address.isEmpty,
                  let coordinate = stop.coordinate else {
                return nil
            }
            return ExtraStopRequest(
                address: stop.address,
                latitude: coordinate.latitude,
                longitude: coordinate.longitude,
                rate: "out_town",
                bookingInstructions: ""
            )
        }
        
        // Build shares array from rates
        let sharesArray = SharesArrayBuilder.buildSharesArray(
            from: bookingRatesService.ratesData?.rateArray ?? BookingRateArray(
                allInclusiveRates: [:],
                amenities: [:],
                taxes: [:],
                misc: [:]
            ),
            serviceType: serviceType,
            numberOfHours: getNoOfHoursForService(serviceType: serviceType),
            accountType: "individual",
            returnGrandTotal: nil
        )
        
        // Build return shares array for round trip bookings
        let returnSharesArray: SharesArray?
        if serviceType == "round_trip", let returnRateArray = bookingRatesService.ratesData?.retrunRateArray {
            returnSharesArray = SharesArrayBuilder.buildSharesArray(
                from: returnRateArray,
                serviceType: serviceType,
                numberOfHours: getNoOfHoursForService(serviceType: serviceType),
                accountType: "individual",
                returnGrandTotal: nil
            )
        } else {
            returnSharesArray = nil
        }
        
        // Get selected vehicle details
        let vehicleId = selectedVehicle?.id ?? 1
        let vehicleSeats = "\(selectedVehicle?.passenger ?? 4)"
        
        // Get driver information from selected vehicle
        let driverInfo = selectedVehicle?.driverInformation
        let driverName = driverInfo?.name ?? "1800LIMO Chauffeurs"
        let driverGender = driverInfo?.gender.lowercased() ?? "male"
        let driverCell = driverInfo?.cellNumber ?? "8005466266"
        let driverCellIsdRaw = driverInfo?.cellIsd ?? "+1"
        let driverCellIsd = driverCellIsdRaw.replacingOccurrences(of: "+", with: "")  // Remove "+" to match web format
        let driverCellCountry = "us" // Default country
        let driverEmail = driverInfo?.email ?? ""
        let driverPhoneType = "" // Not available in driver info
        let driverId = driverInfo?.id?.description ?? ""
        let affiliateId = selectedVehicle?.affiliateId?.description ?? ""
        
        // Get meet & greet choice
        let meetGreetChoice = meetGreetChoices.first?.id ?? 1
        let meetGreetChoiceName = meetGreetChoices.first?.message ?? "Driver - Text/call when on location"
        
        // Get return meet & greet choice
        let returnMeetGreetChoice = meetGreetChoices.first(where: { $0.message == selectedReturnMeetAndGreet })?.id ?? meetGreetChoice
        let returnMeetGreetChoiceName = selectedReturnMeetAndGreet ?? meetGreetChoiceName
        
        // Get airline details
        let pickupAirline = selectedPickupAirline ?? (airlineService.airlines.first?.id.description ?? "1")
        let pickupAirlineName = airlineService.airlines.first(where: { $0.id == Int(pickupAirline) })?.fullDisplayName ?? ""
        let pickupAirlineData = airlineService.airlines.first(where: { $0.id == Int(pickupAirline) })
        let pickupAirlineOption = pickupAirlineData.map { AirlineOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            country: $0.country ?? "",
            formattedName: $0.fullDisplayName
        ) }
        
        let dropoffAirline = selectedDropoffAirline ?? (airlineService.airlines.first?.id.description ?? "1")
        let dropoffAirlineName = airlineService.airlines.first(where: { $0.id == Int(dropoffAirline) })?.fullDisplayName ?? ""
        let dropoffAirlineData = airlineService.airlines.first(where: { $0.id == Int(dropoffAirline) })
        let dropoffAirlineOption = dropoffAirlineData.map { AirlineOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            country: $0.country ?? "",
            formattedName: $0.fullDisplayName
        ) }
        
        // Get return airline details from return trip fields
        let returnPickupAirline = selectedReturnPickupAirline ?? (airlineService.airlines.first?.id.description ?? "1")
        let returnPickupAirlineName = airlineService.airlines.first(where: { $0.id == Int(returnPickupAirline) })?.fullDisplayName ?? ""
        let returnPickupAirlineData = airlineService.airlines.first(where: { $0.id == Int(returnPickupAirline) })
        let returnPickupAirlineOption = returnPickupAirlineData.map { AirlineOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            country: $0.country ?? "",
            formattedName: $0.fullDisplayName
        ) }
        
        let returnDropoffAirline = selectedReturnDropoffAirline ?? (airlineService.airlines.first?.id.description ?? "1")
        let returnDropoffAirlineName = airlineService.airlines.first(where: { $0.id == Int(returnDropoffAirline) })?.fullDisplayName ?? ""
        let returnDropoffAirlineData = airlineService.airlines.first(where: { $0.id == Int(returnDropoffAirline) })
        let returnDropoffAirlineOption = returnDropoffAirlineData.map { AirlineOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            country: $0.country ?? "",
            formattedName: $0.fullDisplayName
        ) }
        
        // Get airport details as AirportOption objects
        print("🔍 AIRPORT OPTION DEBUG:")
        print("  Selected Pickup Airport: \(selectedPickupAirport ?? "nil")")
        print("  Selected Dropoff Airport: \(selectedDropoffAirport ?? "nil")")
        print("  Available airports count: \(airportService.airports.count)")
        
        let pickupAirportData = airportService.airports.first(where: { $0.displayName == selectedPickupAirport })
        print("  Pickup Airport Data Found: \(pickupAirportData != nil)")
        if let pickupData = pickupAirportData {
            print("  Pickup Airport ID: \(pickupData.id), Code: \(pickupData.code), Name: \(pickupData.name)")
        }
        
        let pickupAirportOption = pickupAirportData.map { AirportOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            city: $0.city,
            country: $0.country,
            lat: $0.lat ?? 0.0,
            long: $0.long ?? 0.0,
            formattedName: $0.displayName
        ) }
        
        let dropoffAirportData = airportService.airports.first(where: { $0.displayName == selectedDropoffAirport })
        print("  Dropoff Airport Data Found: \(dropoffAirportData != nil)")
        if let dropoffData = dropoffAirportData {
            print("  Dropoff Airport ID: \(dropoffData.id), Code: \(dropoffData.code), Name: \(dropoffData.name)")
        }
        
        let dropoffAirportOption = dropoffAirportData.map { AirportOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            city: $0.city,
            country: $0.country,
            lat: $0.lat ?? 0.0,
            long: $0.long ?? 0.0,
            formattedName: $0.displayName
        ) }
        
        print("  Pickup Airport Option Created: \(pickupAirportOption != nil)")
        print("  Dropoff Airport Option Created: \(dropoffAirportOption != nil)")
        
        // Get airport details with validation for transfer type
        let pickupAirportId: Int
        let pickupAirportName: String
        let pickupAirportLat: Double
        let pickupAirportLng: Double
        
        if transferType.contains("airport_to") || transferType == "airport_to_airport" {
            // For airport-based pickup, ensure airport is selected
            if let selectedAirport = selectedPickupAirport, !selectedAirport.isEmpty {
                print("🔍 AIRPORT PICKUP DEBUG: Looking for airport '\(selectedAirport)'")
                print("🔍 AIRPORT PICKUP DEBUG: Available airports count: \(airportService.airports.count)")
                
                // Try multiple ways to find the airport
                let foundAirport = airportService.airports.first { airport in
                    airport.displayName == selectedAirport || 
                    airport.name == selectedAirport ||
                    airport.code == selectedAirport
                }
                
                if let airport = foundAirport {
                    pickupAirportId = airport.id
                    pickupAirportName = selectedAirport
                    pickupAirportLat = pickupAirportCoordinate?.latitude ?? (airport.lat ?? 0.0)
                    pickupAirportLng = pickupAirportCoordinate?.longitude ?? (airport.long ?? 0.0)
                    print("✅ AIRPORT PICKUP: Found airport '\(selectedAirport)' with ID \(pickupAirportId)")
                } else {
                    pickupAirportId = 0
                    pickupAirportName = selectedAirport
                    pickupAirportLat = pickupAirportCoordinate?.latitude ?? 0.0
                    pickupAirportLng = pickupAirportCoordinate?.longitude ?? 0.0
                    print("❌ AIRPORT PICKUP ERROR: Airport '\(selectedAirport)' not found in airportService!")
                    print("  - Available airports: \(airportService.airports.map { $0.displayName }.prefix(5))")
                }
            } else {
                // For airport-based pickup with no airport selected, this is an error state
                pickupAirportId = 0
                pickupAirportName = ""
                pickupAirportLat = 0.0
                pickupAirportLng = 0.0
                print("❌ AIRPORT PICKUP ERROR: Transfer type requires airport pickup but no airport selected!")
                print("  - This will result in invalid payload - airport pickup required but missing")
            }
        } else {
            // For city-based pickup, use regular coordinates and clear airport data
            pickupAirportId = 0
            pickupAirportName = ""
            pickupAirportLat = pickupCoord?.latitude ?? 0.0
            pickupAirportLng = pickupCoord?.longitude ?? 0.0
            print("✅ CITY PICKUP: Using city coordinates, airport data cleared")
        }
        
        let dropoffAirportId: Int
        let dropoffAirportName: String
        let dropoffAirportLat: Double
        let dropoffAirportLng: Double
        
        if transferType.contains("_to_airport") || transferType == "airport_to_airport" {
            // For airport-based dropoff, ensure airport is selected
            if let selectedAirport = selectedDropoffAirport, !selectedAirport.isEmpty {
                print("🔍 AIRPORT DROPOFF DEBUG: Looking for airport '\(selectedAirport)'")
                print("🔍 AIRPORT DROPOFF DEBUG: Available airports count: \(airportService.airports.count)")
                
                // Try multiple ways to find the airport
                let foundAirport = airportService.airports.first { airport in
                    airport.displayName == selectedAirport || 
                    airport.name == selectedAirport ||
                    airport.code == selectedAirport
                }
                
                if let airport = foundAirport {
                    dropoffAirportId = airport.id
                    dropoffAirportName = selectedAirport
                    dropoffAirportLat = dropoffAirportCoordinate?.latitude ?? (airport.lat ?? 0.0)
                    dropoffAirportLng = dropoffAirportCoordinate?.longitude ?? (airport.long ?? 0.0)
                    print("✅ AIRPORT DROPOFF: Found airport '\(selectedAirport)' with ID \(dropoffAirportId)")
                } else {
                    dropoffAirportId = 0
                    dropoffAirportName = selectedAirport
                    dropoffAirportLat = dropoffAirportCoordinate?.latitude ?? 0.0
                    dropoffAirportLng = dropoffAirportCoordinate?.longitude ?? 0.0
                    print("❌ AIRPORT DROPOFF ERROR: Airport '\(selectedAirport)' not found in airportService!")
                    print("  - Available airports: \(airportService.airports.map { $0.displayName }.prefix(5))")
                }
            } else {
                // For airport-based dropoff with no airport selected, this is an error state
                dropoffAirportId = 0
                dropoffAirportName = ""
                dropoffAirportLat = 0.0
                dropoffAirportLng = 0.0
                print("❌ AIRPORT DROPOFF ERROR: Transfer type requires airport dropoff but no airport selected!")
                print("  - This will result in invalid payload - airport dropoff required but missing")
            }
        } else {
            // For city-based dropoff, use regular coordinates and clear airport data
            dropoffAirportId = 0
            dropoffAirportName = ""
            dropoffAirportLat = dropoffCoord?.latitude ?? 0.0
            dropoffAirportLng = dropoffCoord?.longitude ?? 0.0
            print("✅ CITY DROPOFF: Using city coordinates, airport data cleared")
        }
        
        // Get return trip airport details
        let returnPickupAirportId = selectedReturnPickupAirport?.isEmpty == false ?
            airportService.airports.first(where: { $0.displayName == selectedReturnPickupAirport })?.id ?? 0 : 0
        let returnPickupAirportName = selectedReturnPickupAirport ?? ""
        let returnPickupAirportLat = returnPickupAirportCoordinate?.latitude ?? (returnPickupCoordinate?.latitude ?? 0.0)
        let returnPickupAirportLng = returnPickupAirportCoordinate?.longitude ?? (returnPickupCoordinate?.longitude ?? 0.0)
        
        let returnDropoffAirportId = selectedReturnDropoffAirport?.isEmpty == false ?
            airportService.airports.first(where: { $0.displayName == selectedReturnDropoffAirport })?.id ?? 0 : 0
        let returnDropoffAirportName = selectedReturnDropoffAirport ?? ""
        let returnDropoffAirportLat = returnDropoffAirportCoordinate?.latitude ?? (returnDropoffCoordinate?.latitude ?? 0.0)
        let returnDropoffAirportLng = returnDropoffAirportCoordinate?.longitude ?? (returnDropoffCoordinate?.longitude ?? 0.0)
        
        print("🔍 AIRPORT DETAILS:")
        print("  Pickup Airport ID: \(pickupAirportId)")
        print("  Pickup Airport Name: \(pickupAirportName)")
        print("  Pickup Airport Lat: \(pickupAirportLat)")
        print("  Pickup Airport Lng: \(pickupAirportLng)")
        print("  Dropoff Airport ID: \(dropoffAirportId)")
        print("  Dropoff Airport Name: \(dropoffAirportName)")
        print("  Dropoff Airport Lat: \(dropoffAirportLat)")
        print("  Dropoff Airport Lng: \(dropoffAirportLng)")
        print("🔍 RETURN TRIP AIRPORT DETAILS:")
        print("  Return Pickup Airport ID: \(returnPickupAirportId)")
        print("  Return Pickup Airport Name: \(returnPickupAirportName)")
        print("  Return Pickup Airport Lat: \(returnPickupAirportLat)")
        print("  Return Pickup Airport Lng: \(returnPickupAirportLng)")
        print("  Return Dropoff Airport ID: \(returnDropoffAirportId)")
        print("  Return Dropoff Airport Name: \(returnDropoffAirportName)")
        print("  Return Dropoff Airport Lat: \(returnDropoffAirportLat)")
        print("  Return Dropoff Airport Lng: \(returnDropoffAirportLng)")
        
        // Format dates and times for API
        let pickupDate: String
        let pickupTime: String
        let returnPickupDate: String
        let returnPickupTime: String
        
        // Always convert from UI format to ensure we use the user-selected time
        // Don't use rideData.pickupTime directly as it may be outdated if user changed the time
        pickupDate = parseDateFromUI(travelDate).map { formatDateForAPI($0) } ?? travelDate
        // Use selectedTime directly or parse from pickupTime string
        pickupTime = formatTimeForAPI(selectedTime)
        returnPickupDate = selectedServiceType == "Round Trip" ? (parseDateFromUI(returnTravelDate).map { formatDateForAPI($0) } ?? returnTravelDate) : ""
        returnPickupTime = selectedServiceType == "Round Trip" ? (parseTimeFromUI(self.returnPickupTime).map { formatTimeForAPI($0) } ?? self.returnPickupTime) : ""
        
        print("🔍 BUILDING CREATE RESERVATION REQUEST:")
        print("  Service Type: \(serviceType)")
        print("  Transfer Type: \(transferType)")
        print("  Selected Transfer Type (UI): \(selectedTransferType ?? "nil")")
        print("  Pickup Address: \(pickupAddress)")
        print("  Dropoff Address: \(dropoffAddress)")
        print("  Pickup Airport: \(selectedPickupAirport ?? "None")")
        print("  Dropoff Airport: \(selectedDropoffAirport ?? "None")")
        print("  Pickup Airport ID: \(pickupAirportId)")
        print("  Dropoff Airport ID: \(dropoffAirportId)")
        print("  Pickup Airport Name: \(pickupAirportName)")
        print("  Dropoff Airport Name: \(dropoffAirportName)")
        print("  Grand Total: \(grandTotal)")
        print("  Sub Total: \(subtotal)")
        print("  Journey Distance: \(Int(await calculateDistance()))")
        
        // Special debugging for the specific issue
        if let rideData = rideData {
            print("🔍 RIDEDATA DEBUG (from ScheduleRideBottomSheet):")
            print("  - rideData.pickupType: \(rideData.pickupType)")
            print("  - rideData.dropoffType: \(rideData.dropoffType)")
            print("  - rideData.selectedPickupAirport: \(rideData.selectedPickupAirport)")
            print("  - rideData.selectedDestinationAirport: \(rideData.selectedDestinationAirport)")
            print("  - rideData.pickupLocation: \(rideData.pickupLocation)")
            print("  - rideData.destinationLocation: \(rideData.destinationLocation)")
        } else {
            print("🔍 RIDEDATA DEBUG: No rideData (not from ScheduleRideBottomSheet)")
        }
        print("🔍 DRIVER INFORMATION:")
        print("  Driver Name: \(driverName)")
        print("  Driver Gender: \(driverGender)")
        print("  Driver Cell: \(driverCell)")
        print("  Driver Cell ISD: \(driverCellIsd)")
        print("  Driver Email: \(driverEmail)")
        print("  Driver ID: \(driverId)")
        print("  Affiliate ID: \(affiliateId)")
        
        // Break down the large initializer into smaller parts to avoid compiler timeout
        let numberOfHoursValue = getNoOfHoursForServiceInt(serviceType: serviceType)
        print("🚀 PAYLOAD DEBUG - numberOfHours being sent: \(numberOfHoursValue)")
        print("🚀 PAYLOAD DEBUG - selectedHours at payload time: '\(selectedHours)'")
        
        // Ensure airports are loaded before validation
        if airportService.airports.isEmpty {
            print("⚠️ WARNING: airportService.airports is empty - attempting to fetch airports")
            await airportService.fetchAllAirports()
        }
        
        // Validate airport fields based on transfer type
        if transferType.contains("airport") {
            print("🔍 VALIDATING AIRPORT FIELDS FOR TRANSFER TYPE: \(transferType)")
            print("🔍 AIRPORT SERVICE STATUS: \(airportService.airports.count) airports loaded")
            
            if transferType.contains("airport_to") || transferType == "airport_to_airport" {
                if selectedPickupAirport?.isEmpty != false {
                    print("❌ CRITICAL ERROR: Transfer type requires airport pickup but no airport selected!")
                    print("  - Selected Pickup Airport: '\(selectedPickupAirport ?? "nil")'")
                    print("  - Transfer Type: \(transferType)")
                    print("  - This will cause incorrect payload generation")
                    print("  - User must select a pickup airport before booking")
                } else {
                    print("✅ Pickup airport validation passed: \(selectedPickupAirport ?? "nil")")
                }
            }
            
            if transferType.contains("_to_airport") || transferType == "airport_to_airport" {
                if selectedDropoffAirport?.isEmpty != false {
                    print("❌ CRITICAL ERROR: Transfer type requires airport dropoff but no airport selected!")
                    print("  - Selected Dropoff Airport: '\(selectedDropoffAirport ?? "nil")'")
                    print("  - Transfer Type: \(transferType)")
                    print("  - This will cause incorrect payload generation")
                    print("  - User must select a dropoff airport before booking")
                } else {
                    print("✅ Dropoff airport validation passed: \(selectedDropoffAirport ?? "nil")")
                }
            }
        }
        
        // Additional validation for all transfer types
        print("🔍 FINAL VALIDATION SUMMARY:")
        print("  - Transfer Type: \(transferType)")
        print("  - Pickup Airport ID: \(pickupAirportId)")
        print("  - Dropoff Airport ID: \(dropoffAirportId)")
        print("  - Pickup Airport Name: '\(pickupAirportName)'")
        print("  - Dropoff Airport Name: '\(dropoffAirportName)'")
        
        let basicInfo = (
            serviceType: serviceType,
            transferType: transferType,
            returnTransferType: returnTransferType,
            numberOfHours: numberOfHoursValue,
            accountType: "individual",
            changeIndividualData: false
        )
        
        let passengerInfo = (
            passengerName: getPassengerName(),
            passengerEmail: getPassengerEmail(),
            passengerCell: getPassengerCell(),
            passengerCellIsd: getPassengerCellIsd(),
            passengerCellCountry: getPassengerCellCountry(),
            totalPassengers: rideData?.noOfPassenger ?? 1,
            luggageCount: rideData?.noOfLuggage ?? 1
        )
        
        let bookingInfo = (
            bookingInstructions: specialInstructions,
            returnBookingInstructions: returnSpecialInstructions,
            affiliateType: "affiliate",
            affiliateId: affiliateId,
            loseAffiliateName: "",
            loseAffiliatePhone: "",
            loseAffiliatePhoneIsd: "+1",
            loseAffiliatePhoneCountry: "us",
            loseAffiliateEmail: ""
        )
        
        let vehicleInfo = (
            vehicleType: "",
            vehicleTypeName: "",
            vehicleId: vehicleId,
            vehicleMake: "",
            vehicleMakeName: "",
            vehicleModel: "",
            vehicleModelName: "",
            vehicleYear: "",
            vehicleYearName: "",
            vehicleColor: "",
            vehicleColorName: "",
            vehicleLicensePlate: "",
            vehicleSeats: vehicleSeats
        )
        
        let driverInfoTuple = (
            driverId: driverId,
            driverName: driverName,
            driverGender: driverGender,
            driverCell: driverCell,
            driverCellIsd: driverCellIsd,
            driverCellCountry: driverCellCountry,
            driverEmail: driverEmail,
            driverPhoneType: driverPhoneType,
            driverImageId: "",
            vehicleImageId: ""
        )
        
        let meetGreetInfo = (
            meetGreetChoices: meetGreetChoice,
            meetGreetChoicesName: meetGreetChoiceName,
            numberOfVehicles: numberOfVehicles
        )
        
        let outboundCruisePickupTypes: Set<String> = ["Cruise Port to City", "Cruise Port to Airport"]
        let outboundCruiseDropoffTypes: Set<String> = ["City to Cruise Port", "Airport to Cruise Port"]
        let transferTypeValue = selectedTransferType ?? ""
        let shouldIncludeOutboundCruiseDetails = outboundCruisePickupTypes.contains(transferTypeValue) || outboundCruiseDropoffTypes.contains(transferTypeValue)
        let outboundCruisePortValue = shouldIncludeOutboundCruiseDetails ? cruisePort : ""
        let outboundCruiseNameValue = shouldIncludeOutboundCruiseDetails ? cruiseShipName : ""
        let outboundCruiseTimeValue = (shouldIncludeOutboundCruiseDetails && !shipArrivalTime.isEmpty) ?
            (parseTimeFromUI(shipArrivalTime).map { formatTimeForAPI($0) } ?? shipArrivalTime) : ""
        let shouldIncludeReturnCruiseDetails = selectedServiceType == "Round Trip" && shouldIncludeOutboundCruiseDetails
        // For return trips where pickup is cruise port, use returnPickupAddress if returnCruisePort is empty
        let returnTransferTypeValue = selectedReturnTransferType ?? ""
        let returnPickupIsCruisePort = returnTransferTypeValue == "City to Cruise Port" || returnTransferTypeValue == "Airport to Cruise Port"
        let returnCruisePortValue = shouldIncludeReturnCruiseDetails ? (returnCruisePort.isEmpty && returnPickupIsCruisePort ? returnPickupAddress : returnCruisePort) : ""
        let returnCruiseNameValue = shouldIncludeReturnCruiseDetails ? returnCruiseShipName : ""
        let returnCruiseTimeValue = (shouldIncludeReturnCruiseDetails && !returnShipArrivalTime.isEmpty) ?
            (parseTimeFromUI(returnShipArrivalTime).map { formatTimeForAPI($0) } ?? returnShipArrivalTime) : ""
        
        let pickupInfo = (
            pickupDate: pickupDate,
            pickupTime: pickupTime,
            extraStops: extraStopsRequests,
            pickup: pickupAddress,
            pickupLatitude: pickupCoord?.latitude.description ?? "0",
            pickupLongitude: pickupCoord?.longitude.description ?? "0",
            pickupAirportOption: pickupAirportOption,
            pickupAirport: pickupAirportId,
            pickupAirportName: pickupAirportName,
            pickupAirportLatitude: pickupAirportLat,
            pickupAirportLongitude: pickupAirportLng,
            pickupAirlineOption: pickupAirlineOption,
            pickupAirline: Int(pickupAirline) ?? 1,
            pickupAirlineName: pickupAirlineName,
            pickupFlight: pickupFlightNumber,
            originAirportCity: originAirportCity,
            cruisePort: outboundCruisePortValue,
            cruiseName: outboundCruiseNameValue,
            cruiseTime: outboundCruiseTimeValue
        )
        
        let dropoffInfo = (
            dropoff: dropoffAddress,
            dropoffLatitude: dropoffCoord?.latitude.description ?? "",
            dropoffLongitude: dropoffCoord?.longitude.description ?? "",
            dropoffAirportOption: dropoffAirportOption,
            dropoffAirport: dropoffAirportId,
            dropoffAirportName: dropoffAirportName,
            dropoffAirportLatitude: dropoffAirportLat,
            dropoffAirportLongitude: dropoffAirportLng,
            dropoffAirlineOption: dropoffAirlineOption,
            dropoffAirline: Int(dropoffAirline) ?? 1,
            dropoffAirlineName: dropoffAirlineName,
            dropoffFlight: dropoffFlightNumber
        )
        
        let returnInfo = (
            returnMeetGreetChoices: returnMeetGreetChoice,
            returnMeetGreetChoicesName: returnMeetGreetChoiceName,
            returnPickupDate: returnPickupDate,
            returnPickupTime: returnPickupTime,
            returnExtraStops: returnExtraStops.compactMap { stop -> ExtraStopRequest? in
                guard !stop.address.isEmpty,
                      let coordinate = stop.coordinate else {
                    return nil
                }
                return ExtraStopRequest(
                    address: stop.address,
                    latitude: coordinate.latitude,
                    longitude: coordinate.longitude,
                    rate: "out_town",
                    bookingInstructions: stop.bookingInstructions
                )
            },
            // Return pickup from return trip fields
            returnPickup: returnPickupAddress,
            returnPickupLatitude: returnPickupCoordinate?.latitude.description ?? "",
            returnPickupLongitude: returnPickupCoordinate?.longitude.description ?? "",
            returnPickupAirportOption: returnPickupAirportId > 0 ? airportService.airports.first(where: { $0.id == returnPickupAirportId }).map { AirportOption(
                id: $0.id,
                code: $0.code,
                name: $0.name,
                city: $0.city,
                country: $0.country,
                lat: $0.lat ?? 0.0,
                long: $0.long ?? 0.0,
                formattedName: $0.displayName
            ) } : nil,
            returnPickupAirport: returnPickupAirportId,
            returnPickupAirportName: returnPickupAirportName,
            returnPickupAirportLatitude: returnPickupAirportLat,
            returnPickupAirportLongitude: returnPickupAirportLng,
            returnPickupAirlineOption: returnPickupAirlineOption,
            returnPickupAirline: Int(returnPickupAirline) ?? 1,
            returnPickupAirlineName: returnPickupAirlineName,
            returnPickupFlight: returnPickupFlightNumber,
            returnCruisePort: returnCruisePortValue,
            returnCruiseName: returnCruiseNameValue,
            returnCruiseTime: returnCruiseTimeValue,
            // Return dropoff from return trip fields
            returnDropoff: returnDropoffAddress,
            returnDropoffLatitude: returnDropoffCoordinate?.latitude.description ?? "",
            returnDropoffLongitude: returnDropoffCoordinate?.longitude.description ?? "",
            returnDropoffAirportOption: returnDropoffAirportId > 0 ? airportService.airports.first(where: { $0.id == returnDropoffAirportId }).map { AirportOption(
                id: $0.id,
                code: $0.code,
                name: $0.name,
                city: $0.city,
                country: $0.country,
                lat: $0.lat ?? 0.0,
                long: $0.long ?? 0.0,
                formattedName: $0.displayName
            ) } : nil,
            returnDropoffAirport: returnDropoffAirportId,
            returnDropoffAirportName: returnDropoffAirportName,
            returnDropoffAirportLatitude: returnDropoffAirportLat,
            returnDropoffAirportLongitude: returnDropoffAirportLng,
            returnDropoffAirlineOption: returnDropoffAirlineOption,
            returnDropoffAirline: Int(returnDropoffAirline) ?? 1,
            returnDropoffAirlineName: returnDropoffAirlineName,
            returnDropoffFlight: returnDropoffFlightNumber
        )
        
        let duplicateReservationId = isRepeatMode ? (repeatBookingId.map { String($0) } ?? "") : ""
        let updateTypeValue = isRepeatMode ? (isRoundTripFlow ? "round" : (isReturnFlow ? "return" : "repeat")) : ""
        
        let additionalInfo = (
            driverLanguages: [1] as [Int],
            driverDresses: [] as [String],
            amenities: [] as [String],
            chargedAmenities: [] as [String],
            journeyDistance: journeyDistance,
            journeyTime: journeyTime,
            returnJourneyDistance: returnJourneyDistance,
            returnJourneyTime: returnJourneyTime,
            reservationId: duplicateReservationId,
            updateType: updateTypeValue,
            departingAirportCity: returnOriginAirportCity,
            currency: "USD",
            isMasterVehicle: selectedVehicle?.isMasterVehicle ?? false,
            proceed: true
        )
        
        let rateInfo = (
            rateArray: bookingRatesService.ratesData?.rateArray ?? BookingRateArray(
                allInclusiveRates: [:],
                amenities: [:],
                taxes: [:],
                misc: [:]
            ),
            grandTotal: grandTotal,
            subTotal: subtotal,
            minRateInvolved: false,
            sharesArray: sharesArray
        )
        
        // Calculate return rates (for round trip, return journey might have different rates)
        let returnSubTotal: Double?
        let returnGrandTotal: Double?
        if serviceType == "round_trip", let returnShares = returnSharesArray {
            returnSubTotal = returnShares.grandTotal
            returnGrandTotal = returnShares.grandTotal
        } else {
            returnSubTotal = nil
            returnGrandTotal = nil
        }
        
        let returnRateInfo = (
            returnRateArray: serviceType == "round_trip" ? bookingRatesService.ratesData?.retrunRateArray : nil,
            returnSubTotal: returnSubTotal,
            returnGrandTotal: returnGrandTotal,
            returnSharesArray: returnSharesArray,
            fboAddress: "",
            fboName: "",
            returnFboAddress: "",
            returnFboName: ""
        )
        
        let finalInfo = (
            returnAffiliateType: "affiliate",
            returnDistance: returnJourneyDistance,
            returnVehicleId: vehicleId,
            noOfHours: getNoOfHoursForService(serviceType: serviceType)
        )
        
        return CreateReservationRequest(
            // Basic Info
            serviceType: basicInfo.serviceType,
             transferType: basicInfo.transferType,
            returnTransferType: basicInfo.returnTransferType,
            numberOfHours: basicInfo.numberOfHours,
            accountType: basicInfo.accountType,
            changeIndividualData: basicInfo.changeIndividualData,
            
            // Passenger Info
            passengerName: passengerInfo.passengerName,
            passengerEmail: passengerInfo.passengerEmail,
            passengerCell: passengerInfo.passengerCell,
            passengerCellIsd: passengerInfo.passengerCellIsd,
            passengerCellCountry: passengerInfo.passengerCellCountry,
            totalPassengers: passengerInfo.totalPassengers,
            luggageCount: passengerInfo.luggageCount,
            
            // Booking Info
            bookingInstructions: bookingInfo.bookingInstructions,
            returnBookingInstructions: bookingInfo.returnBookingInstructions,
            affiliateType: bookingInfo.affiliateType,
            affiliateId: bookingInfo.affiliateId,
            loseAffiliateName: bookingInfo.loseAffiliateName,
            loseAffiliatePhone: bookingInfo.loseAffiliatePhone,
            loseAffiliatePhoneIsd: bookingInfo.loseAffiliatePhoneIsd,
            loseAffiliatePhoneCountry: bookingInfo.loseAffiliatePhoneCountry,
            loseAffiliateEmail: bookingInfo.loseAffiliateEmail,
            
            // Vehicle Info
            vehicleType: vehicleInfo.vehicleType,
            vehicleTypeName: vehicleInfo.vehicleTypeName,
            vehicleId: vehicleInfo.vehicleId,
            vehicleMake: vehicleInfo.vehicleMake,
            vehicleMakeName: vehicleInfo.vehicleMakeName,
            vehicleModel: vehicleInfo.vehicleModel,
            vehicleModelName: vehicleInfo.vehicleModelName,
            vehicleYear: vehicleInfo.vehicleYear,
            vehicleYearName: vehicleInfo.vehicleYearName,
            vehicleColor: vehicleInfo.vehicleColor,
            vehicleColorName: vehicleInfo.vehicleColorName,
            vehicleLicensePlate: vehicleInfo.vehicleLicensePlate,
            vehicleSeats: vehicleInfo.vehicleSeats,
            
            // Driver Info
            driverId: driverInfoTuple.driverId,
            driverName: driverInfoTuple.driverName,
            driverGender: driverInfoTuple.driverGender,
            driverCell: driverInfoTuple.driverCell,
            driverCellIsd: driverInfoTuple.driverCellIsd,
            driverCellCountry: driverInfoTuple.driverCellCountry,
            driverEmail: driverInfoTuple.driverEmail,
            driverPhoneType: driverInfoTuple.driverPhoneType,
            driverImageId: driverInfoTuple.driverImageId,
            vehicleImageId: driverInfoTuple.vehicleImageId,
            
            // Meet & Greet Info
            meetGreetChoices: meetGreetInfo.meetGreetChoices,
            meetGreetChoicesName: meetGreetInfo.meetGreetChoicesName,
            numberOfVehicles: meetGreetInfo.numberOfVehicles,
            
            // Pickup Info
            pickupDate: pickupInfo.pickupDate,
            pickupTime: pickupInfo.pickupTime,
            extraStops: pickupInfo.extraStops,
            pickup: pickupInfo.pickup,
            pickupLatitude: pickupInfo.pickupLatitude,
            pickupLongitude: pickupInfo.pickupLongitude,
            pickupAirportOption: pickupInfo.pickupAirportOption,
            pickupAirport: pickupInfo.pickupAirport,
            pickupAirportName: pickupInfo.pickupAirportName,
            pickupAirportLatitude: pickupInfo.pickupAirportLatitude,
            pickupAirportLongitude: pickupInfo.pickupAirportLongitude,
            pickupAirlineOption: pickupInfo.pickupAirlineOption,
            pickupAirline: pickupInfo.pickupAirline,
            pickupAirlineName: pickupInfo.pickupAirlineName,
            pickupFlight: pickupInfo.pickupFlight,
            originAirportCity: pickupInfo.originAirportCity,
            cruisePort: pickupInfo.cruisePort,
            cruiseName: pickupInfo.cruiseName,
            cruiseTime: pickupInfo.cruiseTime,
            
            // Dropoff Info
            dropoff: dropoffInfo.dropoff,
            dropoffLatitude: dropoffInfo.dropoffLatitude,
            dropoffLongitude: dropoffInfo.dropoffLongitude,
            dropoffAirportOption: dropoffInfo.dropoffAirportOption,
            dropoffAirport: dropoffInfo.dropoffAirport,
            dropoffAirportName: dropoffInfo.dropoffAirportName,
            dropoffAirportLatitude: dropoffInfo.dropoffAirportLatitude,
            dropoffAirportLongitude: dropoffInfo.dropoffAirportLongitude,
            dropoffAirlineOption: dropoffInfo.dropoffAirlineOption,
            dropoffAirline: dropoffInfo.dropoffAirline,
            dropoffAirlineName: dropoffInfo.dropoffAirlineName,
            dropoffFlight: dropoffInfo.dropoffFlight,
            
            // Return Meet & Greet Info (must come before driverLanguages)
            returnMeetGreetChoices: returnInfo.returnMeetGreetChoices,
            returnMeetGreetChoicesName: returnInfo.returnMeetGreetChoicesName,
            returnPickupDate: returnInfo.returnPickupDate,
            returnPickupTime: returnInfo.returnPickupTime,
            returnExtraStops: returnInfo.returnExtraStops,
            returnPickup: returnInfo.returnPickup,
            returnPickupLatitude: Double(returnInfo.returnPickupLatitude) ?? 0.0,
            returnPickupLongitude: Double(returnInfo.returnPickupLongitude) ?? 0.0,
            returnPickupAirportOption: returnInfo.returnPickupAirportOption,
            returnPickupAirport: returnInfo.returnPickupAirport,
            returnPickupAirportName: returnInfo.returnPickupAirportName,
            returnPickupAirportLatitude: returnInfo.returnPickupAirportLatitude,
            returnPickupAirportLongitude: returnInfo.returnPickupAirportLongitude,
            returnPickupAirlineOption: returnInfo.returnPickupAirlineOption,
            returnPickupAirline: returnInfo.returnPickupAirline,
            returnPickupAirlineName: returnInfo.returnPickupAirlineName,
            returnPickupFlight: returnInfo.returnPickupFlight,
            returnCruisePort: returnInfo.returnCruisePort,
            returnCruiseName: returnInfo.returnCruiseName,
            returnCruiseTime: returnInfo.returnCruiseTime,
            returnDropoff: returnInfo.returnDropoff,
            returnDropoffLatitude: Double(returnInfo.returnDropoffLatitude) ?? 0.0,
            returnDropoffLongitude: Double(returnInfo.returnDropoffLongitude) ?? 0.0,
            returnDropoffAirportOption: returnInfo.returnDropoffAirportOption,
            returnDropoffAirport: returnInfo.returnDropoffAirport,
            returnDropoffAirportName: returnInfo.returnDropoffAirportName,
            returnDropoffAirportLatitude: returnInfo.returnDropoffAirportLatitude,
            returnDropoffAirportLongitude: returnInfo.returnDropoffAirportLongitude,
            returnDropoffAirlineOption: returnInfo.returnDropoffAirlineOption,
            returnDropoffAirline: returnInfo.returnDropoffAirline,
            returnDropoffAirlineName: returnInfo.returnDropoffAirlineName,
            returnDropoffFlight: returnInfo.returnDropoffFlight,
            
            // Additional Info
            driverLanguages: additionalInfo.driverLanguages,
            driverDresses: additionalInfo.driverDresses,
            amenities: additionalInfo.amenities,
            chargedAmenities: additionalInfo.chargedAmenities,
            journeyDistance: additionalInfo.journeyDistance,
            journeyTime: additionalInfo.journeyTime,
            returnJourneyDistance: additionalInfo.returnJourneyDistance,
            returnJourneyTime: additionalInfo.returnJourneyTime,
            reservationId: additionalInfo.reservationId,
            updateType: additionalInfo.updateType,
            departingAirportCity: additionalInfo.departingAirportCity,
            currency: additionalInfo.currency,
            isMasterVehicle: additionalInfo.isMasterVehicle,
            proceed: additionalInfo.proceed,
            
            // Rate Info
            rateArray: rateInfo.rateArray,
            returnRateArray: returnRateInfo.returnRateArray,
            grandTotal: rateInfo.grandTotal,
            subTotal: rateInfo.subTotal,
            returnSubTotal: returnRateInfo.returnSubTotal,
            returnGrandTotal: returnRateInfo.returnGrandTotal,
            minRateInvolved: rateInfo.minRateInvolved,
            sharesArray: rateInfo.sharesArray,
            returnSharesArray: returnRateInfo.returnSharesArray,
            
            // Final Info
            returnAffiliateType: finalInfo.returnAffiliateType,
            returnDistance: finalInfo.returnDistance,
            returnVehicleId: finalInfo.returnVehicleId,
            noOfHours: finalInfo.noOfHours,
            
            // FBO Info (must come at the very end)
            fboAddress: returnRateInfo.fboAddress,
            fboName: returnRateInfo.fboName,
            returnFboAddress: returnRateInfo.returnFboAddress,
            returnFboName: returnRateInfo.returnFboName
        )
    }
    
    private func buildEditReservationRequest() async -> EditReservationRequest {
        // Map service type
        let serviceType = mapServiceTypeToAPI(selectedServiceType ?? "One Way")
        
        // Map transfer type
        let transferType = mapTransferTypeToAPI(selectedTransferType ?? "City to City")
        
        // Get coordinates once and store them with fallback logic
        let pickupCoord = self.getPickupCoordinate() ?? self.getFallbackPickupCoordinate()
        let dropoffCoord = self.getDropoffCoordinate() ?? self.getFallbackDropoffCoordinate()
        
        // Calculate distance and time once
        let journeyDistance = Int(await calculateDistance())
        let journeyTime = Int(await calculateJourneyTime())
        
        // Calculate return journey distance and time for round trip
        let returnJourneyDistance: Int
        let returnJourneyTime: Int
        if serviceType == "round_trip" {
            // For round trip, return journey should be calculated from dropoff to pickup
            returnJourneyDistance = Int(await calculateReturnDistance())
            returnJourneyTime = Int(await calculateReturnJourneyTime())
        } else {
            returnJourneyDistance = 0
            returnJourneyTime = 0
        }
        
        print("🔍 EDIT COORDINATE DEBUG:")
        print("  Pickup Coord: \(pickupCoord?.latitude ?? 0), \(pickupCoord?.longitude ?? 0)")
        print("  Dropoff Coord: \(dropoffCoord?.latitude ?? 0), \(dropoffCoord?.longitude ?? 0)")
        print("  Journey Distance: \(journeyDistance)")
        print("  Journey Time: \(journeyTime)")
        print("  Return Journey Distance: \(returnJourneyDistance)")
        print("  Return Journey Time: \(returnJourneyTime)")
        print("🔍 COORDINATE SOURCE DEBUG:")
        print("  dropoffCoordinate: \(dropoffCoordinate?.latitude ?? 0), \(dropoffCoordinate?.longitude ?? 0)")
        print("  dropoffAirportCoordinate: \(dropoffAirportCoordinate?.latitude ?? 0), \(dropoffAirportCoordinate?.longitude ?? 0)")
        print("  selectedTransferType: \(selectedTransferType ?? "nil")")
        print("  rideData?.destinationLat: \(rideData?.destinationLat ?? 0)")
        print("  rideData?.destinationLong: \(rideData?.destinationLong ?? 0)")
        
        // Get extra stops with coordinates
        let extraStopsRequests = extraStops.compactMap { stop -> ExtraStopRequest? in
            guard !stop.address.isEmpty,
                  let coordinate = stop.coordinate else {
                return nil
            }
            
            return ExtraStopRequest(
                address: stop.address,
                latitude: coordinate.latitude,
                longitude: coordinate.longitude,
                rate: "out_town",
                bookingInstructions: ""
            )
        }
        
        // Get vehicle and driver information from editData to match the original booking
        let rawVehicleId = editReservationService.editData?.vehicleId
        let isMasterVehicle = editReservationService.editData?.affiliateType == "unassigned"
        let vehicleId = rawVehicleId ?? 1
        let vehicleSeats = editReservationService.editData?.vehicleSeats.map { String($0) } ?? "4"
        
        // Get driver information from editData (not from selected vehicle)
        let driverName = editReservationService.editData?.driverName ?? "1800LIMO Chauffeurs"
        let driverGender = editReservationService.editData?.driverGender ?? "male"
        let driverCell = editReservationService.editData?.driverCell ?? "8005466266"
        let driverCellIsdRaw = editReservationService.editData?.driverCellIsd ?? "+1"
        let driverCellIsd = driverCellIsdRaw.replacingOccurrences(of: "+", with: "")  // Remove "+" to match web format
        let driverCellCountry = editReservationService.editData?.driverCellCountry ?? "us"
        let driverEmail = editReservationService.editData?.driverEmail ?? ""
        let driverPhoneType = editReservationService.editData?.driverPhoneType ?? ""
        let driverId = editReservationService.editData?.driverId.map { String($0) } ?? ""
        let affiliateId = editReservationService.editData.map { String($0.affiliateId) } ?? ""
        
        // Get meet & greet choice
        let meetGreetChoice = meetGreetChoices.first?.id ?? 1
        let meetGreetChoiceName = meetGreetChoices.first?.message ?? "Driver - Text/call when on location"
        
        // Get return meet & greet choice
        let returnMeetGreetChoice = meetGreetChoices.first(where: { $0.message == selectedReturnMeetAndGreet })?.id ?? meetGreetChoice
        let returnMeetGreetChoiceName = selectedReturnMeetAndGreet ?? meetGreetChoiceName
        
        // Get airline details - use "0" when not selected to match backend expectations
        let pickupAirline = selectedPickupAirline ?? "0"
        let pickupAirlineName = pickupAirline != "0" ? (airlineService.airlines.first(where: { $0.id == Int(pickupAirline) })?.fullDisplayName ?? "") : ""
        let pickupAirlineData = pickupAirline != "0" ? airlineService.airlines.first(where: { $0.id == Int(pickupAirline) }) : nil
        let pickupAirlineOption = pickupAirlineData.map { AirlineOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            country: $0.country ?? "",
            formattedName: $0.fullDisplayName
        ) }
        
        let dropoffAirline = selectedDropoffAirline ?? "0"
        let dropoffAirlineName = dropoffAirline != "0" ? (airlineService.airlines.first(where: { $0.id == Int(dropoffAirline) })?.fullDisplayName ?? "") : ""
        let dropoffAirlineData = dropoffAirline != "0" ? airlineService.airlines.first(where: { $0.id == Int(dropoffAirline) }) : nil
        let dropoffAirlineOption = dropoffAirlineData.map { AirlineOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            country: $0.country ?? "",
            formattedName: $0.fullDisplayName
        ) }
        
        // Get airport details as AirportOption objects
        let pickupAirportData = airportService.airports.first(where: { $0.displayName == selectedPickupAirport })
        let pickupAirportOption = pickupAirportData.map { AirportOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            city: $0.city,
            country: $0.country,
            lat: $0.lat ?? 0.0,
            long: $0.long ?? 0.0,
            formattedName: $0.displayName
        ) }
        
        let dropoffAirportData = airportService.airports.first(where: { $0.displayName == selectedDropoffAirport })
        let dropoffAirportOption = dropoffAirportData.map { AirportOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            city: $0.city,
            country: $0.country,
            lat: $0.lat ?? 0.0,
            long: $0.long ?? 0.0,
            formattedName: $0.displayName
        ) }
        
        // Get airport details
        let pickupAirportId = selectedPickupAirport?.isEmpty == false ?
            airportService.airports.first(where: { $0.displayName == selectedPickupAirport })?.id ?? 0 : 0
        let pickupAirportName = selectedPickupAirport ?? ""
        let pickupAirportLat = pickupAirportCoordinate?.latitude ?? (pickupCoord?.latitude ?? 0.0)
        let pickupAirportLng = pickupAirportCoordinate?.longitude ?? (pickupCoord?.longitude ?? 0.0)
        
        let dropoffAirportId = selectedDropoffAirport?.isEmpty == false ?
            airportService.airports.first(where: { $0.displayName == selectedDropoffAirport })?.id ?? 0 : 0
        let dropoffAirportName = selectedDropoffAirport ?? ""
        let dropoffAirportLat = dropoffAirportCoordinate?.latitude ?? (dropoffCoord?.latitude ?? 0.0)
        let dropoffAirportLng = dropoffAirportCoordinate?.longitude ?? (dropoffCoord?.longitude ?? 0.0)
        
        // Get return trip airport details
        let returnPickupAirportId = selectedReturnPickupAirport?.isEmpty == false ?
            airportService.airports.first(where: { $0.displayName == selectedReturnPickupAirport })?.id ?? 0 : 0
        let returnPickupAirportName = selectedReturnPickupAirport ?? ""
        let returnPickupAirportLat = returnPickupAirportCoordinate?.latitude ?? (returnPickupCoordinate?.latitude ?? 0.0)
        let returnPickupAirportLng = returnPickupAirportCoordinate?.longitude ?? (returnPickupCoordinate?.longitude ?? 0.0)
        
        let returnDropoffAirportId = selectedReturnDropoffAirport?.isEmpty == false ?
            airportService.airports.first(where: { $0.displayName == selectedReturnDropoffAirport })?.id ?? 0 : 0
        let returnDropoffAirportName = selectedReturnDropoffAirport ?? ""
        let returnDropoffAirportLat = returnDropoffAirportCoordinate?.latitude ?? (returnDropoffCoordinate?.latitude ?? 0.0)
        let returnDropoffAirportLng = returnDropoffAirportCoordinate?.longitude ?? (returnDropoffCoordinate?.longitude ?? 0.0)
        
        // Get return airline details from return trip fields - use "0" when not selected
        let returnPickupAirline = selectedReturnPickupAirline ?? "0"
        let returnPickupAirlineName = returnPickupAirline != "0" ? (airlineService.airlines.first(where: { $0.id == Int(returnPickupAirline) })?.fullDisplayName ?? "") : ""
        let returnPickupAirlineData = returnPickupAirline != "0" ? airlineService.airlines.first(where: { $0.id == Int(returnPickupAirline) }) : nil
        let returnPickupAirlineOption = returnPickupAirlineData.map { AirlineOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            country: $0.country ?? "",
            formattedName: $0.fullDisplayName
        ) }
        
        let returnDropoffAirline = selectedReturnDropoffAirline ?? "0"
        let returnDropoffAirlineName = returnDropoffAirline != "0" ? (airlineService.airlines.first(where: { $0.id == Int(returnDropoffAirline) })?.fullDisplayName ?? "") : ""
        let returnDropoffAirlineData = returnDropoffAirline != "0" ? airlineService.airlines.first(where: { $0.id == Int(returnDropoffAirline) }) : nil
        let returnDropoffAirlineOption = returnDropoffAirlineData.map { AirlineOption(
            id: $0.id,
            code: $0.code,
            name: $0.name,
            country: $0.country ?? "",
            formattedName: $0.fullDisplayName
        ) }
        
        // Get pickup date and time for API
        let pickupDate: String
        let pickupTime: String
        let returnPickupDate: String
        let returnPickupTime: String
        
        // Always convert from UI format to ensure we use the user-selected time
        // Don't use rideData.pickupTime directly as it may be outdated if user changed the time
        pickupDate = parseDateFromUI(travelDate).map { formatDateForAPI($0) } ?? travelDate
        // Use selectedTime directly for API format - ensure 24-hour format (HH:mm:ss)
        pickupTime = formatTimeForAPI(selectedTime)
        returnPickupDate = serviceType == "round_trip" ? (parseDateFromUI(returnTravelDate).map { formatDateForAPI($0) } ?? returnTravelDate) : ""
        // For return time, parse from UI format and convert to API format (HH:mm:ss)
        // If parsing fails, use selectedReturnTime which should be a Date object
        if serviceType == "round_trip" {
            if let parsedTime = parseTimeFromUI(self.returnPickupTime) {
                returnPickupTime = formatTimeForAPI(parsedTime)
            } else {
                // Fallback to selectedReturnTime if it's a Date, otherwise use empty string
                returnPickupTime = formatTimeForAPI(selectedReturnTime)
            }
        } else {
            returnPickupTime = ""
        }
        
        // Get shares array
        let sharesArray = SharesArrayBuilder.buildSharesArray(
            from: bookingRatesService.ratesData?.rateArray ?? BookingRateArray(
                allInclusiveRates: [:],
                amenities: [:],
                taxes: [:],
                misc: [:]
            ),
            serviceType: serviceType,
            numberOfHours: getNoOfHoursForService(serviceType: serviceType),
            accountType: "individual",
            returnGrandTotal: serviceType == "round_trip" ? grandTotal : nil
        )
        
        // Build return shares array for round trip bookings
        let returnSharesArray: SharesArray?
        if serviceType == "round_trip", let returnRateArray = bookingRatesService.ratesData?.retrunRateArray {
            returnSharesArray = SharesArrayBuilder.buildSharesArray(
                from: returnRateArray,
                serviceType: serviceType,
                numberOfHours: getNoOfHoursForService(serviceType: serviceType),
                accountType: "individual",
                returnGrandTotal: nil
            )
        } else {
            returnSharesArray = nil
        }
        
        // Calculate return rates (for round trip, return journey might have different rates)
        let returnSubTotal: Double?
        let returnGrandTotal: Double?
        if serviceType == "round_trip", let returnShares = returnSharesArray {
            returnSubTotal = returnShares.grandTotal
            returnGrandTotal = returnShares.grandTotal
        } else {
            returnSubTotal = nil
            returnGrandTotal = nil
        }
        
        print("🔍 EDIT REQUEST DEBUG:")
        print("  Service Type: \(serviceType)")
        print("  Transfer Type: \(transferType)")
        print("  Reservation ID: \(editBookingId?.description ?? "nil")")
        print("🔍 RETURN ARRAYS DEBUG:")
        print("  returnSharesArray: \(returnSharesArray != nil ? "Present" : "Nil")")
        print("  returnSubTotal: \(returnSubTotal ?? 0)")
        print("  returnGrandTotal: \(returnGrandTotal ?? 0)")
        print("🔍 RATE DATA DEBUG:")
        print("  bookingRatesService.ratesData?.rateArray: \(bookingRatesService.ratesData?.rateArray != nil ? "Present" : "Nil")")
        print("  bookingRatesService.ratesData?.retrunRateArray: \(bookingRatesService.ratesData?.retrunRateArray != nil ? "Present" : "Nil")")
        print("  serviceType: \(serviceType)")
        print("  isRoundTrip: \(serviceType == "round_trip")")
        print("🔍 AIRPORT/AIRLINE OPTIONS DEBUG:")
        print("  pickupAirportOption: \(pickupAirportOption != nil ? "Present" : "Nil")")
        print("  dropoffAirportOption: \(dropoffAirportOption != nil ? "Present" : "Nil")")
        print("  pickupAirlineOption: \(pickupAirlineOption != nil ? "Present" : "Nil")")
        print("  dropoffAirlineOption: \(dropoffAirlineOption != nil ? "Present" : "Nil")")
        print("  selectedPickupAirport: \(selectedPickupAirport ?? "nil")")
        print("  selectedDropoffAirport: \(selectedDropoffAirport ?? "nil")")
        print("  selectedPickupAirline: \(selectedPickupAirline ?? "nil")")
        print("  selectedDropoffAirline: \(selectedDropoffAirline ?? "nil")")
        
        let editNumberOfHoursValue = getNoOfHoursForServiceInt(serviceType: serviceType)
        print("🚀 EDIT PAYLOAD DEBUG - numberOfHours being sent: \(editNumberOfHoursValue)")
        print("🚀 EDIT PAYLOAD DEBUG - selectedHours at edit payload time: '\(selectedHours)'")
        
        // Get vehicle data from editData for proper payload construction
        // If master vehicle with missing vehicle_id, default vehicle_type to "1" to mimic web payload
        let vehicleTypeValue: String = {
            if isMasterVehicle && rawVehicleId == nil {
                print("⚙️ Fallback vehicle_type=1 because master vehicle has no vehicle_id in edit payload")
                return "1"
            }
            return editReservationService.editData?.vehicleType?.description ?? ""
        }()
        let vehicleTypeNameValue = editReservationService.editData?.vehicleTypeName ?? ""
        let vehicleMakeValue = editReservationService.editData?.vehicleMake?.description ?? ""
        let vehicleMakeNameValue = editReservationService.editData?.vehicleMakeName ?? ""
        let vehicleModelValue = editReservationService.editData?.vehicleModel?.description ?? ""
        let vehicleModelNameValue = editReservationService.editData?.vehicleModelName ?? ""
        let vehicleYearValue = editReservationService.editData?.vehicleYear ?? ""
        let vehicleYearNameValue = editReservationService.editData?.vehicleYearName ?? ""
        let vehicleColorValue = editReservationService.editData?.vehicleColor?.description ?? ""
        let vehicleColorNameValue = editReservationService.editData?.vehicleColorName ?? ""
        let vehicleLicensePlateValue = editReservationService.editData?.vehicleLicensePlate ?? ""
        
        print("🔍 VEHICLE DATA DEBUG (from editData):")
        print("  vehicleId: \(vehicleId)")
        print("  vehicleType: \(vehicleTypeValue)")
        print("  vehicleTypeName: \(vehicleTypeNameValue)")
        print("  vehicleMake: \(vehicleMakeValue)")
        print("  vehicleMakeName: \(vehicleMakeNameValue)")
        print("  vehicleModel: \(vehicleModelValue)")
        print("  vehicleModelName: \(vehicleModelNameValue)")
        print("  vehicleYear: \(vehicleYearValue)")
        print("  vehicleYearName: \(vehicleYearNameValue)")
        print("  vehicleColor: \(vehicleColorValue)")
        print("  vehicleColorName: \(vehicleColorNameValue)")
        print("  vehicleLicensePlate: \(vehicleLicensePlateValue)")
        print("  vehicleSeats: \(vehicleSeats)")
        print("🔍 DRIVER DATA DEBUG (from editData):")
        print("  driverId: \(driverId)")
        print("  driverName: \(driverName)")
        print("  driverGender: \(driverGender)")
        print("  driverCell: \(driverCell)")
        print("  driverCellIsd: \(driverCellIsd)")
        print("  driverCellCountry: \(driverCellCountry)")
        print("  driverEmail: \(driverEmail)")
        print("  driverPhoneType: \(driverPhoneType)")
        print("  affiliateId: \(affiliateId)")
        
        let outboundCruisePickupTypes: Set<String> = ["Cruise Port to City", "Cruise Port to Airport"]
        let outboundCruiseDropoffTypes: Set<String> = ["City to Cruise Port", "Airport to Cruise Port"]
        let transferTypeDisplayValue = selectedTransferType ?? ""
        let shouldIncludeOutboundCruiseDetails = outboundCruisePickupTypes.contains(transferTypeDisplayValue) || outboundCruiseDropoffTypes.contains(transferTypeDisplayValue)
        let outboundCruisePortValue = shouldIncludeOutboundCruiseDetails ? cruisePort : ""
        let outboundCruiseNameValue = shouldIncludeOutboundCruiseDetails ? cruiseShipName : ""
        let outboundCruiseTimeValue: String = {
            guard shouldIncludeOutboundCruiseDetails, !shipArrivalTime.isEmpty else { return "" }
            if let parsedTime = parseTimeFromUI(shipArrivalTime) {
                return formatTimeForAPI(parsedTime)
            }
            return formatTimeForAPI(selectedCruiseTime)
        }()
        let shouldIncludeReturnCruiseDetails = (selectedServiceType == "Round Trip") && shouldIncludeOutboundCruiseDetails
        // For return trips where pickup is cruise port, use returnPickupAddress if returnCruisePort is empty
        let returnTransferTypeValue = selectedReturnTransferType ?? ""
        let returnPickupIsCruisePort = returnTransferTypeValue == "City to Cruise Port" || returnTransferTypeValue == "Airport to Cruise Port"
        let returnCruisePortValue = shouldIncludeReturnCruiseDetails ? (returnCruisePort.isEmpty && returnPickupIsCruisePort ? returnPickupAddress : returnCruisePort) : ""
        let returnCruiseNameValue = shouldIncludeReturnCruiseDetails ? returnCruiseShipName : ""
        let returnCruiseTimeValue: String = {
            guard shouldIncludeReturnCruiseDetails, !returnShipArrivalTime.isEmpty else { return "" }
            if let parsedTime = parseTimeFromUI(returnShipArrivalTime) {
                return formatTimeForAPI(parsedTime)
            }
            return formatTimeForAPI(selectedReturnCruiseTime)
        }()
        
        return EditReservationRequest(
            serviceType: serviceType,
            transferType: transferType,
            returnTransferType: mapTransferTypeToAPI(selectedReturnTransferType ?? "City to City"),
            numberOfHours: String(editNumberOfHoursValue),  // Convert to String
            accountType: "individual",
            changeIndividualData: "",  // Changed to empty string to match web
            passengerName: getPassengerName(),
            passengerEmail: getPassengerEmail(),
            passengerCell: getPassengerCell(),
            passengerCellIsd: getPassengerCellIsd(),
            passengerCellCountry: getPassengerCellCountry(),
            totalPassengers: String(rideData?.noOfPassenger ?? 1),  // Convert to String
            luggageCount: String(rideData?.noOfLuggage ?? 1),  // Convert to String
            bookingInstructions: specialInstructions,
            returnBookingInstructions: returnSpecialInstructions,
            affiliateType: "affiliate",
            affiliateId: affiliateId,
            loseAffiliateName: "",
            loseAffiliatePhone: "",
            loseAffiliatePhoneIsd: "+1",
            loseAffiliatePhoneCountry: "us",
            loseAffiliateEmail: "",
            vehicleType: vehicleTypeValue,
            vehicleTypeName: vehicleTypeNameValue,
            vehicleId: String(vehicleId),  // Convert to String
            vehicleMake: vehicleMakeValue,
            vehicleMakeName: vehicleMakeNameValue,
            vehicleModel: vehicleModelValue,
            vehicleModelName: vehicleModelNameValue,
            vehicleYear: vehicleYearValue,
            vehicleYearName: vehicleYearNameValue,
            vehicleColor: vehicleColorValue,
            vehicleColorName: vehicleColorNameValue,
            vehicleLicensePlate: vehicleLicensePlateValue,
            vehicleSeats: vehicleSeats,
            driverId: driverId,
            driverName: driverName,
            driverGender: driverGender,
            driverCell: driverCell,
            driverCellIsd: driverCellIsd,
            driverCellCountry: driverCellCountry,
            driverEmail: driverEmail,
            driverPhoneType: driverPhoneType,
            driverImageId: "",
            vehicleImageId: "",
            meetGreetChoices: String(meetGreetChoice),  // Convert to String
            meetGreetChoicesName: meetGreetChoiceName,
            numberOfVehicles: String(numberOfVehicles),  // Convert to String
            pickupDate: pickupDate,
            pickupTime: pickupTime,
            extraStops: extraStopsRequests,
            pickup: pickupAddress,
            pickupLatitude: pickupCoord?.latitude.description ?? "0",
            pickupLongitude: pickupCoord?.longitude.description ?? "0",
            pickupAirportOption: pickupAirportOption,
            pickupAirport: String(pickupAirportId),  // Convert to String
            pickupAirportName: pickupAirportName,
            pickupAirportLatitude: pickupAirportLat.description,  // Convert to String
            pickupAirportLongitude: pickupAirportLng.description,  // Convert to String
            pickupAirlineOption: pickupAirlineOption,
            pickupAirline: pickupAirline,  // Already a String
            pickupAirlineName: pickupAirlineName,
            pickupFlight: pickupFlightNumber,
            originAirportCity: originAirportCity,
            cruisePort: outboundCruisePortValue,
            cruiseName: outboundCruiseNameValue,
            cruiseTime: outboundCruiseTimeValue,
            dropoff: dropoffAddress,
            dropoffLatitude: dropoffCoord?.latitude.description ?? "0",
            dropoffLongitude: dropoffCoord?.longitude.description ?? "0",
            dropoffAirportOption: dropoffAirportOption,
            dropoffAirport: String(dropoffAirportId),  // Convert to String
            dropoffAirportName: dropoffAirportName,
            dropoffAirportLatitude: dropoffAirportLat.description,  // Convert to String
            dropoffAirportLongitude: dropoffAirportLng.description,  // Convert to String
            dropoffAirlineOption: dropoffAirlineOption,
            dropoffAirline: dropoffAirline,  // Already a String
            dropoffAirlineName: dropoffAirlineName,
            dropoffFlight: dropoffFlightNumber,
            returnMeetGreetChoices: String(returnMeetGreetChoice),  // Convert to String
            returnMeetGreetChoicesName: returnMeetGreetChoiceName,
            returnPickupDate: returnPickupDate,
            returnPickupTime: returnPickupTime,
            returnExtraStops: returnExtraStops.compactMap { stop -> ExtraStopRequest? in
                guard !stop.address.isEmpty,
                      let coordinate = stop.coordinate else {
                    return nil
                }
                return ExtraStopRequest(
                    address: stop.address,
                    latitude: coordinate.latitude,
                    longitude: coordinate.longitude,
                    rate: "out_town",
                    bookingInstructions: stop.bookingInstructions
                )
            },
            // Return pickup from return journey fields
            returnPickup: returnPickupAddress,
            returnPickupLatitude: (returnPickupCoordinate?.latitude ?? 0.0).description,  // Convert to String
            returnPickupLongitude: (returnPickupCoordinate?.longitude ?? 0.0).description,  // Convert to String
            returnPickupAirportOption: returnPickupAirportId > 0 ? airportService.airports.first(where: { $0.id == returnPickupAirportId }).map { AirportOption(
                id: $0.id,
                code: $0.code,
                name: $0.name,
                city: $0.city,
                country: $0.country,
                lat: $0.lat ?? 0.0,
                long: $0.long ?? 0.0,
                formattedName: $0.displayName
            ) } : nil,
            returnPickupAirport: String(returnPickupAirportId),  // Convert to String
            returnPickupAirportName: returnPickupAirportName,
            returnPickupAirportLatitude: returnPickupAirportLat.description,  // Convert to String
            returnPickupAirportLongitude: returnPickupAirportLng.description,  // Convert to String
            returnPickupAirlineOption: returnPickupAirlineOption,
            returnPickupAirline: returnPickupAirline,  // Already a String
            returnPickupAirlineName: returnPickupAirlineName,
            returnPickupFlight: returnPickupFlightNumber,
            returnCruisePort: returnCruisePortValue,
            returnCruiseName: returnCruiseNameValue,
            returnCruiseTime: returnCruiseTimeValue,
            // Return dropoff from return journey fields
            returnDropoff: returnDropoffAddress,
            returnDropoffLatitude: (returnDropoffCoordinate?.latitude ?? 0.0).description,  // Convert to String
            returnDropoffLongitude: (returnDropoffCoordinate?.longitude ?? 0.0).description,  // Convert to String
            returnDropoffAirportOption: returnDropoffAirportId > 0 ? airportService.airports.first(where: { $0.id == returnDropoffAirportId }).map { AirportOption(
                id: $0.id,
                code: $0.code,
                name: $0.name,
                city: $0.city,
                country: $0.country,
                lat: $0.lat ?? 0.0,
                long: $0.long ?? 0.0,
                formattedName: $0.displayName
            ) } : nil,
            returnDropoffAirport: String(returnDropoffAirportId),  // Convert to String
            returnDropoffAirportName: returnDropoffAirportName,
            returnDropoffAirportLatitude: returnDropoffAirportLat.description,  // Convert to String
            returnDropoffAirportLongitude: returnDropoffAirportLng.description,  // Convert to String
            returnDropoffAirlineOption: returnDropoffAirlineOption,
            returnDropoffAirline: returnDropoffAirline,  // Already a String
            returnDropoffAirlineName: returnDropoffAirlineName,
            returnDropoffFlight: returnDropoffFlightNumber,
            driverLanguages: ["1"],  // Changed to [String] to match web
            driverDresses: [],
            amenities: [],
            chargedAmenities: [],
            journeyDistance: String(journeyDistance),  // Convert to String
            journeyTime: String(journeyTime),  // Convert to String
            returnJourneyDistance: String(returnJourneyDistance),  // Convert to String
            returnJourneyTime: String(returnJourneyTime),  // Convert to String
            reservationId: editBookingId?.description ?? "",
            updateType: "edit",
            departingAirportCity: returnOriginAirportCity,
            currency: "USD",
            isMasterVehicle: (selectedVehicle?.isMasterVehicle ?? false) ? "1" : "",  // Convert to String to match web
            proceed: "1",  // Changed to "1" to match web
            rateArray: bookingRatesService.ratesData?.rateArray ?? BookingRateArray(
                allInclusiveRates: [:],
                amenities: [:],
                taxes: [:],
                misc: [:]
            ),
            returnRateArray: serviceType == "round_trip" ? bookingRatesService.ratesData?.retrunRateArray : nil,
            grandTotal: String(grandTotal),  // Convert to String
            subTotal: String(subtotal),  // Convert to String
            returnSubTotal: returnSubTotal.map { String($0) },  // Convert to String
            returnGrandTotal: returnGrandTotal.map { String($0) },  // Convert to String
            minRateInvolved: (bookingRatesService.ratesData?.minRateInvolved ?? false) ? "1" : "0",  // Convert to String
            sharesArray: sharesArray,
            returnSharesArray: returnSharesArray,
            returnAffiliateType: "affiliate",  // Use same affiliate type as outbound (affiliateType)
            returnAffiliateId: affiliateId,  // Use same affiliate ID as outbound
            returnDistance: String(returnJourneyDistance),  // Convert to String
            returnVehicleId: String(vehicleId),  // Convert to String
            noOfHours: getNoOfHoursForService(serviceType: serviceType),
            fboAddress: "",
            fboName: "",
            returnFboAddress: "",
            returnFboName: "",
            createdByRole: "admin"  // Added to match web payload
        )
    }
    
    // MARK: - Coordinate Helper Methods
    private func getPickupCoordinate() -> LocationCoordinate? {
        guard let transferType = selectedTransferType else { return nil }
        
        print("🔍 GETTING PICKUP COORDINATE for transfer type: \(transferType)")
        
        switch transferType {
        case "City to City", "City to Airport", "City to Cruise Port":
            if let coord = pickupCoordinate {
                print("✅ Using pickup city coordinates: \(coord.latitude), \(coord.longitude)")
                return coord
            } else {
                print("❌ No pickup city coordinates found")
                return getFallbackPickupCoordinate()
            }
        case "Airport to City", "Airport to Airport", "Airport to Cruise Port":
            if let coord = pickupAirportCoordinate {
                print("✅ Using pickup airport coordinates: \(coord.latitude), \(coord.longitude)")
                return coord
            } else {
                print("❌ No pickup airport coordinates found")
                return getFallbackPickupCoordinate()
            }
        case "Cruise Port to City", "Cruise Port to Airport":
            if let coord = pickupCruiseCoordinate {
                print("✅ Using pickup cruise port coordinates: \(coord.latitude), \(coord.longitude)")
                return coord
            } else {
                print("❌ No pickup cruise port coordinates found")
                return getFallbackPickupCoordinate()
            }
        default:
            print("❌ Unknown transfer type: \(transferType)")
            return getFallbackPickupCoordinate()
        }
    }
    
    private func getDropoffCoordinate() -> LocationCoordinate? {
        guard let transferType = selectedTransferType else { return nil }
        
        print("🔍 GETTING DROPOFF COORDINATE for transfer type: \(transferType)")
        
        switch transferType {
        case "City to City", "Airport to City", "Cruise Port to City":
            if let coord = dropoffCoordinate {
                print("✅ Using dropoff city coordinates: \(coord.latitude), \(coord.longitude)")
                return coord
            } else {
                print("❌ No dropoff city coordinates found")
                return getFallbackDropoffCoordinate()
            }
        case "City to Airport", "Airport to Airport", "Cruise Port to Airport":
            if let coord = dropoffAirportCoordinate {
                print("✅ Using dropoff airport coordinates: \(coord.latitude), \(coord.longitude)")
                return coord
            } else {
                print("❌ No dropoff airport coordinates found")
                return getFallbackDropoffCoordinate()
            }
        case "City to Cruise Port", "Airport to Cruise Port":
            if let coord = dropoffCruiseCoordinate {
                print("✅ Using dropoff cruise port coordinates: \(coord.latitude), \(coord.longitude)")
                return coord
            } else {
                print("❌ No dropoff cruise port coordinates found")
                return getFallbackDropoffCoordinate()
            }
        default:
            print("❌ Unknown transfer type: \(transferType)")
            return getFallbackDropoffCoordinate()
        }
    }
    
    private func getFallbackPickupCoordinate() -> LocationCoordinate? {
        if let lat = rideData?.pickupLat, let lng = rideData?.pickupLong, lat != 0 && lng != 0 {
            let coord = LocationCoordinate(latitude: lat, longitude: lng)
            print("🔄 Using fallback pickup coordinates from rideData: \(coord.latitude), \(coord.longitude)")
            return coord
        }
        print("❌ No fallback pickup coordinates available from rideData")
        return nil
    }
    
    private func getFallbackDropoffCoordinate() -> LocationCoordinate? {
        if let lat = rideData?.destinationLat, let lng = rideData?.destinationLong, lat != 0 && lng != 0 {
            let coord = LocationCoordinate(latitude: lat, longitude: lng)
            print("🔄 Using fallback dropoff coordinates from rideData: \(coord.latitude), \(coord.longitude)")
            return coord
        }
        print("❌ No fallback dropoff coordinates available from rideData")
        return nil
    }
    
    // MARK: - Helper Functions
    private func getButtonText() -> String {
        if isEditMode {
            if isLoading {
                return "Updating..."
            } else {
                return "Update"
            }
        } else {
            if isLoading || createReservationService.isLoading {
                return "Creating..."
            } else {
                return "Submit"
            }
        }
    }
    
    // MARK: - Next Button
    private var nextButton: some View {
        let isProcessing = (isEditMode && isLoading) || (!isEditMode && (isLoading || createReservationService.isLoading))
        
        return VStack {
            Button(action: {
                let isValid = validateFormAndShowErrors()
                guard isValid else { return }
                
                guard !hasBlockingExtraStopError else {
                    return
                }
                
                Task {
                    await createReservation()
                }
            }) {
                HStack {
                    if isProcessing {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(0.8)
                    }
                    Text(getButtonText())
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                }
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background((isProcessing || hasBlockingExtraStopError) ? Color.gray : AppColors.greenColor)
                    .cornerRadius(8)
            }
            .disabled(isProcessing || hasBlockingExtraStopError)
            .padding(.horizontal, 24)
            .padding(.bottom, 10)
        }
    }
    
    // MARK: - User Profile Helper Functions
    
    private func getPassengerName() -> String {
        if let profileData = StorageManager.shared.getUserProfileData() {
            return profileData.fullName
        }
        return "User Name"
    }
    
    private func getPassengerEmail() -> String {
        if let profileData = StorageManager.shared.getUserProfileData() {
            return profileData.email
        }
        return "user@example.com"
    }
    
    private func getPassengerCell() -> String {
        if let profileData = StorageManager.shared.getUserProfileData() {
            return profileData.mobile
        }
        return userData?.phone ?? "1234567890"
    }
    
    private func getPassengerCellIsd() -> String {
        if let profileData = StorageManager.shared.getUserProfileData() {
            return profileData.mobileIsd
        }
        return "+1"
    }
    
    private func getPassengerCellCountry() -> String {
        if let profileData = StorageManager.shared.getUserProfileData() {
            return profileData.mobileCountry
        }
        return "us"
    }
    
    // MARK: - Return Journey Section
    private var returnJourneySection: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Return Journey Header
            VStack(alignment: .leading, spacing: 8) {
                Text("Return Journey")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(AppColors.primaryOrange)
                
                Text("Configure your return trip details")
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(.gray)
            }
            
            // Return Service Type Selection (same dropdown as outbound)
            VStack(alignment: .leading, spacing: 8) {
                Text("SERVICE TYPE")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.gray)
                
                Button(action: {
                    openDropdown = openDropdown == "returnServiceType" ? nil : "returnServiceType"
                    if openDropdown == "returnServiceType" {
                        dropdownOptions = serviceTypes
                        dropdownSelected = $selectedReturnServiceType
                    }
                }) {
                    HStack {
                        Text(selectedReturnServiceType ?? "Select Service Type")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(selectedReturnServiceType == nil ? .black : .black)
                        Spacer()
                         Image("arrowIcon")

                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
                }
                .buttonStyle(PlainButtonStyle())
                .background(
                    GeometryReader { geo in
                        Color.clear
                            .onChange(of: openDropdown) { open in
                                if open == "returnServiceType" {
                                    let frame = geo.frame(in: .named("dropdownArea"))
                                    dropdownFrame = frame
                                }
                            }
                    }
                )
            }
            
            // Return Transfer Type Selection (same dropdown as outbound)
            VStack(alignment: .leading, spacing: 8) {
                Text("TRANSFER TYPE")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.gray)
                
                Button(action: {
                    openDropdown = openDropdown == "returnTransferType" ? nil : "returnTransferType"
                    if openDropdown == "returnTransferType" {
                        dropdownOptions = transferTypes
                        dropdownSelected = $selectedReturnTransferType
                    }
                }) {
                    HStack {
                        Text(selectedReturnTransferType ?? "Select Transfer Type")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(selectedReturnTransferType == nil ? .black : .black)
                        Spacer()
                         Image("arrowIcon")

                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
                }
                .buttonStyle(PlainButtonStyle())
                .background(
                    GeometryReader { geo in
                        Color.clear
                            .onChange(of: openDropdown) { open in
                                if open == "returnTransferType" {
                                    let frame = geo.frame(in: .named("dropdownArea"))
                                    dropdownFrame = frame
                                }
                            }
                    }
                )
            }
            
            // Return Meet and Greet Selection (same dropdown as outbound)
            VStack(alignment: .leading, spacing: 8) {
                Text("MEET & GREET")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.gray)
                
                Button(action: {
                    openDropdown = openDropdown == "returnMeetAndGreet" ? nil : "returnMeetAndGreet"
                    if openDropdown == "returnMeetAndGreet" {
                        dropdownOptions = meetGreetChoices.map { $0.message }
                        dropdownSelected = $selectedReturnMeetAndGreet
                    }
                }) {
                    HStack {
                        Text(selectedReturnMeetAndGreet ?? "Select Meet & Greet Option")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(selectedReturnMeetAndGreet == nil ? .black : .black)
                        Spacer()
                         Image("arrowIcon")

                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
                }
                .buttonStyle(PlainButtonStyle())
                .background(
                    GeometryReader { geo in
                        Color.clear
                            .onChange(of: openDropdown) { open in
                                if open == "returnMeetAndGreet" {
                                    let frame = geo.frame(in: .named("dropdownArea"))
                                    dropdownFrame = frame
                                }
                            }
                    }
                )
            }
            
            // Return Travel Date & Time
            VStack(alignment: .leading, spacing: 16) {
                Text("Return Travel Details")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(AppColors.primaryOrange)
                
                HStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("RETURN DATE")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            // Don't reinitialize - use the selectedReturnDate that was already set
                            showReturnDatePicker = true
                        }) {
                            HStack {
                                Text(returnTravelDate)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "calendar")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(.black)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("RETURN TIME")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            // Don't reinitialize - use the selectedReturnTime that was already set
                            showReturnTimePicker = true
                        }) {
                            HStack {
                                Text(returnPickupTime)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "clock")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(.black)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            }
            
            // Return Pickup Section
            returnPickupSection
            
            // Return Dropoff Section
            returnDropoffSection
            
            // Return Extra Stops Section (always show for round trips)
            returnExtraStopsSection
            
            // Return Special Instructions
            VStack(alignment: .leading, spacing: 8) {
                Text("RETURN SPECIAL INSTRUCTIONS")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.orange)
                
                TextEditor(text: $returnSpecialInstructions)
                    .scrollContentBackground(.hidden) // ✅ Remove default white
                    .background(Color.gray.opacity(0.15)) // ✅ Apply your black

                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.black)
                    .focused($focusedField, equals: .returnSpecialInstructions)
                    .id("returnSpecialInstructions")
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .cornerRadius(8)
                    .frame(minHeight: 80)

            }
            
        }
        .onAppear {
            // Initialize return trip fields when section appears
            initializeReturnTripFields()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                initializeReturnTripFields()
            }
        }
    }
    
    // MARK: - Return Pickup Section
    private var returnPickupSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Return Pick-up")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppColors.primaryOrange)
            
            // Dynamic return pickup fields based on return transfer type
            if let transferType = selectedReturnTransferType, (transferType == "City to City" || transferType == "City to Airport" || transferType == "City to Cruise Port") {
                // Return pickup is city
                AddressAutocompleteField(
                    viewModel: returnPickupAddressVM,
                    label: "RETURN PICKUP ADDRESS",
                    placeholder: "Enter return pickup address",
                    value: $returnPickupAddress,
                    hasError: hasError(for: "returnPickupAddress"),
                    onLocationSelected: { address, coordinate, postalCode in
                        returnPickupAddress = address
                        returnPickupCoordinate = coordinate
                        
                        // Clear error and validate locations
                        clearError(for: "returnPickupAddress")
                        validateReturnLocations()
                        
                        refreshReturnRates()
                    }
                )
                .onChange(of: returnPickupAddress) { newValue in
                    // Validate when address changes (user types manually)
                    if !newValue.isEmpty {
                        validateReturnLocations()
                    }
                }
                validationMessage(for: "returnPickupAddress")
            } else if let transferType = selectedReturnTransferType, (transferType == "Airport to City" || transferType == "Airport to Airport" || transferType == "Airport to Cruise Port") {
                // Return pickup is airport
                VStack(spacing: 16) {
                    // Airport selection
                    VStack(alignment: .leading, spacing: 8) {
                        Text("SELECT AIRPORT")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Text("(search by code or name)")
                            .font(.system(size: 10, weight: .regular))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            currentAirportType = "returnPickup"
                            Task {
                                await airportService.fetchAllAirports()
                                // Only show the sheet after airports are loaded
                                await MainActor.run {
                                    showAirportBottomSheet = true
                                }
                            }
                        }) {
                            HStack {
                                Text(selectedReturnPickupAirport ?? "Search airports...")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(selectedReturnPickupAirport == nil ? .black : .black)
                                Spacer()
                                 Image("arrowIcon")

                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "returnPickupAirport") ? Color.red : Color.clear, lineWidth: hasError(for: "returnPickupAirport") ? 1.5 : 0)
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        validationMessage(for: "returnPickupAirport")
                    }
                    
                    // Airline selection
                    VStack(alignment: .leading, spacing: 8) {
                        Text("SELECT AIRLINE")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            currentAirlineType = "returnPickup"
                            showAirlineBottomSheet = true
                        }) {
                            HStack {
                                Text(returnPickupAirlineDisplayName)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(selectedReturnPickupAirline == nil ? .black : .black)
                                Spacer()
                                 Image("arrowIcon")

                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "returnPickupAirline") ? Color.red : Color.clear, lineWidth: hasError(for: "returnPickupAirline") ? 1.5 : 0)
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        validationMessage(for: "returnPickupAirline")
                    }
                    
                    // Flight number field
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("FLIGHT NUMBER")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        AutoSelectTextField(
                            placeholder: "Enter Flight number",
                            text: $returnPickupFlightNumber,
                            fontSize: 14,
                            fontWeight: .medium,
                            textColor: .black
                        )
                        .focused($focusedField, equals: .returnPickupFlightNumber)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(hasError(for: "returnPickupFlightNumber") ? Color.red : Color.clear, lineWidth: hasError(for: "returnPickupFlightNumber") ? 1.5 : 0)
                        )
                        
                        validationMessage(for: "returnPickupFlightNumber")
                    }
                    
//                    VStack(alignment: .leading, spacing: 8) {
//                        Text("ORIGIN AIRPORT CITY")
//                            .font(.system(size: 12, weight: .medium))
//                            .foregroundColor(.gray)
//                        
//                        AutoSelectTextField(
//                            placeholder: "Enter Origin Airport City",
//                            text: $returnOriginAirportCity,
//                            fontSize: 14,
//                            fontWeight: .medium,
//                            textColor: .gray
//                        )
//                            .padding(.horizontal, 16)
//                            .padding(.vertical, 12)
//                            .background(Color.gray.opacity(0.15))
//                            .cornerRadius(8)
//                    }

                    
                    
//                    AppTextField(
//                        label: "FLIGHT NUMBER",
//                        placeholder: "Enter Flight Number",
//                        text: $returnPickupFlightNumber
//                    )
                    
//                    // Origin airport city field
//                    AppTextField(
//                        label: "ORIGIN AIRPORT CITY",
//                        placeholder: "Enter Origin Airport City",
//                        text: $returnOriginAirportCity
//                    )
                }
            } else if let transferType = selectedReturnTransferType, (transferType == "Cruise Port to City" || transferType == "Cruise Port to Airport" || transferType == "Cruise Port to Cruise Port") {
                // Return pickup is cruise port
                VStack(spacing: 16) {
                    // Cruise port address
                    AddressAutocompleteField(
                        viewModel: returnPickupAddressVM,
                        label: "RETURN PICKUP ADDRESS",
                        placeholder: "Enter return pickup address",
                        value: $returnPickupAddress,
                        hasError: hasError(for: "returnPickupAddress"),
                        onLocationSelected: { address, coordinate, postalCode in
                            returnPickupAddress = address
                            returnPickupCoordinate = coordinate
                            
                            // Clear error and validate locations
                            clearError(for: "returnPickupAddress")
                            validateReturnLocations()
                            
                            refreshReturnRates()
                        }
                    )
                    .onChange(of: returnPickupAddress) { newValue in
                        // Validate when address changes (user types manually)
                        if !newValue.isEmpty {
                            validateReturnLocations()
                        }
                    }
                    
                    validationMessage(for: "returnPickupAddress")
                    
                    validationMessage(for: "returnCruisePort")
                    // Cruise ship name field
                    AppTextField(
                        label: "CRUISE SHIP NAME",
                        placeholder: "Enter Cruise Ship Name",
                        text: $returnCruiseShipName,
                        hasError: hasError(for: "returnCruiseShipName")
                    )
                    .focused($focusedField, equals: .returnCruiseShipName)
                    
                    validationMessage(for: "returnCruiseShipName")
                    
                    // Ship arrival time field
                    VStack(alignment: .leading, spacing: 8) {
                        Text("SHIP ARRIVAL TIME")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            showReturnCruiseTimePicker = true
                        }) {
                            HStack {
                                Image(systemName: "clock")
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundColor(.gray)
                                
                                AutoSelectTextField(
                                    placeholder: "Enter arrival time",
                                    text: $returnShipArrivalTime,
                                    fontSize: 14,
                                    fontWeight: .medium,
                                    textColor: .black,
                                    isEnabled: false
                                )
                                .disabled(true)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "returnShipArrivalTime") ? Color.red : Color.clear, lineWidth: hasError(for: "returnShipArrivalTime") ? 1.5 : 0)
                            )
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        validationMessage(for: "returnShipArrivalTime")
                    }
                }
            }
        }
    }
    
    // MARK: - Return Dropoff Section
    private var returnDropoffSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Return Drop-off")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppColors.primaryOrange)
            
            // Dynamic return dropoff fields based on return transfer type
            if let transferType = selectedReturnTransferType, (transferType == "City to City" || transferType == "Airport to City" || transferType == "Cruise Port to City") {
                // Return dropoff is city
                AddressAutocompleteField(
                    viewModel: returnDropoffAddressVM,
                    label: "RETURN DROPOFF ADDRESS",
                    placeholder: "Enter return dropoff address",
                    value: $returnDropoffAddress,
                    hasError: hasError(for: "returnDropoffAddress"),
                    onLocationSelected: { address, coordinate, postalCode in
                        returnDropoffAddress = address
                        returnDropoffCoordinate = coordinate
                        
                        // Clear error and validate locations
                        clearError(for: "returnDropoffAddress")
                        validateReturnLocations()
                        
                        refreshReturnRates()
                    }
                )
                .onChange(of: returnDropoffAddress) { newValue in
                    // Validate when address changes (user types manually)
                    if !newValue.isEmpty {
                        validateReturnLocations()
                    }
                }
                validationMessage(for: "returnDropoffAddress")
            } else if let transferType = selectedReturnTransferType, (transferType == "City to Airport" || transferType == "Airport to Airport" || transferType == "Cruise Port to Airport") {
                // Return dropoff is airport
                VStack(spacing: 16) {
                    // Airport selection
                    VStack(alignment: .leading, spacing: 8) {
                        Text("SELECT AIRPORT")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Text("(search by code or name)")
                            .font(.system(size: 10, weight: .regular))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            currentAirportType = "returnDropoff"
                            Task {
                                await airportService.fetchAllAirports()
                                // Only show the sheet after airports are loaded
                                await MainActor.run {
                                    showAirportBottomSheet = true
                                }
                            }
                        }) {
                            HStack {
                                Text(selectedReturnDropoffAirport ?? "Search airports...")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(selectedReturnDropoffAirport == nil ? .black : .black)
                                Spacer()
                                 Image("arrowIcon")

                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "returnDropoffAirport") ? Color.red : Color.clear, lineWidth: hasError(for: "returnDropoffAirport") ? 1.5 : 0)
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        validationMessage(for: "returnDropoffAirport")
                    }
                    
                    // Airline selection
                    VStack(alignment: .leading, spacing: 8) {
                        Text("SELECT AIRLINE")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            currentAirlineType = "returnDropoff"
                            showAirlineBottomSheet = true
                        }) {
                            HStack {
                                Text(returnDropoffAirlineDisplayName)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(selectedReturnDropoffAirline == nil ? .black : .black)
                                Spacer()
                                 Image("arrowIcon")

                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "returnDropoffAirline") ? Color.red : Color.clear, lineWidth: hasError(for: "returnDropoffAirline") ? 1.5 : 0)
                            )
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        validationMessage(for: "returnDropoffAirline")
                    }
                    
                    // Flight number field
                    AppTextField(
                        
                        label: "FLIGHT NUMBER",
                        placeholder: "Enter Flight Number",
                        text: $returnDropoffFlightNumber,
                        hasError: hasError(for: "returnDropoffFlightNumber")
                    )
                    .focused($focusedField, equals: .returnDropoffFlightNumber)
                    
                    validationMessage(for: "returnDropoffFlightNumber")
                }
            } else if let transferType = selectedReturnTransferType, (transferType == "City to Cruise Port" || transferType == "Airport to Cruise Port" || transferType == "Cruise Port to Cruise Port") {
                // Return dropoff is cruise port
                VStack(spacing: 16) {
                    // Cruise port address
                    AddressAutocompleteField(
                        viewModel: returnDropoffAddressVM,
                        label: "RETURN DROPOFF ADDRESS",
                        placeholder: "Enter return dropoff address",
                        value: $returnDropoffAddress,
                        hasError: hasError(for: "returnDropoffAddress"),
                        onLocationSelected: { address, coordinate, postalCode in
                            returnDropoffAddress = address
                            returnDropoffCoordinate = coordinate
                            
                            // Clear error and validate locations
                            clearError(for: "returnDropoffAddress")
                            validateReturnLocations()
                            
                            refreshReturnRates()
                        }
                    )
                    .onChange(of: returnDropoffAddress) { newValue in
                        // Validate when address changes (user types manually)
                        if !newValue.isEmpty {
                            validateReturnLocations()
                        }
                    }
                    
                    validationMessage(for: "returnDropoffAddress")
                    
                    // Cruise ship name field
                    AppTextField(
                        label: "CRUISE SHIP NAME",
                        placeholder: "Enter Cruise Ship Name",
                        text: $returnCruiseShipName,
                        hasError: hasError(for: "returnCruiseShipName")
                    )
                    .focused($focusedField, equals: .returnCruiseShipName)
                    
                    validationMessage(for: "returnCruiseShipName")
                    
                    // Ship arrival time field
                    VStack(alignment: .leading, spacing: 8) {
                        Text("SHIP ARRIVAL TIME")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.gray)
                        
                        Button(action: {
                            showReturnCruiseTimePicker = true
                        }) {
                            HStack {
                                Image(systemName: "clock")
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundColor(.gray)
                                
                                AutoSelectTextField(
                                    placeholder: "Enter arrival time",
                                    text: $returnShipArrivalTime,
                                    fontSize: 14,
                                    fontWeight: .medium,
                                    textColor: .gray,
                                    isEnabled: false
                                )
                                .disabled(true)
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(hasError(for: "returnShipArrivalTime") ? Color.red : Color.clear, lineWidth: hasError(for: "returnShipArrivalTime") ? 1.5 : 0)
                            )
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        validationMessage(for: "returnShipArrivalTime")
                    }
                }
            }
        }
    }
    
    // MARK: - Return Extra Stops Section
    private var returnExtraStopsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            returnExtraStopsHeader
            returnExtraStopsList
            addReturnStopButton
        }
    }
    
    private var returnExtraStopsHeader: some View {
        Text("Return Extra Stops")
            .font(.system(size: 18, weight: .bold))
            .foregroundColor(AppColors.primaryOrange)
    }
    
    private var returnExtraStopsList: some View {
        VStack(spacing: 12) {
            ForEach(Array(returnExtraStops.enumerated()), id: \.element.id) { index, stop in
                returnExtraStopRow(index: index, stop: stop)
            }
        }
    }
    
    private func returnExtraStopRow(index: Int, stop: ExtraStop) -> some View {
        HStack(alignment: .top, spacing: 12) {
            AddressAutocompleteField(
                viewModel: stop.addressVM,
                label: "STOP \(index + 1)",
                placeholder: "Enter stop address",
                value: Binding(
                    get: { stop.address },
                    set: { stop.address = $0 }
                ),
                onLocationSelected: { address, coordinate, postalCode in
                    stop.address = address
                    stop.coordinate = coordinate
                    stop.isLocationSelected = true
                    
                    if let errorMessage = validateExtraStop(stop, isReturnTrip: true) {
                        stop.address = ""
                        stop.coordinate = nil
                        stop.isLocationSelected = false
                        returnExtraStopValidationError = errorMessage
                        showInvalidLocationDialog = false
                        return
                    }
                    
                    returnExtraStopValidationError = nil
                    
                    // Automatically call booking rates API when return extra stop location is selected
                    Task {
                        await fetchBookingRates()
                    }
                }
            )
            
            Button(action: {
                returnExtraStops.removeAll { $0.id == stop.id }
                returnExtraStopValidationError = nil
                showInvalidLocationDialog = false
                // Refresh return rates when return extra stop is removed
                refreshReturnRates()
            }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 20))
                    .foregroundColor(.red)
            }
            .frame(width: 30, height: 30)
        }
    }
    
    private var addReturnStopButton: some View {
        VStack(alignment: .leading, spacing: 8) {
            if !isReturnExtraStopButtonEnabled {
                Text("Extra stop should be in the same country as pickup and drop-off.")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.red)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(6)
            }
            
            if let returnExtraStopValidationError {
                Text(returnExtraStopValidationError)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.red)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(6)
            }
            
            Button(action: {
                addReturnExtraStop()
            }) {
                HStack {
                    Text("Add Extra Stop")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background((isReturnExtraStopButtonEnabled && returnExtraStopValidationError == nil) ? AppColors.primaryOrange : AppColors.greenColor.opacity(0.4))
                        .cornerRadius(8)
                }

            }
            .disabled(!isReturnExtraStopButtonEnabled || returnExtraStopValidationError != nil)
            .buttonStyle(PlainButtonStyle())
        }
    }
    
    // MARK: - Helper Functions for Bottom Sheets
    private func getCurrentSelectedAirport() -> Binding<Airport?> {
        return Binding<Airport?>(
            get: {
                switch currentAirportType {
                case "pickup":
                    guard let airportName = selectedPickupAirport else { return nil }
                    return airportService.airports.first { $0.displayName == airportName }
                case "dropoff":
                    guard let airportName = selectedDropoffAirport else { return nil }
                    return airportService.airports.first { $0.displayName == airportName }
                case "returnPickup":
                    guard let airportName = selectedReturnPickupAirport else { return nil }
                    return airportService.airports.first { $0.displayName == airportName }
                case "returnDropoff":
                    guard let airportName = selectedReturnDropoffAirport else { return nil }
                    return airportService.airports.first { $0.displayName == airportName }
                default:
                    return nil
                }
            },
            set: { _ in }
        )
    }
    
    private func getCurrentSelectedAirline() -> Binding<Airline?> {
        return Binding<Airline?>(
            get: {
                switch currentAirlineType {
                case "pickup":
                    guard let airlineId = selectedPickupAirline else { return nil }
                    return airlineService.airlines.first { $0.id == Int(airlineId) }
                case "dropoff":
                    guard let airlineId = selectedDropoffAirline else { return nil }
                    return airlineService.airlines.first { $0.id == Int(airlineId) }
                case "returnPickup":
                    guard let airlineId = selectedReturnPickupAirline else { return nil }
                    return airlineService.airlines.first { $0.id == Int(airlineId) }
                case "returnDropoff":
                    guard let airlineId = selectedReturnDropoffAirline else { return nil }
                    return airlineService.airlines.first { $0.id == Int(airlineId) }
                default:
                    return nil
                }
            },
            set: { _ in }
        )
    }
    
    private func handleAirportSelection(airport: Airport) {
        switch currentAirportType {
        case "pickup":
            selectedPickupAirport = airport.displayName
            pickupAirportSearch = airport.displayName
            pickupAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
            // Clear error and validate after selection
            clearError(for: "pickupAirport")
            validateOutboundLocations()
        case "dropoff":
            selectedDropoffAirport = airport.displayName
            dropoffAirportSearch = airport.displayName
            dropoffAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
            // Clear error and validate after selection
            clearError(for: "dropoffAirport")
            validateOutboundLocations()
        case "returnPickup":
            selectedReturnPickupAirport = airport.displayName
            returnPickupAirportSearch = airport.displayName
            returnPickupAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
            // Clear error and validate after selection
            clearError(for: "returnPickupAirport")
            validateReturnLocations()
        case "returnDropoff":
            selectedReturnDropoffAirport = airport.displayName
            returnDropoffAirportSearch = airport.displayName
            returnDropoffAirportCoordinate = LocationCoordinate(latitude: airport.lat ?? 0, longitude: airport.long ?? 0)
            // Clear error and validate after selection
            clearError(for: "returnDropoffAirport")
            validateReturnLocations()
        default:
            break
        }
    }
    
    private func handleAirlineSelection(airline: Airline) {
        switch currentAirlineType {
        case "pickup":
            selectedPickupAirline = String(airline.id)
        case "dropoff":
            selectedDropoffAirline = String(airline.id)
        case "returnPickup":
            selectedReturnPickupAirline = String(airline.id)
        case "returnDropoff":
            selectedReturnDropoffAirline = String(airline.id)
        default:
            break
        }
    }
}

#Preview {
    ComprehensiveBookingView(
        onComplete: nil,
        rideData: VehicleSelectionView.RideData(
            serviceType: "one_way",
            bookingHour: "2",
            pickupType: "city",
            dropoffType: "airport",
            pickupDate: "2025-01-15",
            pickupTime: "14:30:00",
            pickupLocation: "Manhattan, New York, NY, USA",
            destinationLocation: "JFK Airport",
            selectedPickupAirport: "",
            selectedDestinationAirport: "JFK-John F Kennedy Intl",
            noOfPassenger: 2,
            noOfLuggage: 1, noOfVehicles: 5,
            pickupLat: 40.7589,
            pickupLong: -73.9851,
            destinationLat: 40.6413,
            destinationLong: -73.7781
        ),
        selectedVehicle: nil
    )
}


// MARK: - Extra Stop Error Banner View
struct ExtraStopErrorBannerView: View {
    let message: String
    
    private var labels: (title: String, subtitle: String) {
        let trimmed = message.trimmingCharacters(in: .whitespacesAndNewlines)
        let lowercased = trimmed.lowercased()
        
        if lowercased.contains("country") {
            return (
                "Pickup and drop countries must match",
                "Please select pickup and drop-off within the same country."
            )
        }
        
        if lowercased.contains("cannot be the same") || lowercased.contains("same location") || lowercased.contains("pickup and drop") || lowercased.contains("extra stop") {
            return (
                "Invalid location selected",
                trimmed
            )
        }
        
        if let periodIndex = trimmed.firstIndex(of: ".") {
            let title = String(trimmed[..<periodIndex]).trimmingCharacters(in: .whitespaces)
            let remainder = trimmed[trimmed.index(after: periodIndex)...].trimmingCharacters(in: .whitespaces)
            if !title.isEmpty && !remainder.isEmpty {
                return (title, remainder)
            }
        }
        
        return ("Invalid location selected", trimmed)
    }
    
    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color(red: 1.0, green: 0.94, blue: 0.94))
                    .frame(width: 36, height: 36)
                Circle()
                    .stroke(Color(red: 0.93, green: 0.46, blue: 0.46), lineWidth: 1)
                    .frame(width: 36, height: 36)
                Image(systemName: "info.circle.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(Color(red: 0.78, green: 0.12, blue: 0.12))
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(labels.title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(Color(red: 0.78, green: 0.12, blue: 0.12))
                Text(labels.subtitle)
                    .font(.system(size: 14, weight: .regular))
                    .foregroundColor(Color(red: 0.58, green: 0.16, blue: 0.16))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color(red: 1.0, green: 0.95, blue: 0.95))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(Color(red: 0.94, green: 0.47, blue: 0.47), lineWidth: 1)
        )
    }
}
