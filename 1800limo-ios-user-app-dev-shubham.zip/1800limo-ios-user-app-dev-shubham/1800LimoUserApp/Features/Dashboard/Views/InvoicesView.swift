//
//  InvoicesView.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct InvoicesView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = InvoiceViewModel()
    @State private var navigateToInvoiceDetails = false
    @State private var navigateToInvoiceWebView = false
    @State private var selectedInvoice: Invoice?
    @State private var isSearching = false
    
    var body: some View {
        VStack(spacing: 0) {
            headerView
            contentView
        }
        .background(navigationLinks)
    }
    
    // MARK: - Header View
    private var headerView: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Text("Invoices")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.black)
                
                Spacer()
                
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        isSearching.toggle()
                        if !isSearching {
                            viewModel.searchText = ""
                        }
                    }
                }) {
                    Image(systemName: isSearching ? "xmark" : "magnifyingglass")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                }
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            
            if isSearching {
                searchBarView
            }
        }
        .background(Color.white)
    }
    
    // MARK: - Search Bar View
    private var searchBarView: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("Search invoices...", text: $viewModel.searchText)
                .textFieldStyle(PlainTextFieldStyle())
                .onChange(of: viewModel.searchText) { newValue in
                    viewModel.handleSearch(newValue)
                }
            
            if !viewModel.searchText.isEmpty {
                Button(action: { 
                    viewModel.searchText = ""
                    viewModel.refreshInvoices()
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
        .padding(.horizontal, 18)
        .padding(.bottom, 12)
        .transition(.opacity.combined(with: .move(edge: .top)))
    }
    
    // MARK: - Content View
    private var contentView: some View {
        ScrollView {
            VStack(spacing: 18) {
                summaryCardView
                timePeriodSelectorView
                invoicesSectionView
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .refreshable {
            // Refresh invoices
            viewModel.refreshInvoices()
        }
        .onAppear {
            // Fetch initial invoices
            viewModel.fetchInvoices()
        }
        .alert("Error", isPresented: $viewModel.showError) {
            Button("OK") { }
        } message: {
            Text(viewModel.errorMessage ?? "An error occurred")
        }
    }
    
    // MARK: - Summary Card View
    private var summaryCardView: some View {
        UserWeeklySummaryCard(
            dateRange: viewModel.dateRangeString,
            totalSpent: String(format: "%.2f", viewModel.totalSpent),
            totalBookings: "\(viewModel.invoices.count)",
            completedRides: "\(viewModel.paidInvoices)",
            onPreviousPeriod: {
                handlePreviousNavigation()
            },
            onNextPeriod: {
                handleNextNavigation()
            },
            canGoPrevious: true,
            canGoNext: true,
            currencySymbol: "$",
            hideMetrics: true
        )
        .padding(.horizontal, 18)
        .padding(.top, 20)
    }
    
    // MARK: - Time Period Selector View
    private var timePeriodSelectorView: some View {
        VStack(spacing: 12) {
            Picker("Time Period", selection: $viewModel.selectedTimePeriod) {
                ForEach(TimePeriod.allCases, id: \.self) { period in
                    Text(period.rawValue).tag(period)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.horizontal, 18)
            .onChange(of: viewModel.selectedTimePeriod) { newPeriod in
                viewModel.handleTimePeriodChange(newPeriod)
            }
            
            if viewModel.selectedTimePeriod == .custom {
                UserCustomDateRangePicker(
                    startDate: $viewModel.selectedWeekStart,
                    endDate: $viewModel.selectedWeekEnd,
                    onDateRangeSelected: {
                        viewModel.handleDateRangeSelection(
                            startDate: viewModel.selectedWeekStart,
                            endDate: viewModel.selectedWeekEnd
                        )
                    }
                )
                .padding(.horizontal, 18)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(.top, 16)
    }
    
    // MARK: - Invoices Section View
    private var invoicesSectionView: some View {
        Group {
            if viewModel.isLoading && viewModel.invoices.isEmpty {
                loadingView
            } else if viewModel.invoices.isEmpty {
                emptyStateView
            } else {
                invoicesListView
            }
        }
    }
    
    // MARK: - Loading View
    private var loadingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .scaleEffect(1.2)
                .progressViewStyle(CircularProgressViewStyle(tint: .orange))
            
            Text("Loading invoices...")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.vertical, 40)
    }
    
    // MARK: - Empty State View
    private var emptyStateView: some View {
        VStack(spacing: 16) {
            Image(systemName: "doc.text")
                .font(.system(size: 48))
                .foregroundColor(.gray)
            Text("No invoices found")
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.black)
            Text("No invoices available for the selected period")
                .font(.system(size: 14))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.top, 100)
    }
    
    // MARK: - Invoices List View
    private var invoicesListView: some View {
        let groupedInvoices = Dictionary(grouping: viewModel.invoices) { invoice in
            invoice.date
        }
        
        let sortedDates = groupedInvoices.keys.sorted()
        
        return VStack(spacing: 24) {
            ForEach(sortedDates, id: \.self) { date in
                if let invoicesForDate = groupedInvoices[date] {
                    dateGroupView(date: date, invoices: invoicesForDate)
                }
            }
        }
    }
    
    // MARK: - Date Group View
    private func dateGroupView(date: String, invoices: [Invoice]) -> some View {
        VStack(spacing: 12) {
            VStack(spacing: 18) {
                ForEach(invoices, id: \.id) { invoice in
                    InvoiceCard(
                        invoice: invoice,
                        onViewInvoiceSummary: {
                            selectedInvoice = invoice
                            navigateToInvoiceWebView = true
                        }
                    )
                }
            }
            .padding(.horizontal, 18)
        }
    }
    
    // MARK: - Navigation Links
    private var navigationLinks: some View {
        Group {
            NavigationLink(
                destination: InvoiceDetailsView(invoice: selectedInvoice ?? Invoice.sampleInvoices[0]),
                isActive: $navigateToInvoiceDetails
            ) {
                EmptyView()
            }
        }
        .fullScreenCover(isPresented: $navigateToInvoiceWebView) {
            if let invoice = selectedInvoice {
                InvoiceWebView(invoiceId: invoice.booking_id)
            }
        }
    }
    
    // MARK: - Navigation Handlers
    
    private func handlePreviousNavigation() {
        switch viewModel.selectedTimePeriod {
        case .weekly:
            viewModel.goToPreviousWeek()
        case .monthly:
            viewModel.goToPreviousMonth()
        case .yearly:
            viewModel.goToPreviousYear()
        case .custom:
            // Custom doesn't have navigation arrows
            break
        }
    }
    
    private func handleNextNavigation() {
        switch viewModel.selectedTimePeriod {
        case .weekly:
            viewModel.goToNextWeek()
        case .monthly:
            viewModel.goToNextMonth()
        case .yearly:
            viewModel.goToNextYear()
        case .custom:
            // Custom doesn't have navigation arrows
            break
        }
    }
}

// MARK: - Invoice Details View (Placeholder)
struct InvoiceDetailsView: View {
    let invoice: Invoice
    
    var body: some View {
        VStack {
            Text("Invoice Details")
                .font(.title)
            Text("Invoice #\(invoice.invoice_number)")
            Text("Amount: \(invoice.formattedTotal)")
        }
        .padding()
    }
}

// MARK: - Preview
#Preview {
    NavigationView {
        InvoicesView()
    }
}
