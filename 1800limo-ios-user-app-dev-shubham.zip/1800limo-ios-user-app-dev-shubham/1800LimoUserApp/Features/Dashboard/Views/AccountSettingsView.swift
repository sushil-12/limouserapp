import SwiftUI

struct AccountSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var profileService = ProfileService()
    @StateObject private var addressAutocompleteViewModel = AddressAutocompleteViewModel()
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var email = ""
    @State private var mobileNumber = ""
    @State private var address = ""
    @State private var country = ""
    @State private var zipCode = ""
    @State private var gender = ""
    @State private var dateOfBirth = ""
    @State private var city = ""
    @State private var stateName = ""
    @State private var latitude: Double?
    @State private var longitude: Double?
    @State private var isSaving = false
    @State private var showSaveSuccess = false
    @State private var saveSuccessMessage = ""
    @State private var selectedCountry = Country(name: "United States", code: "+1", flag: "🇺🇸", phoneLength: 10, shortCode: "US")
    @State private var showCountrySheet = false
    
    var body: some View {
        VStack(spacing: 0) {
            headerView
            
            ScrollView {
                VStack(spacing: 20) {
                    // First Name and Last Name Row
                    HStack(spacing: 16) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("FIRST NAME *")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.black)
                            
                            TextField("Enter first name", text: $firstName)
                                .font(.system(size: 16, weight: .regular))
                                .foregroundColor(.black)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(8)
                        }
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("LAST NAME *")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.black)
                            
                            TextField("Enter last name", text: $lastName)
                                .font(.system(size: 16, weight: .regular))
                                .foregroundColor(.black)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 12)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(8)
                        }
                    }
                    
                    // Email Field
                    VStack(alignment: .leading, spacing: 8) {
                        Text("EMAIL *")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.black)
                        
                        TextField("Enter email", text: $email)
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(.black)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                    
                    // Mobile Number Field
                    VStack(alignment: .leading, spacing: 8) {
                        Text("MOBILE *")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.black)
                        
                        HStack(spacing: 12) {
                            // Country Code Dropdown (enabled)
                            Button(action: {
                                showCountrySheet = true
                            }) {
                                HStack(spacing: 6) {
                                    Text(selectedCountry.flag)
                                     Image("arrowIcon")

                                        .foregroundColor(.gray)
                                }
                                .padding(.horizontal, 12)
                                .padding(.vertical, 10)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(8)
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            // Phone Number Field (read-only but visible)
                            HStack {
                                Text(selectedCountry.code)
                                    .foregroundColor(.black)
                                    .font(.system(size: 16))
                                Text(mobileNumber)
                                    .foregroundColor(.black)
                                    .font(.system(size: 16))
                                Spacer()
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 10)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                        }
                    }
                    
                    // Address Field (Google Places Autocomplete)
                    AddressAutocompleteField(
                        viewModel: addressAutocompleteViewModel,
                        label: "ADDRESS *",
                        placeholder: "Enter address",
                        isRequired: false,
                        value: $address,
                        onLocationSelected: { selectedLocation, coordinate, postalCode in
                            address = selectedLocation
                            let components = parseLocationComponents(from: selectedLocation)
                            if let newCity = components.city {
                                city = newCity
                            }
                            if let newState = components.state {
                                stateName = newState
                            }
                            if let postalCode = postalCode {
                                zipCode = postalCode
                            }
                            if let selectedCountry = addressAutocompleteViewModel.selectedCountry, !selectedCountry.isEmpty {
                                country = sanitizedCountryName(selectedCountry)
                            } else if let derivedCountry = components.country {
                                country = sanitizedCountryName(derivedCountry)
                            }
                            if let coordinate = coordinate {
                                latitude = coordinate.latitude
                                longitude = coordinate.longitude
                            }
                        }
                    )
                    
                    // Country Field (auto-filled from Address selection)
                    VStack(alignment: .leading, spacing: 8) {
                        Text("COUNTRY *")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.black)
                        
                        TextField("Enter country", text: $country)
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(.black)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                    
                    // ZIP Code Field
                    VStack(alignment: .leading, spacing: 8) {
                        Text("ZIP CODE / COUNTRY ADDRESS CODE *")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundColor(.black)
                        
                        TextField("Enter ZIP code", text: $zipCode)
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(.black)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 100) // Space for the save button
            }
            
            Spacer()
            
            // Save Button
            Button(action: {
                saveAccountSettings()
            }) {
                HStack(spacing: 8) {
                    if isSaving {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    }
                    
                    Text(isSaving ? "Saving..." : "Save")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(AppColors.primaryOrange)
                    .cornerRadius(8)
            }
            .disabled(isSaving)
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .onAppear {
            loadProfileData()
        }
        .alert("Error", isPresented: $profileService.showError) {
            Button("OK") { }
        } message: {
            Text(profileService.errorMessage ?? "An error occurred")
        }
        .alert("Success", isPresented: $showSaveSuccess) {
            Button("OK") { }
        } message: {
            Text(saveSuccessMessage)
        }
        .sheet(isPresented: $showCountrySheet) {
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Spacer()
                    Text("Select Country")
                        .font(.headline)
                        .padding()
                    Spacer()
                }
                Divider()
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(countries) { country in
                            Button(action: {
                                selectedCountry = country
                                showCountrySheet = false
                            }) {
                                HStack {
                                    Text(country.flag)
                                    Text(country.name)
                                    Spacer()
                                    Text(country.code)
                                }
                                .padding(12)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
            }
            .presentationDetents([.medium, .large])
        }
    }
    
    // MARK: - Header View
    private var headerView: some View {
        HStack {
            Button(action: {
                dismiss()
            }) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
            }
            
            Spacer()
            
            Text("Account Settings")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
            
            Spacer()
            
            // Invisible button to balance the layout
            Button(action: {}) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.clear)
            }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 16)
        .background(Color.white)
    }
    
    // MARK: - Helper Methods
    private func loadProfileData() {
        // First try to load from storage
        if let storedProfileData = StorageManager.shared.getProfileData() {
            populateFields(with: storedProfileData)
        }
        
        // Then fetch fresh data from API
        Task {
            await profileService.fetchProfileData()
            if let freshProfileData = profileService.profileData {
                populateFields(with: freshProfileData)
            } else if profileService.errorMessage == nil {
                profileService.errorMessage = "Unable to load profile data. Please try again."
                profileService.showError = true
            }
        }
    }
    
    private func populateFields(with profileData: ProfileData) {
        firstName = profileData.first_name
        lastName = profileData.last_name
        email = profileData.email
        mobileNumber = profileData.mobile
        address = profileData.address ?? profileData.city
        city = profileData.city
        stateName = profileData.state
        country = sanitizedCountryName(countryName(from: profileData))
        zipCode = profileData.zip
        gender = profileData.gender ?? gender
        dateOfBirth = profileData.dob ?? defaultDOB()
        latitude = Double(profileData.latitude ?? "")
        longitude = Double(profileData.longitude ?? "")
        
        // Ensure the autocomplete field shows the prefilled address
        addressAutocompleteViewModel.input = address
        
        // Set country for phone field
        selectedCountry = profileService.getCountryFromCode(profileData.mobileCountry)
    }
    
    private func saveAccountSettings() {
        let trimmedFirstName = firstName.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedLastName = lastName.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedAddress = address.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedCountry = sanitizedCountryName(country)
        let trimmedZip = zipCode.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !trimmedFirstName.isEmpty else {
            showValidationError("First name is required.")
            return
        }
        
        guard !trimmedLastName.isEmpty else {
            showValidationError("Last name is required.")
            return
        }
        
        guard !trimmedEmail.isEmpty else {
            showValidationError("Email is required.")
            return
        }
        
        guard isValidEmail(trimmedEmail) else {
            showValidationError("Please enter a valid email address.")
            return
        }
        
        guard !trimmedAddress.isEmpty else {
            showValidationError("Address is required.")
            return
        }
        
        guard !trimmedCountry.isEmpty else {
            showValidationError("Country is required.")
            return
        }
        
        guard !trimmedZip.isEmpty else {
            showValidationError("ZIP code is required.")
            return
        }
        
        let resolvedGender = gender.isEmpty ? (profileService.profileData?.gender ?? "male") : gender
        let resolvedDOB = dateOfBirth.isEmpty ? defaultDOB() : normalizeDOB(dateOfBirth)
        let resolvedCity = city.isEmpty ? (profileService.profileData?.city ?? "") : city
        let resolvedState = stateName.isEmpty ? (profileService.profileData?.state ?? "") : stateName
        let cleanedCity = resolvedCity.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanedState = resolvedState.trimmingCharacters(in: .whitespacesAndNewlines)
        let resolvedLatitude = latitude ?? double(from: profileService.profileData?.latitude) ?? 0.0
        let resolvedLongitude = longitude ?? double(from: profileService.profileData?.longitude) ?? 0.0
        
        isSaving = true
        
        let request = UpdateProfileRequest(
            firstName: trimmedFirstName,
            lastName: trimmedLastName,
            email: trimmedEmail,
            gender: resolvedGender,
            dateOfBirth: resolvedDOB,
            address: trimmedAddress,
            city: cleanedCity,
            state: cleanedState,
            country: trimmedCountry,
            zip: trimmedZip,
            latitude: resolvedLatitude,
            longitude: resolvedLongitude
        )
        
        Task { @MainActor in
            let result = await profileService.updateUserProfile(request: request)
            
            if result.success {
                saveSuccessMessage = result.message ?? "Profile updated successfully"
                showSaveSuccess = true
            } else if profileService.errorMessage == nil {
                profileService.errorMessage = result.message ?? "Unable to update profile. Please try again."
                profileService.showError = true
            }
            
            isSaving = false
        }
    }
    
    private func showValidationError(_ message: String) {
        profileService.errorMessage = message
        profileService.showError = true
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: email)
    }
    
    private func parseLocationComponents(from address: String) -> (city: String?, state: String?, country: String?) {
        let components = address
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        
        guard !components.isEmpty else {
            return (nil, nil, nil)
        }
        
        let countryComponent = components.last
        let stateComponent = components.dropLast().last
        let cityComponent: String?
        
        if components.count >= 3 {
            cityComponent = components.dropLast(2).last
        } else if components.count == 2 {
            cityComponent = components.first
        } else {
            cityComponent = components.first
        }
        
        return (cityComponent, stateComponent, countryComponent)
    }
    
    private func sanitizedCountryName(_ value: String) -> String {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return "" }
        
        if trimmed.count == 2, let match = countries.first(where: { $0.shortCode.compare(trimmed, options: .caseInsensitive) == .orderedSame }) {
            return match.name
        }
        
        if let match = countries.first(where: { $0.name.compare(trimmed, options: .caseInsensitive) == .orderedSame }) {
            return match.name
        }
        
        return trimmed
    }
    
    private func countryName(from profileData: ProfileData) -> String {
        if let countryName = countries.first(where: { $0.shortCode.compare(profileData.country, options: .caseInsensitive) == .orderedSame })?.name {
            return countryName
        }
        if let profileCountry = countries.first(where: { $0.name.compare(profileData.country, options: .caseInsensitive) == .orderedSame })?.name {
            return profileCountry
        }
        return profileService.getCountryName()
    }
    
    private func defaultDOB() -> String {
        return "1990-01-01"
    }
    
    private func normalizeDOB(_ value: String) -> String {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            return defaultDOB()
        }
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        if let _ = formatter.date(from: trimmed) {
            return trimmed
        }
        
        let fallbackFormatter = DateFormatter()
        fallbackFormatter.dateFormat = "MM/dd/yyyy"
        if let date = fallbackFormatter.date(from: trimmed) {
            return formatter.string(from: date)
        }
        
        return defaultDOB()
    }
    
    private func double(from value: String?) -> Double? {
        guard let value = value?.trimmingCharacters(in: .whitespacesAndNewlines),
              !value.isEmpty else { return nil }
        return Double(value)
    }
}

#Preview {
    NavigationView {
        AccountSettingsView()
    }
}
