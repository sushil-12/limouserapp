import SwiftUI

struct MyCardsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var profileService = ProfileService()
    @State private var cardHolderName = ""
    @State private var cardNumber = ""
    @State private var expiryMonth = "MM"
    @State private var expiryYear = "YYYY"
    @State private var cvv = ""
    @State private var isEditing = false
    @State private var savedCards: [SavedCard] = []
    @State private var showSuccessAlert = false
    @State private var successMessage = ""
    @State private var showErrorAlert = false
    @State private var errorMessage = ""
    @State private var currentCardIndex = 0
    @State private var showMonthSheet = false
    @State private var showYearSheet = false
    @State private var shouldScrollToCards = false
    
    var body: some View {
        VStack(spacing: 0) {
            headerView
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(spacing: 24) {
                        if profileService.isLoading && savedCards.isEmpty {
                            MyCardsShimmerView()
                        } else {
                        // Saved Cards Section
                        VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Text("My Cards")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(AppColors.primaryOrange)
                            
//                            Spacer()
//                            
//                            Button(action: {
//                                isEditing.toggle()
//                            }) {
//                                HStack(spacing: 4) {
//                                    Image(systemName: "pencil")
//                                        .font(.system(size: 14, weight: .medium))
//                                        .foregroundColor(.gray)
//                                    
//                                    Text("Edit")
//                                        .font(.system(size: 14, weight: .medium))
//                                        .foregroundColor(.gray)
//                                }
//                            }
                        }
                        
                        // Saved Cards Display - Card Slider
                        if !savedCards.isEmpty {
                            VStack(spacing: 16) {
                                // Card Slider
                                GeometryReader { geometry in
                                    let containerWidth = geometry.size.width
                                    let cardSpacing: CGFloat = 16
                                    let sideInset: CGFloat = 20
                                    let tabHorizontalPadding = max(0, sideInset - (cardSpacing / 2))
                                    let cardWidth = containerWidth - (sideInset * 2)
                                    
                                    TabView(selection: $currentCardIndex) {
                                        ForEach(Array(savedCards.enumerated()), id: \.element.id) { index, card in
                                            SavedCardView(card: card, isEditing: isEditing)
                                                .frame(width: cardWidth, height: 200)
                                                .padding(.horizontal, cardSpacing / 2)
                                                .padding(.vertical, 4)
                                                .padding(.horizontal, 14)
                                                .contentShape(Rectangle())
                                                .tag(index)
                                        }
                                    }
                                    .frame(width: containerWidth, height: 220)
                                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                                    .padding(.horizontal, tabHorizontalPadding)
                                    .onChange(of: currentCardIndex) { newIndex in
                                        print("Card slider changed to index: \(newIndex)")
                                    }
                                }
                                .frame(height: 220)
                                
                                // Dot Indicators
                                if savedCards.count > 1 {
                                    HStack(spacing: 12) {
                                        ForEach(0..<savedCards.count, id: \.self) { index in
                                            Circle()
                                                .fill(index == currentCardIndex ? AppColors.primaryOrange : Color.gray.opacity(0.3))
                                                .frame(width: 8, height: 8)
                                                .animation(.easeInOut(duration: 0.3), value: currentCardIndex)
                                        }
                                    }
                                    .padding(.top, 8)
                                }
                            }
                        } else {
                            // No cards message
                            VStack(spacing: 12) {
                                Image(systemName: "creditcard")
                                    .font(.system(size: 40))
                                    .foregroundColor(.gray.opacity(0.6))
                                
                                Text("No cards saved yet")
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundColor(.gray)
                                
                                Text("Add your first card below")
                                    .font(.system(size: 14))
                                    .foregroundColor(.gray.opacity(0.8))
                            }
                            .frame(height: 200)
                            .frame(maxWidth: .infinity)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(12)
                        }
                    }
                    .id("savedCardsSection")
                    .padding(.horizontal, 20)
                    
                    // Separator
                    HStack {
                        Rectangle()
                            .fill(Color.gray.opacity(0.3))
                            .frame(height: 1)
                        
                        Text("Or")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.gray)
                            .padding(.horizontal, 16)
                        
                        Rectangle()
                            .fill(Color.gray.opacity(0.3))
                            .frame(height: 1)
                    }
                    .padding(.horizontal, 20)
                    
                    // Add Another Card Section
                    VStack(alignment: .leading, spacing: 20) {
                        Text("Add another card")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(AppColors.primaryOrange)
                            .padding(.horizontal, 20)
                        
                        VStack(spacing: 16) {
                            // First & Last Name
                            VStack(alignment: .leading, spacing: 8) {
                                Text("FIRST & LAST NAME *")
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                                
                                TextField("Enter name", text: $cardHolderName)
                                    .font(.system(size: 16, weight: .regular))
                                    .foregroundColor(.black)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 12)
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(8)
                            }
                            
                            // Card Number
                            VStack(alignment: .leading, spacing: 8) {
                                Text("CARD NO. *")
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                                
                                TextField("Enter card number", text: $cardNumber)
                                    .font(.system(size: 16, weight: .regular))
                                    .foregroundColor(.black)
                                    .keyboardType(.numberPad)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 12)
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(8)
                                    .onChange(of: cardNumber) { newValue in
                                        cardNumber = CardValidationService.formatCardNumber(newValue)
                                    }
                            }
                            
                            // Expiry Date Row
                            HStack(spacing: 16) {
                                // Expiry Month
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("EXPIRY MONTH *")
                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(.gray)
                                    Button(action: {
                                        showMonthSheet = true
                                    }) {
                                        HStack {
                                            Text(expiryMonth)
                                                .font(.system(size: 16, weight: .regular))
                                                .foregroundColor(expiryMonth == "MM" ? .gray : .black)
                                            Spacer()
                                            Image("arrowIcon")
                                                .font(.system(size: 12))
                                                .foregroundColor(.gray)
                                        }
                                        .padding(.horizontal, 16)
                                        .padding(.vertical, 12)
                                        .background(Color.gray.opacity(0.1))
                                        .cornerRadius(8)
                                    }
                                }
                                
                                // Expiry Year
                                VStack(alignment: .leading, spacing: 8) {
                                    Text("EXPIRY YEAR *")
                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(.gray)
                                    Button(action: {
                                        showYearSheet = true
                                    }) {
                                        HStack {
                                            Text(expiryYear)
                                                .font(.system(size: 16, weight: .regular))
                                                .foregroundColor(expiryYear == "YYYY" ? .gray : .black)
                                            Spacer()
                                            Image("arrowIcon")
                                                .font(.system(size: 12))
                                                .foregroundColor(.gray)
                                        }
                                        .padding(.horizontal, 16)
                                        .padding(.vertical, 12)
                                        .background(Color.gray.opacity(0.1))
                                        .cornerRadius(8)
                                    }
                                }
                            }
                            
                            // CVV/CVC
                            VStack(alignment: .leading, spacing: 8) {
                                Text("CVV/CVC *")
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                                
                                SecureField("Enter CVV", text: $cvv)
                                    .font(.system(size: 16, weight: .regular))
                                    .foregroundColor(.black)
                                    .keyboardType(.numberPad)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 12)
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(8)
                                    .onChange(of: cvv) { newValue in
                                        cvv = CardValidationService.formatCVV(newValue)
                                    }
                            }
                            
                        }
                        .padding(.horizontal, 20)
                    }
                    
                    // Action Buttons
                    HStack(spacing: 8) {
                        Spacer()
                        
                        Button(action: {
                            resetForm()
                        }) {
                            Text("Reset")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(width: 94, height: 48)
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(24)
                        }
                        .disabled(profileService.isLoading)
                        
                        Button(action: {
                            saveCard()
                        }) {
                            HStack(spacing: 8) {
                                if profileService.isLoading {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                        .scaleEffect(0.8)
                                }
                                
                                Text(profileService.isLoading ? "Saving" : "Save")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                            .frame(width: 94, height: 48)
                            .background(profileService.isLoading ? AppColors.primaryOrange.opacity(0.7) : AppColors.primaryOrange)
                            .cornerRadius(24)
                        }
                        .disabled(profileService.isLoading)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                        }
                    }
                }
                .onChange(of: savedCards.count) { newCount in
                    // Only scroll if we have cards and shouldScrollToCards is true
                    if shouldScrollToCards && newCount > 0 {
                        Task { @MainActor in
                            try? await Task.sleep(nanoseconds: 300_000_000) // 0.3 seconds
                            withAnimation(.easeInOut(duration: 0.5)) {
                                proxy.scrollTo("savedCardsSection", anchor: .top)
                            }
                            shouldScrollToCards = false
                        }
                    }
                }
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .onAppear {
            loadProfileData()
        }
        // Month bottom sheet
        .appBottomSheet(isPresented: $showMonthSheet, title: "Select Expiry Month") {
            ScrollView {
                VStack(spacing: 0) {
                    ForEach(monthOptions, id: \.self) { month in
                        Button(action: {
                            expiryMonth = month
                            showMonthSheet = false
                        }) {
                            HStack {
                                Text(month)
                                    .foregroundColor(.black)
                                    .font(.system(size: 16))
                                Spacer()
                                if expiryMonth == month {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(.orange)
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(PlainButtonStyle())
                        if month != monthOptions.last {
                            Divider()
                        }
                    }
                }
            }
            .frame(height: UIScreen.main.bounds.height * 0.5)
        }
        // Year bottom sheet
        .appBottomSheet(isPresented: $showYearSheet, title: "Select Expiry Year") {
            ScrollView {
                VStack(spacing: 0) {
                    ForEach(yearOptions, id: \.self) { year in
                        Button(action: {
                            expiryYear = year
                            showYearSheet = false
                        }) {
                            HStack {
                                Text(year)
                                    .foregroundColor(.black)
                                    .font(.system(size: 16))
                                Spacer()
                                if expiryYear == year {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(.orange)
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(PlainButtonStyle())
                        if year != yearOptions.last {
                            Divider()
                        }
                    }
                }
            }
            .frame(height: UIScreen.main.bounds.height * 0.5)
        }
        .alert("Error", isPresented: $profileService.showError) {
            Button("OK") { }
        } message: {
            Text(profileService.errorMessage ?? "An error occurred")
        }
        .alert("Success", isPresented: $showSuccessAlert) {
            Button("OK") { }
        } message: {
            Text(successMessage)
        }
        .alert("Error", isPresented: $showErrorAlert) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
    }
    
    // MARK: - Header View
    private var headerView: some View {
        HStack {
            Button(action: {
                dismiss()
            }) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
            }
            
            Spacer()
            
            Text("My Cards")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
            
            Spacer()
            
            // Invisible button to balance the layout
            Button(action: {}) {
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.clear)
            }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 16)
        .background(Color.white)
    }
    
    // MARK: - Helper Methods
    private var monthOptions: [String] {
        (1...12).map { String(format: "%02d", $0) }
    }
    
    private var yearOptions: [String] {
        let current = Calendar.current.component(.year, from: Date())
        return (0...20).map { String(current + $0) }
    }
    private func loadProfileData() {
        // First try to load from storage
        if let storedProfileData = StorageManager.shared.getProfileData() {
            populateFields(with: storedProfileData)
        }
        
        // Then fetch fresh data from API
        Task {
            await profileService.fetchProfileData()
            if let freshProfileData = profileService.profileData {
                populateFields(with: freshProfileData)
            } else if profileService.errorMessage == nil {
                // Ensure a visible, user-friendly error if decoding failed silently
                profileService.errorMessage = "Unable to load profile data. Please try again."
                profileService.showError = true
            }
        }
    }
    
    private func populateFields(with profileData: ProfileData) {
        // Set card holder name from profile
        cardHolderName = "\(profileData.first_name) \(profileData.last_name)"
        
        // Convert API cards to SavedCard format and sort by most recent first
        savedCards = profileData.cards.map { cardData in
            SavedCard(
                id: cardData.id,
                cardType: "Credit",
                cardBrand: cardData.brand.uppercased(),
                cardHolderName: cardData.name,
                cardNumber: cardData.last4,
                isPrimary: (cardData.cc_prority?.lowercased() == "primary") ?? false
            )
        }.sorted { card1, card2 in
            // Sort by primary first, then by ID (assuming newer cards have higher IDs)
            if card1.isPrimary && !card2.isPrimary {
                return true
            } else if !card1.isPrimary && card2.isPrimary {
                return false
            } else {
                // If both have same primary status, sort by ID (newest first)
                return card1.id > card2.id
            }
        }
        
        // Reset current card index to 0 when cards are loaded
        currentCardIndex = 0
    }
    
    private func resetForm() {
        cardHolderName = ""
        cardNumber = ""
        expiryMonth = "MM"
        expiryYear = "YYYY"
        cvv = ""
    }
    
    private func saveCard() {
        print("💳 MyCardsView - Starting save card process...")
        print("📋 Form data:")
        print("   - Card Holder: \(cardHolderName)")
        print("   - Card Number: \(cardNumber)")
        print("   - CVV: \(cvv)")
        print("   - Exp Month: \(expiryMonth)")
        print("   - Exp Year: \(expiryYear)")
        
        // Validate form
        let validation = CardValidationService.validateCardForm(
            cardNumber: cardNumber,
            cvv: cvv,
            expMonth: expiryMonth,
            expYear: expiryYear,
            cardHolderName: cardHolderName
        )
        
        print("✅ Validation result: \(validation.isValid)")
        if let message = validation.message {
            print("📝 Validation message: \(message)")
        }
        
        if !validation.isValid {
            errorMessage = validation.message ?? "Please check your input"
            showErrorAlert = true
            return
        }
        
        // Prepare request
        let cleanCardNumber = cardNumber.filter { $0.isNumber } // Remove spaces
        let request = AddCreditCardRequest(
            card_type: "personal",
            number: cleanCardNumber,
            cvc: cvv,
            exp_month: expiryMonth,
            exp_year: expiryYear,
            name: cardHolderName
        )
        
        print("📤 Prepared request:")
        print("   - Card Type: \(request.card_type)")
        print("   - Number: \(request.number)")
        print("   - CVC: \(request.cvc)")
        print("   - Exp Month: \(request.exp_month)")
        print("   - Exp Year: \(request.exp_year)")
        print("   - Name: \(request.name)")
        
        // Call API with timeout
        Task {
            print("🌐 Calling ProfileService.addCreditCard...")
            print("⏱️ Starting API call at: \(Date())")
            
            // Add timeout to prevent infinite loading
            do {
                let result = try await withTimeout(seconds: 30) {
                    await profileService.addCreditCard(request: request)
                }
                
                print("⏱️ API call completed at: \(Date())")
                
                await MainActor.run {
                    print("📱 Back on main thread with result:")
                    print("   - Success: \(result.success)")
                    print("   - Message: \(result.message ?? "No message")")
                    print("   - ProfileService isLoading: \(profileService.isLoading)")
                    
                    if result.success {
                        successMessage = result.message ?? "Card added successfully"
                        showSuccessAlert = true
                        resetForm()
                        // Set flag to scroll after cards are loaded
                        shouldScrollToCards = true
                        // Reload profile data to get updated cards
                        loadProfileData()
                        print("✅ Card added successfully, form reset and cards reloaded")
                    } else {
                        errorMessage = result.message ?? "Failed to add card"
                        showErrorAlert = true
                        print("❌ Card addition failed: \(result.message ?? "Unknown error")")
                    }
                }
            } catch {
                print("⏱️ API call timed out at: \(Date())")
                await MainActor.run {
                    errorMessage = "Request timed out. Please try again."
                    showErrorAlert = true
                }
            }
        }
    }
}

// MARK: - Shimmer Placeholders
struct MyCardsShimmerView: View {
    var body: some View {
        VStack(spacing: 24) {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    ShimmerText(width: 120, height: 18)
                    Spacer()
                    ShimmerText(width: 50, height: 14)
                }
                
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.gray.opacity(0.08))
                        .frame(height: 200)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.gray.opacity(0.12), lineWidth: 1)
                        )
                    
                    VStack(alignment: .leading, spacing: 12) {
                        ShimmerText(width: 140, height: 14)
                        Spacer()
                        ShimmerText(width: 180, height: 14)
                        ShimmerText(width: 120, height: 14)
                    }
                    .padding(24)
                }
                
                HStack(spacing: 12) {
                    ForEach(0..<3) { index in
                        Circle()
                            .fill(index == 0 ? AppColors.primaryOrange.opacity(0.7) : Color.gray.opacity(0.2))
                            .frame(width: 8, height: 8)
                    }
                }
            }
            .padding(.horizontal, 20)
            
            HStack {
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .frame(height: 1)
                ShimmerText(width: 30, height: 14)
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .frame(height: 1)
            }
            .padding(.horizontal, 20)
            
            VStack(alignment: .leading, spacing: 20) {
                ShimmerText(width: 160, height: 18)
                
                VStack(spacing: 16) {
                    ShimmerFieldPlaceholder(labelWidth: 140)
                    ShimmerFieldPlaceholder(labelWidth: 100)
                    
                    HStack(spacing: 16) {
                        ShimmerFieldPlaceholder(labelWidth: 110, valueWidth: 80)
                        ShimmerFieldPlaceholder(labelWidth: 110, valueWidth: 100)
                    }
                    
                    ShimmerFieldPlaceholder(labelWidth: 80, valueWidth: 140)
                }
            }
            .padding(.horizontal, 20)
            
            HStack(spacing: 8) {
                Spacer()
                ShimmerText(width: 94, height: 48)
                    .background(Color.gray.opacity(0.16))
                    .cornerRadius(24)
                ShimmerText(width: 94, height: 48)
                    .background(AppColors.primaryOrange.opacity(0.8))
                    .cornerRadius(24)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
    }
}

struct ShimmerFieldPlaceholder: View {
    let labelWidth: CGFloat
    var valueWidth: CGFloat = 180
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ShimmerText(width: labelWidth, height: 12)
            ShimmerText(width: valueWidth, height: 44)
                .cornerRadius(8)
        }
    }
}

// MARK: - Saved Card View Component
struct SavedCardView: View {
    let card: SavedCard
    let isEditing: Bool
    
    var body: some View {
        ZStack {
            // Card Background Image
            Image("cardbackground")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 200)
                .cornerRadius(12)
                .clipped()
            
            // Card Content
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text(card.cardType)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.white.opacity(0.8))
                    
                    Spacer()
                    
                    Text(card.cardBrand)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.white)
                }
                
                Spacer()
                
                VStack(alignment: .leading, spacing: 8) {
                    Text(card.cardHolderName)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.white)
                    
                    Text(card.cardNumber)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundColor(.white)
                }
            }
            .padding(20)
        }
        .frame(height: 200)
        .cornerRadius(12)
        .shadow(radius: 4)
    }
}

// MARK: - Saved Card Model
struct SavedCard: Identifiable {
    let id: String
    let cardType: String
    let cardBrand: String
    let cardHolderName: String
    let cardNumber: String
    let isPrimary: Bool
}

// MARK: - Timeout Helper
func withTimeout<T>(seconds: TimeInterval, operation: @escaping () async -> T) async throws -> T {
    return try await withThrowingTaskGroup(of: T?.self) { group in
        // Add the main operation task
        group.addTask {
            await operation()
        }
        
        // Add the timeout task
        group.addTask {
            try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            return nil // Return nil to indicate timeout
        }
        
        // Wait for the first task to complete
        guard let result = try await group.next() else {
            group.cancelAll()
            throw TimeoutError()
        }
        
        group.cancelAll()
        
        // If result is nil, it means timeout occurred
        guard let validResult = result else {
            throw TimeoutError()
        }
        
        return validResult
    }
}

// MARK: - Timeout Error
struct TimeoutError: Error {
    let message = "Operation timed out"
}

#Preview {
    MyCardsView()
}
