import SwiftUI
import MapKit

struct DetailsBookingView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: [Screen]
    let rideData: VehicleSelectionView.RideData
    let selectedVehicle: VehicleListingItem?
    
    // State variables for dialogs
    @State private var showSubtotalDialog = false
    @State private var showDriverInfoDialog = false
    @State private var showAmenitiesDialog = false
    
    init(rideData: VehicleSelectionView.RideData, selectedVehicle: VehicleListingItem?, path: Binding<[Screen]>) {
        self.rideData = rideData
        self.selectedVehicle = selectedVehicle
        self._path = path
    }
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                // Header
                HStack {
                    Button(action: {
                        path.removeLast()
                    }) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                    }
                    
                    Spacer()
                    
                    Text("Booking details")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.black)
                    
                    Spacer()
                    
                    // Invisible button to balance the layout
                    Button(action: {}) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.clear)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.top, 16)
                .padding(.bottom, 24)
                
//                // Filter Button
//                HStack {
//                    Spacer()
//                    
//                    Button(action: {
//                        // Handle filter
//                    }) {
//                        HStack(spacing: 8) {
//                            Text("Filter By")
//                                .font(.system(size: 14, weight: .medium))
//                                .foregroundColor(.black)
//                            
//                            Image(systemName: "line.3.horizontal.decrease.circle")
//                                .font(.system(size: 14, weight: .medium))
//                                .foregroundColor(.black)
//                        }
//                        .padding(.horizontal, 16)
//                        .padding(.vertical, 8)
//                        .background(Color.gray.opacity(0.1))
//                        .cornerRadius(8)
//                    }
//                    
//                    Spacer()
//                }
//                .padding(.horizontal, 24)
//                .padding(.bottom, 16)
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Vehicle Selection Card - Always show with sample data
                        if let selectedVehicle = selectedVehicle {
                            VehicleSelectionCard(
                                rideData: rideData, 
                                vehicle: selectedVehicle,
                                onViewSubtotals: { showSubtotalDialog = true },
                                onDriverInfo: { showDriverInfoDialog = true },
                                onAmenities: { showAmenitiesDialog = true }
                            )
                        } else {
                            // Fallback to sample vehicle if none selected
                            VehicleSelectionCard(
                                rideData: rideData, 
                                vehicle: createSampleVehicle(),
                                onViewSubtotals: { showSubtotalDialog = true },
                                onDriverInfo: { showDriverInfoDialog = true },
                                onAmenities: { showAmenitiesDialog = true }
                            )
                        }
                        
                        // Pickup Details Card
                        PickupDetailsCard(rideData: rideData)
                        
                        // Map Section
                        MapSection(rideData: rideData)
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 100) // Extra padding for the Next button
                }
                
                // Complete Button
                VStack {
                    Button(action: {
                        // Navigate to ComprehensiveBookingView using path
                        path.append(.comprehensiveBooking(
                            rideData: rideData,
                            selectedVehicle: selectedVehicle,
                            isEditMode: false,
                            editBookingId: nil,
                            isRepeatMode: false,
                            repeatBookingId: nil,
                            isReturnFlow: false,
                            isRoundTripFlow: false
                        ))
                    }) {
                        Text("Book Now")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(AppColors.primaryOrange)
                            .cornerRadius(12)
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 34)
                }
                .background(Color.white)
            }
            .background(Color.white)
            .navigationBarHidden(true)
            
            // Subtotal Dialog
            if showSubtotalDialog {
                SubtotalDialog(
                    vehicle: selectedVehicle ?? createSampleVehicle(),
                    serviceType: rideData.serviceType,
                    onClose: { showSubtotalDialog = false }
                )
            }
            
            // Driver Info Dialog
            if showDriverInfoDialog {
                DriverInfoDialog(
                    vehicle: selectedVehicle ?? createSampleVehicle(),
                    onClose: { showDriverInfoDialog = false }
                )
            }
            
            // Amenities Dialog
            if showAmenitiesDialog {
                AmenitiesDialog(
                    vehicle: selectedVehicle ?? createSampleVehicle(),
                    onClose: { showAmenitiesDialog = false }
                )
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct VehicleSelectionCard: View {
    let rideData: VehicleSelectionView.RideData
    let vehicle: VehicleListingItem
    let onViewSubtotals: () -> Void
    let onDriverInfo: () -> Void
    let onAmenities: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            // 1. Vehicle image on top (full width)
            AsyncImage(url: URL(string: vehicle.vehicleImages.first ?? "")) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 120)
                    .cornerRadius(8)
            } placeholder: {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.white)
                    .frame(height: 120)
                    .overlay(
                        Image(systemName: "car.fill")
                            .font(.system(size: 50))
                            .foregroundColor(.gray)
                    )
            }
            
            // 2. Vehicle name below image
            Text(vehicle.name)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            // 3. Three tags (make, model, year) below name
            HStack(spacing: 12) {
                if let make = vehicle.vehicleDetails?.make, !make.isEmpty {
                    Text(make)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.black)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(4)
                }
                
                if let model = vehicle.vehicleDetails?.model, !model.isEmpty {
                    Text(model)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.black)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(4)
                }
                
                if let year = vehicle.vehicleDetails?.year, !year.isEmpty {
                    Text(year)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.black)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(4)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            // Divider after name and tags
            Divider()
                .background(Color.gray.opacity(0.3)).padding(.horizontal,-20)

            
            // 4. Selected service type and capacity row - side by side layout 
            HStack {
                // Selected service type display with amount in orange box
                if let selectedPrice = vehicle.getPrice(for: rideData.serviceType) {
                    HStack(spacing: 8) {
                        Text(getSelectedServiceTypeName())
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.white)
                        
                        Text("$ \(String(format: "%.2f", selectedPrice))")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.orange)
                    .cornerRadius(8)
                } else {
                    // Fallback if no price available
                    Text(getSelectedServiceTypeName())
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                // Capacity (Pax and Lug) on the right side with light orange background
                VStack(spacing: 4) {
                    HStack(spacing: 8) {
                        Image(systemName: "person.fill")
                            .font(.system(size: 16))
                            .foregroundColor(.orange)
                        
                        Text("Pax \(String(format: "%02d", vehicle.passenger))")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.orange.opacity(0.08))
                    .cornerRadius(8)
                    
                    HStack(spacing: 8) {
                        Image(systemName: "bag.fill")
                            .font(.system(size: 16))
                            .foregroundColor(.orange)
                        
                        Text("Lug \(String(format: "%02d", vehicle.luggage))")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.orange.opacity(0.09))
                    .cornerRadius(8)
                }
            }
            
            // 5. Disclaimer text - positioned on the left side with specific font styling
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("All Inclusive Rates *")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(.gray)
                        .kerning(-0.23)
                    Text("(Some Taxes, and Tolls are additional)")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(.gray)
                        .kerning(-0.23)
                }
                
                Spacer()
            }
            
            // Divider above buttons
            Divider()
                .background(Color.gray.opacity(0.3))     .padding(.horizontal,-20)

            
            // 6. Three action buttons at bottom - all with height 34
            HStack(spacing: 12) {
                // Large orange View Subtotals button
                Button(action: {
                    onViewSubtotals()
                }) {
                    Text("View Subtotals")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 34)
                        .background(Color.orange)
                        .cornerRadius(8)
                }
                
                // Two smaller black buttons
                Button(action: {
                    onDriverInfo()
                }) {
                    Text("Driver Info")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white)
                        .frame(width: 80, height: 34)
                        .background(Color.black)
                        .cornerRadius(8)
                }
                
                Button(action: {
                    onAmenities()
                }) {
                    Text("Amenities")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.white)
                        .frame(width: 80, height: 34)
                        .background(Color.black)
                        .cornerRadius(8)
                }
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.black, lineWidth: 3)
        )
    }
    
    // Helper function to get display name for selected service type
    private func getSelectedServiceTypeName() -> String {
        print("🔍 DetailsBookingView - Service Type: '\(rideData.serviceType)'")
        switch rideData.serviceType {
        case "one_way":
            return "One way"
        case "round_trip":
            return "Round trip"
        case "charter_tour":
            print("✅ Charter Tour detected!")
            return "Charter Tour"
        default:
            print("⚠️ Unknown service type, defaulting to One way")
            return "One way"
        }
    }
}

struct PickupDetailsCard: View {
    let rideData: VehicleSelectionView.RideData
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Header
            Text("Pickup details")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
            
            // Route Information with light grey background
            HStack(spacing: 12) {
                // Left side: line that exactly connects circle and square with bigger line
                ZStack(alignment: .center) {
                    // Vertical connecting line - made wider
                    Rectangle()
                        .fill(Color.gray.opacity(0.4))
                        .frame(width: 4, height: 24) // Increased from 2 to 4 width
                    
                    VStack(spacing: 12) {
                        // Pickup point circle
                        Circle()
                            .fill(AppColors.primaryOrange)
                            .frame(width: 12, height: 12)
                        
                        // Destination point square  
                        RoundedRectangle(cornerRadius: 2)
                            .fill(AppColors.primaryOrange)
                            .frame(width: 12, height: 12)
                    }
                }
                .frame(width: 12)
                
                // Right side: location texts aligned with markers
                VStack(alignment: .leading, spacing: 12) {
                    // Pickup location aligned with circle
                    Text(rideData.pickupLocation)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    // Destination location aligned with square  
                    Text(rideData.destinationLocation)
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                
                Spacer()
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.gray.opacity(0.1))
//            .cornerRadius(8)
            .padding(.horizontal,-20)

            // Divider 1
            Divider()
                .background(Color.gray.opacity(0.3))
                .padding(.horizontal, -20)
            
            // Date, Time, and Service Type
            HStack {
                Image(systemName: "clock.fill")
                    .font(.system(size: 16))
                    .foregroundColor(AppColors.primaryOrange)
                
                Text(formatDate(rideData.pickupDate, rideData.pickupTime))
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.black)
                
                Spacer()
                
                // Service Type Tag - improved styling
                Text(getTripTypeText())
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.black)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(20)
            }
            
            // Divider 2
            Divider()
                .background(Color.gray.opacity(0.3))
                .padding(.horizontal, -20)
            
            // Passenger and Luggage
            HStack(spacing: 10) {
                HStack(spacing: 6) {
                    Image(systemName: "person.fill")
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                    Text("No. of Pax \(String(format: "%02d", rideData.noOfPassenger))")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.black)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .frame(height: 34) // Set height to 34
                .background(Color.gray.opacity(0.1))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                )
                .cornerRadius(12)
                
                HStack(spacing: 6) {
                    Image(systemName: "suitcase.fill")
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                    Text("No. of Lug \(String(format: "%02d", rideData.noOfLuggage))")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.black)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .frame(height: 34) // Set height to 34
                .background(Color.gray.opacity(0.1))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                )
                .cornerRadius(12)
                
                Spacer()
            }
            
            // Divider 3
            Divider()
                .background(Color.gray.opacity(0.3))
                .padding(.horizontal, -20)
            
            // Travel Time
            VStack(alignment: .leading, spacing: 4) {
                Text("Total Travel Time")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.black)
                
                Text(getDynamicTravelInfo())
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(AppColors.primaryOrange)
            }
        }
        .padding(20)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 2)
    }
    
    private func formatDate(_ dateString: String, _ timeString: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm:ss"
        
        if let date = dateFormatter.date(from: dateString),
           let time = timeFormatter.date(from: timeString) {
            let displayFormatter = DateFormatter()
            displayFormatter.dateFormat = "EEE, MMM dd"
            
            let timeDisplayFormatter = DateFormatter()
            timeDisplayFormatter.dateFormat = "h:mm a"
            
            return displayFormatter.string(from: date) + " " + timeDisplayFormatter.string(from: time)
        }
        
        return "\(dateString) \(timeString)"
    }
    
    private func getTripTypeText() -> String {
        // Get service type text
        let serviceTypeText: String
        switch rideData.serviceType {
        case "one_way":
            serviceTypeText = "One Way"
        case "round_trip":
            serviceTypeText = "Round Trip"
        case "charter_tour":
            serviceTypeText = "Charter Tour"
        default:
            serviceTypeText = "One Way"
        }
        
        // Get transfer type text based on pickup and dropoff types
        let transferTypeText = getTransferTypeText()
        
        // Combine service type with transfer type
        return "\(serviceTypeText)/ \(transferTypeText)"
    }
    
    private func getTransferTypeText() -> String {
        let pickupType = rideData.pickupType.lowercased()
        let dropoffType = rideData.dropoffType.lowercased()
        
        // Determine transfer type based on pickup and dropoff types
        if pickupType == "city" && dropoffType == "city" {
            return "City to City"
        } else if pickupType == "city" && dropoffType == "airport" {
            return "City to Airport"
        } else if pickupType == "airport" && dropoffType == "city" {
            return "Airport to City"
        } else if pickupType == "airport" && dropoffType == "airport" {
            return "Airport to Airport"
        } else if pickupType == "city" && dropoffType == "cruise" {
            return "City to Cruise Port"
        } else if pickupType == "cruise" && dropoffType == "city" {
            return "Cruise Port to City"
        } else {
            return "City to City"
        }
    }
    
    private func getDynamicTravelInfo() -> String {
        // For all service types including charter tours, calculate actual distance and time
        guard let pickupLat = rideData.pickupLat,
              let pickupLong = rideData.pickupLong,
              let destLat = rideData.destinationLat,
              let destLong = rideData.destinationLong else {
            return "Calculating route..."
        }
        
        // Calculate distance using Haversine formula
        let distance = calculateDistance(
            lat1: pickupLat, lon1: pickupLong,
            lat2: destLat, lon2: destLong
        )
        
        // Estimate travel time (assuming average speed of 35 mph in city traffic)
        let estimatedTimeMinutes = Int(distance * 1.7) // Rough estimate: 1.7 minutes per mile
        let hours = estimatedTimeMinutes / 60
        let minutes = estimatedTimeMinutes % 60
        
        let distanceMiles = String(format: "%.1f", distance)
        
        if hours > 0 {
            return "\(hours) hours, \(minutes) minutes / \(distanceMiles) miles"
        } else {
            return "\(minutes) minutes / \(distanceMiles) miles"
        }
    }
    
    private func calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double) -> Double {
        let earthRadius = 3959.0 // Earth's radius in miles
        
        let dLat = (lat2 - lat1) * .pi / 180
        let dLon = (lon2 - lon1) * .pi / 180
        
        let a = sin(dLat/2) * sin(dLat/2) +
                cos(lat1 * .pi / 180) * cos(lat2 * .pi / 180) *
                sin(dLon/2) * sin(dLon/2)
        
        let c = 2 * atan2(sqrt(a), sqrt(1-a))
        return earthRadius * c
    }
}

struct MapSection: View {
    let rideData: VehicleSelectionView.RideData
    @State private var region: MKCoordinateRegion
    @State private var route: MKRoute?
    @State private var isLoadingRoute = false
    
    init(rideData: VehicleSelectionView.RideData) {
        self.rideData = rideData
        
        // Initialize with proper region based on coordinates
        if let pickupLat = rideData.pickupLat,
           let pickupLong = rideData.pickupLong,
           let destLat = rideData.destinationLat,
           let destLong = rideData.destinationLong {
            
            // Calculate center point between pickup and destination
            let centerLat = (pickupLat + destLat) / 2
            let centerLong = (pickupLong + destLong) / 2
            
            // Calculate span to fit both points with some padding
            let latSpan = max(abs(pickupLat - destLat) * 1.5, 0.01)
            let longSpan = max(abs(pickupLong - destLong) * 1.5, 0.01)
            
            self._region = State(initialValue: MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: centerLat, longitude: centerLong),
                span: MKCoordinateSpan(latitudeDelta: latSpan, longitudeDelta: longSpan)
            ))
        } else {
            // Fallback to a default region (e.g., New York area)
            self._region = State(initialValue: MKCoordinateRegion(
                center: CLLocationCoordinate2D(latitude: 40.7128, longitude: -74.0060),
                span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
            ))
        }
    }
    
    var body: some View {
        // Full card map with proper route display
        VStack(spacing: 0) {
            // Map with route using MKMapView for better control
            ZStack {
                MapViewRepresentable(
                    region: $region,
                    route: $route,
                    isLoadingRoute: $isLoadingRoute,
                    rideData: rideData
                )
                .frame(height: 330)
                .cornerRadius(12)
                
                // Loading indicator
                if isLoadingRoute {
                    VStack {
                        Spacer()
                        HStack {
                            Spacer()
                            VStack(spacing: 8) {
                                ProgressView()
                                    .scaleEffect(1.2)
                                    .progressViewStyle(CircularProgressViewStyle(tint: AppColors.primaryOrange))
                                Text("Calculating route...")
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                            .padding(12)
                            .background(Color.white.opacity(0.9))
                            .cornerRadius(12)
                            .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
                            Spacer()
                        }
                        Spacer()
                    }
                }
            }
        }
        .onAppear {
            // Calculate route and update region properly
            calculateRoute()
        }
//        .padding(8)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 2)
    }
    
    
    private func calculateRoute() {
        // Determine route coordinates based on service type
        let (pickupCoord, destinationCoord) = getRouteCoordinates()
        
        guard let pickupCoordinate = pickupCoord,
              let destinationCoordinate = destinationCoord else {
            print("❌ No coordinates available for route calculation")
            return
        }
        
        // Update region to properly fit the route
        updateRegionForRoute(pickup: pickupCoordinate, destination: destinationCoordinate)
        
        isLoadingRoute = true
        
        let pickupPlacemark = MKPlacemark(coordinate: pickupCoordinate)
        let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate)
        
        let pickupMapItem = MKMapItem(placemark: pickupPlacemark)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
        
        let request = MKDirections.Request()
        request.source = pickupMapItem
        request.destination = destinationMapItem
        request.transportType = .automobile
        request.requestsAlternateRoutes = false // Use fastest route only
        
        let directions = MKDirections(request: request)
        directions.calculate { response, error in
            DispatchQueue.main.async {
                self.isLoadingRoute = false
                
                if let error = error {
                    print("❌ Route calculation error: \(error.localizedDescription)")
                    // Show a direct line between points if routing fails
                    self.createDirectLineRoute(from: pickupCoordinate, to: destinationCoordinate)
                    return
                }
                
                if let route = response?.routes.first {
                    self.route = route
                    print("✅ Route calculated successfully with \(route.polyline.pointCount) points")
                } else {
                    print("❌ No route found in response")
                    // Show a direct line between points if no route is found
                    self.createDirectLineRoute(from: pickupCoordinate, to: destinationCoordinate)
                }
            }
        }
    }
    
    // Handle different route scenarios based on service type
    private func getRouteCoordinates() -> (CLLocationCoordinate2D?, CLLocationCoordinate2D?) {
        switch rideData.serviceType {
        case "one_way":
            // Airport to City: route between airport lat/long and address lat/long
            if let pickupLat = rideData.pickupLat,
               let pickupLong = rideData.pickupLong,
               let destLat = rideData.destinationLat,
               let destLong = rideData.destinationLong {
                return (
                    CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong),
                    CLLocationCoordinate2D(latitude: destLat, longitude: destLong)
                )
            }
        case "round_trip":
            // City to City: route between pickup and dropoff locations selected by user
            if let pickupLat = rideData.pickupLat,
               let pickupLong = rideData.pickupLong,
               let destLat = rideData.destinationLat,
               let destLong = rideData.destinationLong {
                return (
                    CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong),
                    CLLocationCoordinate2D(latitude: destLat, longitude: destLong)
                )
            }
        case "charter_tour":
            // Charter tour: route between selected pickup and destination
            if let pickupLat = rideData.pickupLat,
               let pickupLong = rideData.pickupLong,
               let destLat = rideData.destinationLat,
               let destLong = rideData.destinationLong {
                return (
                    CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong),
                    CLLocationCoordinate2D(latitude: destLat, longitude: destLong)
                )
            }
        default:
            // Default: use pickup and destination coordinates
            if let pickupLat = rideData.pickupLat,
               let pickupLong = rideData.pickupLong,
               let destLat = rideData.destinationLat,
               let destLong = rideData.destinationLong {
                return (
                    CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong),
                    CLLocationCoordinate2D(latitude: destLat, longitude: destLong)
                )
            }
        }
        
        return (nil, nil)
    }
    
    private func updateRegionForRoute(pickup: CLLocationCoordinate2D, destination: CLLocationCoordinate2D) {
        // Calculate center point between pickup and destination
        let centerLat = (pickup.latitude + destination.latitude) / 2
        let centerLong = (pickup.longitude + destination.longitude) / 2
        
        // Calculate span to fit both points with some padding
        let latSpan = max(abs(pickup.latitude - destination.latitude) * 1.5, 0.01)
        let longSpan = max(abs(pickup.longitude - destination.longitude) * 1.5, 0.01)
        
        self.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: centerLat, longitude: centerLong),
            span: MKCoordinateSpan(latitudeDelta: latSpan, longitudeDelta: longSpan)
        )
    }
    
    private func createDirectLineRoute(from: CLLocationCoordinate2D, to: CLLocationCoordinate2D) {
        // Create a simple polyline route as fallback
        let coordinates = [from, to]
        let polyline = MKPolyline(coordinates: coordinates, count: coordinates.count)
        
        // Create a mock route with the polyline
        let mockRoute = MKRoute()
        // Since MKRoute doesn't have a public initializer, we'll create a simple polyline overlay instead
        // This will be handled by updating the route overlay logic
        print("📍 Created direct line route between points")
    }
}


// MARK: - Map View Representable for better route control
struct MapViewRepresentable: UIViewRepresentable {
    @Binding var region: MKCoordinateRegion
    @Binding var route: MKRoute?
    @Binding var isLoadingRoute: Bool
    let rideData: VehicleSelectionView.RideData
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = false
        mapView.mapType = .standard
        
        // Add annotations for pickup and destination
        addAnnotations(to: mapView)
        
        return mapView
    }
    
    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Update region
        mapView.setRegion(region, animated: true)
        
        // Clear existing overlays
        mapView.removeOverlays(mapView.overlays)
        
        // Add route if available
        if let route = route {
            mapView.addOverlay(route.polyline)
            print("✅ Route added to map with \(route.polyline.pointCount) points")
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
    private func addAnnotations(to mapView: MKMapView) {
        var annotations: [MKPointAnnotation] = []
        
        // Add pickup annotation
        if let pickupLat = rideData.pickupLat,
           let pickupLong = rideData.pickupLong {
            let pickupAnnotation = MKPointAnnotation()
            pickupAnnotation.coordinate = CLLocationCoordinate2D(latitude: pickupLat, longitude: pickupLong)
            pickupAnnotation.title = "Pickup"
            pickupAnnotation.subtitle = rideData.pickupLocation
            annotations.append(pickupAnnotation)
        }
        
        // Add destination annotation
        if let destLat = rideData.destinationLat,
           let destLong = rideData.destinationLong {
            let destAnnotation = MKPointAnnotation()
            destAnnotation.coordinate = CLLocationCoordinate2D(latitude: destLat, longitude: destLong)
            destAnnotation.title = "Destination"
            destAnnotation.subtitle = rideData.destinationLocation
            annotations.append(destAnnotation)
        }
        
        mapView.addAnnotations(annotations)
    }
    
    class Coordinator: NSObject, MKMapViewDelegate {
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let polyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: polyline)
                renderer.strokeColor = UIColor.systemOrange
                renderer.lineWidth = 6
                renderer.lineCap = .round
                renderer.lineJoin = .round
                renderer.alpha = 0.8
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            guard !(annotation is MKUserLocation) else { return nil }
            
            let identifier = "CustomAnnotation"
            var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            
            if annotationView == nil {
                annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                annotationView?.canShowCallout = true
            } else {
                annotationView?.annotation = annotation
            }
            
            // Customize annotation appearance
            if annotation.title == "Pickup" {
                // Pickup marker (orange circle)
                let circleView = UIView(frame: CGRect(x: 0, y: 0, width: 24, height: 24))
                circleView.backgroundColor = UIColor.systemOrange
                circleView.layer.cornerRadius = 12
                circleView.layer.borderWidth = 4
                circleView.layer.borderColor = UIColor.white.cgColor
                circleView.layer.shadowColor = UIColor.black.cgColor
                circleView.layer.shadowOpacity = 0.3
                circleView.layer.shadowOffset = CGSize(width: 0, height: 2)
                circleView.layer.shadowRadius = 4
                
                annotationView?.addSubview(circleView)
                annotationView?.frame = circleView.frame
            } else if annotation.title == "Destination" {
                // Destination marker (orange square)
                let squareView = UIView(frame: CGRect(x: 0, y: 0, width: 24, height: 24))
                squareView.backgroundColor = UIColor.systemOrange
                squareView.layer.cornerRadius = 6
                squareView.layer.borderWidth = 4
                squareView.layer.borderColor = UIColor.white.cgColor
                squareView.layer.shadowColor = UIColor.black.cgColor
                squareView.layer.shadowOpacity = 0.3
                squareView.layer.shadowOffset = CGSize(width: 0, height: 2)
                squareView.layer.shadowRadius = 4
                
                annotationView?.addSubview(squareView)
                annotationView?.frame = squareView.frame
            }
            
            return annotationView
        }
    }
}


// Helper function to create a sample vehicle for preview/fallback
private func createSampleVehicle() -> VehicleListingItem {
    // Since VehicleListingItem only has init(from decoder:), we'll create a simple mock
    // by creating a JSON string and decoding it
    let sampleJSON = """
    {
        "id": 1,
        "name": "Mid-Size Sedan",
        "passenger": 4,
        "luggage": 2,
        "vehicle_images": ["https://1800limoapi.infodevbox.com/storage/images/er36AmYtWByZz9aTIIlRyC4c8UByYsCKdnd9Sj4w.png"],
        "vehicle_details": {
            "make": "BMW",
            "model": "1 Series M",
            "year": "2019"
        },
        "rate_breakdown_one_way": {
            "rateArray": {
                "all_inclusive_rates": {
                    "trip_rate": {
                        "rate_label": "Trip Rate",
                        "baserate": 400.0,
                        "amount": 400.0
                    },
                    "gratuity": {
                        "rate_label": "Gratuity",
                        "baserate": 38.55,
                        "amount": 38.55
                    },
                    "trip_tax": {
                        "rate_label": "Tax",
                        "baserate": 0.0,
                        "amount": 0.0
                    }
                }
            },
            "sub_total": 400.0,
            "grand_total": 438.55,
            "total": 438.55
        },
        "rate_breakdown_round_trip": {
            "rateArray": {
                "all_inclusive_rates": {
                    "trip_rate": {
                        "rate_label": "Trip Rate",
                        "baserate": 800.0,
                        "amount": 800.0
                    },
                    "gratuity": {
                        "rate_label": "Gratuity",
                        "baserate": 176.55,
                        "amount": 176.55
                    },
                    "trip_tax": {
                        "rate_label": "Tax",
                        "baserate": 0.0,
                        "amount": 0.0
                    }
                }
            },
            "sub_total": 800.0,
            "grand_total": 976.55,
            "total": 976.55
        },
        "amenities": [
            {
                "id": 1,
                "name": "Baby Seat",
                "chargeable": "yes"
            },
            {
                "id": 2,
                "name": "Bike Rack",
                "chargeable": "yes"
            },
            {
                "id": 3,
                "name": "Security/Guard",
                "chargeable": "yes"
            },
            {
                "id": 4,
                "name": "Golf Bags",
                "chargeable": "yes"
            },
            {
                "id": 5,
                "name": "LGBTQA+ Friendly",
                "chargeable": "no"
            },
            {
                "id": 6,
                "name": "Handicap Friendly",
                "chargeable": "no"
            },
            {
                "id": 7,
                "name": "Water",
                "chargeable": "no"
            },
            {
                "id": 8,
                "name": "USB Charger",
                "chargeable": "no"
            }
        ]
    }
    """
    
    do {
        let data = sampleJSON.data(using: .utf8)!
        let sampleVehicle = try JSONDecoder().decode(VehicleListingItem.self, from: data)
        return sampleVehicle
    } catch {
        print("Error creating sample vehicle: \(error)")
        // Return a minimal vehicle as fallback
        fatalError("Failed to create sample vehicle: \(error)")
    }
}

// MARK: - Subtotal Dialog

struct SubtotalDialog: View {
    let vehicle: VehicleListingItem
    let serviceType: String
    let onClose: () -> Void
    
    var body: some View {
        ZStack {
            // Background overlay
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture { onClose() }
            
            VStack(spacing: 0) {
                
                // Header Section
                HStack {
                    Spacer()
                    Text("Estimated Rate Slip")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                    Spacer()
                    Button(action: onClose) {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 12)
                .background(Color(white: 0.97))
                
                // Gratuity Tag (Yellow pill background)
                HStack {
                    Text("Gratuity included (hard to extra at own discretion)")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(Color(red: 0.57, green: 0.13, blue: 0.0)) // same reddish tone
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(
                            Capsule()
                                .fill(Color(red: 1.0, green: 0.91, blue: 0.67))
                        )
                }
                .frame(maxWidth: .infinity)
                .padding(.bottom, 12)
                .background(Color(white: 0.97))

                Spacer().frame(height: 16)
                // Rate Table
                VStack(spacing: 0) {
                    // Table Header
                    HStack {
                        Text("Rate Type")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(Color(red: 0.98, green: 0.60, blue: 0.15))
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Text("Rate")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(Color(red: 0.98, green: 0.60, blue: 0.15))
                            .frame(width: 90, alignment: .trailing)
                        
                        Text("Amount")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(Color(red: 0.98, green: 0.60, blue: 0.15))
                            .frame(width: 90, alignment: .trailing)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(Color(red: 1.0, green: 0.97, blue: 0.93))
                    
                    Divider()
                    
                    // Trip Fare row
                    HStack {
                        Text("Trip Fare")
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Text("$\(formatted(getTripFare()))")
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                            .frame(width: 90, alignment: .trailing)
                        
                        Text("$\(formatted(getTripFare()))")
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                            .frame(width: 90, alignment: .trailing)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    
                    Divider()
                    
                    // Tax row
                    HStack {
                        Text("Tax")
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Text("$\(formatted(getTaxAmount()))")
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                            .frame(width: 90, alignment: .trailing)
                        
                        Text("$\(formatted(getTaxAmount()))")
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                            .frame(width: 90, alignment: .trailing)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    
                    // Line above total
                    Divider()
                        .frame(height: 1)
                        .background(Color.black)
                        .padding(.top, 2)
                    
                    // Total row
                    HStack {
                        Text("Total")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Spacer()
                        
                        Text("$\(formatted(getTotalAmount()))")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.black)
                            .frame(width: 90, alignment: .trailing)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 14)
                }
                .background(Color.white)
                
                Divider()

                // Close Button
                Button(action: onClose) {
                    Text("Close")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 90, height: 36)
                        .background(Color.black)
                        .cornerRadius(8)
                }
                .padding(.top, 12)
                .padding(.bottom, 20)
            }
            .frame(maxWidth: 340)
            .background(Color.white)
            .cornerRadius(16)
            .shadow(color: Color.black.opacity(0.15), radius: 10, x: 0, y: 5)
            .padding(.horizontal, 32)
        }
        .transition(.scale.combined(with: .opacity))
        .animation(.easeInOut(duration: 0.25), value: true)
    }
    
    // MARK: - Helpers
    
    private func formatted(_ value: Double) -> String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        numberFormatter.maximumFractionDigits = 2
        return numberFormatter.string(from: NSNumber(value: value)) ?? "0.00"
    }
    
    private func getTripFare() -> Double {
        switch serviceType {
        case "one_way":
            return vehicle.rateBreakdownOneWay?.rateArray.allInclusiveRates.tripRate.amount ?? 0.0
        case "round_trip":
            return vehicle.rateBreakdownRoundTrip?.rateArray.allInclusiveRates.tripRate.amount ?? 0.0
        case "charter_tour":
            return vehicle.rateBreakdownCharterTour?.rateArray.allInclusiveRates.tripRate.amount ?? 0.0
        default:
            return 0.0
        }
    }
    
    private func getTaxAmount() -> Double {
        switch serviceType {
        case "one_way":
            return vehicle.rateBreakdownOneWay?.rateArray.allInclusiveRates.tripTax.amount ?? 0.0
        case "round_trip":
            return vehicle.rateBreakdownRoundTrip?.rateArray.allInclusiveRates.tripTax.amount ?? 0.0
        case "charter_tour":
            return vehicle.rateBreakdownCharterTour?.rateArray.allInclusiveRates.tripTax.amount ?? 0.0
        default:
            return 0.0
        }
    }
    
    private func getTotalAmount() -> Double {
        switch serviceType {
        case "one_way":
            return vehicle.rateBreakdownOneWay?.grandTotal ?? 0.0
        case "round_trip":
            return vehicle.rateBreakdownRoundTrip?.grandTotal ?? 0.0
        case "charter_tour":
            return vehicle.rateBreakdownCharterTour?.grandTotal ?? 0.0
        default:
            return 0.0
        }
    }
}


// MARK: - Driver Info Dialog

struct DriverInfoDialog: View {
    let vehicle: VehicleListingItem
    let onClose: () -> Void

    var body: some View {
        ZStack {
            // Dimmed background
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture { onClose() }

            VStack(spacing: 0) {
                // Header
                HStack {
                    Spacer()

                    Text("Driver Details")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(.black)

                    Spacer()

                    Button(action: onClose) {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 14)
                .background(Color(UIColor.systemGray6))

                // Profile section
                HStack(alignment: .center, spacing: 16) {
                    // Profile image
                    Spacer()

                    AsyncImage(url: URL(string: getDriverImageUrl())) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    } placeholder: {
                        Circle()
                            .fill(Color.gray.opacity(0.3))
                            .overlay(
                                Image(systemName: "person.fill")
                                    .font(.system(size: 40))
                                    .foregroundColor(.gray)
                            )
                    }
                    .frame(width: 70, height: 70)
                    .clipShape(Circle())

                    // Info texts
                    VStack(alignment: .leading, spacing: 4) {
                        Text(getDriverName())
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.black)

                        Text(getDriverPhone())
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
//
//                        Text("-1800LIMO.C.-")
//                            .font(.system(size: 13))
//                            .foregroundColor(.gray)
                    }

                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 20)

                // Attribute section
                VStack(spacing: 12) {
                    DriverAttributeRow(label: "Gender", value: getDriverGender())
                    DriverAttributeRow(label: "Dress", value: getDriverDress())
                    DriverAttributeRow(label: "Experience", value: getDriverExperience())
                    DriverAttributeRow(label: "Languages", value: getDriverLanguages())
                    DriverAttributeRow(label: "Insurance Limit", value: getInsuranceLimit())
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 20)
                .cornerRadius(8)
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
                .background(Color(red: 1.0, green: 0.97, blue: 0.93))

                // Close button
                Spacer().frame(height: 8)
                Button(action: onClose) {
                    Text("Close")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 90, height: 36)
                        .background(Color.black)
                        .cornerRadius(8)
                }
                .padding(.bottom, 20)
            }
            .background(Color.white)
            .cornerRadius(16)
            .shadow(color: Color.black.opacity(0.15), radius: 10, x: 0, y: 5)
            .padding(.horizontal, 32)
        }
        .transition(.scale.combined(with: .opacity))
        .animation(.easeInOut(duration: 0.3), value: true)
    }

    // MARK: - Helpers
    private func getDriverImageUrl() -> String {
        vehicle.driverInformation?.imageUrl ?? ""
    }
    private func getDriverName() -> String {
        vehicle.driverInformation?.name ?? "John Smith"
    }
    private func getDriverPhone() -> String {
        let isd = vehicle.driverInformation?.cellIsd ?? "+1"
        let number = vehicle.driverInformation?.cellNumber ?? "98765 43210"
        return "\(isd) \(number)"
    }
    private func getDriverGender() -> String {
        vehicle.driverInformation?.gender ?? "Male"
    }
    private func getDriverDress() -> String {
        vehicle.driverInformation?.dress ?? "Business Casual"
    }
    private func getDriverExperience() -> String {
        vehicle.driverInformation?.experience ?? "20+ Years"
    }
    private func getDriverLanguages() -> String {
        vehicle.driverInformation?.languages ?? "English"
    }
    private func getInsuranceLimit() -> String {
        vehicle.driverInformation?.insuranceLimit ?? "$500,000"
    }
}

// MARK: - Fixed Attribute Row Alignment
struct DriverAttributeRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label)
                .font(.system(size: 14))
                .foregroundColor(.black.opacity(0.8))
                .frame(width: 140, alignment: .leading) // fixed width for consistent alignment
            
            Text(value)
                .font(.system(size: 14, weight: .bold))
                .foregroundColor(.black)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}


// MARK: - Amenities Dialog
struct AmenitiesDialog: View {
    let vehicle: VehicleListingItem
    let onClose: () -> Void
    
    var body: some View {
        ZStack {
            // Background overlay
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture {
                    onClose()
                }
            
            // Dialog content
            VStack(spacing: 0) {
                // Header - "Amenities" with grey background
                HStack {
                    Spacer()
                    
                    Text("Amenities")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .cornerRadius(8)
                    
                    Spacer()
                    
                    Button(action: onClose) {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 20)
                .background(Color.gray.opacity(0.1))

                Spacer().frame(height: 10)
                // Chargable Amenities Section (simple white background)
                VStack(alignment: .leading, spacing: 16) {
                    // Section header
                    HStack {
                        Text("CHARGABLE AMENITIES")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.gray)
                        
                        Spacer()
                        
                        Text("In $")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.orange)
                    }                .padding(.horizontal, 20)

                                        
                    // Dynamic amenities list in two columns
                    Group {
                        if !getChargeableAmenities().isEmpty {
                            HStack(spacing: 20) {
                                // Left column
                                VStack(alignment: .leading, spacing: 8) {
                                    ForEach(Array(getChargeableAmenities().enumerated()), id: \.offset) { index, amenity in
                                        if index % 2 == 0 {
                                            AmenityRow(name: amenity.name)
                                        }
                                    }
                                }
                                
                                // Right column
                                VStack(alignment: .leading, spacing: 8) {
                                    ForEach(Array(getChargeableAmenities().enumerated()), id: \.offset) { index, amenity in
                                        if index % 2 == 1 {
                                            AmenityRow(name: amenity.name)
                                        }
                                    }
                                }
                                
                                Spacer()
                            }
                        } else {
                            // Fallback to hardcoded values if no dynamic data
                            HStack(spacing: 20) {
                                // Left column
                                VStack(alignment: .leading, spacing: 8) {
                                    AmenityRow(name: "Baby Seat")
                                    AmenityRow(name: "Bike Rack")
                                    AmenityRow(name: "Security/Guard")
                                    AmenityRow(name: "Per Diem")
                                    AmenityRow(name: "Red Carpet")
                                    AmenityRow(name: "Luggage Trailer")
                                }
                                
                                // Right column
                                VStack(alignment: .leading, spacing: 8) {
                                    AmenityRow(name: "Golf Bags")
                                    AmenityRow(name: "Skis")
                                    AmenityRow(name: "Wedding Package")
                                    AmenityRow(name: "(Decorations & Champaign)", isSubtitle: true)
                                }
                                
                                Spacer()
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
                .background(Color.white)
//                .padding(.horizontal, 20)
//                .padding(.bottom, 16)
                
                // Non-Chargable Amenities Section (simple light orange background)
                VStack(alignment: .leading, spacing: 16) {
                    // Section header
                    Text("NON-CHARGABLE AMENITIES")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.gray)
                        .padding(.horizontal, 20)
                        .padding(.top, 20)
                    
                    // Dynamic amenities list in two columns
                    Group {
                        if !getNonChargeableAmenities().isEmpty {
                            HStack(spacing: 20) {
                                // Left column
                                VStack(alignment: .leading, spacing: 8) {
                                    ForEach(Array(getNonChargeableAmenities().enumerated()), id: \.offset) { index, amenity in
                                        if index % 2 == 0 {
                                            AmenityRow(name: amenity.name)
                                        }
                                    }
                                }
                                
                                // Right column
                                VStack(alignment: .leading, spacing: 8) {
                                    ForEach(Array(getNonChargeableAmenities().enumerated()), id: \.offset) { index, amenity in
                                        if index % 2 == 1 {
                                            AmenityRow(name: amenity.name)
                                        }
                                    }
                                }
                                
                                Spacer()
                            }
                        } else {
                            // Fallback to hardcoded values if no dynamic data
                            HStack(spacing: 20) {
                                // Left column
                                VStack(alignment: .leading, spacing: 8) {
                                    AmenityRow(name: "LGBTQA+ Friendly")
                                    AmenityRow(name: "Handicap Friendly")
                                    AmenityRow(name: "Snacks")
                                    AmenityRow(name: "Pet Friendly")
                                    AmenityRow(name: "Water")
                                    AmenityRow(name: "iPad")
                                    AmenityRow(name: "PA/Intercom")
                                    AmenityRow(name: "Dash-Cam")
                                    AmenityRow(name: "Tinted Glass")
                                }
                                
                                // Right column
                                VStack(alignment: .leading, spacing: 8) {
                                    AmenityRow(name: "Ice Chest")
                                    AmenityRow(name: "Mask")
                                    AmenityRow(name: "Magazines")
                                    AmenityRow(name: "Soda")
                                    AmenityRow(name: "Pillow")
                                    AmenityRow(name: "USB Charger")
                                    AmenityRow(name: "3 Pin Laptop Charger")
                                    AmenityRow(name: "CD Player")
                                }
                                
                                Spacer()
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
                .background(Color.orange.opacity(0.2))
                .padding(.bottom, 20)
                
                // Close button - Updated to match Figma specs
                Button(action: onClose) {
                    Text("Close")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 75, height: 34)
                        .background(Color.black)
                        .cornerRadius(8)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
            }
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: Color.black.opacity(0.15), radius: 10, x: 0, y: 5)
            .padding(.horizontal, 32)
        }
        .transition(.scale.combined(with: .opacity))
        .animation(.easeInOut(duration: 0.3), value: true)
    }
    
    // Helper functions to get dynamic amenities data
    private func getChargeableAmenities() -> [Amenity] {
        return vehicle.amenities?.filter { amenity in
            amenity.chargeable.lowercased() == "yes" || amenity.chargeable.lowercased() == "true" || amenity.chargeable == "1"
        } ?? []
    }
    
    private func getNonChargeableAmenities() -> [Amenity] {
        return vehicle.amenities?.filter { amenity in
            amenity.chargeable.lowercased() == "no" || amenity.chargeable.lowercased() == "false" || amenity.chargeable == "0"
        } ?? []
    }
}

// MARK: - Amenity Row
struct AmenityRow: View {
    let name: String
    let isSubtitle: Bool
    
    init(name: String, isSubtitle: Bool = false) {
        self.name = name
        self.isSubtitle = false
    }
    
    var body: some View {
        HStack {
            Text("•")
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.black)
            
            Text(name)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(isSubtitle ? .gray : .black)
        }
    }
}


