import Foundation
import CoreLocation

// Model for booking notification data
struct BookingNotificationData: Codable {
    let bookingId: Int
    let pickupDate: String
    let pickupTime: String
    let pickupAddress: String
    let dropoffAddress: String
    let reminderType: String
    let formattedDatetime: String
    let pickupAddressLat: Double?
    let pickupAddressLong: Double?
    let dropoffAddressLat: Double?
    let dropoffAddressLong: Double?
    let status: String?
    
    enum CodingKeys: String, CodingKey {
        case bookingId = "booking_id"
        case pickupDate = "pickup_date"
        case pickupTime = "pickup_time"
        case pickupAddress = "pickup_address"
        case dropoffAddress = "dropoff_address"
        case reminderType = "reminder_type"
        case formattedDatetime = "formatted_datetime"
        case pickupAddressLat = "pickup_address_lat"
        case pickupAddressLong = "pickup_address_long"
        case dropoffAddressLat = "dropoff_address_lat"
        case dropoffAddressLong = "dropoff_address_long"
        case status = "status"
    }
    
    // Check if this notification requires driver action
    func requiresDriverEnRouteAction() -> Bool {
        return reminderType == "2_hours" || 
               reminderType == "1_hour" || 
               reminderType == "30_minutes" || 
               reminderType == "15_minutes"
    }
    
    // Get user-friendly reminder type text
    func getReminderTypeText() -> String {
        switch reminderType {
        case "2_hours":
            return "2 Hours"
        case "1_hour":
            return "1 Hour"
        case "30_minutes":
            return "30 Minutes"
        case "15_minutes":
            return "15 Minutes"
        case "5_minutes":
            return "5 Minutes"
        case "driver_en_route":
            return "Driver En Route"
        case "driver_arrived":
            return "Driver Arrived"
        case "ride_started":
            return "Ride Started"
        case "ride_completed":
            return "Ride Completed"
        case "24_hours":
            return "24 Hours"
        default:
            return "General"
        }
    }
    
    // Get pickup coordinates
    func getPickupCoordinates() -> CLLocationCoordinate2D? {
        guard let lat = pickupAddressLat, let long = pickupAddressLong else {
            return nil
        }
        return CLLocationCoordinate2D(latitude: lat, longitude: long)
    }
    
    // Get dropoff coordinates
    func getDropoffCoordinates() -> CLLocationCoordinate2D? {
        guard let lat = dropoffAddressLat, let long = dropoffAddressLong else {
            return nil
        }
        return CLLocationCoordinate2D(latitude: lat, longitude: long)
    }
}

