import Foundation

struct NotificationModel: Identifiable, Codable {
    let id: String
    let title: String
    let body: String
    let timestamp: Date
    let type: NotificationType
    var isRead: Bool
    
    enum NotificationType: String, Codable {
        case booking = "booking"
        case message = "message"
        case alert = "alert"
        case general = "general"
    }
}

// For Socket.IO notification data
struct SocketNotificationData: Codable {
    let title: String
    let message: String
    let type: String?
    let data: [String: String]?
}

// For Firebase push notification data
struct FirebaseNotificationData: Codable {
    let title: String
    let body: String
    let badge: Int?
    let sound: String?
    let data: [String: String]?
}






