import Foundation

// API Response for notifications
struct NotificationResponse: Codable {
    let success: Bool
    let message: String
    let data: [NotificationModel]?
}

// Mark notification as read request
struct MarkNotificationReadRequest: Codable {
    let notificationId: String
    let isRead: Bool
}






