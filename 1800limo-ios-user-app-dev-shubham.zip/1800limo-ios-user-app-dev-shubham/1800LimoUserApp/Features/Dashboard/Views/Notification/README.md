# Notification System - User App

## Overview
This module handles both real-time Socket.IO notifications and local notifications for the 1800LIMO User app.

## Components

### Services
- **LocalNotificationManager**: Handles local system notifications and in-app notifications
- **SimpleSocketIOService**: Manages Socket.IO connection for real-time notifications

### Models
- **NotificationModel**: Data model for notifications
- **NotificationResponse**: API response models for notifications

### Views
- **InAppNotificationView**: Custom UI for in-app notifications
- **SocketIOTestView**: Testing interface for Socket.IO

## Socket.IO Configuration

### Server Details
- **Production URL**: `https://limortservice.infodevbox.com`
- **User Type**: `customer` (for user app)
- **Authentication**: Secret-based authentication

### Connection Parameters
```swift
{
    "client": "ios_app",
    "secret": "limoapi_notifications_secret_2024_xyz789",
    "userId": "{dynamic from StorageManager}",
    "userType": "customer"
}
```

## Usage

### Auto-Connect on Login
Socket.IO automatically connects when user logs in:

```swift
// After successful OTP verification
SimpleSocketIOService.shared.reconnectWithNewUserId()
```

### Manual Connection
```swift
// Connect
SimpleSocketIOService.shared.connect()

// Disconnect
SimpleSocketIOService.shared.disconnect()

// Check status
if SimpleSocketIOService.shared.isConnected {
    print("Socket.IO is connected")
}
```

### Showing Notifications

#### In-App Notification (Foreground)
```swift
LocalNotificationManager.shared.showNotificationEvent(
    title: "New Booking",
    body: "You have a new booking request"
)
```

#### System Notification (Background)
Automatically handled by LocalNotificationManager based on app state.

### In-App Notification UI
Add to your main view:

```swift
YourView()
    .withInAppNotifications()
```

## Event Handling

### Socket.IO Events
The service listens for these event types:
- Events containing "notification"
- Events containing "notify"
- Events containing "alert"
- Events containing "user.notifications"

### Event Data Structure
```json
{
  "title": "Notification Title",
  "message": "Notification message body",
  "type": "booking|message|alert",
  "data": {
    "key": "value"
  }
}
```

## Testing

### Using SocketIOTestView
1. Navigate to SocketIOTestView
2. Verify user ID is displayed
3. Tap "Connect" to establish connection
4. Use "Send Test Event" to test
5. Check console for detailed logs

### Console Output
```
🔌 Socket.IO - User ID retrieved successfully: 1234
🔌 Socket.IO - Connection initiated to https://limortservice.infodevbox.com
Socket.IO: Connected to server
Socket.IO: Received event - Name: user.notifications
Socket.IO: Processing notification event
```

## Notification Flow

### 1. Socket.IO Notification Received
```
Server Event → SimpleSocketIOService
    ↓
handleNotificationEvent()
    ↓
LocalNotificationManager.showNotificationEvent()
    ↓
Check App State
    ↓
Foreground: Show InAppNotificationView
Background: Show System Notification
```

### 2. Firebase Push Notification
```
Firebase Cloud Messaging
    ↓
AppDelegate (didReceiveRemoteNotification)
    ↓
FirebasePushNotificationService
    ↓
Update lastNotification
    ↓
Show Notification (handled by system)
```

## Duplicate Prevention

LocalNotificationManager prevents duplicate notifications:
- Tracks recent notifications (last 5 seconds)
- Ignores duplicates with same title and body
- Auto-cleanup of old tracking data

## Debug Methods

### Socket.IO Debug
```swift
// Debug user ID status
SimpleSocketIOService.shared.debugUserIDStatus()

// Expected output:
// 🔍 Socket.IO - User ID from StorageManager: 1234
// ✅ Socket.IO - User ID is valid: 1234
// ✅ Socket.IO - Auth token is present: eyJhbGciOiJIUzI1NiIs...
```

### Notification Manager Debug
```swift
// Check permission status
UNUserNotificationCenter.current().getNotificationSettings { settings in
    print("Authorization: \(settings.authorizationStatus.rawValue)")
}
```

## Important Notes

1. **User Type**: Always uses "customer" (not "driver")
2. **Auto-Reconnect**: Enabled with retry logic
3. **User ID Required**: Must be logged in for Socket.IO to work
4. **Permissions**: User must grant notification permissions
5. **Foreground vs Background**: Different notification UI based on app state

## Troubleshooting

### Socket.IO Won't Connect
- Check user is logged in
- Verify user ID is not "unknown"
- Check internet connection
- Verify server URL is reachable

### Notifications Not Showing
- Check notification permissions in Settings
- Verify app is not in Do Not Disturb mode
- Check console logs for error messages
- Use SocketIOTestView to diagnose

### User ID Shows as "unknown"
- User is not logged in
- OTP verification not completed
- User data not saved to StorageManager
- Check login flow implementation

## Integration with UI

### Show Test Views
```swift
// In your settings or debug menu
NavigationLink("Test Socket.IO") {
    SocketIOTestView()
}
```

### Add In-App Notification Support
```swift
// In your main view or root view
ContentView()
    .withInAppNotifications()
```

### Handle Notification Taps
Extend `handleNotificationEvent` in SimpleSocketIOService to add custom logic:

```swift
private func handleNotificationEvent(data: [Any]) {
    // Parse notification data
    // Navigate to specific screen
    // Update app state
}
```

## Best Practices

1. **Connect After Login**: Always reconnect Socket.IO after successful login
2. **Disconnect on Logout**: Clean disconnect when user logs out
3. **Handle Reconnection**: Use `reconnectWithNewUserId()` when user ID changes
4. **Test Thoroughly**: Use provided test views before production
5. **Monitor Console**: Check logs for connection and notification events

## Production Considerations

1. Update server URL if needed for production
2. Test on real devices (simulator has limitations)
3. Verify Socket.IO server handles user authentication
4. Ensure notification permissions are requested appropriately
5. Test with various notification types and payloads






