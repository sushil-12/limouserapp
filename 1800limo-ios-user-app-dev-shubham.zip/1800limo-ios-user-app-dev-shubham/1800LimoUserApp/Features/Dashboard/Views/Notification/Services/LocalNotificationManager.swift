import Foundation
import UserNotifications
import SwiftUI
import UIKit

class LocalNotificationManager: NSObject, ObservableObject {
    static let shared = LocalNotificationManager()
    
    @Published var currentNotification: (title: String, body: String)?
    
    // Track recent notifications to prevent duplicates
    private var recentNotifications: [(title: String, body: String, timestamp: Date)] = []
    private let duplicateThreshold: TimeInterval = 5.0 // 5 seconds
    
    private override init() {
        super.init()
        requestNotificationPermission()
    }
    
    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("Notification permission granted")
            } else {
                print("Notification permission denied: \(error?.localizedDescription ?? "")")
            }
        }
    }
    
    func showNotification(title: String, body: String, identifier: String = UUID().uuidString) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        content.badge = 1
        
        // Use immediate trigger
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 0.1, repeats: false)
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            DispatchQueue.main.async {
                if let error = error {
                    print("Error showing notification: \(error)")
                } else {
                    print("Local notification scheduled: \(title)")
                    
                    // Also show an immediate notification using UNUserNotificationCenter
                    UNUserNotificationCenter.current().getNotificationSettings { settings in
                        print("Notification settings - Authorization: \(settings.authorizationStatus.rawValue)")
                        print("Notification settings - Alert: \(settings.alertSetting.rawValue)")
                        print("Notification settings - Sound: \(settings.soundSetting.rawValue)")
                        
                        if settings.authorizationStatus == .authorized {
                            print("Notifications are authorized")
                        } else {
                            print("Notifications are NOT authorized")
                        }
                    }
                }
            }
        }
    }
    
    func showNotificationEvent(title: String, body: String) {
        print("LocalNotificationManager: Received notification event - Title: \(title), Body: \(body)")
        
        // Check for duplicates
        if isDuplicateNotification(title: title, body: body) {
            print("LocalNotificationManager: Duplicate notification detected, ignoring")
            return
        }
        
        // Add to recent notifications
        addToRecentNotifications(title: title, body: body)
        
        // Check if app is in foreground or background
        let isAppInForeground = UIApplication.shared.applicationState == .active
        
        // Always show a proper system notification, even when app is in foreground,
        // so user sees the same banner/alert style everywhere in the app.
        showNotification(title: title, body: body, identifier: "notification_event_\(Date().timeIntervalSince1970)")
        if isAppInForeground {
            print("LocalNotificationManager: Showing SYSTEM notification (app in foreground)")
        } else {
            print("LocalNotificationManager: Showing system notification (app in background)")
        }
    }
    
    private func isDuplicateNotification(title: String, body: String) -> Bool {
        let now = Date()
        let recentThreshold = now.addingTimeInterval(-duplicateThreshold)
        
        // Clean up old notifications
        recentNotifications = recentNotifications.filter { $0.timestamp > recentThreshold }
        
        // Check if this notification already exists
        return recentNotifications.contains { $0.title == title && $0.body == body }
    }
    
    private func addToRecentNotifications(title: String, body: String) {
        let now = Date()
        recentNotifications.append((title: title, body: body, timestamp: now))
        
        // Keep only recent notifications (cleanup)
        let recentThreshold = now.addingTimeInterval(-duplicateThreshold)
        recentNotifications = recentNotifications.filter { $0.timestamp > recentThreshold }
    }
    
    func showMessageEvent(title: String, body: String) {
        showNotification(title: title, body: body, identifier: "message_event")
    }
    
    func showBookingUpdateEvent(title: String, body: String) {
        showNotification(title: title, body: body, identifier: "booking_update_event")
    }
    
    // MARK: - Badge Management
    
    /// Clear the app icon badge count
    func clearBadge() {
        DispatchQueue.main.async {
            // Clear badge using UIApplication (standard method)
            UIApplication.shared.applicationIconBadgeNumber = 0
            print("Badge cleared successfully")
        }
    }
}






