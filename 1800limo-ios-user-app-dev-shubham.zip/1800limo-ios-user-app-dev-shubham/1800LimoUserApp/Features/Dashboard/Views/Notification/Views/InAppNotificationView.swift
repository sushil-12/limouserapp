import SwiftUI

struct InAppNotificationView: View {
    let title: String
    let message: String
    let onDismiss: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Text(message)
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.9))
                }
                
                Spacer()
                
                Button(action: onDismiss) {
                    Image(systemName: "xmark")
                        .foregroundColor(.white)
                        .font(.caption)
                }
            }
            .padding()
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.blue, Color.blue.opacity(0.8)]),
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
        }
        .padding(.horizontal)
        .transition(.move(edge: .top).combined(with: .opacity))
    }
}

// Overlay modifier to show in-app notifications
struct InAppNotificationModifier: ViewModifier {
    @ObservedObject var notificationManager = LocalNotificationManager.shared
    
    func body(content: Content) -> some View {
        ZStack {
            content
            
            VStack {
                if let notification = notificationManager.currentNotification {
                    InAppNotificationView(
                        title: notification.title,
                        message: notification.body,
                        onDismiss: {
                            withAnimation {
                                notificationManager.currentNotification = nil
                            }
                        }
                    )
                    .padding(.top, 50)
                    
                    Spacer()
                }
            }
            .animation(.spring(), value: notificationManager.currentNotification != nil)
        }
    }
}

extension View {
    func withInAppNotifications() -> some View {
        self.modifier(InAppNotificationModifier())
    }
}

#Preview {
    InAppNotificationView(
        title: "New Booking",
        message: "You have a new booking request",
        onDismiss: {}
    )
}

