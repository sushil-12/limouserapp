import SwiftUI

struct SocketIOTestView: View {
    @StateObject private var socketService = SimpleSocketIOService.shared
    @State private var showingStatus = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header
                Text("Socket.IO Testing")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.bottom)
                
                // Connection Status
                HStack {
                    Circle()
                        .fill(socketService.isConnected ? Color.green : Color.red)
                        .frame(width: 12, height: 12)
                    
                    Text(socketService.isConnected ? "Connected" : "Disconnected")
                        .font(.headline)
                        .foregroundColor(socketService.isConnected ? AppColors.greenColor : .red)
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color(.systemGray6))
                .cornerRadius(10)
                
                // User Info
                VStack(alignment: .leading, spacing: 10) {
                    Text("User Information")
                        .font(.headline)
                    
                    HStack {
                        Text("User ID:")
                            .fontWeight(.medium)
                        Text(StorageManager.shared.getUserIdString() ?? "Not Available")
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Auth Token:")
                            .fontWeight(.medium)
                        if let token = StorageManager.shared.getAuthToken() {
                            Text("\(token.prefix(20))...")
                                .foregroundColor(.secondary)
                                .font(.caption)
                        } else {
                            Text("Not Available")
                                .foregroundColor(.red)
                        }
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
                
                // Actions
                VStack(alignment: .leading, spacing: 15) {
                    Text("Actions")
                        .font(.headline)
                    
                    Button(action: {
                        socketService.connect()
                    }) {
                        HStack {
                            Image(systemName: "wifi")
                            Text("Connect")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(AppColors.greenColor)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .disabled(socketService.isConnected)
                    
                    Button(action: {
                        socketService.disconnect()
                    }) {
                        HStack {
                            Image(systemName: "wifi.slash")
                            Text("Disconnect")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .disabled(!socketService.isConnected)
                    
                    Button(action: {
                        socketService.reconnectWithNewUserId()
                    }) {
                        HStack {
                            Image(systemName: "arrow.clockwise")
                            Text("Reconnect with User ID")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    Button(action: {
                        
                    }) {
                        HStack {
                            Image(systemName: "paperplane")
                            Text("Send Test Event")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .disabled(!socketService.isConnected)
                    
                    Button(action: {
                        socketService.debugUserIDStatus()
                    }) {
                        HStack {
                            Image(systemName: "info.circle")
                            Text("Debug User ID Status")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
                
                // Instructions
                VStack(alignment: .leading, spacing: 10) {
                    Text("Instructions")
                        .font(.headline)
                    
                    Text("1. Make sure you're logged in with a valid user ID")
                    Text("2. Tap 'Connect' to establish Socket.IO connection")
                    Text("3. Use 'Send Test Event' to test the connection")
                    Text("4. Check console logs for detailed information")
                    
                    Text("\nNote: Socket.IO will automatically connect with your user ID and userType 'customer'")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.top, 5)
                }
                .font(.caption)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
            }
            .padding()
        }
        .onAppear {
            // Auto-connect if user is logged in
            if StorageManager.shared.getUserIdString() != nil && !socketService.isConnected {
                print("Auto-connecting Socket.IO on view appear...")
                socketService.connect()
            }
        }
    }
}

#Preview {
    SocketIOTestView()
}






