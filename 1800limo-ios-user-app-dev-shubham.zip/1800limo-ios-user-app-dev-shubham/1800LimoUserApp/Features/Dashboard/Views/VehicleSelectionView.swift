import SwiftUI

struct VehicleSelectionView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: [Screen]
    @State private var selectedVehicle: Vehicle?
    @StateObject private var vehicleService = VehicleService()
    @StateObject private var sheetDismissalManager = SheetDismissalManager.shared
    @State private var showFilterDialog = false
    @StateObject private var filterSelection = FilterSelectionState()
    private let shouldHideBackButton = true

    // Parameters passed from previous screens
    let rideData: RideData
    
    // Convenience initializer for path-based navigation
    init(rideData: RideData, path: Binding<[Screen]>) {
        self.rideData = rideData
        self._path = path
    }
    
    struct RideData: Hashable {
        let serviceType: String
        let bookingHour: String
        let pickupType: String
        let dropoffType: String
        let pickupDate: String
        let pickupTime: String
        let pickupLocation: String
        let destinationLocation: String
        let selectedPickupAirport: String
        let selectedDestinationAirport: String
        let noOfPassenger: Int
        let noOfLuggage: Int
        let noOfVehicles: Int
        let pickupLat: Double?
        let pickupLong: Double?
        let destinationLat: Double?
        let destinationLong: Double?
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Drag Handle
            RoundedRectangle(cornerRadius: 2.5)
                .fill(Color.gray.opacity(0.3))
                .frame(width: 36, height: 5)
                .padding(.top, 8)
                .padding(.bottom, 16)
            
            // Header with back button and title
            HStack {
                Button(action: {
                    path.removeLast()
                }) {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Text("Select Vehicle Category")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
                
                Spacer()
                
                // Invisible spacer to center the title
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.clear)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 8)
            
            // Sub-header
            Text("Use Filter / Sort to customize your ride.")
                .font(.system(size: 14, weight: .regular))
                .foregroundColor(.gray)
                .padding(.horizontal, 24)
                .padding(.bottom, 24)
            
            // Sort and Filter Buttons
            HStack {
                Spacer()
                
             
                
                Button(action: {
                    showFilterDialog = true
                }) {
                    HStack(spacing: 4) {
                        Text("Filter")
                            .font(.system(size: 14, weight: .medium))

                        Image("mi_filter")
                            .font(.system(size: 14, weight: .medium))
                                            }
                    .foregroundColor(.black)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(6)
                }
                
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 24)
            
            // Vehicle Options
            if vehicleService.isLoading {
                VehicleSelectionShimmerList()
            } else if let errorMessage = vehicleService.errorMessage {
                VStack {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.system(size: 40))
                        .foregroundColor(.red)
                    Text("Error loading vehicles")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.black)
                        .padding(.top, 8)
                    Text(errorMessage)
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.top, 4)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    VStack(spacing: 16) {
                        ForEach(vehicleService.vehicles) { vehicle in
                            VehicleOptionCard(
                                vehicle: vehicle,
                                isSelected: selectedVehicle?.id == vehicle.id,
                                onTap: {
                                    selectedVehicle = vehicle
                                    // Navigate immediately when card is tapped using path
                                    path.append(.bookingDetails(
                                        rideData: rideData,
                                        selectedMasterVehicleId: vehicle.id,
                                        initialFilterSelection: filterSelection
                                    ))
                                }
                            )
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 40)
                }
            }
        }
        .navigationBarBackButtonHidden(shouldHideBackButton)
        .background(Color.white)
        // Navigation is now handled via path, so we don't need fullScreenCover here
        .onReceive(NotificationCenter.default.publisher(for: .dismissAllSheets)) { _ in
            print("🔚 VehicleSelectionView received dismiss notification")
            if !path.isEmpty {
                path.removeLast()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .forceDismissAllSheets)) { _ in
            print("🔚 VehicleSelectionView received force dismiss notification")
            // Clear entire path to go back to dashboard
            path.removeAll()
        }
        .onAppear {
            Task {
                await fetchVehicleQuote()
            }
        }
        .sheet(isPresented: $showFilterDialog) {
            FilterDialogView(
                onApplyFilters: { selectedFilters in
                // Store filters for passing to BookingDetailsView
                filterSelection.selectedVehicleTypes = selectedFilters.selectedVehicleTypes
                filterSelection.selectedAmenities = selectedFilters.selectedAmenities
                filterSelection.selectedSpecialAmenities = selectedFilters.selectedSpecialAmenities
                filterSelection.selectedInteriors = selectedFilters.selectedInteriors
                filterSelection.selectedMakes = selectedFilters.selectedMakes
                filterSelection.selectedModels = selectedFilters.selectedModels
                filterSelection.selectedYears = selectedFilters.selectedYears
                filterSelection.selectedColors = selectedFilters.selectedColors
                filterSelection.selectedDriverLanguages = selectedFilters.selectedDriverLanguages
                filterSelection.selectedDriverDresses = selectedFilters.selectedDriverDresses
                filterSelection.selectedDriverGenders = selectedFilters.selectedDriverGenders
                filterSelection.selectedDriverBackgrounds = selectedFilters.selectedDriverBackgrounds
                filterSelection.selectedVehicleServiceAreas = selectedFilters.selectedVehicleServiceAreas
                filterSelection.selectedAffiliatePreferences = selectedFilters.selectedAffiliatePreferences
                
                // Note: Filters will be applied in BookingDetailsView, not here
                print("🔍 FILTERS STORED FOR BOOKING DETAILS VIEW:")
                print("Selected Vehicle Types: \(filterSelection.selectedVehicleTypes)")
                print("Selected Amenities: \(filterSelection.selectedAmenities)")
                print("Selected Special Amenities: \(filterSelection.selectedSpecialAmenities)")
                print("Selected Interiors: \(filterSelection.selectedInteriors)")
                print("Selected Makes: \(filterSelection.selectedMakes)")
                print("Selected Models: \(filterSelection.selectedModels)")
                print("Selected Years: \(filterSelection.selectedYears)")
                print("Selected Colors: \(filterSelection.selectedColors)")
                print("Selected Driver Languages: \(filterSelection.selectedDriverLanguages)")
                print("Selected Driver Dresses: \(filterSelection.selectedDriverDresses)")
                print("Selected Driver Genders: \(filterSelection.selectedDriverGenders)")
                print("Selected Driver Backgrounds: \(filterSelection.selectedDriverBackgrounds)")
                print("Selected Vehicle Service Areas: \(filterSelection.selectedVehicleServiceAreas)")
                print("Selected Affiliate Preferences: \(filterSelection.selectedAffiliatePreferences)")
                
                // Automatically navigate to BookingDetailsView after applying filters
                print("🚀 NAVIGATING TO BOOKING DETAILS VIEW WITH FILTERS...")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    // Use selected vehicle ID if available, otherwise use first vehicle or default to 1
                    let vehicleId = selectedVehicle?.id ?? vehicleService.vehicles.first?.id ?? 1
                    path.append(.bookingDetails(
                        rideData: rideData,
                        selectedMasterVehicleId: vehicleId,
                        initialFilterSelection: filterSelection
                    ))
                }
                },
                initialFilterState: filterSelection
            )
        }
    }
    
    private func fetchVehicleQuote() async {
        // Set loading state immediately so shimmer shows during location info calculation
        await MainActor.run {
            vehicleService.isLoading = true
            vehicleService.errorMessage = nil
        }
        
        let request = await createVehicleQuoteRequest()
        
        print("🔍 VEHICLE SELECTION DEBUG:")
        print("🎯 PROCESSING SERVICE TYPE: \(rideData.serviceType.uppercased())")
        print("Ride Data:")
        print("- Service Type: \(rideData.serviceType)")
        print("- Booking Hour: \(rideData.bookingHour)")
        print("- Pickup Type: \(rideData.pickupType)")
        print("- Dropoff Type: \(rideData.dropoffType)")
        print("- Pickup Location: \(rideData.pickupLocation)")
        print("- Destination Location: \(rideData.destinationLocation)")
        print("- Pickup Airport: \(rideData.selectedPickupAirport)")
        print("- Destination Airport: \(rideData.selectedDestinationAirport)")
        print("- Passengers: \(rideData.noOfPassenger)")
        print("- Luggage: \(rideData.noOfLuggage)")
        print("- Pickup Lat: \(rideData.pickupLat ?? 0)")
        print("- Pickup Long: \(rideData.pickupLong ?? 0)")
        print("- Destination Lat: \(rideData.destinationLat ?? 0)")
        print("- Destination Long: \(rideData.destinationLong ?? 0)")
        
        print("🚀 CALLING VEHICLE SERVICE FOR \(rideData.serviceType.uppercased())...")
        await vehicleService.fetchVehicleQuote(request: request)
        print("✅ VEHICLE SERVICE CALL COMPLETED FOR \(rideData.serviceType.uppercased())")
    }
    
    private func createVehicleQuoteRequest() async -> VehicleQuoteRequest {
        let bookingHourInt = Int(rideData.bookingHour) ?? 0
        let isRoundTrip = rideData.serviceType == "round_trip"
        
        // Airport IDs based on selection
        let pickupAirportId = rideData.pickupType == "airport" ? getAirportId(from: rideData.selectedPickupAirport) : nil
        let dropoffAirportId = rideData.dropoffType == "airport" ? getAirportId(from: rideData.selectedDestinationAirport) : nil
        let returnPickupAirportId = isRoundTrip && rideData.dropoffType == "airport" ? getAirportId(from: rideData.selectedDestinationAirport) : nil
        let returnDropoffAirportId = isRoundTrip && rideData.pickupType == "airport" ? getAirportId(from: rideData.selectedPickupAirport) : nil
        
        // Addresses vs airport fields
        let pickupAddress = rideData.pickupType == "airport" ? nil : rideData.pickupLocation
        let dropoffAddress = rideData.dropoffType == "airport" ? nil : rideData.destinationLocation
        let returnPickupAddress = isRoundTrip ? (rideData.dropoffType == "airport" ? nil : rideData.destinationLocation) : nil
        let returnDropoffAddress = isRoundTrip ? (rideData.pickupType == "airport" ? nil : rideData.pickupLocation) : nil
        
        // Coordinates for address types
        let pickupAddressLat = rideData.pickupType == "airport" ? nil : rideData.pickupLat
        let pickupAddressLong = rideData.pickupType == "airport" ? nil : rideData.pickupLong
        let dropoffAddressLat = rideData.dropoffType == "airport" ? nil : rideData.destinationLat
        let dropoffAddressLong = rideData.dropoffType == "airport" ? nil : rideData.destinationLong
        let returnPickupAddressLat = isRoundTrip && rideData.dropoffType != "airport" ? rideData.destinationLat : nil
        let returnPickupAddressLong = isRoundTrip && rideData.dropoffType != "airport" ? rideData.destinationLong : nil
        let returnDropoffAddressLat = isRoundTrip && rideData.pickupType != "airport" ? rideData.pickupLat : nil
        let returnDropoffAddressLong = isRoundTrip && rideData.pickupType != "airport" ? rideData.pickupLong : nil
        
        let locationInfo = await createLocationInfoForQuote()
        
        let request = VehicleQuoteRequest(
            serviceType: rideData.serviceType,
            bookingHour: bookingHourInt,
            pickupType: rideData.pickupType,
            dropoffType: rideData.dropoffType,
            pickupDate: rideData.pickupDate,
            pickupTime: rideData.pickupTime,
            pickupAirport: pickupAirportId,
            pickupAirportName: rideData.pickupType == "airport" ? rideData.selectedPickupAirport : nil,
            pickupAirportLat: rideData.pickupType == "airport" ? rideData.pickupLat : nil,
            pickupAirportLong: rideData.pickupType == "airport" ? rideData.pickupLong : nil,
            pickupAddress: pickupAddress,
            pickupAddressLat: pickupAddressLat,
            pickupAddressLong: pickupAddressLong,
            dropoffAirport: dropoffAirportId,
            dropoffAirportName: rideData.dropoffType == "airport" ? rideData.selectedDestinationAirport : nil,
            dropoffAirportLat: rideData.dropoffType == "airport" ? rideData.destinationLat : nil,
            dropoffAirportLong: rideData.dropoffType == "airport" ? rideData.destinationLong : nil,
            dropoffAddress: dropoffAddress,
            dropoffAddressLat: dropoffAddressLat,
            dropoffAddressLong: dropoffAddressLong,
            returnPickupDate: isRoundTrip ? rideData.pickupDate : nil,
            returnPickupTime: isRoundTrip ? rideData.pickupTime : nil,
            returnPickupAirport: returnPickupAirportId,
            returnPickupAirportName: isRoundTrip && rideData.dropoffType == "airport" ? rideData.selectedDestinationAirport : nil,
            returnPickupAirportLat: isRoundTrip && rideData.dropoffType == "airport" ? rideData.destinationLat : nil,
            returnPickupAirportLong: isRoundTrip && rideData.dropoffType == "airport" ? rideData.destinationLong : nil,
            returnPickupAddress: returnPickupAddress,
            returnPickupAddressLat: returnPickupAddressLat,
            returnPickupAddressLong: returnPickupAddressLong,
            returnDropoffAirport: returnDropoffAirportId,
            returnDropoffAirportName: isRoundTrip && rideData.pickupType == "airport" ? rideData.selectedPickupAirport : nil,
            returnDropoffAirportLat: isRoundTrip && rideData.pickupType == "airport" ? rideData.pickupLat : nil,
            returnDropoffAirportLong: isRoundTrip && rideData.pickupType == "airport" ? rideData.pickupLong : nil,
            returnDropoffAddress: returnDropoffAddress,
            returnDropoffAddressLat: returnDropoffAddressLat,
            returnDropoffAddressLong: returnDropoffAddressLong,
            noOfPassenger: rideData.noOfPassenger,
            noOfLuggage: rideData.noOfLuggage,
            locationInfo: locationInfo,
            otherDetails: OtherDetails(
                pickupAirportName: rideData.pickupType == "airport" ? rideData.selectedPickupAirport : nil,
                dropoffAirportName: rideData.dropoffType == "airport" ? rideData.selectedDestinationAirport : nil,
                returnPickupAirportName: isRoundTrip && rideData.dropoffType == "airport" ? rideData.selectedDestinationAirport : nil,
                returnDropoffAirportName: isRoundTrip && rideData.pickupType == "airport" ? rideData.selectedPickupAirport : nil
            ),
            filters: nil,
            userId: 1
        )
        
        print("📋 REQUEST OBJECT DEBUG:")
        print("Service Type: \(request.serviceType)")
        print("Pickup Type: \(request.pickupType)")
        print("Dropoff Type: \(request.dropoffType)")
        print("Location Info Count: \(request.locationInfo.count)")
        print("Return Pickup Airport: \(request.returnPickupAirport ?? 0)")
        print("Return Dropoff Airport: \(request.returnDropoffAirport ?? 0)")
        print("Pickup Address: \(request.pickupAddress ?? "nil")")
        print("Dropoff Address: \(request.dropoffAddress ?? "nil")")
        print("Return Pickup Address: \(request.returnPickupAddress ?? "nil")")
        print("Return Dropoff Address: \(request.returnDropoffAddress ?? "nil")")
        
        return request
    }
    
    private func createLocationInfoForQuote() async -> [LocationInfo] {
        let outbound = await vehicleService.createLocationInfo(
            pickupLat: rideData.pickupLat,
            pickupLong: rideData.pickupLong,
            dropoffLat: rideData.destinationLat,
            dropoffLong: rideData.destinationLong
        )
        
        if rideData.serviceType == "round_trip" {
            let returnInfo = await vehicleService.createLocationInfo(
                pickupLat: rideData.destinationLat,
                pickupLong: rideData.destinationLong,
                dropoffLat: rideData.pickupLat,
                dropoffLong: rideData.pickupLong
            )
            return outbound + returnInfo
        } else {
            return outbound
        }
    }
    
    private func getAirportId(from airportName: String) -> Int? {
        return AirportMapping.getAirportId(from: airportName)
    }
}

struct VehicleOptionCard: View {
    let vehicle: Vehicle
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 8) {
                    // Vehicle Name
                    Text(vehicle.name)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                    
                    // Price Tag with FROM label inside
                    HStack(spacing: 4) {
                        Text("FROM")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white)
                            .lineLimit(1)
                        
                        Text("$ \(String(format: "%.2f", vehicle.price))")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(AppColors.primaryOrange)
                    .cornerRadius(6)
                    .fixedSize(horizontal: false, vertical: true)
                    
//                    Spacer()
                    
                    // Capacity Tags
                    HStack(spacing: 4) {
                        HStack(spacing: 4) {
                            Image(systemName: "person.fill")
                                .font(.system(size: 10))
                                .foregroundColor(AppColors.primaryOrange)
                            Text("Passengers \(vehicle.capacity)")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(.black)
                        }
                        .frame(width: 100, height: 22)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(4)
                        
                        HStack(spacing: 4) {
                            Image(systemName: "suitcase.fill")
                                .font(.system(size: 10))
                                .foregroundColor(AppColors.primaryOrange)
                            Text("Luggage \(vehicle.luggage)")
                                .font(.system(size: 12, weight: .bold ))
                                .foregroundColor(.black)
                        }
                        .frame(width: 90, height: 22)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(4)
                    }
                }
                
//                Spacer()
                
                // Vehicle Image
                if let imageUrl = vehicle.image, !imageUrl.isEmpty {
                    AsyncImage(url: URL(string: imageUrl)) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 80, height: 60)
                            .cornerRadius(8)
                    } placeholder: {
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.gray.opacity(0.1))
                            .frame(width: 80, height: 60)
                            .overlay(
                                Image(systemName: "car.fill")
                                    .font(.system(size: 32))
                                    .foregroundColor(.gray)
                            )
                    }
                } else {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.gray.opacity(0.1))
                        .frame(width: 80, height: 60)
                        .overlay(
                            Image(systemName: "car.fill")
                                .font(.system(size: 32))
                                .foregroundColor(.gray)
                        )
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
            .background(Color.white)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(isSelected ? Color.black : Color.gray.opacity(0.3), lineWidth: 2.8)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// MARK: - Shimmer Placeholders
struct VehicleSelectionShimmerList: View {
    // Use more placeholders so screen appears filled
    private let placeholderCount = 6
    
    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 16) {
                    ForEach(0..<placeholderCount, id: \.self) { _ in
                        VehicleSelectionCardShimmer()
                    }
                }
                .padding(.horizontal, max(16, geometry.size.width < 375 ? 16 : 24))
                .padding(.bottom, 40)
            }
        }
    }
}

struct VehicleSelectionCardShimmer: View {
    var body: some View {
        GeometryReader { geometry in
            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 10) {
                    // Vehicle name
                    ShimmerText(width: min(160, geometry.size.width * 0.5), height: 18)
                    
                    // Price pill mimic
                    ShimmerPill(width: min(120, geometry.size.width * 0.35), height: 28, cornerRadius: 6)
                    
                    // Capacity tags mimic
                    HStack(spacing: 8) {
                        ShimmerPill(width: min(110, geometry.size.width * 0.32), height: 22, cornerRadius: 4)
                        ShimmerPill(width: min(100, geometry.size.width * 0.3), height: 22, cornerRadius: 4)
                    }
                }
                
                Spacer()
                
                // Image placeholder
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color.gray.opacity(0.15))
                    .frame(width: 80, height: 60)
                    .overlay(
                        ShimmerView()
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    )
            }
            .padding(.horizontal, max(12, geometry.size.width < 375 ? 12 : 16))
            .padding(.vertical, 16)
            .background(Color.white)
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray.opacity(0.3), lineWidth: 2.8)
            )
        }
        .frame(height: 120) // Fixed height to prevent layout issues
    }
}

struct ShimmerPill: View {
    let width: CGFloat
    let height: CGFloat
    let cornerRadius: CGFloat
    
    var body: some View {
        RoundedRectangle(cornerRadius: cornerRadius)
            .fill(Color.gray.opacity(0.25))
            .frame(width: width, height: height)
            .overlay(
                ShimmerView()
                    .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
            )
    }
}

#Preview {
    VehicleSelectionView(
        rideData: VehicleSelectionView.RideData(
            serviceType: "one_way",
            bookingHour: "2",
            pickupType: "city",
            dropoffType: "airport",
            pickupDate: "2025-01-15",
            pickupTime: "14:30:00",
            pickupLocation: "Manhattan, New York, NY, USA",
            destinationLocation: "JFK Airport",
            selectedPickupAirport: "",
            selectedDestinationAirport: "JFK-John F Kennedy Intl",
            noOfPassenger: 2,
            noOfLuggage: 1,
            noOfVehicles: 1,
            pickupLat: 40.7589,
            pickupLong: -73.9851,
            destinationLat: 40.6413,
            destinationLong: -73.7781
        ),
        path: .constant([])
    )
}
