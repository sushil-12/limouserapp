//
//  MyBookingsView.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

// Helper struct for repeat booking navigation
struct RepeatBookingItem: Identifiable {
    let id: Int
    let isReturnFlow: Bool
    let isRoundTripFlow: Bool
}

enum TimePeriod: String, CaseIterable {
    case weekly = "Weekly"
    case monthly = "Monthly"
    case yearly = "Yearly"
    case custom = "Custom"
}

struct MyBookingsView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = UserBookingsViewModel()
    @State private var navigateToBookingDetails = false
    @State private var navigateToEditBooking = false
    @State private var selectedBooking: UserBooking?
    @State private var navigateToRepeatBooking = false
    @State private var repeatBooking: UserBooking?
    @State private var repeatBookingId: Int?
    @State private var isReturnFlow = false
    @State private var isRoundTripFlow = false
    @State private var isSearching = false
    @State private var showCancelConfirmation = false
    @State private var isCancellingBooking = false
    @State private var cancelResultMessage: String?
    @State private var showCancelResult = false
    @State private var cancellationWasSuccessful = false
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                headerView
                contentView
            }
            .disabled(showCancelConfirmation || isCancellingBooking)
            .blur(radius: showCancelConfirmation ? 2 : 0)
            
            if showCancelConfirmation {
                Color.black.opacity(0.45)
                    .ignoresSafeArea()
                
                if let booking = selectedBooking {
                    CancelBookingConfirmationView(
                        booking: booking,
                        isProcessing: isCancellingBooking,
                        onEdit: handleCancelEditFromDialog,
                        onConfirm: confirmCancellation,
                        onDismiss: { showCancelConfirmation = false }
                    )
                    .padding(.horizontal, 24)
                    .transition(.opacity.combined(with: .scale))
                }
            }
        }
        .background(navigationLinks)
        .fullScreenCover(isPresented: $navigateToEditBooking) {
            // When user returns from edit booking, refresh the bookings data
            print("🔄 Returned from edit booking - refreshing bookings data")
            viewModel.refreshBookings()
        } content: {
            ComprehensiveBookingView(
                isEditMode: true,
                editBookingId: selectedBooking?.id
            )
        }
        .fullScreenCover(item: Binding(
            get: { repeatBookingId.map { RepeatBookingItem(id: $0, isReturnFlow: isReturnFlow, isRoundTripFlow: isRoundTripFlow) } },
            set: { _ in
                print("🔄 Returned from repeat booking - refreshing bookings data")
                resetRepeatFlowState(shouldRefresh: true)
            }
        )) { item in
            ComprehensiveBookingView(
                onComplete: {
                    resetRepeatFlowState(shouldRefresh: true)
                },
                rideData: nil,
                selectedVehicle: nil,
                isEditMode: false,
                editBookingId: nil,
                isRepeatMode: true,
                repeatBookingId: item.id,
                isReturnFlow: item.isReturnFlow,
                isRoundTripFlow: item.isRoundTripFlow
            )
        }
    }
    
    // MARK: - Header View
    private var headerView: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Text("My Bookings")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(.black)
                
                Spacer()
                
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        isSearching.toggle()
                        if !isSearching {
                            viewModel.searchText = ""
                        }
                    }
                }) {
                    Image(systemName: isSearching ? "xmark" : "magnifyingglass")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.black)
                }
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            
            if isSearching {
                searchBarView
            }
        }
        .background(Color.white)
    }
    
    // MARK: - Search Bar View
    private var searchBarView: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("Search bookings...", text: $viewModel.searchText)
                .textFieldStyle(PlainTextFieldStyle())
                .onChange(of: viewModel.searchText) { newValue in
                    viewModel.handleSearch(newValue)
                }
            
            if !viewModel.searchText.isEmpty {
                Button(action: { 
                    viewModel.searchText = ""
                    viewModel.refreshBookings()
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
        .padding(.horizontal, 18)
        .padding(.bottom, 12)
        .transition(.opacity.combined(with: .move(edge: .top)))
    }
    
    // MARK: - Content View
    private var contentView: some View {
        ScrollView {
            VStack(spacing: 18) {
                summaryCardView
                timePeriodSelectorView
                bookingsSectionView
            }
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .refreshable {
            // Refresh bookings
            viewModel.refreshBookings()
        }
        .onAppear {
            // Fetch initial bookings
            print("📱 MyBookingsView appeared - fetching initial bookings")
            print("📱 Current time period: \(viewModel.selectedTimePeriod.rawValue)")
            // Ensure the initial time period is set correctly and API is called
            viewModel.handleTimePeriodChange(viewModel.selectedTimePeriod)
        }
        .alert("Error", isPresented: $viewModel.showError) {
            Button("OK") { }
        } message: {
            Text(viewModel.errorMessage ?? "An error occurred")
        }
        .alert("Booking Cancellation", isPresented: $showCancelResult) {
            Button("OK") {
                showCancelResult = false
                cancelResultMessage = nil
                selectedBooking = nil
                if cancellationWasSuccessful {
                    // Keep the refreshed list; nothing else needed
                }
            }
        } message: {
            Text(cancelResultMessage ?? "Something went wrong.")
        }
    }
    
    // MARK: - Summary Card View
    private var summaryCardView: some View {
        UserWeeklySummaryCard(
            dateRange: viewModel.dateRangeString,
            totalSpent: String(format: "%.2f", viewModel.totalSpent),
            totalBookings: "\(viewModel.bookings.count)",
            completedRides: "\(viewModel.completedRides)",
            onPreviousPeriod: {
                handlePreviousNavigation()
            },
            onNextPeriod: {
                handleNextNavigation()
            },
            canGoPrevious: true,
            canGoNext: true,
            currencySymbol: "$",
            hideMetrics: true
        )
        .padding(.horizontal, 18)
        .padding(.top, 20)
    }
    
    // MARK: - Time Period Selector View
    private var timePeriodSelectorView: some View {
        VStack(spacing: 12) {
            Picker("Time Period", selection: $viewModel.selectedTimePeriod) {
                ForEach(TimePeriod.allCases, id: \.self) { period in
                    Text(period.rawValue).tag(period)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.horizontal, 18)
            .onChange(of: viewModel.selectedTimePeriod) { newPeriod in
                viewModel.handleTimePeriodChange(newPeriod)
            }
            
            if viewModel.selectedTimePeriod == .custom {
                UserCustomDateRangePicker(
                    startDate: $viewModel.selectedWeekStart,
                    endDate: $viewModel.selectedWeekEnd,
                    onDateRangeSelected: {
                        viewModel.handleDateRangeSelection(
                            startDate: viewModel.selectedWeekStart,
                            endDate: viewModel.selectedWeekEnd
                        )
                    }
                )
                .padding(.horizontal, 18)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(.top, 16)
    }
    
    // MARK: - Bookings Section View
    private var bookingsSectionView: some View {
        Group {
            if viewModel.isLoading && viewModel.bookings.isEmpty {
                loadingView
            } else if viewModel.bookings.isEmpty {
                emptyStateView
            } else {
                bookingsListView
            }
        }
    }
    
    // MARK: - Loading View
    private var loadingView: some View {
        ScrollView {
            VStack(spacing: 18) {
                summaryShimmerView
                timePeriodShimmerView
                
                VStack(spacing: 16) {
                    ForEach(0..<3) { _ in
                        BookingCardShimmerView()
                    }
                }
                .padding(.horizontal, 18)
            }
            .padding(.top, 20)
        }
        .background(Color.white)
    }
    
    private var summaryShimmerView: some View {
        VStack(spacing: 0) {
            HStack {
                ShimmerText(width: 100, height: 14)
                Spacer()
                ShimmerText(width: 80, height: 14)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 20)
            
            Divider()
                .padding(.horizontal, -16)
            
            HStack(spacing: 0) {
                ShimmerText(width: 80, height: 18)
                    .frame(maxWidth: .infinity)
                Divider().frame(height: 40)
                ShimmerText(width: 60, height: 18)
                    .frame(maxWidth: .infinity)
                Divider().frame(height: 40)
                ShimmerText(width: 80, height: 18)
                    .frame(maxWidth: .infinity)
            }
            .padding(.vertical, 20)
        }
        .background(Color.white)
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.gray.opacity(0.12), lineWidth: 1)
        )
        .padding(.horizontal, 18)
    }
    
    private var timePeriodShimmerView: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                ForEach(0..<4) { _ in
                    ShimmerText(width: 70, height: 28)
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 18)
        }
        .padding(.top, 16)
    }
    
    // MARK: - Empty State View
    private var emptyStateView: some View {
        VStack(spacing: 16) {
            Image(systemName: "calendar.badge.plus")
                .font(.system(size: 48))
                .foregroundColor(.gray)
            Text("No bookings found")
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.black)
            Text("No bookings available for the selected period")
                .font(.system(size: 14))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.top, 100)
    }
    
    // MARK: - Bookings List View
    private var bookingsListView: some View {
        let groupedBookings = Dictionary(grouping: viewModel.bookings) { booking in
            booking.pickup_date
        }
        
        let sortedDates = groupedBookings.keys.sorted()
        
        return VStack(spacing: 24) {
            ForEach(sortedDates, id: \.self) { date in
                if let bookingsForDate = groupedBookings[date] {
                    dateGroupView(date: date, bookings: bookingsForDate)
                }
            }
        }
    }
    
    // MARK: - Date Group View
    private func dateGroupView(date: String, bookings: [UserBooking]) -> some View {
        VStack(spacing: 12) {
            VStack(spacing: 18) {
                ForEach(bookings, id: \.id) { booking in
                    UserBookingCard(
                        booking: booking,
                        onEditBooking: {
                            selectedBooking = booking
                            navigateToEditBooking = true
                        },
                        onCancelBooking: {
                            selectedBooking = booking
                            showCancelConfirmation = true
                        },
                        onRepeatBooking: {
                            // Guard: Only navigate if booking ID is valid
                            guard booking.id > 0 else {
                                print("❌ Cannot repeat booking: Invalid booking ID")
                                return
                            }
                            // Store booking ID directly - using item-based navigation ensures ID is captured
                            repeatBooking = booking
                            repeatBookingId = booking.id
                            isReturnFlow = false
                            isRoundTripFlow = false
                            print("🔄 Setting up repeat booking with ID: \(booking.id)")
                        },
                        onReturnBooking: {
                            // Guard: Only navigate if booking ID is valid
                            guard booking.id > 0 else {
                                print("❌ Cannot return booking: Invalid booking ID")
                                return
                            }
                            // Store booking ID directly - using item-based navigation ensures ID is captured
                            repeatBooking = booking
                            repeatBookingId = booking.id
                            isReturnFlow = true
                            isRoundTripFlow = false
                            print("🔄 Setting up return booking with ID: \(booking.id)")
                        },
                        onRoundTripBooking: {
                            // Guard: Only navigate if booking ID is valid
                            guard booking.id > 0 else {
                                print("❌ Cannot round trip booking: Invalid booking ID")
                                return
                            }
                            // Store booking ID directly - using item-based navigation ensures ID is captured
                            repeatBooking = booking
                            repeatBookingId = booking.id
                            isReturnFlow = false
                            isRoundTripFlow = true
                            print("🔄 Setting up round trip booking with ID: \(booking.id)")
                        }
                    )
                }
            }
            .padding(.horizontal, 18)
        }
    }
    
    // MARK: - Navigation Links
    private var navigationLinks: some View {
        Group {
            NavigationLink(
                destination: UserBookingDetailsView(booking: selectedBooking ?? UserBooking.sampleBookings[0]),
                isActive: $navigateToBookingDetails
            ) {
                EmptyView()
            }
            
            // NavigationLink removed - using fullScreenCover instead
        }
    }
    
    // MARK: - Navigation Handlers
    
    private func handlePreviousNavigation() {
        switch viewModel.selectedTimePeriod {
        case .weekly:
            viewModel.goToPreviousWeek()
        case .monthly:
            viewModel.goToPreviousMonth()
        case .yearly:
            viewModel.goToPreviousYear()
        case .custom:
            // Custom doesn't have navigation arrows
            break
        }
    }
    
    private func handleNextNavigation() {
        switch viewModel.selectedTimePeriod {
        case .weekly:
            viewModel.goToNextWeek()
        case .monthly:
            viewModel.goToNextMonth()
        case .yearly:
            viewModel.goToNextYear()
        case .custom:
            // Custom doesn't have navigation arrows
            break
        }
    }

    private func resetRepeatFlowState(shouldRefresh: Bool) {
        if shouldRefresh {
            viewModel.refreshBookings()
        }
        repeatBooking = nil
        repeatBookingId = nil
        isReturnFlow = false
        isRoundTripFlow = false
    }
    
    private func handleCancelEditFromDialog() {
        showCancelConfirmation = false
        navigateToEditBooking = true
    }
    
    private func confirmCancellation() {
        guard let booking = selectedBooking else {
            return
        }
        
        isCancellingBooking = true
        cancellationWasSuccessful = false
        
        Task {
            do {
                let response = try await viewModel.cancelBooking(bookingId: booking.id)
                
                await MainActor.run {
                    isCancellingBooking = false
                    cancellationWasSuccessful = response.success
                    cancelResultMessage = response.message
                    showCancelConfirmation = false
                    showCancelResult = true
                    
                    if response.success {
                        viewModel.refreshBookings()
                    }
                }
            } catch {
                await MainActor.run {
                    isCancellingBooking = false
                    cancelResultMessage = error.localizedDescription
                    cancellationWasSuccessful = false
                    showCancelConfirmation = false
                    showCancelResult = true
                }
            }
        }
    }
}

// MARK: - My Bookings Shimmer Placeholders
struct BookingCardShimmerView: View {
    var body: some View {
        VStack(spacing: 0) {
            // Top header
            HStack {
                HStack(spacing: 8) {
                    Circle()
                        .fill(Color.orange)
                        .frame(width: 16, height: 16)
                    ShimmerText(width: 140, height: 12)
                }
                
                Spacer()
                
                ShimmerText(width: 90, height: 22)
                    .background(Color.white)
                    .cornerRadius(6)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.black.opacity(0.9))
            
            // Booking summary row
            HStack {
                ShimmerText(width: 60, height: 12)
                Spacer()
                ShimmerText(width: 80, height: 12)
                Spacer()
                HStack(spacing: 8) {
                    ShimmerText(width: 40, height: 12)
                    ShimmerText(width: 60, height: 22)
                        .background(Color.orange)
                        .cornerRadius(8)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color.gray.opacity(0.08))
            
            // Route details
            HStack(alignment: .top, spacing: 12) {
                VStack(spacing: 6) {
                    Circle()
                        .fill(Color.black)
                        .frame(width: 12, height: 12)
                    Rectangle()
                        .fill(Color.black)
                        .frame(width: 2, height: 28)
                    RoundedRectangle(cornerRadius: 2)
                        .fill(Color.black)
                        .frame(width: 12, height: 12)
                }
                .padding(.top, 4)
                
                VStack(alignment: .leading, spacing: 12) {
                    ShimmerText(width: 220, height: 14)
                    ShimmerText(width: 200, height: 14)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
            
            // Driver info
            HStack(spacing: 12) {
                ShimmerText(width: 70, height: 12)
                HStack(spacing: 12) {
                    ShimmerText(width: 120, height: 12)
                    Rectangle()
                        .fill(Color.gray.opacity(0.4))
                        .frame(width: 1, height: 20)
                    ShimmerText(width: 100, height: 12)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.white)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                )
                
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.gray.opacity(0.06))
            
            // Action buttons
            HStack(spacing: 12) {
                ShimmerText(width: 90, height: 36)
                    .background(Color.black)
                    .cornerRadius(8)
                ShimmerText(width: 90, height: 40)
                    .background(Color.red)
                    .cornerRadius(8)
                ShimmerText(width: 70, height: 32)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(8)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.white)
        }
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
        )
    }
}

// MARK: - User Weekly Summary Card
struct UserWeeklySummaryCard: View {
    let dateRange: String
    let totalSpent: String
    let totalBookings: String
    let completedRides: String
    let onPreviousPeriod: () -> Void
    let onNextPeriod: () -> Void
    let canGoPrevious: Bool
    let canGoNext: Bool
    let currencySymbol: String?
    let hideMetrics: Bool
    
    init(
        dateRange: String,
        totalSpent: String,
        totalBookings: String,
        completedRides: String,
        onPreviousPeriod: @escaping () -> Void,
        onNextPeriod: @escaping () -> Void,
        canGoPrevious: Bool = true,
        canGoNext: Bool = true,
        currencySymbol: String? = nil,
        hideMetrics: Bool = false
    ) {
        self.dateRange = dateRange
        self.totalSpent = totalSpent
        self.totalBookings = totalBookings
        self.completedRides = completedRides
        self.onPreviousPeriod = onPreviousPeriod
        self.onNextPeriod = onNextPeriod
        self.canGoPrevious = canGoPrevious
        self.canGoNext = canGoNext
        self.currencySymbol = currencySymbol
        self.hideMetrics = hideMetrics
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Date Range Navigation
            HStack {
                Button(action: {
                    if canGoPrevious {
                        onPreviousPeriod()
                    }
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(canGoPrevious ? .black : .gray.opacity(0.5))
                }
                .disabled(!canGoPrevious)
                
                Spacer()
                
                Text(dateRange)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.black)
                
                Spacer()
                
                Button(action: {
                    if canGoNext {
                        onNextPeriod()
                    }
                }) {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(canGoNext ? .black : .gray.opacity(0.5))
                }
                .disabled(!canGoNext)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 20)
            
            // Only show divider and metrics if hideMetrics is false
            if !hideMetrics {
                // Divider
                Divider()
                    .padding(.horizontal, -16)
                
                // Summary Metrics
                HStack(spacing: 0) {
                    UserDashboardSummaryItem(title: "SPENT", value: totalSpent, color: .orange, isEarnings: true, currencySymbol: currencySymbol)
                    Divider().frame(height: 40)
                    UserDashboardSummaryItem(title: "BOOKINGS", value: totalBookings, color: .black, isEarnings: false)
                    Divider().frame(height: 40)
                    UserDashboardSummaryItem(title: "COMPLETED", value: completedRides, color: AppColors.greenColor, isEarnings: false)
                }
                .padding(.vertical, 20)
            }
        }
        .background(Color.white)
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.gray.opacity(0.18), lineWidth: 1)
        )
    }
}

// MARK: - Cancel Booking Confirmation View
struct CancelBookingConfirmationView: View {
    let booking: UserBooking
    let isProcessing: Bool
    let onEdit: () -> Void
    let onConfirm: () -> Void
    let onDismiss: () -> Void
    
    var body: some View {
        VStack(spacing: 24) {
            VStack(spacing: 12) {
                Text("Are you sure you want to cancel the booking?")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(AppColors.error)
                    .multilineTextAlignment(.center)
                
                Text("Booking #\(booking.id)")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(AppColors.primaryText)
                    .multilineTextAlignment(.center)
                
                Text("Click Edit / Change to make changes to the booking instead of cancelling.")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(AppColors.primaryText)
                    .multilineTextAlignment(.center)
            }
            
            HStack(spacing: 12) {
                Button(action: onEdit) {
                    Text("Edit / Change")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(AppColors.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(AppColors.greenColor)
                        .cornerRadius(12)
                }
                .disabled(isProcessing)
                
                Button(action: onConfirm) {
                    Group {
                        if isProcessing {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: AppColors.white))
                        } else {
                            Text("Yes")
                                .font(.system(size: 15, weight: .semibold))
                        }
                    }
                    .foregroundColor(AppColors.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 48)
                    .background(AppColors.greenColor.opacity(isProcessing ? 0.7 : 1.0))
                    .cornerRadius(12)
                }
                .disabled(isProcessing)
                
                Button(action: onDismiss) {
                    Text("No")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(AppColors.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(AppColors.black)
                        .cornerRadius(12)
                }
                .disabled(isProcessing)
            }
        }
        .padding(.vertical, 28)
        .padding(.horizontal, 24)
        .background(AppColors.white)
        .cornerRadius(24)
        .shadow(color: Color.black.opacity(0.2), radius: 24, x: 0, y: 12)
    }
}

// MARK: - User Dashboard Summary Item
struct UserDashboardSummaryItem: View {
    let title: String
    let value: String
    let color: Color
    let isEarnings: Bool
    let currencySymbol: String?
    
    init(title: String, value: String, color: Color, isEarnings: Bool, currencySymbol: String? = nil) {
        self.title = title
        self.value = value
        self.color = color
        self.isEarnings = isEarnings
        self.currencySymbol = currencySymbol
    }
    
    var body: some View {
        VStack(spacing: 6) {
            Text(title)
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.gray)
                .textCase(.uppercase)
            
            if isEarnings {
                HStack(spacing: 2) {
                    Text(currencySymbol ?? "$")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.orange)
                    Text(value)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                }
            } else {
                Text(value)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(color)
            }
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - User Custom Date Range Picker
struct UserCustomDateRangePicker: View {
    @Binding var startDate: Date
    @Binding var endDate: Date
    let onDateRangeSelected: () -> Void
    
    @State private var showingCalendar = false
    @State private var tempStartDate: Date = Date()
    @State private var tempEndDate: Date = Date()
    
    var body: some View {
        VStack(spacing: 16) {
            Button(action: {
                showingCalendar.toggle()
            }) {
                VStack(spacing: 0) {
                    HStack(spacing: 12) {
                        // Calendar Icon
                        ZStack {
                            Circle()
                                .fill(Color.orange.opacity(0.1))
                                .frame(width: 40, height: 40)
                            
                            Image(systemName: "calendar")
                                .font(.system(size: 18, weight: .medium))
                                .foregroundColor(.orange)
                        }
                        
                        // Content
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Select Date Range")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                            
                            Text("\(formatDate(startDate)) - \(formatDate(endDate))")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.gray)
                        }
                        
                        Spacer()
                        
                        // Chevron
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 16)
                }
                .background(Color.white)
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                )
                .shadow(color: .black.opacity(0.05), radius: 2, x: 0, y: 1)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .sheet(isPresented: $showingCalendar) {
            UserCalendarRangePickerView(
                startDate: $tempStartDate,
                endDate: $tempEndDate,
                isPresented: $showingCalendar,
                onApply: {
                    startDate = tempStartDate
                    endDate = tempEndDate
                    onDateRangeSelected()
                    showingCalendar = false
                }
            )
        }
        .onAppear {
            tempStartDate = startDate
            tempEndDate = endDate
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy"
        return formatter.string(from: date)
    }
}

// MARK: - User Calendar Range Picker View (Matching Driver App)
struct UserCalendarRangePickerView: View {
    @Binding var startDate: Date
    @Binding var endDate: Date
    @Binding var isPresented: Bool
    let onApply: () -> Void
    
    @State private var currentMonth = Date()
    @State private var tempStartDate: Date?
    @State private var tempEndDate: Date?
    @State private var showingYearPicker = false
    
    private let calendar = Calendar.current
    private let dateFormatter = DateFormatter()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Compact Professional Header
                VStack(spacing: 0) {
                    // Top Bar with Close and Title
                    HStack {
                        Button(action: {
                            isPresented = false
                        }) {
                            Image(systemName: "xmark")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.gray)
                                .frame(width: 28, height: 28)
                                .background(Color.gray.opacity(0.08))
                                .cornerRadius(14)
                        }
                        
                        Spacer()
                        
                        Text("Select Date Range")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundColor(.black)
                        
                        Spacer()
                        
                        // Invisible spacer for balance
                        Color.clear
                            .frame(width: 28, height: 28)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                    .padding(.bottom, 16)
                    
                    // Compact Month Navigation
                    HStack(spacing: 0) {
                        Button(action: previousMonth) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(width: 36, height: 36)
                                .background(Color.gray.opacity(0.08))
                                .cornerRadius(18)
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            showingYearPicker.toggle()
                        }) {
                            VStack(spacing: 1) {
                                Text(monthString)
                                    .font(.system(size: 18, weight: .bold))
                                    .foregroundColor(.black)
                                
                                Text(yearString)
                                    .font(.system(size: 13, weight: .medium))
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Color.gray.opacity(0.04))
                            .cornerRadius(6)
                        }
                        
                        Spacer()
                        
                        Button(action: nextMonth) {
                            Image(systemName: "chevron.right")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(width: 36, height: 36)
                                .background(Color.gray.opacity(0.08))
                                .cornerRadius(18)
                        }
                    }
                    .padding(.horizontal, 16)
                    
                    // Compact Year Navigation
                    HStack(spacing: 8) {
                        Button("Prev Year") {
                            previousYear()
                        }
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(.gray)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Color.gray.opacity(0.08))
                        .cornerRadius(4)
                        
                        Spacer()
                        
                        Button("Current") {
                            goToCurrentYear()
                        }
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Color.orange)
                        .cornerRadius(4)
                        
                        Spacer()
                        
                        Button("Next Year") {
                            nextYear()
                        }
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(.gray)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Color.gray.opacity(0.08))
                        .cornerRadius(4)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                    .padding(.bottom, 16)
                }
                .background(Color.white)
                
                // Compact Calendar Content
                VStack(spacing: 0) {
                    // Compact Day headers
                    HStack(spacing: 0) {
                        ForEach(dayHeaders, id: \.self) { day in
                            Text(day)
                                .font(.system(size: 12, weight: .semibold))
                                .foregroundColor(.gray)
                                .frame(maxWidth: .infinity)
                                .frame(height: 28)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 12)
                    
                    // Compact Calendar grid
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 2), count: 7), spacing: 2) {
                        ForEach(calendarDays, id: \.self) { date in
                            UserCompactCalendarDayView(
                                date: date,
                                currentMonth: currentMonth,
                                startDate: tempStartDate,
                                endDate: tempEndDate,
                                onTap: { selectDate(date) }
                            )
                        }
                    }
                    .padding(.horizontal, 16)
                }
                
                Spacer()
                
                // Compact Selected range display
                if let start = tempStartDate, let end = tempEndDate {
                    VStack(spacing: 8) {
                        HStack {
                            Text("Selected Range")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundColor(.gray)
                            
                            Spacer()
                        }
                        
                        HStack(spacing: 12) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("From")
                                    .font(.system(size: 11, weight: .medium))
                                    .foregroundColor(.gray)
                                Text(formatDate(start))
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(.black)
                            }
                            
                            Spacer()
                            
                            Image(systemName: "arrow.right")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.gray)
                            
                            Spacer()
                            
                            VStack(alignment: .trailing, spacing: 2) {
                                Text("To")
                                    .font(.system(size: 11, weight: .medium))
                                    .foregroundColor(.gray)
                                Text(formatDate(end))
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundColor(.black)
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.orange.opacity(0.06))
                    .cornerRadius(8)
                    .padding(.horizontal, 16)
                    .padding(.bottom, 16)
                }
                
                // Compact Action buttons
                VStack(spacing: 0) {
                    Divider()
                        .background(Color.gray.opacity(0.15))
                    
                    HStack(spacing: 10) {
                        Button("Reset") {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                tempStartDate = nil
                                tempEndDate = nil
                            }
                        }
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .background(Color.gray.opacity(0.08))
                        .cornerRadius(8)
                        
                        Button("Apply") {
                            if let start = tempStartDate, let end = tempEndDate {
                                startDate = start
                                endDate = end
                                onApply()
                            }
                        }
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .background(tempStartDate != nil && tempEndDate != nil ? Color.orange : Color.gray)
                        .cornerRadius(8)
                        .disabled(tempStartDate == nil || tempEndDate == nil)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }
                .background(Color.white)
            }
            .background(Color.gray.opacity(0.05))
        }
        .sheet(isPresented: $showingYearPicker) {
            UserYearPickerView(
                selectedYear: Binding(
                    get: { calendar.component(.year, from: currentMonth) },
                    set: { newYear in
                        if let newDate = calendar.date(bySetting: .year, value: newYear, of: currentMonth) {
                            currentMonth = newDate
                        }
                    }
                ),
                isPresented: $showingYearPicker
            )
        }
        .onAppear {
            tempStartDate = startDate
            tempEndDate = endDate
        }
    }
    
    private var monthString: String {
        dateFormatter.dateFormat = "MMMM"
        return dateFormatter.string(from: currentMonth)
    }
    
    private var yearString: String {
        dateFormatter.dateFormat = "yyyy"
        return dateFormatter.string(from: currentMonth)
    }
    
    private var dayHeaders: [String] {
        ["S", "M", "T", "W", "T", "F", "S"]
    }
    
    private var calendarDays: [Date] {
        guard let monthInterval = calendar.dateInterval(of: .month, for: currentMonth),
              let monthFirstWeek = calendar.dateInterval(of: .weekOfYear, for: monthInterval.start),
              let monthLastWeek = calendar.dateInterval(of: .weekOfYear, for: monthInterval.end - 1) else {
            return []
        }
        
        var days: [Date] = []
        var currentDate = monthFirstWeek.start
        
        while currentDate < monthLastWeek.end {
            days.append(currentDate)
            currentDate = calendar.date(byAdding: .day, value: 1, to: currentDate) ?? currentDate
        }
        
        return days
    }
    
    private func previousMonth() {
        currentMonth = calendar.date(byAdding: .month, value: -1, to: currentMonth) ?? currentMonth
    }
    
    private func nextMonth() {
        currentMonth = calendar.date(byAdding: .month, value: 1, to: currentMonth) ?? currentMonth
    }
    
    private func previousYear() {
        currentMonth = calendar.date(byAdding: .year, value: -1, to: currentMonth) ?? currentMonth
    }
    
    private func nextYear() {
        currentMonth = calendar.date(byAdding: .year, value: 1, to: currentMonth) ?? currentMonth
    }
    
    private func goToCurrentYear() {
        currentMonth = Date()
    }
    
    private func selectDate(_ date: Date) {
        if tempStartDate == nil {
            tempStartDate = date
            tempEndDate = nil
        } else if tempEndDate == nil {
            if date >= tempStartDate! {
                tempEndDate = date
            } else {
                tempEndDate = tempStartDate
                tempStartDate = date
            }
        } else {
            tempStartDate = date
            tempEndDate = nil
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        dateFormatter.dateFormat = "MMM dd"
        return dateFormatter.string(from: date)
    }
}

// MARK: - User Compact Calendar Day View
struct UserCompactCalendarDayView: View {
    let date: Date
    let currentMonth: Date
    let startDate: Date?
    let endDate: Date?
    let onTap: () -> Void
    
    private let calendar = Calendar.current
    
    private var isCurrentMonth: Bool {
        calendar.isDate(date, equalTo: currentMonth, toGranularity: .month)
    }
    
    private var isToday: Bool {
        calendar.isDateInToday(date)
    }
    
    private var isStartDate: Bool {
        startDate == date
    }
    
    private var isEndDate: Bool {
        endDate == date
    }
    
    private var isInRange: Bool {
        guard let start = startDate, let end = endDate else { return false }
        return date > start && date < end
    }
    
    var body: some View {
        Button(action: onTap) {
            ZStack {
                // Background for range selection
                if isInRange {
                    Rectangle()
                        .fill(Color.orange.opacity(0.2))
                        .frame(height: 32)
                }
                
                // Day number
                Text("\(calendar.component(.day, from: date))")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(textColor)
                    .frame(width: 32, height: 32)
                    .background(backgroundColor)
                    .cornerRadius(16)
                    .overlay(
                        Circle()
                            .stroke(borderColor, lineWidth: borderWidth)
                            .frame(width: 32, height: 32)
                    )
            }
        }
        .disabled(!isCurrentMonth)
        .buttonStyle(PlainButtonStyle())
    }
    
    private var textColor: Color {
        if !isCurrentMonth {
            return .gray.opacity(0.3)
        } else if isStartDate || isEndDate {
            return .white
        } else if isToday {
            return .orange
        } else {
            return .black
        }
    }
    
    private var backgroundColor: Color {
        if isStartDate || isEndDate {
            return .orange
        } else if isToday {
            return .orange.opacity(0.1)
        } else {
            return .clear
        }
    }
    
    private var borderColor: Color {
        if isToday && !isStartDate && !isEndDate {
            return .orange
        } else {
            return .clear
        }
    }
    
    private var borderWidth: CGFloat {
        if isToday && !isStartDate && !isEndDate {
            return 1.5
        } else {
            return 0
        }
    }
}

// MARK: - User Year Picker View
struct UserYearPickerView: View {
    @Binding var selectedYear: Int
    @Binding var isPresented: Bool
    
    private let currentYear = Calendar.current.component(.year, from: Date())
    private var years: [Int] {
        Array((currentYear - 10)...(currentYear + 10))
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Compact Header
                HStack {
                    Button("Cancel") {
                        isPresented = false
                    }
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(.gray)
                    
                    Spacer()
                    
                    Text("Select Year")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundColor(.black)
                    
                    Spacer()
                    
                    Button("Done") {
                        isPresented = false
                    }
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.orange)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 16)
                
                // Compact Year Picker
                ScrollView {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 3), spacing: 8) {
                        ForEach(years, id: \.self) { year in
                            Button(action: {
                                selectedYear = year
                            }) {
                                Text(year, format: .number.grouping(.never))
                                    .font(.system(size: 15, weight: .medium))
                                    .foregroundColor(year == selectedYear ? .white : .black)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 40)
                                    .background(year == selectedYear ? Color.orange : Color.gray.opacity(0.08))
                                    .cornerRadius(6)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.horizontal, 16)
                }
                
                Spacer()
            }
            .background(Color.gray.opacity(0.03))
        }
    }
}

// MARK: - Placeholder Views for Navigation
struct UserBookingDetailsView: View {
    let booking: UserBooking
    
    var body: some View {
        VStack {
            Text("Booking Details")
                .font(.title)
            Text("Booking ID: \(booking.id)")
        }
    }
}


// MARK: - Preview
#Preview {
    NavigationView {
        MyBookingsView()
    }
}
