import SwiftUI

struct PaxLuggageVehicleView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: [Screen]
    @State private var numberOfPassengers = 2
    @State private var numberOfLuggage = 1
    @State private var numberOfVehicles = 1
    @StateObject private var sheetDismissalManager = SheetDismissalManager.shared
    
    // Parameters passed from previous screens
    let rideData: VehicleSelectionView.RideData
    let onDataUpdated: ((Int, Int, Int) -> Void)?
    
    // Updated ride data with current selections
    @State private var updatedRideData: VehicleSelectionView.RideData
    
    init(rideData: VehicleSelectionView.RideData, path: Binding<[Screen]>, onDataUpdated: ((Int, Int, Int) -> Void)? = nil) {
        self.rideData = rideData
        self._path = path
        self.onDataUpdated = onDataUpdated
        // Initialize with data from rideData if available
        self._numberOfPassengers = State(initialValue: rideData.noOfPassenger)
        self._numberOfLuggage = State(initialValue: rideData.noOfLuggage)
        self._numberOfVehicles = State(initialValue: rideData.noOfVehicles)
        // Initialize updated ride data
        self._updatedRideData = State(initialValue: rideData)
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Drag Handle
            RoundedRectangle(cornerRadius: 2.5)
                .fill(Color.gray.opacity(0.3))
                .frame(width: 36, height: 5)
                .padding(.top, 8)
                .padding(.bottom, 16)
            
            // Header with back button and title
            HStack {
                Button(action: {
                    path.removeLast()
                }) {
                    Image(systemName: "arrow.left")
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Text("Pax, Luggage & Vehicle Info")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
                
                Spacer()
                
                // Invisible spacer to center the title
                Image(systemName: "arrow.left")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(.clear)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 16)
            
            // Divider after header
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(height: 1)
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
            
            // NO. OF PASSENGERS
            VStack(alignment: .leading, spacing: 12) {
                Text("NO. OF PASSENGERS")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.gray)
                    .textCase(.uppercase)
                    .lineSpacing(6) // 150% line height
                
                QuantitySelector(value: $numberOfPassengers)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 32)
            
            // NO. OF LUGGAGE
            VStack(alignment: .leading, spacing: 12) {
                Text("NO. OF LUGGAGE")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.gray)
                    .textCase(.uppercase)
                    .lineSpacing(6) // 150% line height
                
                QuantitySelector(value: $numberOfLuggage)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 32)
            
            // NO. OF VEHICLES
            VStack(alignment: .leading, spacing: 12) {
                Text("NO. OF VEHICLES")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.gray)
                    .textCase(.uppercase)
                    .lineSpacing(6) // 150% line height
                
                QuantitySelector(value: $numberOfVehicles)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 53)
            
            Spacer()
            
            // Next Button
            Button(action: {
                // Update the ride data with current selections (preserving the date/time from TimeSelectionView)
                updatedRideData = VehicleSelectionView.RideData(
                    serviceType: rideData.serviceType,
                    bookingHour: rideData.bookingHour,
                    pickupType: rideData.pickupType,
                    dropoffType: rideData.dropoffType,
                    pickupDate: rideData.pickupDate, // This now contains the updated date from TimeSelectionView
                    pickupTime: rideData.pickupTime, // This now contains the updated time from TimeSelectionView
                    pickupLocation: rideData.pickupLocation,
                    destinationLocation: rideData.destinationLocation,
                    selectedPickupAirport: rideData.selectedPickupAirport,
                    selectedDestinationAirport: rideData.selectedDestinationAirport,
                    noOfPassenger: numberOfPassengers,
                    noOfLuggage: numberOfLuggage,
                    noOfVehicles: numberOfVehicles,
                    pickupLat: rideData.pickupLat,
                    pickupLong: rideData.pickupLong,
                    destinationLat: rideData.destinationLat,
                    destinationLong: rideData.destinationLong
                )
                
                // Pass the collected data back
                onDataUpdated?(numberOfPassengers, numberOfLuggage, numberOfVehicles)
                
                // Navigate to VehicleSelectionView using path
                path.append(.vehicleSelection(rideData: updatedRideData))
            }) {
                Text("Next")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 40)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 4)
                    .background(AppColors.primaryOrange)
                    .cornerRadius(8)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.clear, lineWidth: 1)
                    )
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
            
        }
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .background(Color.white)
        // Navigation is now handled via path, so we don't need fullScreenCover here
        .onReceive(NotificationCenter.default.publisher(for: .dismissAllSheets)) { _ in
            print("🔚 PaxLuggageVehicleView received dismiss notification")
            if !path.isEmpty {
                path.removeLast()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .forceDismissAllSheets)) { _ in
            print("🔚 PaxLuggageVehicleView received force dismiss notification")
            // Clear entire path to go back to dashboard
            path.removeAll()
        }
    }
}

struct QuantitySelector: View {
    @Binding var value: Int
    @State private var textValue: String = ""
    @State private var isEditing: Bool = false
    
    var body: some View {
        HStack(spacing: 0) {
            // Decrement Button
            Button(action: {
                if value > 1 {
                    value -= 1
                    textValue = String(format: "%02d", value)
                }
            }) {
                Image(systemName: "minus")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white)
                    .frame(width: 20, height: 20)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(AppColors.primaryOrange)
            }
            
            // Text Field for Manual Input
            AutoSelectTextField(
                placeholder: "",
                text: $textValue,
                keyboardType: .numberPad,
                textAlignment: .center,
                fontSize: 16,
                fontWeight: .medium
            )
            .frame(maxWidth: .infinity)
            .frame(height: 22) // Fixed height to match UITextField intrinsic size (font 16 + padding)
            .padding(.vertical, 12)
            .onAppear {
                textValue = String(format: "%02d", value)
            }
            .onChange(of: value) { newValue in
                if !isEditing {
                    textValue = String(format: "%02d", newValue)
                }
            }
            .onChange(of: textValue) { newTextValue in
                isEditing = true
                if let intValue = Int(newTextValue), intValue >= 1 {
                    value = intValue
                } else if newTextValue.isEmpty {
                    value = 1
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    isEditing = false
                }
            }
            
            // Increment Button
            Button(action: {
                value += 1
                textValue = String(format: "%02d", value)
            }) {
                Image(systemName: "plus")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white)
                    .frame(width: 20, height: 20)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(AppColors.primaryOrange)
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 6)
        .background(Color.gray.opacity(0.1))
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
        )
    }
}


