import Foundation

class RecentLocationService: ObservableObject {
    static let shared = RecentLocationService()
    
    @Published var isLoading = false
    @Published var pickupLocations: [RecentLocation] = []
    @Published var dropoffLocations: [RecentLocation] = []
    @Published var errorMessage: String?
    
    private init() {}
    
    // Fetch recent locations based on type (pickup or dropoff)
    func fetchRecentLocations(type: String) async {
        await MainActor.run {
            isLoading = true
            errorMessage = nil
        }
        
        do {
            let endpoint = APIEndpoints.recentLocations(type: type)
            let response: RecentLocationResponse = try await NetworkService.shared.request(
                endpoint: endpoint,
                responseType: RecentLocationResponse.self
            )
            
            await MainActor.run {
                if response.success {
                    if type == "pickup" {
                        self.pickupLocations = response.data.locations
                    } else if type == "dropoff" {
                        self.dropoffLocations = response.data.locations
                    }
                } else {
                    self.errorMessage = response.message
                }
                self.isLoading = false
            }
        } catch {
            await MainActor.run {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
                print("❌ Error fetching recent locations: \(error)")
            }
        }
    }
    
    // Clear locations cache
    func clearCache() {
        pickupLocations = []
        dropoffLocations = []
    }
}
