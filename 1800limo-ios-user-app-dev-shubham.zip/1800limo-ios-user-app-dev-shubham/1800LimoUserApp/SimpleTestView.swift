//
//  SimpleTestView.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct SimpleTestView: View {
    @State private var showSubtotalDialog = false
    @State private var showDriverInfoDialog = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Dialog Test View")
                .font(.title)
                .padding()
            
            Button("Show Subtotal Dialog") {
                showSubtotalDialog = true
            }
            .padding()
            .background(Color.orange)
            .foregroundColor(.white)
            .cornerRadius(8)
            
            Button("Show Driver Info Dialog") {
                showDriverInfoDialog = true
            }
            .padding()
            .background(Color.black)
            .foregroundColor(.white)
            .cornerRadius(8)
        }
        .padding()
        
        // Subtotal Dialog
        if showSubtotalDialog {
            SubtotalDialog(
                vehicle: createTestVehicle(),
                serviceType: "one_way",
                onClose: { showSubtotalDialog = false }
            )
        }
        
        // Driver Info Dialog
        if showDriverInfoDialog {
            DriverInfoDialog(
                vehicle: createTestVehicle(),
                onClose: { showDriverInfoDialog = false }
            )
        }
    }
    
    private func createTestVehicle() -> VehicleListingItem {
        let sampleJSON = """
        {
            "id": 1,
            "name": "Test Vehicle",
            "passenger": 4,
            "luggage": 2,
            "vehicle_images": ["https://example.com/image.png"],
            "vehicle_details": {
                "make": "BMW",
                "model": "Test Model",
                "year": "2024"
            },
            "rate_breakdown_one_way": {
                "rateArray": {
                    "all_inclusive_rates": {
                        "trip_rate": {
                            "rate_label": "Trip Rate",
                            "baserate": 2450.0,
                            "amount": 2450.0
                        },
                        "gratuity": {
                            "rate_label": "Gratuity",
                            "baserate": 0.0,
                            "amount": 0.0
                        },
                        "trip_tax": {
                            "rate_label": "Tax",
                            "baserate": 0.0,
                            "amount": 0.0
                        }
                    }
                },
                "sub_total": 2450.0,
                "grand_total": 2450.0,
                "total": 2450.0
            },
            "driverInformation": {
                "insurance_limit": "$500,000",
                "id": 1,
                "name": "John Smith",
                "gender": "Male",
                "email": "john@example.com",
                "phone": "+1 98765 43210",
                "cell_isd": "+1",
                "cell_number": "98765 43210",
                "starRating": "4.5",
                "background": "Professional driver",
                "dress": "Business Casual",
                "languages": "English",
                "experience": "20+ Years",
                "imageUrl": "https://example.com/driver.jpg"
            }
        }
        """
        
        do {
            let data = sampleJSON.data(using: .utf8)!
            return try JSONDecoder().decode(VehicleListingItem.self, from: data)
        } catch {
            print("Error creating test vehicle: \(error)")
            fatalError("Failed to create test vehicle: \(error)")
        }
    }
}

#Preview {
    SimpleTestView()
}









