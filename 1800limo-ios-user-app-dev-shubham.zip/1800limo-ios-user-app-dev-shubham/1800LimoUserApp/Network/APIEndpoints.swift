//
//  APIEndpoints.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

enum APIEndpoints {
    // Auth endpoints
    case loginOrRegister
    case verifyOTP
    case resendOTP
    
    // Registration endpoints
    case basicDetails
    case creditCard
    case airports(search: String?, page: Int?, limit: Int?)
    case airlines(search: String?)
    case meetGreetChoices
    case vehicleQuote(request: VehicleQuoteRequest)
    case vehicleListing(request: VehicleListingRequest)
    case bookingRates(request: BookingRatesRequest)
    case reservationRates(bookingId: Int)
    case createReservation
    case duplicateReservation
    case editReservation
    case repeatReservation(bookingId: Int)
    case returnReservation(bookingId: Int)
    case roundTripReservation(bookingId: Int)
    case filters
    
    // User Bookings endpoints
    case getAllReservations
    case cancelBooking(bookingId: Int)
    
    // User Profile endpoints
    case userProfile
    case updateUserProfile
    case getProfileData
    
    // Credit Card endpoints
    case addCreditCard
    
    // Invoice endpoints
    case getInvoices
    
    // Recent Locations endpoints
    case recentLocations(type: String)
    
    // Booking Audit Records endpoint
    case bookingAuditRecords

    var path: String {
        switch self {
        case .loginOrRegister:
            return "/api/mobile/v1/auth/login-or-register"
        case .verifyOTP:
            return "/api/mobile/v1/auth/verify-otp"
        case .resendOTP:
            return "/api/mobile/v1/auth/resend-otp"
        case .basicDetails:
            return "/api/mobile/v1/user/registration/basic-details"
        case .creditCard:
            return "/api/mobile/v1/user/registration/credit-card"
        case .airports(let search, let page, let limit):
            var path = "/api/mobile-data?only_airports=true"
            if let search = search, !search.isEmpty {
                path += "&search=\(search.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? search)"
            }
            if let page = page {
                path += "&page=\(page)"
            }
            if let limit = limit {
                path += "&limit=\(limit)"
            }
            return path
        case .airlines(let search):
            var path = "/api/mobile-data?only_airlines=true"
            if let search = search, !search.isEmpty {
                path += "&search=\(search.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? search)"
            }
            return path
        case .meetGreetChoices:
            return "/api/mobile-data?only_meet_greet=true"
        case .vehicleQuote:
            return "/api/quote/master-vehicle-listing"
        case .vehicleListing:
            return "/api/quote/vehicle-listing"
        case .bookingRates:
            return "/api/admin/booking-rates-vehicle"
        case .reservationRates(let bookingId):
            return "/api/admin/reservation-rates/\(bookingId)"
        case .createReservation:
            return "/api/individual/create-reservation"
        case .duplicateReservation:
            return "/api/individual/duplicate-reservation"
        case .editReservation:
            return "/api/individual/edit-reservation"
        case .repeatReservation(let bookingId):
            return "/api/individual/get-reservation/\(bookingId)/repeat"
        case .returnReservation(let bookingId):
            return "/api/individual/get-reservation/\(bookingId)/return"
        case .roundTripReservation(let bookingId):
            return "/api/individual/get-reservation/\(bookingId)/round"
        case .filters:
            return "/api/quote/filters"
        case .getAllReservations:
            return "/api/individual/get-all-reservation"
        case .cancelBooking(let bookingId):
            return "/api/individual/cancel-booking/\(bookingId)"
        case .userProfile:
            return "/api/mobile/v1/user/registration/profile"
        case .updateUserProfile:
            return "/api/mobile/v1/user/profile"
        case .getProfileData:
            return "/api/individual/get-profile-data"
        case .addCreditCard:
            return "/api/individual/add-credit-card"
        case .getInvoices:
            return "/api/individual/invoices"
        case .recentLocations(let type):
            return "/api/mobile/v1/user/recent-locations?type=\(type)"
        case .bookingAuditRecords:
            return "/api/mobile/v1/user/bookings/audit-records"
        }
    }
    
    var method: HTTPMethod {
        switch self {
        case .loginOrRegister:
            return .POST
        case .verifyOTP:
            return .POST
        case .resendOTP:
            return .POST
        case .basicDetails:
            return .POST
        case .creditCard:
            return .POST
        case .airports:
            return .GET
        case .airlines:
            return .GET
        case .meetGreetChoices:
            return .GET
        case .vehicleQuote:
            return .POST
        case .vehicleListing:
            return .POST
        case .bookingRates:
            return .POST
        case .reservationRates:
            return .GET
        case .createReservation:
            return .POST
        case .duplicateReservation:
            return .POST
        case .editReservation:
            return .POST
        case .repeatReservation:
            return .GET
        case .returnReservation:
            return .GET
        case .roundTripReservation:
            return .GET
        case .filters:
            return .GET
        case .getAllReservations:
            return .GET
        case .cancelBooking:
            return .GET
        case .userProfile:
            return .GET
        case .updateUserProfile:
            return .PUT
        case .getProfileData:
            return .GET
        case .addCreditCard:
            return .POST
        case .getInvoices:
            return .GET
        case .recentLocations:
            return .GET
        case .bookingAuditRecords:
            return .GET
        }
    }
    
    var body: Data? {
        switch self {
        case .vehicleQuote(let request):
            return try? JSONEncoder().encode(request)
        case .vehicleListing(let request):
            return try? JSONEncoder().encode(request)
        case .bookingRates(let request):
            return try? JSONEncoder().encode(request)
        case .createReservation:
            return nil
        case .editReservation:
            return nil
        case .getAllReservations:
            return nil
        case .addCreditCard:
            return nil
        case .getInvoices:
            return nil
        default:
            return nil
        }
    }
}

enum HTTPMethod: String {
    case GET = "GET"
    case POST = "POST"
    case PUT = "PUT"
    case DELETE = "DELETE"
    case PATCH = "PATCH"
}
