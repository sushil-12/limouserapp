//
//  NetworkService.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

// Generic lightweight message wrapper some endpoints return
fileprivate struct GenericAPIMessage: Codable {
    let success: Bool?
    let message: String?
}

class NetworkService {
    static let shared = NetworkService()
    private init() {}
    
    func request<T: Codable>(
        endpoint: APIEndpoints,
        body: [String: Any]? = nil,
        queryParameters: [String: Any]? = nil,
        responseType: T.Type
    ) async throws -> T {
        
        var urlString = APIConfig.baseURL + endpoint.path
        
        // Add query parameters for GET requests
        if endpoint.method == .GET, let queryParams = queryParameters, !queryParams.isEmpty {
            let queryItems = queryParams.map { key, value in
                URLQueryItem(name: key, value: "\(value)")
            }
            if var urlComponents = URLComponents(string: urlString) {
                urlComponents.queryItems = queryItems
                urlString = urlComponents.url?.absoluteString ?? urlString
            }
        }
        
        guard let url = URL(string: urlString) else {
            throw NetworkError.invalidURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = endpoint.method.rawValue
        request.timeoutInterval = APIConfig.requestTimeout
        
        // Add headers
        for (key, value) in APIConfig.defaultHeaders {
            request.setValue(value, forHTTPHeaderField: key)
        }
        
        // Add auth token if available
        if let token = StorageManager.shared.getAuthToken() {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        // Add body for requests that support an HTTP body
        if endpoint.method == .POST || endpoint.method == .PUT || endpoint.method == .PATCH {
            if let body = body {
                // Use provided body
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: body)
                    request.httpBody = jsonData
                } catch {
                    throw NetworkError.networkError(error)
                }
            } else if let endpointBody = endpoint.body {
                // Use endpoint's body
                request.httpBody = endpointBody
            }
        }
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw NetworkError.invalidResponse
            }
            
            
            // Check for HTTP errors
            if httpResponse.statusCode >= 400 {
                // Try strict APIErrorResponse shape first
                if let errorResponse = try? JSONDecoder().decode(APIErrorResponse.self, from: data) {
                    throw NetworkError.serverError(errorResponse.message)
                }
                // Try a generic wrapper with just message
                if let generic = try? JSONDecoder().decode(GenericAPIMessage.self, from: data),
                   let msg = generic.message, !msg.isEmpty {
                    throw NetworkError.serverError(msg)
                }
                // Fallback to status code
                throw NetworkError.serverError("HTTP \(httpResponse.statusCode)")
            }
            
            // Special-case raw Data responses: return as-is
            if T.self == Data.self {
                // swiftlint:disable:next force_cast
                return data as! T
            }

            // Decode response
            do {
                let decodedResponse = try JSONDecoder().decode(T.self, from: data)
                return decodedResponse
            } catch let decodeErr {
                // Attempt to provide a more helpful error by inspecting the raw payload
                let rawString = String(data: data, encoding: .utf8) ?? "<non-utf8 payload of size \(data.count) bytes>"
                print("❌ Decoding error for \(endpoint.path): \(decodeErr)")
                print("🔎 Raw response body (first 1000 chars): \(rawString.prefix(1000))")

                // Try to decode a generic error wrapper to surface server message
                if let generic = try? JSONDecoder().decode(GenericAPIMessage.self, from: data),
                   let msg = generic.message, !(generic.success ?? true) {
                    throw NetworkError.serverError(msg)
                }

                throw NetworkError.decodingError
            }
            
        } catch {
            if let networkError = error as? NetworkError {
                throw networkError
            } else {
                throw NetworkError.networkError(error)
            }
        }
    }
    
    // MARK: - Static API Methods
    static func loginOrRegister(_ request: LoginRegisterRequest) async throws -> AuthResponse {
        return try await performRequest(endpoint: .loginOrRegister, body: request)
    }
    
    static func verifyOTP(_ request: VerifyOTPRequest) async throws -> VerifyOTPResponse {
        return try await performRequest(endpoint: .verifyOTP, body: request)
    }
    
    static func resendOTP(_ request: ResendOTPRequest) async throws -> ResendOTPResponse {
        return try await performRequest(endpoint: .resendOTP, body: request)
    }
    
    static func submitBasicDetails(_ request: BasicDetailsRequest) async throws -> BasicDetailsResponse {
        return try await performRequest(endpoint: .basicDetails, body: request)
    }
    
    static func submitCreditCard(_ request: CreditCardRequest) async throws -> CreditCardResponse {
        return try await performRequest(endpoint: .creditCard, body: request)
    }
    
    // MARK: - Helper Method
    static func performRequest<T: Codable, U: Codable>(endpoint: APIEndpoints, body: T) async throws -> U {
        let shared = NetworkService.shared
        
        // Convert body to dictionary
        let jsonData = try JSONEncoder().encode(body)
        let bodyDict = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] ?? [:]
        
        return try await shared.request(endpoint: endpoint, body: bodyDict, responseType: U.self)
    }
    
    static func getRawResponse(endpoint: APIEndpoints, body: [String: Any]? = nil) async throws -> Data {
        // Use the typed request with Data.self which is now special-cased to return raw bytes
        let shared = NetworkService.shared
        return try await shared.request(endpoint: endpoint, body: body, responseType: Data.self)
    }
}
