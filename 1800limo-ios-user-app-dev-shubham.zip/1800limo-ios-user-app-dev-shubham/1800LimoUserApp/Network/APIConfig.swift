//
//  APIConfig.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import Foundation

struct APIConfig {
    // Base URLs
    static let baseURL = "https://1800limoapi.infodevbox.com"
//    static let baseURL = "http://10.20.20.188:8000"
    
    // API Headers
    static let defaultHeaders: [String: String] = [
        "Content-Type": "application/json",
        "Accept": "application/json"
    ]
    
    // Timeout configuration
    static let requestTimeout: TimeInterval = 30.0
    
    // Retry configuration
    static let maxRetries = 3
    static let retryDelay: TimeInterval = 2.0
}
