//
//  TestView.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct TestView: View {
    @State private var text = ""
    @State private var selectedOption: String?
    @State private var showDialog = false
    @State private var showBottomSheet = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Test AppText
                AppText.largeHeading("Test Components")
                AppText.body("All components should work correctly")
                
                // Test AppTextField
                AppTextField(
                    label: "Test Field",
                    placeholder: "Enter text",
                    text: $text
                )
                
                // Test AppDropdown
                AppDropdown(
                    label: "Test Dropdown",
                    placeholder: "Select option",
                    options: ["Option 1", "Option 2", "Option 3"],
                    optionToString: { $0 },
                    selectedOption: $selectedOption
                )
                
                // Test AppButton
                AppButton(
                    title: "Test Button",
                    action: {
                        showDialog = true
                    }
                )
                
                AppButton(
                    title: "Show Bottom Sheet",
                    action: {
                        showBottomSheet = true
                    },
                    buttonStyle: .secondary
                )
            }
            .padding()
        }
        .appDialog(
            isPresented: $showDialog,
            dialog: AppDialog(
                title: "Test Dialog",
                message: "This is a test dialog",
                primaryButtonTitle: "OK",
                dialogType: .info,
                primaryAction: {}
            )
        )
        .appBottomSheet(
            isPresented: $showBottomSheet,
            title: "Test Bottom Sheet"
        ) {
            VStack(spacing: 16) {
                AppText.body("This is a test bottom sheet")
                AppButton(title: "Close", action: {})
            }
        }
    }
}

#Preview {
    TestView()
}









