//
//  SplashScreen.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct SplashScreen: View {
    private enum SplashDestination {
        case onboarding
        case dashboard
        case basicInfo(autoLaunchCreditCard: Bool)
    }
    
    @State private var isActive = false
    @State private var shouldNavigateToDashboard = false
    @State private var shouldNavigateToMyBookings = false
    @State private var shouldNavigateToBasicInfo = false
    @State private var autoLaunchCreditCardFromBasicInfo = false
    
    // Notification data manager for deep link handling
    @StateObject private var notificationDataManager = NotificationDataManager.shared
    
    
    var body: some View {
        ZStack {
            // Black background
            Color.black
                .ignoresSafeArea()
            
            // Centered logo image
            Image("spleshlogo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(maxWidth: 300)
        }
        .onAppear {
            // Check for deep link navigation first
            checkDeepLinkNavigation()
            
            // Check authentication and driver registration state
            checkUserState()
            
            // Fallback timer - if no navigation happens within 5 seconds, go to onboarding
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                if !isActive {
                    withAnimation(.easeInOut(duration: 0.5)) {
                        isActive = true
                    }
                }
            }
        }
        .onChange(of: isActive) { newValue in
        }
        .fullScreenCover(isPresented: $isActive) {
            Group {
                if shouldNavigateToMyBookings {
                    NavigationView {
                        MyBookingsView()
                            .onAppear {
                                notificationDataManager.clearNavigationFlags()
                            }
                    }
                    .toastOverlay()
                } else if shouldNavigateToDashboard {
                    DashboardView()
                        .onAppear {
                        }
                } else if shouldNavigateToBasicInfo {
                    BasicInfoScreen(autoLaunchCreditCard: autoLaunchCreditCardFromBasicInfo)
                        .onDisappear {
                            autoLaunchCreditCardFromBasicInfo = false
                        }
                } else {
                    OnboardingScreen()
                        .onAppear {
                        }
                        .toastOverlay()
                }
            }
            .onAppear {
            }
        }
    }
    
    // MARK: - Deep Link Navigation
    
    /// Check if app was opened from notification and handle navigation accordingly
    private func checkDeepLinkNavigation() {
        notificationDataManager.printCurrentState()
        
        // Check if we should navigate to MyBookingsView
        if notificationDataManager.shouldOpenToMyBookings {
            shouldNavigateToMyBookings = true
            shouldNavigateToDashboard = false
            
            // Navigate immediately after splash screen delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    isActive = true
                }
            }
            return
        }
        
        // Check if we should navigate to DashboardView
        if notificationDataManager.shouldOpenToDashboard {
            shouldNavigateToMyBookings = false
            shouldNavigateToDashboard = true
            
            // Navigate immediately after splash screen delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    isActive = true
                }
            }
            return
        }
        
    }
    
    private func checkUserState() {
        // Check if user is logged in and has valid token
        let isLoggedIn = StorageManager.shared.isLoggedIn()
        
        guard isLoggedIn else {
            // Navigate to onboarding after 3 seconds
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                withAnimation(.easeInOut(duration: 0.5)) {
                    isActive = true
                }
            }
            return
        }
        
        // Get user data for debugging
        if let userData = StorageManager.shared.getUserData() {
        } else {
        }
        
        var destination: SplashDestination = .onboarding
        
        let storedNextStep = StorageManager.shared.getNormalizedCustomerNextStep()
        let profileStatus = StorageManager.shared.getProfileCompletionStatus()
            ?? StorageManager.shared.getUserData()?.isProfileCompleted
            ?? false
        
        // Reset navigation flags
        shouldNavigateToDashboard = false
        shouldNavigateToBasicInfo = false
        autoLaunchCreditCardFromBasicInfo = false
        
        // Check driver registration state
        if let driverRegistrationState = StorageManager.shared.getDriverRegistrationState() {
            if driverRegistrationState.isCompleted {
                destination = .dashboard
            } else {
                destination = resolveDestination(nextStep: storedNextStep, isProfileCompleted: profileStatus)
            }
        } else {
            destination = resolveDestination(nextStep: storedNextStep, isProfileCompleted: profileStatus)
        }
        
        switch destination {
        case .dashboard:
            shouldNavigateToDashboard = true
        case .basicInfo(let launchCard):
            autoLaunchCreditCardFromBasicInfo = launchCard
            shouldNavigateToBasicInfo = true
        case .onboarding:
            break
        }
        
        let delay: Double = {
            switch destination {
            case .dashboard, .basicInfo:
                return 1.0
            case .onboarding:
                return 3.0
            }
        }()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            withAnimation(.easeInOut(duration: 0.5)) {
                isActive = true
            }
        }
    }
    
    private func resolveDestination(nextStep: String?, isProfileCompleted: Bool) -> SplashDestination {
        guard let nextStep = nextStep else {
            return isProfileCompleted ? .dashboard : .onboarding
        }
        
        switch nextStep {
        case "basic_info", "basic_details":
            return .basicInfo(autoLaunchCreditCard: false)
        case "credit_card":
            return isProfileCompleted ? .dashboard : .basicInfo(autoLaunchCreditCard: true)
        case "dashboard":
            return .dashboard
        default:
            return isProfileCompleted ? .dashboard : .onboarding
        }
    }
}

#Preview {
    SplashScreen()
}
