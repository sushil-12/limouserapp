//
//  OnboardingScreen.swift
//  1800LimoUserApp
//
//  Created by shubham on 25/08/25.
//

import SwiftUI

struct OnboardingScreen: View {
    @State private var showLoginScreen = false
    @State private var showBasicInfoScreen = false
    @State private var showDashboard = false
    @State private var autoLaunchCreditCard = false
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background image
                Image("onboardingimg")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .clipped()
                
                // Dark overlay
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.clear,
                        Color.black.opacity(0.3),
                        Color.black.opacity(0.8)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
                
                // Content
                VStack {
                    Spacer()
                    
                    VStack(alignment: .leading, spacing: 20) {
                        // Main headline
                        VStack(alignment: .leading, spacing: 4) {
                            HStack(spacing: 0) {
                                Text("Sit back & ")
                                    .font(.system(size: 32, weight: .semibold))
                                    .foregroundColor(.white)
                                
                                Text("go")
                                    .font(.system(size: 32, weight: .semibold))
                                    .foregroundColor(AppColors.primaryOrange)
                            }
                            
                            Text("wherever you want")
                                .font(.system(size: 32, weight: .semibold))
                                .foregroundColor(AppColors.primaryOrange)
                        }
                        
                        // Body text
                        Text("Book a ride that offers exceptional value and a top-notch experience with 1800limo.")
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(.white)
                            .lineSpacing(4)
                            .multilineTextAlignment(.leading)
                        
                        // Button
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.5)) {
                                showLoginScreen = true
                            }
                        }) {
                            HStack {
                                Text("Let's get started")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 20)

                                Spacer()
                                
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 20)

                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(AppColors.primaryOrange)
                            .cornerRadius(8)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, geometry.safeAreaInsets.bottom + 40)
                }
            }
        }
        .ignoresSafeArea()
        .fullScreenCover(isPresented: $showLoginScreen) {
            LoginScreen()
        }
        .fullScreenCover(isPresented: $showBasicInfoScreen) {
            BasicInfoScreen(autoLaunchCreditCard: autoLaunchCreditCard)
                .onDisappear {
                    autoLaunchCreditCard = false
                }
        }
        .fullScreenCover(isPresented: $showDashboard) {
            DashboardView()
        }
        .onAppear {
            handleExistingSession()
        }
    }
}

#Preview {
    OnboardingScreen()
}

extension OnboardingScreen {
    private enum OnboardingDestination {
        case dashboard
        case basicInfo(autoLaunchCreditCard: Bool)
        case stay
    }
    
    private func handleExistingSession() {
        guard StorageManager.shared.isLoggedIn() else { return }
        
        let destination = resolveDestination(
            nextStep: StorageManager.shared.getNormalizedCustomerNextStep(),
            isProfileCompleted: StorageManager.shared.getProfileCompletionStatus()
                ?? StorageManager.shared.getUserData()?.isProfileCompleted
                ?? false
        )
        
        switch destination {
        case .dashboard:
            showDashboard = true
        case .basicInfo(let launchCard):
            autoLaunchCreditCard = launchCard
            showBasicInfoScreen = true
        case .stay:
            break
        }
    }
    
    private func resolveDestination(nextStep: String?, isProfileCompleted: Bool) -> OnboardingDestination {
        guard let nextStep = nextStep else {
            return isProfileCompleted ? .dashboard : .stay
        }
        
        switch nextStep {
        case "basic_info", "basic_details":
            return .basicInfo(autoLaunchCreditCard: false)
        case "credit_card":
            return isProfileCompleted ? .dashboard : .basicInfo(autoLaunchCreditCard: true)
        case "dashboard":
            return .dashboard
        default:
            return isProfileCompleted ? .dashboard : .stay
        }
    }
}
