# How to Add Info.plist Keys in Xcode

## ⚠️ Important: Info.plist Configuration

The Info.plist file was removed to fix the build error. Instead, add these keys directly in Xcode.

## Step-by-Step Instructions

### 1. Open Project Settings
1. In Xcode, click on the **1800LimoUserApp** project (blue icon at the top of navigator)
2. Select the **1800LimoUserApp** target
3. Click on the **Info** tab

### 2. Add Background Modes

**Method 1: Using Signing & Capabilities (Recommended)**
1. Go to **Signing & Capabilities** tab
2. Click **+ Capability** button
3. Search for and add **Background Modes**
4. Check these boxes:
   - ✅ **Remote notifications**
   - ✅ **Background fetch**
   - ✅ **Background processing**

**Method 2: Using Info.plist directly**
1. In the **Info** tab, find or add `UIBackgroundModes` (if not exists, click + button)
2. Expand it (it should be an Array)
3. Add these three items:
   - `remote-notification`
   - `fetch`
   - `processing`

### 3. Add Firebase Configuration Keys

In the **Info** tab, add these keys by clicking the **+** button:

1. **FirebaseAppDelegateProxyEnabled**
   - Type: Boolean
   - Value: NO (unchecked)

2. **FirebaseAutomaticScreenReportingEnabled**
   - Type: Boolean
   - Value: NO (unchecked)

### 4. Add Network Security Settings (Optional)

If you need to allow insecure connections for development:

1. Add key: **NSAppTransportSecurity** (Dictionary)
2. Inside it, add: **NSExceptionDomains** (Dictionary)
3. Inside NSExceptionDomains, add: **googleapis.com** (Dictionary)
4. Inside googleapis.com, add these:
   - **NSExceptionAllowsInsecureHTTPLoads** - Boolean - YES
   - **NSIncludesSubdomains** - Boolean - YES

### 5. Verify Configuration

After adding all keys, your Info tab should show:

```
UIBackgroundModes (Array)
  - Item 0: remote-notification
  - Item 1: fetch
  - Item 2: processing

FirebaseAppDelegateProxyEnabled (Boolean): NO
FirebaseAutomaticScreenReportingEnabled (Boolean): NO

NSAppTransportSecurity (Dictionary)
  - NSExceptionDomains (Dictionary)
    - googleapis.com (Dictionary)
      - NSExceptionAllowsInsecureHTTPLoads: YES
      - NSIncludesSubdomains: YES
```

## Quick Visual Guide

### Background Modes (Via Capabilities Tab)

```
Signing & Capabilities
├── + Capability (button)
    └── Background Modes
        ├── ✅ Remote notifications
        ├── ✅ Background fetch
        └── ✅ Background processing
```

### Firebase Keys (Via Info Tab)

```
Info Tab
├── + Add new key
│   ├── FirebaseAppDelegateProxyEnabled = NO
│   └── FirebaseAutomaticScreenReportingEnabled = NO
```

## Try Building Again

After adding these keys:

1. Clean Build Folder: **Cmd + Shift + K**
2. Build: **Cmd + B**

The build error should be resolved! ✅

## Troubleshooting

### If build still fails:
1. Make sure no Info.plist file exists in your source folder
2. Verify the keys are added correctly in Xcode's Info tab
3. Clean derived data: Xcode → Preferences → Locations → Derived Data → Delete
4. Restart Xcode

### To check your configuration:
1. Select your target
2. Info tab should show all the keys mentioned above
3. Signing & Capabilities should show Background Modes capability

---

**Note**: This is the modern way to configure iOS projects. SwiftUI projects typically don't need a separate Info.plist file in the source directory.






