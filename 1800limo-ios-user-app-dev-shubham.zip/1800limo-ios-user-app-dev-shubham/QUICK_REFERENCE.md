# Quick Reference - Firebase & Socket.IO

## 🚀 Quick Start

### After Login (OTP Verification)
```swift
// Subscribe to Firebase notifications
FirebasePushNotificationService.shared.subscribeToUserTopic()

// Connect Socket.IO
SimpleSocketIOService.shared.reconnectWithNewUserId()
```

### After Logout
```swift
// Unsubscribe from Firebase
FirebasePushNotificationService.shared.unsubscribeFromUserTopic()

// Disconnect Socket.IO
SimpleSocketIOService.shared.disconnect()
```

## 🧪 Testing

### Open Test Views
```swift
FirebaseTestView()    // Test Firebase push notifications
SocketIOTestView()    // Test Socket.IO connection
```

### Check Status
```swift
// Firebase
print(FirebasePushNotificationService.shared.getCurrentStatus())

// Socket.IO
print("Connected: \(SimpleSocketIOService.shared.isConnected)")
```

## 🔍 Debug Commands

### Firebase Debug
```swift
FirebasePushNotificationService.shared.printDebugInfo()
FirebasePushNotificationService.shared.manuallyTriggerSetup()
FirebasePushNotificationService.shared.resetAndReinitialize()
```

### Socket.IO Debug
```swift
SimpleSocketIOService.shared.debugUserIDStatus()
SimpleSocketIOService.shared.reconnectWithNewUserId()
SimpleSocketIOService.shared.emitTestEvent()
```

## 📱 Show Notifications

### Manual Notification
```swift
LocalNotificationManager.shared.showNotificationEvent(
    title: "Title",
    body: "Message"
)
```

### Add In-App Notifications to View
```swift
YourView()
    .withInAppNotifications()
```

## ⚙️ Configuration

### Info.plist (Already Configured)
- ✅ UIBackgroundModes: remote-notification, processing, fetch
- ✅ FirebaseAppDelegateProxyEnabled: false

### Entitlements (Already Configured)
- ✅ aps-environment: development

### Socket.IO Settings
- Server: `https://limortservice.infodevbox.com`
- User Type: `customer`
- Auto-reconnect: Enabled

## 🎯 Common Tasks

### Get User ID
```swift
let userId = StorageManager.shared.getUserIdString()
```

### Get Auth Token
```swift
let token = StorageManager.shared.getAuthToken()
```

### Check Firebase Status
```swift
let isSubscribed = FirebasePushNotificationService.shared.isSubscribed
let fcmToken = FirebasePushNotificationService.shared.fcmToken
```

### Check Socket.IO Status
```swift
let isConnected = SimpleSocketIOService.shared.isConnected
```

## 🐛 Troubleshooting

### Firebase Not Working
1. Check permissions: Settings → Notifications → App
2. Verify entitlements file is configured in Xcode
3. Run: `FirebasePushNotificationService.shared.printDebugInfo()`

### Socket.IO Not Connecting
1. Check user is logged in
2. Verify user ID: `StorageManager.shared.getUserIdString()`
3. Run: `SimpleSocketIOService.shared.debugUserIDStatus()`

### No Notifications Received
1. Grant notification permissions
2. Check Firebase topic subscription
3. Verify Socket.IO is connected
4. Test with FirebaseTestView and SocketIOTestView

## 📋 Testing Checklist

- [ ] Open FirebaseTestView - all green?
- [ ] Open SocketIOTestView - connected?
- [ ] Login - auto-subscribe happens?
- [ ] Send test notification - received?
- [ ] Test in foreground, background, terminated

## 🔗 Key Files

- **AppDelegate**: `Features/Firebase/Services/AppDelegate.swift`
- **Firebase Service**: `Features/Firebase/Services/FirebasePushNotificationService.swift`
- **Socket.IO Service**: `Features/Notification/Services/SimpleSocketIOService.swift`
- **Notification Manager**: `Features/Notification/Services/LocalNotificationManager.swift`

## 📚 Full Documentation

- Firebase Setup: `Features/Firebase/README_FirebaseSetup.md`
- Notification System: `Features/Notification/README.md`
- Complete Setup: `FIREBASE_SOCKETIO_SETUP_COMPLETE.md`

## 🎨 UI Integration

### Navigation to Test Views
```swift
NavigationLink("Test Firebase") {
    FirebaseTestView()
}

NavigationLink("Test Socket.IO") {
    SocketIOTestView()
}
```

### In-App Notification UI
```swift
ContentView()
    .withInAppNotifications()  // Add this modifier
```

## ⚡ Quick Fixes

### Reset Everything
```swift
FirebasePushNotificationService.shared.resetAndReinitialize()
SimpleSocketIOService.shared.reconnectWithNewUserId()
```

### Force Reconnect Socket.IO
```swift
SimpleSocketIOService.shared.disconnect()
DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
    SimpleSocketIOService.shared.connect()
}
```

### Resubscribe to Firebase
```swift
FirebasePushNotificationService.shared.unsubscribeFromUserTopic()
DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
    FirebasePushNotificationService.shared.subscribeToUserTopic()
}
```

## 🔐 Production

Before App Store release:

1. Change entitlements: `development` → `production`
2. Upload APNs certificate to Firebase Console
3. Test on real devices
4. Verify all background modes work

## 📞 Support

Check console logs for:
- `Firebase:` prefix for Firebase logs
- `🔌 Socket.IO` prefix for Socket.IO logs
- Error messages with ❌ prefix
- Success messages with ✅ prefix






