# 1800Limo User App

A premium limousine booking iOS app built with SwiftUI following MVVM architecture.

## 🎨 Design System

### Colors
- **Primary Orange**: `#F3933D` - Main brand color used for buttons and accents
- **Background Gray**: `#F5F5F5` - Text field background color
- **Text Colors**: Black for primary text, gray for secondary text
- **Status Colors**: Green (success), red (error), orange (warning), blue (info)

### Typography
- **Font Family**: SF Pro
- **Font Weight**: Medium (510)
- **Font Size**: 14px for body text
- **Line Height**: 150%
- **Text Transform**: Capitalize for labels and buttons

## 📱 Common Components

### 1. AppColors
Centralized color management for consistent theming.

```swift
// Usage
AppColors.primaryOrange
AppColors.backgroundGray
AppColors.primaryText
AppColors.secondaryText
```

### 2. AppTypography
Typography system with predefined styles and extensions.

```swift
// Text extensions
Text("Hello").appHeading()
Text("Body text").appBodyText()
Text("Label").appLabel()
```

### 3. AppTextField
Custom text field component matching the design specifications.

```swift
AppTextField(
    label: "Enter Your Name",
    placeholder: "eg. Alexa Smith",
    text: $name,
    keyboardType: .default,
    textContentType: .name
)
```

**Features:**
- Label above the field
- Placeholder text
- Background color: `#F5F5F5`
- Border styling
- Support for secure text entry
- Keyboard type customization
- Text content type for auto-fill

### 4. AppButton
Custom button component with multiple styles.

```swift
// Primary button (orange background)
AppButton(
    title: "Add a Card & Sign Up",
    action: { /* action */ }
)

// Secondary button
AppButton(
    title: "Cancel",
    action: { /* action */ },
    buttonStyle: .secondary
)

// Outline button
AppButton(
    title: "Learn More",
    action: { /* action */ },
    buttonStyle: .outline
)
```

**Button Styles:**
- `.primary` - Orange background with white text
- `.secondary` - Gray background with black text
- `.outline` - Transparent background with orange border
- `.danger` - Red background with white text

**Features:**
- Loading state support
- Disabled state
- Rounded corners (pill shape)
- Uppercase text transform

### 5. AppDropdown
Dropdown component that opens just below the field.

```swift
AppDropdown(
    label: "Select Vehicle Type",
    placeholder: "Choose a vehicle",
    options: ["Sedan", "SUV", "Luxury"],
    optionToString: { $0 },
    selectedOption: $selectedVehicle
)
```

**Features:**
- Opens below the field
- Animated expansion/collapse
- Selected state highlighting
- Tap outside to close
- Custom option to string conversion

### 6. AppDialog
Modal dialog component with different types.

```swift
// Success dialog
AppDialog(
    title: "Success!",
    message: "Your booking has been confirmed.",
    primaryButtonTitle: "OK",
    dialogType: .success,
    primaryAction: { /* action */ }
)

// Confirmation dialog
AppDialog(
    title: "Confirm Booking",
    message: "Are you sure?",
    primaryButtonTitle: "Confirm",
    secondaryButtonTitle: "Cancel",
    dialogType: .confirmation,
    primaryAction: { /* confirm */ },
    secondaryAction: { /* cancel */ }
)
```

**Dialog Types:**
- `.info` - Information dialog
- `.success` - Success message
- `.warning` - Warning message
- `.error` - Error message
- `.confirmation` - Confirmation dialog

### 7. AppBottomSheet
Bottom sheet component for additional options.

```swift
.appBottomSheet(
    isPresented: $showBottomSheet,
    title: "Additional Options"
) {
    VStack {
        // Your content here
        AppButton(title: "Confirm", action: {})
    }
}
```

**Features:**
- Drag indicator
- Dismiss on tap outside
- Animated presentation
- Custom content
- Optional title

### 8. AppText
Centralized text component with predefined styles.

```swift
// Different text styles
AppText.largeHeading("Welcome to 1800Limo")
AppText.heading("Book Your Ride")
AppText.title("Vehicle Selection")
AppText.body("Choose from our premium fleet")
AppText.label("Enter Your Name")
AppText.small("Additional information")
AppText.caption("Terms & Conditions")
AppText.button("Book Now")
```

## 🏗️ Architecture

The app follows **MVVM (Model-View-ViewModel)** architecture:

- **Models**: Data structures and business logic
- **Views**: SwiftUI views using common components
- **ViewModels**: Business logic and state management

## 📁 Project Structure

```
1800LimoUserApp/
├── Common/
│   ├── AppColors.swift
│   ├── AppTypography.swift
│   ├── AppTextField.swift
│   ├── AppButton.swift
│   ├── AppDropdown.swift
│   ├── AppDialog.swift
│   ├── AppBottomSheet.swift
│   ├── AppText.swift
│   └── CommonComponentsExample.swift
├── Views/
│   └── ContentView.swift
├── ViewModels/
├── Models/
└── Services/
```

## 🚀 Getting Started

1. Open the project in Xcode
2. Build and run the app
3. The `CommonComponentsExample` view demonstrates all components
4. Use the common components in your own views

## 📝 Usage Guidelines

### Text Fields
- Always provide a descriptive label
- Use appropriate placeholder text
- Set correct keyboard type and text content type
- Use secure text for passwords

### Buttons
- Use primary style for main actions
- Use secondary style for alternative actions
- Use outline style for less important actions
- Use danger style for destructive actions

### Dropdowns
- Provide clear labels and placeholders
- Keep options concise and clear
- Use appropriate option to string conversion

### Dialogs
- Use appropriate dialog type for the context
- Keep messages concise and clear
- Provide clear action button text

### Bottom Sheets
- Use for additional options or secondary actions
- Keep content focused and relevant
- Provide clear dismissal options

## 🎯 Best Practices

1. **Consistency**: Always use the common components for UI elements
2. **Accessibility**: Components include proper accessibility support
3. **Performance**: Components are optimized for SwiftUI performance
4. **Maintainability**: Centralized design system makes updates easy
5. **Reusability**: Components are designed to be reusable across the app

## 🔧 Customization

All components can be customized by modifying the respective files:
- Colors: `AppColors.swift`
- Typography: `AppTypography.swift`
- Component styles: Individual component files

## 📱 Platform Support

- iOS 15.0+
- SwiftUI 3.0+
- Xcode 13.0+

## 🤝 Contributing

When adding new features:
1. Follow the existing component patterns
2. Use the established color and typography system
3. Include proper documentation and previews
4. Test on different device sizes









